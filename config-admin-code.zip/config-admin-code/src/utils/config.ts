import dotenv from 'dotenv'

dotenv.config()

export const config = {
  configurators: {
    scheme: process.env.NEXT_PUBLIC_CONFIGURATORS_SCHEME,
    host: process.env.NEXT_PUBLIC_CONFIGURATORS_HOST,
    port: process.env.NEXT_PUBLIC_CONFIGURATORS_PORT,
    version: process.env.NEXT_PUBLIC_CONFIGURATORS_VERSION,
  },

  ecom: {
    scheme: process.env.NEXT_PUBLIC_ECOM_SCHEME,
    host: process.env.NEXT_PUBLIC_ECOM_HOST,
    port: process.env.NEXT_PUBLIC_ECOM_PORT,
    version: process.env.NEXT_PUBLIC_ECOM_VERSION,
  },
}
