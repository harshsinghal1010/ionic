const Routes = {
  ADMIN_TOOL: 'config-admin-tool',
  DISPLAY_CONFIGURATION: 'display-configuration',
  PRICE_LOGIC: 'price-logic',
  PRICE_LIST: 'price-list'
}

export const ACCESS_TOKEN = '45aa6420-6f7a-11eb-9968-6bfe2628ab28'

export enum ErrorTypes {
  SSO_ERROR = 'ssoError',
  PROFILE_ERROR = 'profileError'
}



export default Routes
