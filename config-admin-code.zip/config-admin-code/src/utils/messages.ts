import { defineMessages } from 'react-intl'

const messages = defineMessages({
  CONFIGURATOR_ADMIN_TOOL: {
    id: 'CONFIGURATOR_ADMIN_TOOL',
    defaultMessage: 'Configurator Admin Tool'
  },
  PRICE_LIST: {
    id: 'PRICE_LIST',
    defaultMessage: 'Price List'
  },
  PRICE_LOGIC: {
    id: 'PRICE_LOGIC',
    defaultMessage: 'Price Logic'
  },
  DISPLAY_CONFIGURATION: {
    id: 'DISPLAY_CONFIGURATION',
    defaultMessage: 'Display Configuration'
  },
  SEARCH_BY_ORDER_NO: {
    id: 'SEARCH_BY_ORDER_NO',
    defaultMessage: 'Search by Order No.'
  },
  ORDER_NUMBER: {
    id: 'ORDER_NUMBER',
    defaultMessage: 'Order Number'
  },
  SEARCH: {
    id: 'SEARCH',
    defaultMessage: 'Search'
  },
  SEARCH_BY_PO_NO: {
    id: 'SEARCH_BY_PO_NO',
    defaultMessage: 'Search by PO No.'
  },
  RESET: {
    id: 'RESET',
    defaultMessage: 'Reset'
  },
  PO_NUMBER: {
    id: 'PO_NUMBER',
    defaultMessage: 'PO Number'
  },
  COUNTRY_CODE: {
    id: 'COUNTRY_CODE',
    defaultMessage: 'Country Code'
  },
  SOLD_TO_NUMBER: {
    id: 'SOLD_TO_NUMBER',
    defaultMessage: 'Sold To Number'
  },
  START_DATE: {
    id: 'START_DATE',
    defaultMessage: 'Start Date'
  },
  END_DATE: {
    id: 'END_DATE',
    defaultMessage: 'End Date'
  },
  COUNTRY_CODE_POPOVER_MSG: {
    id: 'COUNTRY_CODE_POPOVER_MSG',
    defaultMessage:
      'Please provide valid ISD country code. Example: US, IN, GB, JP, AU, NZ'
  },
  SEARCH_BY_CONFIGURATION_ID: {
    id: 'SEARCH_BY_CONFIGURATION_ID',
    defaultMessage: 'Search by Configuration ID'
  },
  SEARCH_BY_ORDER_ITEM_ID: {
    id: 'SEARCH_BY_ORDER_ITEM_ID',
    defaultMessage: 'Search by Order Item ID'
  },
  CONFIGURATION_ID: {
    id: 'CONFIGURATION_ID',
    defaultMessage: 'Configuration ID'
  },
  ORDER_ITEM_ID: {
    id: 'ORDER_ITEM_ID',
    defaultMessage: 'Order Item ID'
  },
  OR: {
    id: 'OR',
    defaultMessage: 'OR'
  },
  SEARCH_RESULTS: {
    id: 'SEARCH_RESULTS',
    defaultMessage: 'Search Results'
  },
  COMMENTS: {
    id: 'COMMENTS',
    defaultMessage: 'Comments'
  },
  SHIPPING: {
    id: 'SHIPPING',
    defaultMessage: 'Shipping'
  },
  PRODUCT_TYPE: {
    id: 'PRODUCT_TYPE',
    defaultMessage: 'Product Type'
  },
  PURIFICATION: {
    id: 'PURIFICATION',
    defaultMessage: 'Purification'
  },
  OLIGO_ID: {
    id: 'OLIGO_ID',
    defaultMessage: 'Oligo ID'
  },
  TECHNOCAL_SEQUENCE: {
    id: 'TECHNOCAL_SEQUENCE',
    defaultMessage: 'Technical Sequence'
  },
  CONCENTRATION: {
    id: 'CONCENTRATION',
    defaultMessage: 'Concentration'
  },
  MATERIAL: {
    id: 'MATERIAL',
    defaultMessage: 'Material'
  },
  SYNTHESIS_SCALE: {
    id: 'SYNTHESIS_SCALE',
    defaultMessage: 'Synthesis Scale'
  },
  MELTING_TEMP: {
    id: 'MELTING_TEMP',
    defaultMessage: 'Melting Temp (A℃)'
  },
  SEQUENCE: {
    id: 'SEQUENCE',
    defaultMessage: 'Sequence'
  },
  TYPE_CODE: {
    id: 'TYPE_CODE',
    defaultMessage: 'Type Code'
  },
  NUMBER_OF_TUBE_PER_OLIGO: {
    id: 'NUMBER_OF_TUBE_PER_OLIGO',
    defaultMessage: 'Number of Tubes per Oligo'
  },
  NAME: {
    id: 'NAME',
    defaultMessage: 'Name'
  },
  ID: {
    id: 'ID',
    defaultMessage: 'ID'
  },
  FORMAT: {
    id: 'FORMAT',
    defaultMessage: 'Format'
  },
  SO_QUOTE_NUMBER: {
    id: 'SO_QUOTE_NUMBER',
    defaultMessage: 'SO/Quote Number'
  },
  TYPE: {
    id: 'TYPE',
    defaultMessage: 'Type'
  },
  Sales_ORG: {
    id: 'Sales_ORG',
    defaultMessage: 'Sales Org'
  },
  SOLD_TO: {
    id: 'SOLD_TO',
    defaultMessage: 'Sold To'
  },
  SHIP_TO: {
    id: 'SHIP_TO',
    defaultMessage: 'Ship To'
  },
  BILL_TO: {
    id: 'BILL_TO',
    defaultMessage: 'Bill To'
  },
  PAYER: {
    id: 'PAYER',
    defaultMessage: 'Payer'
  },
  DATE_CREATED: {
    id: 'DATE_CREATED',
    defaultMessage: 'Date Created'
  },
  SO_QUOTE_STATUS: {
    id: 'SO_QUOTE_STATUS',
    defaultMessage: 'SO/Quote Status'
  },
  OLIGO_NAME: {
    id: 'OLIGO_NAME',
    defaultMessage: 'Oligo Name'
  },
  TOTAL_PRICE: {
    id: 'TOTAL_PRICE',
    defaultMessage: 'Total Price'
  },
  CONFIGURATION: {
    id: 'CONFIGURATION',
    defaultMessage: 'Configuration'
  },
  SPECIFICATION: {
    id: 'SPECIFICATION',
    defaultMessage: 'Specification'
  },
  DISCOUNT_PRICE: {
    id: 'DISCOUNT_PRICE',
    defaultMessage: 'List / Discount Price'
  },
  PRICE: {
    id: 'PRICE',
    defaultMessage: 'Price'
  },
  PRICE_LOGIC_NO_RESULT_FOUND: {
    id: 'PRICE_LOGIC_NO_RESULT_FOUND',
    defaultMessage: `Sorry, we couldn't find any matches. Please try again or search by different ID.`
  },
  INVALID_DATA: {
    id: 'INVALID_DATA',
    defaultMessage: 'Invalid data'
  },
  INVALID_ORDER_NUMBER: {
    id: 'INVALID_ORDER_NUMBER',
    defaultMessage: 'Please enter a valid Order Number.'
  },
  INVALID_PO_NUMBER: {
    id: 'INVALID_PO_NUMBER',
    defaultMessage: 'Please enter a valid PO Number.'
  },
  SHIP_TO_NUMBER: {
    id: 'SHIP_TO_NUMBER',
    defaultMessage: 'Ship To Number'
  },
  BILL_TO_NUMBER: {
    id: 'BILL_TO_NUMBER',
    defaultMessage: 'Bill To Number'
  },
  PAYER_NUMBER: {
    id: 'PAYER_NUMBER',
    defaultMessage: 'Payer Number'
  },
  DOWNLOAD: {
    id: 'DOWNLOAD',
    defaultMessage: 'Download'
  },
  PRICE_LIST_TOOLTIP_MESSAGE_SOLD_TO: {
    id: 'PRICE_LIST_TOOLTIP_MESSAGE_SOLD_TO',
    defaultMessage:
      'Please provide the Sold To here. To download List Price, leave Sold To & Ship To text boxes empty'
  },
  PRICE_LIST_TOOLTIP_MESSAGE_SHIP_TO: {
    id: 'PRICE_LIST_TOOLTIP_MESSAGE_SHIP_TO',
    defaultMessage:
      'Please provide the Ship To here. To download List Price, leave Sold To & Ship To text boxes empty'
  },
  PRICE_LIST_TOOLTIP_MESSAGE_BILL_TO: {
    id: 'PRICE_LIST_TOOLTIP_MESSAGE_BILL_TO',
    defaultMessage:
      'Please provide the BIll To here. To download List Price, leave Bill To & Payer text boxes empty'
  },
  PRICE_LIST_TOOLTIP_MESSAGE_PAYER: {
    id: 'PRICE_LIST_TOOLTIP_MESSAGE_PAYER',
    defaultMessage:
      'Please provide the Ship To here. To download List Price, leave Payer & Bill To text boxes empty'
  },
  PRICE_LIST_SEARCH: {
    id: 'PRICE_LIST_SEARCH',
    defaultMessage: 'Price List Search'
  },
  PRICE_LIST_DOWNLOAD_DESC: {
    id: 'PRICE_LIST_DOWNLOAD_DESC',
    defaultMessage:
      'Please enter a Country Code and leave other fields blank to download specifc List Price.'
  },
  DISPLAY_CONFIGURATION_NO_RESULT_FOUND: {
    id: 'DISPLAY_CONFIGURATION_NO_RESULT_FOUND',
    defaultMessage: `Sorry, we couldn't find any matches. Please try again or search by different ID.`
  },
  PRICE_LIST_NO_RESULT_FOUND: {
    id: 'PRICE_LIST_NO_RESULT_FOUND',
    defaultMessage: `No discounted prices found for this account. List price is active.`
  },
  ORDER_ID: {
    id: 'ORDER_ID',
    defaultMessage: 'Order ID'
  },
  USERNAME: {
    id: 'USERNAME',
    defaultMessage: 'Username'
  },
  PASSWORD: {
    id: 'PASSWORD',
    defaultMessage: 'Password'
  },
  WELCOME: {
    id: 'WELCOME',
    defaultMessage: 'Welcome!'
  }
})

export default messages
