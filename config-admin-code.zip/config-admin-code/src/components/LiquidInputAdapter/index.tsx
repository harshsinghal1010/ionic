import LiquidInputAdapter from './LiquidInputAdapter'

export default LiquidInputAdapter
