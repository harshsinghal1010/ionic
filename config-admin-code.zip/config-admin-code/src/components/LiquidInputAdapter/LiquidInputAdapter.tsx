import React, { ReactNode, CSSProperties } from 'react'
import clsx from 'clsx'
import { FieldProps, getIn } from 'formik'
import LiquidInput from '../LiquidInput'
import { LiquidInputProps } from '../LiquidInput/LiquidInput'
import LiquidFormLabel from '../LiquidFormLabel'
import LiquidFormHelpText from '../LiquidFormHelpText'

interface LiquidInputAdapterProps extends FieldProps, LiquidInputProps {
  rootClass?: string
  rootStyle?: CSSProperties
  label?: ReactNode
  required?: boolean
  help?: ReactNode
}

const LiquidInputAdapter: React.FC<LiquidInputAdapterProps> = ({
  rootClass,
  rootStyle,
  size = 'medium',
  field,
  form,
  label,
  required,
  help,
  ...otherProps
}) => {
  const error = getIn(form.errors, field.name)
  const touched = getIn(form.touched, field.name)
  const hasError = error && touched

  return (
    <div
      className={clsx({
        [String(rootClass)]: rootClass
      })}
      style={rootStyle}
    >
      {label && (
        <LiquidFormLabel htmlFor={field.name} size={size} required={required}>
          {label}
        </LiquidFormLabel>
      )}
      <LiquidInput
        id={field.name}
        {...field}
        size={size}
        error={Boolean(hasError)}
        aria-describedby={(hasError || help) && `${field.name}-help-text`}
        {...otherProps}
      />
      {(hasError || help) && (
        <LiquidFormHelpText
          id={`${field.name}-help-text`}
          error={Boolean(hasError)}
        >
          {hasError ? error : help ? help : null}
        </LiquidFormHelpText>
      )}
    </div>
  )
}

export default LiquidInputAdapter
