import LiquidFormLabel from './LiquidFormLabel'

export default LiquidFormLabel
