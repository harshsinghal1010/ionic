import React, { ReactNode, CSSProperties } from 'react'
import clsx from 'clsx'
import { makeStyles, createStyles } from '@material-ui/core/styles'
import { Theme } from '@material-ui/core'
import FormLabel from '@material-ui/core/FormLabel'

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    label: {
      fontSize: theme.typography.pxToRem(13),
      color: theme.palette.text.primary,
      margin: theme.spacing(0, 0, 2),
      display: 'block'
    },
    labelSmall: {
      fontSize: theme.typography.pxToRem(12)
    },
    labelLarge: {
      fontSize: theme.typography.pxToRem(14),
      margin: theme.spacing(0, 0, 3, 1)
    }
  })
)

interface LiquidFormLabelProps {
  size?: 'small' | 'medium' | 'large'
  children: ReactNode
  required?: boolean
  className?: string
  style?: CSSProperties
  htmlFor?: string
}

const LiquidFormLabel: React.FC<LiquidFormLabelProps> = ({
  size = 'medium',
  children,
  required,
  className,
  style,
  htmlFor,
  ...other
}) => {
  const classes = useStyles()

  return (
    <FormLabel
      classes={{
        root: clsx(
          classes.label,
          size === 'small' && classes.labelSmall,
          size === 'large' && classes.labelLarge
        )
      }}
      required={required}
      className={className}
      style={style}
      htmlFor={htmlFor}
      {...other}
    >
      {children}
    </FormLabel>
  )
}

export default LiquidFormLabel
