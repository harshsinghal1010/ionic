import React, { ReactNode, CSSProperties } from 'react'
import { makeStyles, createStyles } from '@material-ui/core/styles'
import { Theme } from '@material-ui/core'
import FormHelperText from '@material-ui/core/FormHelperText'
import ErrorIcon from '@material-ui/icons/Error'

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      color: theme.palette.grey[800],
      margin: theme.spacing(1, 0, 0)
    },
    error: {
      marginBottom: -theme.spacing(3)
    },
    errorIcon: {
      height: 16,
      marginTop: theme.spacing(0.5)
    },
    displayErrorData: {
      display: 'flex'
    }
  })
)

interface LiquidFormHelpTextProps {
  children: ReactNode
  error?: boolean
  className?: string
  style?: CSSProperties
  id?: string
}

const LiquidFormHelpText: React.FC<LiquidFormHelpTextProps> = ({
  children,
  error,
  className,
  style,
  id
}) => {
  const classes = useStyles()

  return (
    <FormHelperText
      id={id}
      classes={{ root: classes.root, error: classes.error }}
      error={error}
      className={className}
      style={style}
    >
      <div className={classes.displayErrorData}>
        <ErrorIcon fontSize="small" className={classes.errorIcon} />
        <span>{children}</span>
      </div>
    </FormHelperText>
  )
}

export default LiquidFormHelpText
