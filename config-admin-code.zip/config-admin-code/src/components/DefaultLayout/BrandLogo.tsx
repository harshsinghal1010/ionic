import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import CompanyLogo from './CompanyLogo'
const useStyles = makeStyles(() => ({
  link: {
    display: 'flex',
    alignItems: 'center',
  },
  logo: {
    height: 32,
    width: 124,
  },
}))

const BrandLogo: React.FC<{}> = () => {
  const classes = useStyles()
  return (
    // <Link to={Routes.Home} className={classes.link}>
    <div className={classes.logo}>
      <CompanyLogo />
    </div>
    // </Link>
  )
}

export default BrandLogo
