import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import Header from './Header'

const useStyles = makeStyles(() => ({
  wrapper: {
    minHeight: '100%',
    display: 'flex',
    flexDirection: 'column'
  },
  body: {
    display: 'flex',
    flex: 1,
    paddingTop: 112,
    paddingBottom: 48,
    backgroundColor: '#fff'
  }
}))

interface Props {
  children: React.ReactNode
}

const DefaultLayout: React.FC<Props> = ({ children }) => {
  const classes = useStyles()
  return (
    <div className={classes.wrapper}>
      <Header />
      <div className={classes.body}>{children}</div>
    </div>
  )
}

export default DefaultLayout
