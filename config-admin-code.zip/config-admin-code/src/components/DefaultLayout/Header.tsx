import React from 'react'
import clsx from 'clsx'
import { makeStyles } from '@material-ui/core/styles'
import BrandLogo from './BrandLogo'
import { Theme } from '@material-ui/core/'

const useStyles = makeStyles((theme: Theme) => ({
  wrapper: {
    height: 64,
    position: 'fixed',
    left: 0,
    right: 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: theme.spacing(0, 10),
    backgroundColor: '#fff',
    borderBottom: `1px solid ${theme.palette.grey[300]}`,
    zIndex: 10,
    boxShadow: '0 0 4px rgba(0, 0, 0, 0.12)',
  },
  accountIcon: {
    fontSize: theme.typography.pxToRem(28),
  },
}))

const Header: React.FC<{}> = () => {
  const classes = useStyles()

  return (
    <div className={clsx(classes.wrapper, 'mui-fixed')}>
      <BrandLogo />
    </div>
  )
}

export default Header
