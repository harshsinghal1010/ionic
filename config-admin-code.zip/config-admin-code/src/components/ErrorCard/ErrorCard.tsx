import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import { FormattedMessage } from 'react-intl'
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline'
import { Card, Theme } from '@material-ui/core'

const useStyles = makeStyles((theme: Theme) => ({
  wrapper: {
    textAlign: 'center',
    padding: theme.spacing(6, 4, 8, 4)
  },
  errorCardIcon: {
    fontSize: theme.typography.pxToRem(60),
    color: theme.palette.grey[500]
  },
  errorCardMessage: {
    fontSize: theme.typography.h6.fontSize,
    marginTop: theme.spacing(2)
  }
}))

interface Props {
  message?: React.ReactNode
}

const ErrorCard: React.FC<Props> = ({
  message = (
    <FormattedMessage
      id="UNEXPECTED_ERROR"
      defaultMessage="Sorry, an unexpected error has occurred."
    />
  )
}) => {
  const classes = useStyles()
  return (
    <Card className={classes.wrapper}>
      <div>
        <ErrorOutlineIcon className={classes.errorCardIcon} />
      </div>
      <div className={classes.errorCardMessage}>{message}</div>
    </Card>
  )
}

export default ErrorCard
