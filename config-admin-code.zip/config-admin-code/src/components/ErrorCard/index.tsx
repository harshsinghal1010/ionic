export { default } from './ErrorCard'
