import React from 'react'
import clsx from 'clsx'
import InputBase, { InputBaseProps } from '@material-ui/core/InputBase'
import { makeStyles, createStyles } from '@material-ui/core/styles'
import { Theme } from '@material-ui/core'

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      fontSize: theme.typography.pxToRem(13),
      borderRadius: theme.shape.borderRadius,
      backgroundColor: theme.palette.common.white,
      border: `1px solid ${theme.palette.grey[300]}`,
      transition: 'all .3s',
      '&:hover:not($disabled)': {
        border: `1px solid ${theme.palette.primary.main}`
      },
      '&$error': {
        border: `1px solid ${theme.palette.error.main}`,
        '&:hover': { border: `1px solid ${theme.palette.error.main}` },
        '&$focused': { border: `1px solid ${theme.palette.error.main}` }
      }
    },
    input: {
      height: 38,
      boxSizing: 'border-box',
      padding: '4px 12px 6px',
      borderRadius: theme.shape.borderRadius,
      // Todo: investiate this hack for noto-sans
      '&[type=password]': {
        fontFamily: 'sans-serif',
        fontSize: 16,
        letterSpacing: 1,
        padding: '8px 12px 6px'
      }
    },
    focused: {
      border: `1px solid ${theme.palette.primary.main}`
    },
    filled: {
      backgroundColor: '#f3f3f7',
      border: `1px solid #f3f3f7`,
      '&$focused': {
        border: `1px solid ${theme.palette.primary.main}`
      }
    },
    inputSmall: { height: 34 },
    inputLarge: { fontSize: theme.typography.pxToRem(14), height: 46 },
    multiline: { height: 'auto' },
    disabled: {},
    error: {}
  })
)

export interface LiquidInputProps extends InputBaseProps {
  filled?: boolean
  size?: 'small' | 'medium' | 'large'
  placeholder?: string
  fullWidth?: boolean
  error?: boolean
  inputClass?: string
}

const LiquidInput: React.FC<LiquidInputProps> = ({
  filled = false,
  size = 'medium',
  placeholder,
  fullWidth = true,
  error,
  inputClass,
  multiline,
  ...otherProps
}) => {
  const classes = useStyles()

  return (
    <InputBase
      classes={{
        root: clsx(classes.root, filled && classes.filled),
        input: clsx(
          classes.input,
          size === 'small' && classes.inputSmall,
          size === 'large' && classes.inputLarge,
          multiline && classes.multiline,
          inputClass && inputClass
        ),
        focused: classes.focused,
        error: classes.error,
        disabled: classes.disabled
      }}
      placeholder={placeholder}
      fullWidth={fullWidth}
      error={error}
      multiline={multiline}
      {...otherProps}
    />
  )
}

export default LiquidInput
