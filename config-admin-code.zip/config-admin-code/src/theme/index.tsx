import { createMuiTheme } from '@material-ui/core/styles'

const fontFamily = "'Lato', 'Helvetica', 'Arial', sans-serif"

export default createMuiTheme({
  palette: {
    primary: {
      main: '#0F69AF'
    },
    secondary: {
      main: '#2dbecd'
    },
    error: {
      main: '#e61e50'
    }
  },
  typography: {
    fontFamily: fontFamily,
    fontWeightMedium: 700,
    fontWeightBold: 900
  },
  spacing: 4,
  overrides: {
    MuiCssBaseline: {
      '@global': {
        html: {
          height: '100%'
        },
        body: {
          height: '100%',
          fontFamily: fontFamily,
          margin: 0,
          backgroundColor: '#fff'
        },
        '#root': {
          height: '100%'
        },
        a: {
          color: 'inherit',
          textDecoration: 'none'
        }
      }
    },
    MuiInputBase: {
      input: {
        boxSizing: 'border-box'
      }
    },
    MuiButtonBase: {
      root: {
        fontFamily: fontFamily
      }
    },
    MuiMenuItem: {
      root: {
        minHeight: 36,
        fontSize: '0.875rem'
      }
    }
  },
  props: {
    MuiLink: {
      underline: 'none'
    }
  }
})
