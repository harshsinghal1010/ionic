import { makeStyles, Theme } from '@material-ui/core/styles'

const useStyles = makeStyles((theme: Theme) => ({
  sideNavWidth: {
    width: 230,
  },
  title: {
    fontSize: theme.typography.pxToRem(28),
    fontWeight: theme.typography.fontWeightBold,
    marginBottom: theme.spacing(6),
    fontFamily: 'Helvetica,sans-serif',
  },
  boxCss: {
    border: `${theme.spacing(0.25)}px solid #949494`,
    width: 980,
    margin: '0px 0px 0px 20px',
    padding: '32px 30px 32px 40px',
    height: 400,
    overflow: 'auto',
    backgroundColor: theme.palette.common.white,
  },
  priceLogicSearchBox: {
    border: `${theme.spacing(0.25)}px solid #949494`,
    width: 980,
    height: 'fit-content',
    margin: '0px 0px 0px 20px',
    padding: '32px 30px 32px 20px',
    backgroundColor: theme.palette.common.white,
  },
  divider_vertical: {
    width: 1,
    height: `5rem`,
    position: `absolute`,
    right: '35rem',
    backgroundColor: '#f1f1f1',
  },
  OR_CSS: {
    position: 'absolute',
    left: -8,
    marginTop: 5,
  },
  bottom9: {
    top: '21rem',
  },
  placeholder: {
    '& ::-webkit-input-placeholder': {
      color: '#949494',
    },
  },
  calender: {
    '& ::-webkit-calendar-picker-indicator': {
      filter:
        'invert(29%) sepia(87%) saturate(1073%) hue-rotate(178deg) brightness(95%) contrast(91%)',
    },
  },
  table: {
    width: 932,
  },
  panelBorder: {
    borderRight: '1px solid #c9c9c9',
    borderTop: '1px solid #c9c9c9',
    borderBottom: '1px solid #c9c9c9',
  },
  panelPriceBorder: {
    borderTop: '1px solid #c9c9c9',
    borderBottom: '1px solid #c9c9c9',
  },
  borderBottom: {
    borderBottom: '1px solid #949494',
  },
  whiteColor: {
    backgroundColor: theme.palette.common.white,
  },
  dividerColor: {
    backgroundColor: '#c9c9c9',
  },
  fieldWidth: {
    width: 330,
  },
  dividerWidth: {
    width: 1,
  },
  dividerHeight: {
    height: 134,
  },
  dividerHeight100: {
    height: 100,
  },
  font18: {
    fontSize: 18,
  },
  fontWeight900: {
    fontWeight: 900,
  },
  headingCss: {
    fontSize: 18,
    fontWeight: 900,
    fontStretch: 'normal',
    fontStyle: 'normal',
    lineHeight: '1.22',
    letterSpacing: '0.18px',
    textAlign: 'left',
    color: theme.palette.common.black,
  },
  headingFont14: {
    fontSize: 14,
    fontWeight: 900,
    fontStretch: 'normal',
    fontStyle: 'normal',
    lineHeight: '1.43',
    letterSpacing: 'normal',
    textAlign: 'left',
    color: theme.palette.common.black,
  },
  normalFont: {
    fontSize: 12,
    fontStretch: 'normal',
    fontStyle: 'normal',
    lineHeight: '1.25',
    letterSpacing: 'normal',
    textAlign: 'left',
  },
  InfoIcon: {
    position: 'relative',
    fontSize: theme.typography.pxToRem(16),
    top: theme.spacing(0.5),
    marginLeft: theme.spacing(1.5),
  },
  arrowColor: {
    color: theme.palette.common.white,
  },
  InfoPopup: {
    maxWidth: theme.spacing(65),
    backgroundColor: theme.palette.common.white,
    position: 'relative',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(5),
    fontSize: theme.typography.pxToRem(12),
    color: theme.palette.common.black,
    borderRadius: '2%',
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
  },
  paddingTop5: {
    paddingTop: theme.spacing(1.25),
  },
  marginTop4: {
    marginTop: theme.spacing(4),
  },
  marginTop3: {
    marginTop: theme.spacing(3),
  },
  marginTop6: {
    marginTop: theme.spacing(6),
  },
  marginLeft2: {
    marginLeft: theme.spacing(-2),
  },
  marginLeft20: {
    marginLeft: theme.spacing(5),
  },
  marginBottom4: {
    marginBottom: theme.spacing(4),
  },
  marginBottom3: {
    marginBottom: theme.spacing(3),
  },
  marginRight7: {
    marginRight: theme.spacing(7),
  },
  greyColor: {
    color: '#949494',
  },
  Button: {
    textTransform: 'none',
    paddingLeft: theme.spacing(10),
    paddingRight: theme.spacing(10),
    marginTop: theme.spacing(3),
  },
  AccordionSummary: {
    fontSize: theme.typography.pxToRem(12),
    fontWeight: theme.typography.fontWeightBold,
    marginTop: 3,
    display: 'flex',
    justifyContent: 'space-between',
    width: '100%',
  },
  PriceListBox: {
    border: `${theme.spacing(0.25)}px solid #949494`,
    width: 980,
    margin: '0px 0px 0px 20px',
    padding: '32px 30px 32px 40px',
    backgroundColor: 'white',
  },
  BorderTop: {
    borderTop: '1px solid #000',
  },
  displayConfiguratorBox: {
    border: `${theme.spacing(0.25)}px solid #949494`,
    width: 980,
    height: 350,
    margin: '0px 0px 0px 20px',
    padding: '32px 30px 32px 40px',
    backgroundColor: 'white',
  },
  displayConfiguratorSearchBox: {
    border: `${theme.spacing(0.25)}px solid #949494`,
    width: 980,
    height: 'fit-content',
    margin: '80px 0px 0px 20px',
    padding: '32px 30px 32px 20px',
    backgroundColor: 'white',
  },
  height30: {
    height: ' 30px !important',
  },
  width200: {
    width: 200,
    border: `${theme.spacing(0.25)}px solid #949494`,
  },
  width20: {
    width: 20,
  },
  widthPriceListPanel: {
    width: 315,
    border: `${theme.spacing(0.25)}px solid #949494`,
  },
  widthListData: {
    width: 150,
    border: `${theme.spacing(0.25)}px solid #949494`,
  },
  textAlignCenter: {
    textAlign: 'center',
  },
  blueColor: {
    color: theme.palette.primary.main,
  },
  fontWeight700: {
    fontWeight: 700,
  },
  errorField: {
    fontWeight: 700,
    color: theme.palette.error.main,
  },
  noPadding: {
    padding: 0,
  },
  sideBarDivider: {
    width: 224,
    height: 1,
    marginLeft: 6,
    marginBottom: 12,
    backgroundColor: '#949494',
  },
  buttonSize: {
    width: 120,
    height: 36,
  },
  loginBox: {
    backgroundColor: theme.palette.common.white,
    borderRadius: theme.spacing(1.5),
    padding: '28px 44px 64px',
    boxShadow: '0 2px 10px 2px rgba(0, 0, 0, 0.2)',
  },
  loginPage: {
    padding: '28px 44px 64px',
    display: 'flex',
    flexDirection: 'column',
    position: 'relative',
    height: '100%',
    width: '100%',
    backgroundColor: '#503291',
  },
  loginLogo: {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    height: '148px',
    width: '148px',
    padding: '28px',
    backgroundColor: '#2dbecd',
    borderRadius: '50%',
    marginBottom: '4px',
    marginTop: 148
  },
  width100: {
    width: '100%',
  },
  height100: {
    height: '100%',
  },
  textDescription: {
    fontSize: theme.typography.pxToRem(24),
    fontWeight: 400,
    marginTop: theme.spacing(7),
    letterSpacing: -0.7,
    color: theme.palette.common.white,
  },
  logoPosition: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
  },
  alignCenter: {
    alignItems: 'center',
  },
  loginHeading: {
    fontSize: theme.typography.pxToRem(40),
    fontWeight: 900,
    fontFamily:
      'BlinkMacSystemFont,Segoe UI,Roboto,Oxygen-Sans,Ubuntu,Cantarell,Helvetica Neue,sans-serif',
  },
  loginError: {
    display: 'inline-block',
    fontSize: theme.typography.pxToRem(13),
    border: `1px solid ${theme.palette.error.main}`,
    borderRadius: 2,
    color: theme.palette.error.main,
    padding: '10px 16px',
    marginTop: theme.spacing(6),
    marginBottom: theme.spacing(-2),
  },
  titleCenter: {
    margin: 'auto',
    height: '100%',
    width: '100%',
    backgroundColor: '#503291',
    position: 'fixed',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  marginAuto: {
    margin: 'auto',
  },
}))

export default useStyles
