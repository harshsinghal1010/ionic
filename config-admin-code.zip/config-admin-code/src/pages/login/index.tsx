import React from 'react'
import Head from 'next/head'
import { useLazyQuery } from '@apollo/client'
import getAuthUrl from '@src/graphql/query/getAuthUrl'

const LoginPage: React.FC = () => {
  const [getAuthURL, { data: authURL }] = useLazyQuery(getAuthUrl, {
    fetchPolicy: 'no-cache',
  })
  const handleLoginSubmit = async (host,scheme) => {
    const redirectURL = `${window.location.origin}/auth/openid/return`
    const URL = `${scheme}://${host}/auth/v1/oauth2/authorize?redirect_uri=${redirectURL}`
    await window.location.replace(URL)
  }

  React.useEffect(() => {
   if(authURL){
    const {host,scheme} = authURL.getAuthURL
    handleLoginSubmit(host,scheme)
   }
  }, [authURL])
  React.useEffect(() => {
    getAuthURL()
  }, [])
  return (
    <React.Fragment>
      <Head>
        <title>Configurator Admin Tool | Login</title>
      </Head>
    </React.Fragment>
  )
}

export default LoginPage
