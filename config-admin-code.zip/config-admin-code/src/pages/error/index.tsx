import React from 'react'
import Head from 'next/head'
import DefaultLayout from '../../components/DefaultLayout'
import useStyles from '@src/theme/style'
import { useRouter as useNextRouter } from 'next/router'
import { ErrorTypes } from '../../utils/Constants'

const ErrorMessages = {
  sso: 'We are sorry, we are experiencing some technical difficulties in fulfilling your request. Please try again in some time.',
  profile:
    'Your profile is not assigned access to the internal apps maintained through this portal. Please contact the Web Help desk if you believe this is incorrect.',
}

const checkError = (key) => {
  switch (key) {
    case ErrorTypes.SSO_ERROR:
      return ErrorMessages.sso
    case ErrorTypes.PROFILE_ERROR:
      return ErrorMessages.profile
    default:
      return ErrorMessages.profile
  }
}

const ErrorPage: React.FC = () => {
  const classes = useStyles()
  const router = useNextRouter()
  const { type } = router.query
  return (
    <React.Fragment>
      <Head>
        <title>Configurator Admin Tool</title>
      </Head>
      <DefaultLayout>
        <span className={classes.marginAuto}>{checkError(type)}</span>
      </DefaultLayout>
    </React.Fragment>
  )
}

export default ErrorPage
