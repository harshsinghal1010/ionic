import '../styles/globals.css'
import { ApolloProvider } from '@apollo/client'
import client from '../lib/apolloClient'
import {
  StylesProvider,
  ThemeProvider as MuiThemeProvider,
} from '@material-ui/styles'
import CssBaseline from '@material-ui/core/CssBaseline'
import { IntlProvider } from 'react-intl'
import theme from '../theme'
import React from 'react'

function MyApp({ Component, pageProps }) {

  React.useEffect(() => {
    if (document) {
      const jssStyles = document.querySelector('#jss-server-side')
      if (jssStyles && jssStyles.parentNode) {
        jssStyles.parentNode.removeChild(jssStyles)
      }
    }
  }, [])

  return (
    <ApolloProvider client={client}>
      <React.Fragment>
        <div >
          <StylesProvider injectFirst>
            <MuiThemeProvider theme={theme}>
              <IntlProvider locale="en">
                <CssBaseline />
                <Component {...pageProps} />
              </IntlProvider>
            </MuiThemeProvider>
          </StylesProvider>
        </div>
      </React.Fragment>
    </ApolloProvider>
  )
}

export default MyApp
