import React, {useState} from 'react'
import useStyles from '@src/theme/style'
import clsx from 'clsx'
import Image from 'next/image'
import { useRouter } from 'next/router'

const IndexPage = () => {
  const classes = useStyles()
  const router = useRouter()
  const [loaded,setLoaded] = useState(false)
  React.useEffect(() => {
    if(router.pathname === '/'){
      if (!sessionStorage.getItem('access_token')) {
        router.push('/login')
      }
      else {
        router.push('/config-admin-tool/price-logic')
      }
    }
    else {
      setLoaded(true)
    }
  }, [])
  if(!loaded){
    return <></> //show nothing or a loader
  }
  return (
    <div className={clsx(classes.titleCenter)}>
      <center>
        <div className={classes.loginLogo}>
          <a href="/config-admin-tool/price-logic">
            <Image alt="merckLogo" src="/merckLogo.png" height={'105px'} width={'213px'}/>
          </a>
        </div>
        <div className={clsx(classes.title)}>
          <span className={clsx(classes.arrowColor)}>
            Welcome to Configurator Admin Tool
          </span>
        </div>
      </center>
    </div>
  )
}

export default IndexPage
