import React from 'react'
import Head from 'next/head'
import DefaultLayout from '../../../components/DefaultLayout'
import AdminTool from '../../../routes/AdminTool/AdminTool'
import { sessionStorage } from 'react-storage'
import { useRouter } from 'next/router'

const AdminToolPage: React.FC = () => {
  const router = useRouter()
  const { page = '' } = router ? router.query : {}
  React.useEffect(() => {
    if(page){
      sessionStorage.setItem('page', page)
      if (!sessionStorage.getItem('access_token')) {
        router.push('/login')
      }
    }
   
  }, [page])

  return (
    <React.Fragment>
      <Head>
        <title>Configurator Admin Tool</title>
      </Head>

      <DefaultLayout>
        <AdminTool />
      </DefaultLayout>
    </React.Fragment>
  )
}

export default AdminToolPage
