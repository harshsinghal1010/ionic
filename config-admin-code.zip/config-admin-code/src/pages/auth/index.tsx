import React from 'react'
import Head from 'next/head'
import { useRouter as useNextRouter } from 'next/router'
import { useLazyQuery } from '@apollo/client'
import getBearerToken from '@src/graphql/query/GetBearerToken'
import getInternalMetadata from '@src/graphql/query/getInternalMetadata'
import { sessionStorage } from 'react-storage'

const AuthPage: React.FC = () => {
  const router = useNextRouter()
  const {
    code = '',
    state = '',
    session_state = '',
  } = router ? router.query : {}
  const [GetBearerToken, { data }] = useLazyQuery(getBearerToken, {
    fetchPolicy: 'no-cache',
  })
  const [GetInternalMetadata, { data: metaData }] = useLazyQuery(
    getInternalMetadata,
    {
      fetchPolicy: 'no-cache',
    }
  )

  const handleAuthRequest = () => {
    if (session_state && state && code)
      GetBearerToken({
        variables: {
          code: code,
          state: state,
          session_state: session_state,
        },
      })
  }

  React.useEffect(() => {
    if (metaData && metaData.getMetadata) {
      const { appMetaDataList } = metaData.getMetadata
      if (appMetaDataList && appMetaDataList.length > 0) {
        const isValid = appMetaDataList.some(
          (data) => data.contextPath === '/config-admin-tool'
        )
        if (isValid) {
          const { altPersonas } = appMetaDataList[0]
          const { userId } = altPersonas[0]
          if (userId) {
            sessionStorage.setItem('userId', userId)
            const page = sessionStorage.getItem('page')
            if (page) {
              router.push(`/config-admin-tool/${page}`)
            } else {
              router.push('/config-admin-tool/price-logic')
            }
          }
        } else {
          sessionStorage.removeItem('access_token')
          sessionStorage.removeItem('userId')
          router.push('/error')
        }
      } else {
        sessionStorage.removeItem('access_token')
        sessionStorage.removeItem('userId')
        router.push('/error')
      }
    }
  }, [metaData])

  React.useEffect(() => {
    if (data) {
      if (data.getBearerToken) {
        const { access_token } = data.getBearerToken
        if (access_token) {
          sessionStorage.setItem('access_token', access_token)
          GetInternalMetadata({
            variables: {
              token: access_token,
            },
          })
        } else {
          sessionStorage.removeItem('access_token')
          sessionStorage.removeItem('userId')
          router.push('/')
        }
      } else {
        sessionStorage.removeItem('access_token')
        sessionStorage.removeItem('userId')
        router.push('/error?type=ssoError')
      }
    }
  }, [data])

  React.useEffect(() => {
    if (session_state) {
      handleAuthRequest()
    }
  }, [session_state])

  return (
    <React.Fragment>
      <Head>
        <title>Configurator Admin Tool</title>
      </Head>
    </React.Fragment>
  )
}

export default AuthPage
