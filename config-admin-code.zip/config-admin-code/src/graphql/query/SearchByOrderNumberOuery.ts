import { gql } from '@apollo/client'

const SEARCH_BY_ORDER_NUMBER_QUERY = gql`query GetSearchByOderNumber ($orderNumber: String){
    getSearchByOrderNumber(orderNumber: $orderNumber){
      result
    }
  }
`

export default SEARCH_BY_ORDER_NUMBER_QUERY
