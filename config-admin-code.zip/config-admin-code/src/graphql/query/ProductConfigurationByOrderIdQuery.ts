import { gql } from '@apollo/client'

const PRODUCT_CONFIGURATION_BY_ORDER_ID = gql`
query getProductConfigurationByCartId($cartId: String,$cartItemId: String $accessToken: String, $userId: String){
  getProductConfigurationByCartId(cartId: $cartId,cartItemId: $cartItemId accessToken: $accessToken, userId: $userId){
    configuration{
      name
      sapCharc
      value
    }
    itemTexts{
      name
      value
    }
    metaData{
      name
      value
    }
    isSessionExpired
  }
}  
`
export default PRODUCT_CONFIGURATION_BY_ORDER_ID