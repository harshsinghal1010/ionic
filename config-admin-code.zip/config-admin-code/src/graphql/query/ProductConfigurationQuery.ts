import { gql } from '@apollo/client'

const GET_PRODUCT_COFIGURATION = gql`
query GetProductConfiguration($configID: String, $accessToken: String, $userId: String){
    getProductConfiguration(configID: $configID, accessToken: $accessToken, userId: $userId){
      configuration{
        name
        sapCharc
        value
      }
      itemTexts{
        name
        value
      }
      metaData{
        name
        value
      }
      isSessionExpired
    }
  }   
`

export default GET_PRODUCT_COFIGURATION