import { gql } from '@apollo/client'

const GET_URL = gql`
  query {
    getURL {
      host
      scheme
      port
      version
    }
  }
`
export default GET_URL
