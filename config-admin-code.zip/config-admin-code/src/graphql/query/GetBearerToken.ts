import { gql } from '@apollo/client'

const GET_BEARER_TOKEN = gql`
query GetBearerToken($code: String!
    $state: String!
    $session_state : String!){
      getBearerToken(code: $code
        state: $state
         session_state: $session_state){
        access_token
        token_type
        expires_in
        refresh_token
        scope
      }
    }
  
`
export default GET_BEARER_TOKEN
