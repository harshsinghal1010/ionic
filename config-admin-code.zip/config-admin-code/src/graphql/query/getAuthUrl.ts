import { gql } from '@apollo/client'

const GET_AUTH_URL = gql`
query {
    getAuthURL{
     host
     scheme
   }
 }
`
export default GET_AUTH_URL
