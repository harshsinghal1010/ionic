import { gql } from '@apollo/client'

const SEARCH_BY_PO_NUMBER_QUERY = gql`
  query getSearchByPONumber(
    $country: String
    $soldTo: String
    $toDate: String
    $fromDate: String
    $ponumber: String
    $accessToken: String
    $userId: String
  ) {
    getSearchByPONumber(
      country: $country
      soldTo: $soldTo
      toDate: $toDate
      fromDate: $fromDate
      ponumber: $ponumber
      accessToken: $accessToken
      userId: $userId
    ) {
      isSessionExpired
      result
    }
  }
`

export default SEARCH_BY_PO_NUMBER_QUERY
