import { gql } from '@apollo/client'

const GET_INTERNAL_METADATA = gql`
  query GetInternalMetadata($token: String) {
    getMetadata(token: $token) {
      adEmailId
      appMetaDataList{
        appName
        contextPath
        altPersonas{
          name
          userId
          logonId
          email
        }
      }
    }
  }
`
export default GET_INTERNAL_METADATA
