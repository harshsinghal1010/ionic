import { gql } from '@apollo/client'

const LOGIN_MUTATION = gql`
  mutation Login($userName: String, $password: String) {
    login(userName: $userName, password: $password) {
      accessToken
    }
  }
`
export default LOGIN_MUTATION
