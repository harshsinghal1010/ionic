import { Grid, Paper, Theme } from '@material-ui/core'
import React from 'react'
import { makeStyles } from '@material-ui/core/styles'

const useStyles = makeStyles((theme: Theme) => {
  return {
    root: {
      margin:'10px 5px 5px 5px'
    },
    paper: {
      height: theme.spacing(7),
      backgroundColor: '#EFEFEF'
    }
  }
})
const LoadingScreen: React.FC<{}> = () => {
  const classes = useStyles()

  return (
    <div className={classes.root}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper className={classes.paper}></Paper>
        </Grid>
        {Array.from(Array(3), (_) =>
          Array.from(Array(4), (_, i) => (
            <Grid item xs={3} key={i}>
              <Paper className={classes.paper}></Paper>
            </Grid>
          ))
        )}
      </Grid>
    </div>
  )
}

export default LoadingScreen
