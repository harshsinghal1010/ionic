import React from 'react'
import clsx from 'clsx'
import useStyles from '../../../../theme/style'
import LoadingScreen from '../LoadingScreen'

interface NoResultProps {
  heading: string
  message: string
  isLoading: boolean
}

const NoResult: React.FC<NoResultProps> = props => {
  const classes = useStyles()
  const { message, heading, isLoading } = props

  return (
    <div className={clsx(classes.priceLogicSearchBox, classes.marginTop4)}>
      <div>
        <span className={clsx(classes.headingCss)}>{heading}</span>
        {isLoading ? (
          <LoadingScreen  />
        ) : (
          <div className={clsx(classes.normalFont, classes.marginTop4)}>
            <span>{message}</span>
          </div>
        )}
      </div>
    </div>
  )
}

export default NoResult
