export { default } from './NoResult'
