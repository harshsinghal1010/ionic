import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import {
  Theme,
  Grid,
  Link,
  Stepper,
  Step,
  StepConnector,
  StepLabel,
  Divider
} from '@material-ui/core'
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight'
import clsx from 'clsx'

const useStyles = makeStyles((theme: Theme) => {
  return {
    icon: {
      display: 'none'
    },
    label: {
      fontSize: theme.typography.pxToRem(14),
      fontWeight: theme.typography.fontWeightRegular,
      borderBottom: `1px solid #949494`,
      marginTop: theme.spacing(3),
      marginBottom: theme.spacing(3),
      paddingTop: theme.spacing(1),
      paddingBottom: theme.spacing(5),
      '&:first-child': {
        color: 'rgba(0, 0, 0, 0.54)',
        fontWeight: theme.typography.fontWeightRegular
      }
    },
    activeGrid: {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center'
    },
    activeLink: {
      color: theme.palette.primary.main,
      alignSelf: 'flex-end'
    },
    disabledIcon: {
      color: theme.palette.common.black,
      alignSelf: 'flex-end'
    },
    disabledText: {
      color: theme.palette.common.black,
      fontWeight: 800
    },
    stepperContainer: {
      backgroundColor: 'transparent',
      padding: theme.spacing(3, 0),
      marginTop: theme.spacing(2)
    },
    resetConnector: {
      display: 'none'
    },
    font: {
      fontSize: theme.typography.pxToRem(16),
      fontWeight: theme.typography.fontWeightBold,
      color: theme.palette.primary.main
    },
    sideBarDivider: {
      width: 224,
      height: 1,
      marginLeft: 6,
      marginBottom: 12,
      backgroundColor: '#949494'
    }
  }
})

export interface SidebarItem {
  url?: string
  label: any
  activeLink?: boolean
}

export interface SidebarProps {
  items: SidebarItem[]
}

const Sidebar: React.FC<SidebarProps> = ({ items }) => {
  const classes = useStyles()

  return (
    <Stepper
      orientation="vertical"
      classes={{ root: classes.stepperContainer }}
      connector={
        <StepConnector
          classes={{
            root: classes.resetConnector
          }}
        />
      }
    >
      <>
        <Divider className={classes.sideBarDivider} />
        {items.map((item: any, index: number) => (
          <Step key={index}>
            <StepLabel
              classes={{ label: classes.label }}
              StepIconProps={{
                classes: {
                  root: classes.icon
                }
              }}
            >
              <Link href={item.url}>
                <Grid container justify="space-between">
                  <Grid
                    item
                    sm={10}
                    className={clsx(
                      item.activeLink ? classes.font : classes.disabledText
                    )}
                  >
                    {item.label}
                  </Grid>
                  <Grid item sm={1} className={classes.activeGrid}>
                    <KeyboardArrowRight
                      className={
                        item.activeLink
                          ? classes.activeLink
                          : classes.disabledIcon
                      }
                    />
                  </Grid>
                </Grid>
              </Link>
            </StepLabel>
          </Step>
        ))}
      </>
    </Stepper>
  )
}

export default Sidebar
