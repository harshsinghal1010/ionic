
// This will return true if browser is IE
export const isIEBrowser = () => {
  return false || !!window.document['documentMode']
}
