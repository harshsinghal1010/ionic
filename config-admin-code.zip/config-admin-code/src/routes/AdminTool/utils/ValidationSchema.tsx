import * as Yup from 'yup'

export const orderNumberSchema = Yup.object().shape({
  orderNumber: Yup.string()
    .matches(/^\d+$/, 'Please enter a valid Order Number.')
    .required('Please enter a valid Order Number.')
})

export const poNumberSchema = Yup.object().shape({
  poNumber: Yup.string().required('Please enter a valid PO Number.'),
  countryCode: Yup.string()
    .matches(/^[a-zA-Z]+$/, 'Invalid data')
    .min(2, 'Invalid data'),
  soldToNumber: Yup.string().matches(/^\d+$/, 'Invalid data')
})

export const displayConfigurationSchema = Yup.object().shape({
  orderId: Yup.string().required('Required Field'),
  orderItemId: Yup.string().required('Required Field')
})

const validatePriceList = (parent: any, path: any) => {
  let isError = false
  switch (path) {
    case 'soldTo':
      if (
        parent.shipTo === undefined &&
        parent.billTo === undefined &&
        parent.payer === undefined
      ) {
        isError = true
      }
      break

    case 'shipTo':
      if (
        parent.soldTo === undefined &&
        parent.billTo === undefined &&
        parent.payer === undefined
      ) {
        isError = true
      }
      break

    case 'billTo':
      if (
        parent.shipTo === undefined &&
        parent.soldTo === undefined &&
        parent.payer === undefined
      ) {
        isError = true
      }
      break

    case 'payer':
      if (
        parent.shipTo === undefined &&
        parent.billTo === undefined &&
        parent.soldTo === undefined
      ) {
        isError = true
      }
      break

    default:
      isError = false
      break
  }
  return isError
}

export const priceListSchema = Yup.object().shape({
  countryCode: Yup.string()
    .matches(/^[a-zA-Z]+$/, 'Invalid data')
    .min(2, 'Invalid data')
    .required('Required Field'),
  soldTo: Yup.string().test(
    'priceList',
    'Please provide either Sold To or Ship To or Bill To or Payer',
    function(value) {
      return value !== undefined
        ? validatePriceList(this.parent, this.path)
        : true
    }
  ),
  shipTo: Yup.string().test(
    'priceList',
    'Please provide either Sold To or Ship To or Bill To or Payer',
    function(value) {
      return value !== undefined
        ? validatePriceList(this.parent, this.path)
        : true
    }
  ),
  billTo: Yup.string().test(
    'priceList',
    'Please provide either Sold To or Ship To or Bill To or Payer',
    function(value) {
      return value !== undefined
        ? validatePriceList(this.parent, this.path)
        : true
    }
  ),
  payer: Yup.string().test(
    'priceList',
    'Please provide either Sold To or Ship To or Bill To or Payer',
    function(value) {
      return value !== undefined
        ? validatePriceList(this.parent, this.path)
        : true
    }
  )
})



export const loginSchema = Yup.object().shape({
  userName: Yup.string().required('Required Field'),
  password: Yup.string().required('Required Field')
})

