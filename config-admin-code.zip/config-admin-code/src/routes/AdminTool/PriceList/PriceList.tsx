import React from 'react'
import PriceListForm from './PriceListForm'
import SearchResult from './SearchResult'
import NoResult from '../Component/NoResultFound'
import { useIntl } from 'react-intl'
import messages from '../../../utils/messages'

const PriceList: React.FC<{}> = () => {
  const intl = useIntl()

  const [workbook, setWorkbook] = React.useState({})
  // This is to set the status of loading
  const [isLoading, setIsLoading] = React.useState(false)

  // 0 - hide search table
  // 1 - display with data
  // 2- No resutl found
  const [isSearchData, setIsSearchData] = React.useState(0)
  return (
    <div>
      <PriceListForm
        setWorkbook={setWorkbook}
        setIsSearchData={setIsSearchData}
        setIsLoading={setIsLoading}
      />
      {isSearchData === 0 ? (
        ''
      ) : isSearchData === 1 ? (
        <SearchResult workbook={workbook} />
      ) : (
        <NoResult
          heading={intl.formatMessage(messages[`SEARCH_RESULTS`])}
          message={intl.formatMessage(messages[`PRICE_LIST_NO_RESULT_FOUND`])}
          isLoading={isLoading}
        />
      )}
    </div>
  )
}

export default PriceList
