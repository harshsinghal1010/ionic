import React, { useState } from 'react'
import clsx from 'clsx'
import useStyles from '../../../theme/style'
import { FormattedMessage } from 'react-intl'
import messages from '../../../utils/messages'
import AccordionDetails from '@material-ui/core/AccordionDetails'
import Typography from '@material-ui/core/Typography'
import Accordion from '@material-ui/core/Accordion'
import AccordionSummary from '@material-ui/core/AccordionSummary'
import XLSX from 'xlsx'
import KeyboardArrowRightIcon from '@material-ui/icons/KeyboardArrowRight'
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown'
import Table from '@material-ui/core/Table'
import TableCell from '@material-ui/core/TableCell'
import TableHead from '@material-ui/core/TableHead'
import TableRow from '@material-ui/core/TableRow'
import { withStyles, Theme, createStyles } from '@material-ui/core/styles'
import { productsMap } from '../utils/MappingFiles'
import LoadingScreen from '../Component/LoadingScreen'

const StyledTableCell = withStyles((theme: Theme) =>
  createStyles({
    head: {
      backgroundColor: '#f8f8fc',
      padding: 5,
      fontSize: 12,
      fontStretch: 'normal',
      fontStyle: 'normal',
      lineHeight: '1.25',
      letterSpacing: 'normal',
      color: theme.palette.common.black
    },
    body: {
      fontSize: 12
    }
  })
)(TableCell)

interface SearchResultProps {
  workbook: any
}
const SearchResult: React.FC<SearchResultProps> = props => {
  const classes = useStyles()
  const { workbook } = props
  
  // To open multiple panel at a time
  const [open, setOpen] = useState<number[]>(
    workbook && workbook.SheetNames
      ? Array(workbook.SheetNames.length).fill(-1)
      : [-1]
  )

  const priceHeaders = ['Price', 'Expiry Date']
  const headers = [
    'Purification Charge',
    'Modification Price',
    'Other Charges',
    'Amino Acid Price',
    'Price Per Base',
    'Scaled Pricing',
    'Synthesis Scale (μmole)',
    'Quantity (O.D.)'
  ]
  const otherHeaders = [
    'Tubes Charge',
    'Concentration',
    'Plate Fee',
    'Shipping Fee',
    'Variants'
  ]

  React.useEffect(() => {
    // Initially workbook.SheetNames is undefined that why this useEffect is required
    if (workbook.SheetNames) {
      setOpen(Array(workbook.SheetNames.length).fill(-1))
    }
  }, [workbook.SheetNames])

  // Check if the row is a header row
  function isHeaderRow(productType, rowData) {
    return rowData.some(r => headers.includes(r))
  }

  // Check if the row is a price header row
  function isPriceHeaderRow(productType, rowData) {
    return rowData.some(r => priceHeaders.includes(r))
  }

  // Check if the row is an empty row
  function isEmptyRow(rowData) {
    return rowData.every(element => element === '')
  }

  // Check if the row is other charges row
  function isOtherChargesRow(rowData) {
    return rowData.some(r => otherHeaders.includes(r))
  }

  const fetchRowData = (text: any, sheetName: string, pos: number) => {
    const rowData = text.split(',')
    const rowHeader = rowData[0]
    return (
      <>
        <TableHead>
          {isEmptyRow(rowData) ? (
            <TableRow className={classes.height30}></TableRow>
          ) : isHeaderRow(sheetName, rowData) ? (
            <>
              <TableRow key={pos}>
                {rowData.map((header, count) => (
                  <>
                    {header !== '' ? (
                      <>
                        {count === 0 ? (
                          <StyledTableCell
                            key={count}
                            className={clsx(
                              classes.widthPriceListPanel,
                              classes.headingFont14
                            )}
                            align="left"
                          >
                            {header}
                          </StyledTableCell>
                        ) : (
                          <StyledTableCell
                            key={count}
                            align="center"
                            className={clsx(
                              classes.widthPriceListPanel,
                              classes.textAlignCenter,
                              classes.headingFont14
                            )}
                            colSpan={2}
                          >
                            {header}
                          </StyledTableCell>
                        )}
                      </>
                    ) : header === '' &&
                      (sheetName === 'screen' || sheetName === 'aqua') ? (
                      rowHeader === 'Purification Charge' ||
                      rowHeader === 'Other Charges' ||
                      rowHeader === 'Modification Price' ? (
                        <StyledTableCell
                          className={clsx(
                            classes.widthPriceListPanel,
                            classes.headingFont14
                          )}
                        >
                          {rowHeader}
                        </StyledTableCell>
                      ) : (
                        ''
                      )
                    ) : (
                      ''
                    )}
                  </>
                ))}
              </TableRow>
            </>
          ) : isPriceHeaderRow(sheetName, rowData) ||
            isOtherChargesRow(rowData) ? (
            <>
              <TableRow>
                {rowData.map((header, index) => (
                  <>
                    <StyledTableCell
                      key={index}
                      align="left"
                      className={clsx(classes.width200, classes.headingFont14)}
                    >
                      {header}
                    </StyledTableCell>
                  </>
                ))}
              </TableRow>
            </>
          ) : (
            <>
              <TableRow>
                {rowData.map((row, index) => (
                  <>
                    <StyledTableCell
                      key={index}
                      align="left"
                      className={classes.width200}
                    >
                      {row}
                    </StyledTableCell>
                  </>
                ))}
              </TableRow>
            </>
          )}
        </TableHead>
      </>
    )
  }

  const renderProductData = (sheetName: any) => {
    const csvData = XLSX.utils.sheet_to_csv(workbook.Sheets[sheetName])
    const productData = csvData.split(/\n/)

    return (
      <>
        <Table aria-label="customized table">
          {productData
            ? productData.map((text: any, pos: number) => (
                <>{fetchRowData(text, sheetName, pos)}</>
              ))
            : ''}
        </Table>
      </>
    )
  }

  const updateOpenState = (index, value) => {
    const newArr = [...open] 
    newArr[index] = value
    setOpen(newArr)
  }

  const renderPanelData = () => {
    return (
      <div>
        {workbook && workbook.SheetNames ? (
          workbook.SheetNames.map((sheetName: any, index: number) => (
            <div key={index}>
              <Accordion
                className={clsx(classes.BorderTop)}
                onChange={() => {
                  index === open[index]
                    ? updateOpenState(index, -1)
                    : updateOpenState(index, index)
                }}
                expanded={index === open[index] ? true : false}
              >
                <AccordionSummary
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  {index === open[index] ? (
                    <KeyboardArrowDownIcon className={classes.blueColor} />
                  ) : (
                    <KeyboardArrowRightIcon className={classes.blueColor} />
                  )}
                  <Typography className={classes.AccordionSummary}>
                    {productsMap.get(sheetName)
                      ? productsMap.get(sheetName)
                      : sheetName}
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  {renderProductData(sheetName)}
                </AccordionDetails>
              </Accordion>
            </div>
          ))
        ) : (
          <LoadingScreen />
        )}
      </div>
    )
  }

  return (
    <div className={clsx(classes.priceLogicSearchBox, classes.marginTop4)}>
      <div>
        <span className={clsx(classes.headingCss)}>
          <FormattedMessage {...messages[`SEARCH_RESULTS`]} />
        </span>
      </div>
      <div className={clsx(classes.marginTop4)}>{renderPanelData()}</div>
    </div>
  )
}

export default SearchResult
