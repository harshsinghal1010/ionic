import React from 'react'
import { Tooltip, Button, Grid } from '@material-ui/core'
import useStyles from '../../../theme/style'
import { FormattedMessage } from 'react-intl'
import messages from '../../../utils/messages'
import LiquidInputAdapter from '../../../components/LiquidInputAdapter'
import clsx from 'clsx'
import axios from 'axios'
import { Formik, Field } from 'formik'
import { priceListSchema } from '../utils/ValidationSchema'
import InfoIcon from '@material-ui/icons/Info'
import XLSX from 'xlsx'

interface FormValues {
  countryCode: string
  soldTo: string
  shipTo: string
  billTo: string
  payer: string
  buttonType: string
}

interface PriceListFormProps {
  setWorkbook: any
  setIsSearchData: any
  setIsLoading: any
}
const PriceListForm: React.FC<PriceListFormProps> = (props) => {
  const classes = useStyles()
  const { setWorkbook, setIsSearchData, setIsLoading } = props
  const initialValues: FormValues = {
    soldTo: '',
    shipTo: '',
    countryCode: '',
    billTo: '',
    payer: '',
    buttonType: '',
  }


  const displayData = async (file: any) => {
    // Create A File Reader HTML5
    const reader = new FileReader()
    // Ready The Event For When A File Gets Selected
    reader.onload = async (e) => {
      const data = (e.target as any).result
      const baseEncoded = btoa(data)
      const wb = XLSX.read(baseEncoded, { type: 'base64' })
      setWorkbook(wb)
    }
    // Tell JS To Start Reading The File.. You could delay this if desired
    reader.readAsBinaryString(file)
    setIsSearchData(1)
  }

  //http://uc1a-ecomdev-mlb01.sial.com:30012/pc/price/api/v2/pricedata/GB?soldTo=2035656147&shipTo=&billTo=&payer=&isSapNextEnabled=true
  const fetchPriceList = (priceList: FormValues) => {
    setIsLoading(true)
    setIsSearchData(2)
    setWorkbook({})
    axios({
      url: `/config/priceList/${priceList.countryCode.toLocaleUpperCase()}?soldTo=${
        priceList.soldTo
      }&shipTo=${priceList.shipTo}&billTo=${priceList.billTo}&payer=${
        priceList.payer
      }&isSapNextEnabled=true`,
      method: 'GET',
      headers: { Pragma: 'no-cache' },
      responseType: 'blob', // important

    })
      .then((response) => {
        if (response.status === 200) {
          const blob = new Blob([response.data], {
            type: 'application/vnd.ms-excel',
          })

          setIsLoading(false)
          const fileName = `List Price_${priceList.countryCode.toLocaleUpperCase()}.xls`
          if (priceList.buttonType === 'download') {
            const url = window.URL.createObjectURL(new Blob([response.data]))
            const link = document.createElement('a')
            link.href = url
            link.setAttribute('download', fileName)
            document.body.appendChild(link)
            link.click()
            setIsSearchData(0)
          } else {
            const file = new File([blob], fileName)
            displayData(file)
          }
        } else {
          setIsLoading(false)
          setIsSearchData(2)
        }
      })
      .catch((error) => {
        console.log(error)
        setIsLoading(false)
        setIsSearchData(2)
      })
   
  }

  return (
    <div className={classes.PriceListBox}>
      <Formik
        initialValues={initialValues}
        validationSchema={priceListSchema}
        validateOnChange={false}
        validateOnBlur={false}
        onSubmit={(values, actions) => {
          setTimeout(() => {
            actions.validateForm(values)
            fetchPriceList(values)
            actions.setSubmitting(false)
          }, 100)
        }}
      >
        {(props) => (
          <form onSubmit={props.handleSubmit}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <span className={clsx(classes.headingCss)}>
                  <FormattedMessage {...messages[`PRICE_LIST_SEARCH`]} />
                </span>
              </Grid>
              <Grid item xs={12}>
                <span className={clsx(classes.normalFont)}>
                  <FormattedMessage {...messages[`PRICE_LIST_DOWNLOAD_DESC`]} />
                </span>
              </Grid>
              <Grid item xs={4}>
                <Field
                  name="countryCode"
                  component={LiquidInputAdapter}
                  autoComplete="off"
                  className={classes.placeholder}
                  placeholder={'i.e JP'}
                  inputProps={{ maxLength: 2 }}
                  label={
                    <span>
                      <span
                        className={
                          props.errors.countryCode
                            ? classes.errorField
                            : classes.fontWeight700
                        }
                      >
                        <FormattedMessage {...messages[`COUNTRY_CODE`]} />
                      </span>

                      <Tooltip
                        title={
                          <FormattedMessage
                            {...messages.COUNTRY_CODE_POPOVER_MSG}
                          />
                        }
                        classes={{
                          tooltip: classes.InfoPopup,
                          arrow: classes.arrowColor,
                        }}
                        arrow
                        placement="bottom-start"
                      >
                        <InfoIcon
                          aria-label="info"
                          className={classes.InfoIcon}
                          color="primary"
                        ></InfoIcon>
                      </Tooltip>
                    </span>
                  }
                  onChange={props.handleChange}
                  value={props.values.countryCode.toLocaleUpperCase()}
                />
              </Grid>
              <Grid item xs={4}>
                <Field
                  name="soldTo"
                  component={LiquidInputAdapter}
                  autoComplete="off"
                  label={
                    <span>
                      <span
                        className={
                          props.errors.soldTo
                            ? classes.errorField
                            : classes.fontWeight700
                        }
                      >
                        <FormattedMessage {...messages[`SOLD_TO_NUMBER`]} />
                      </span>

                      <Tooltip
                        title={
                          <FormattedMessage
                            {...messages.PRICE_LIST_TOOLTIP_MESSAGE_SOLD_TO}
                          />
                        }
                        classes={{
                          tooltip: classes.InfoPopup,
                          arrow: classes.arrowColor,
                        }}
                        arrow
                        placement="bottom-start"
                      >
                        <InfoIcon
                          aria-label="info"
                          className={classes.InfoIcon}
                          color="primary"
                        ></InfoIcon>
                      </Tooltip>
                    </span>
                  }
                  onChange={props.handleChange}
                  value={props.values.soldTo}
                />
              </Grid>
              <Grid item xs={4}>
                <Field
                  name="shipTo"
                  component={LiquidInputAdapter}
                  autoComplete="off"
                  label={
                    <span>
                      <span
                        className={
                          props.errors.shipTo
                            ? classes.errorField
                            : classes.fontWeight700
                        }
                      >
                        <FormattedMessage {...messages[`SHIP_TO_NUMBER`]} />
                      </span>

                      <Tooltip
                        title={
                          <FormattedMessage
                            {...messages.PRICE_LIST_TOOLTIP_MESSAGE_SHIP_TO}
                          />
                        }
                        classes={{
                          tooltip: classes.InfoPopup,
                          arrow: classes.arrowColor,
                        }}
                        arrow
                        placement="bottom-start"
                      >
                        <InfoIcon
                          aria-label="info"
                          className={classes.InfoIcon}
                          color="primary"
                        ></InfoIcon>
                      </Tooltip>
                    </span>
                  }
                  onChange={props.handleChange}
                  value={props.values.shipTo}
                />
              </Grid>
              <Grid item xs={4}>
                <Field
                  name="billTo"
                  component={LiquidInputAdapter}
                  autoComplete="off"
                  label={
                    <span>
                      <span
                        className={
                          props.errors.billTo
                            ? classes.errorField
                            : classes.fontWeight700
                        }
                      >
                        <FormattedMessage {...messages[`BILL_TO_NUMBER`]} />
                      </span>

                      <Tooltip
                        title={
                          <FormattedMessage
                            {...messages.PRICE_LIST_TOOLTIP_MESSAGE_BILL_TO}
                          />
                        }
                        classes={{
                          tooltip: classes.InfoPopup,
                          arrow: classes.arrowColor,
                        }}
                        arrow
                        placement="bottom-start"
                      >
                        <InfoIcon
                          aria-label="info"
                          className={classes.InfoIcon}
                          color="primary"
                        ></InfoIcon>
                      </Tooltip>
                    </span>
                  }
                  onChange={props.handleChange}
                  value={props.values.billTo}
                />
              </Grid>
              <Grid item xs={4}>
                <Field
                  name="payer"
                  component={LiquidInputAdapter}
                  autoComplete="off"
                  label={
                    <span>
                      <span
                        className={
                          props.errors.payer
                            ? classes.errorField
                            : classes.fontWeight700
                        }
                      >
                        <FormattedMessage {...messages[`PAYER_NUMBER`]} />
                      </span>

                      <Tooltip
                        title={
                          <FormattedMessage
                            {...messages.PRICE_LIST_TOOLTIP_MESSAGE_PAYER}
                          />
                        }
                        classes={{
                          tooltip: classes.InfoPopup,
                          arrow: classes.arrowColor,
                        }}
                        arrow
                        placement="bottom-start"
                      >
                        <InfoIcon
                          aria-label="info"
                          className={classes.InfoIcon}
                          color="primary"
                        ></InfoIcon>
                      </Tooltip>
                    </span>
                  }
                  onChange={props.handleChange}
                  value={props.values.payer}
                />
              </Grid>
              <Grid item xs={12}>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => {
                    props.setFieldValue('buttonType', 'search')
                  }}
                  type="submit"
                  className={clsx(classes.Button, classes.marginRight7)}
                >
                  <FormattedMessage {...messages.SEARCH} />
                </Button>
                <Button
                  variant="outlined"
                  color="primary"
                  className={clsx(
                    classes.Button,
                    classes.marginRight7,
                    classes.buttonSize
                  )}
                  onClick={() => {
                    props.setFieldValue('buttonType', 'download')
                  }}
                  type="submit"
                >
                  <FormattedMessage {...messages.DOWNLOAD} />
                </Button>
                <Button
                  variant="outlined"
                  className={clsx(
                    classes.Button,
                    classes.marginRight7,
                    classes.greyColor,
                    classes.width20
                  )}
                  onClick={() => {
                    setWorkbook({})
                    props.handleReset()
                    setIsSearchData(0)
                  }}
                >
                  <FormattedMessage {...messages.RESET} />
                </Button>
              </Grid>
            </Grid>
          </form>
        )}
      </Formik>
    </div>
  )
}

export default PriceListForm
