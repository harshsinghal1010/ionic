import React from 'react'
import { Grid, Divider } from '@material-ui/core'
import clsx from 'clsx'
import useStyles from '../../../theme/style'
import { FormattedMessage } from 'react-intl'
import messages from '../../../utils/messages'
import { headerMap } from '../utils/MappingFiles'

interface SearchResultProps {
  displayConfigurationData: any
}

const SearchResult: React.FC<SearchResultProps> = (props) => {
  const classes = useStyles()
  const { displayConfigurationData } = props
  const commentData = displayConfigurationData.filter(
    (data) => data.name === 'comments'
  )
  const listConfigurationData = displayConfigurationData.filter(
    (data) => data.name !== 'comments'
  )
  return (
    <div className={classes.displayConfiguratorSearchBox}>
      <div>
        <span className={clsx(classes.headingCss)}>
          <FormattedMessage {...messages[`SEARCH_RESULTS`]} />
        </span>
        <Divider className={clsx(classes.marginTop6, classes.dividerColor)} />
      </div>
      <Grid
        container
        spacing={6}
        direction="row"
        className={clsx(classes.marginTop4)}
      >
        <Grid item xs={12}>
          <div className={clsx(classes.headingFont14)}>
            <FormattedMessage {...messages[`COMMENTS`]} />:
          </div>
          <div>{commentData.length > 0 ? commentData[0].value : '--'}</div>
        </Grid>
        {listConfigurationData.map((item: any, index: number) => (
            <Grid item xs={6} key={index}>
              <div className={clsx(classes.headingFont14)}>
                <span>
                  {headerMap.get(item.name)
                    ? headerMap.get(item.name)
                    : item.name}:
                </span>
              </div>
              <div className={clsx(classes.normalFont)}>
                <span>{item.value}</span>
              </div>
            </Grid>
        ))}
      </Grid>
    </div>
  )
}

export default SearchResult
