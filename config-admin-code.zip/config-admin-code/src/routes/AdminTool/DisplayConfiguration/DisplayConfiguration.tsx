import React from 'react'
import DisplayConfigurationForm from './DisplayConfigurationForm'
import SearchResult from './SearchResult'
import NoResult from '../Component/NoResultFound'
import { useIntl } from 'react-intl'
import messages from '../../../utils/messages'

const DisplayConfiguration: React.FC<{}> = () => {
  const intl = useIntl()

  // This is to display the data on table
  const [
    displayConfigurationData,
    setDisplayConfigurationData
  ] = React.useState<any>([])

  // 0 - hide search table
  // 1 - display with data
  // 2- No resutl found
  const [isSearchData, setIsSearchData] = React.useState(0)

  // This is to set the status of loading
  const [isLoading, setIsLoading] = React.useState(false)

  return (
    <div>
      <DisplayConfigurationForm
        setDisplayConfigurationData={setDisplayConfigurationData}
        setIsSearchData={setIsSearchData}
        setIsLoading={setIsLoading}
      />
      {isSearchData === 0 ? (
        ''
      ) : isSearchData === 1 ? (
        <SearchResult displayConfigurationData={displayConfigurationData} />
      ) : (
        <NoResult
          heading={intl.formatMessage(messages[`SEARCH_RESULTS`])}
          message={intl.formatMessage(messages[`DISPLAY_CONFIGURATION_NO_RESULT_FOUND`])}
          isLoading={isLoading}
        />
      )}
    </div>
  )
}

export default DisplayConfiguration
