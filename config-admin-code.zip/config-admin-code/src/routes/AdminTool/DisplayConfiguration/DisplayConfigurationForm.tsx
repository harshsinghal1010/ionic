import React, { useState } from 'react'
import { Button, Grid, Divider } from '@material-ui/core'
import useStyles from '../../../theme/style'
import { FormattedMessage } from 'react-intl'
import messages from '../../../utils/messages'
import LiquidInputAdapter from '../../../components/LiquidInputAdapter'
import clsx from 'clsx'
import { Formik, Field } from 'formik'
import { displayConfigurationSchema } from '../utils/ValidationSchema'
import { useLazyQuery } from '@apollo/client'
import ProductConfigurationQuery from '@src/graphql/query/ProductConfigurationQuery'
import ProductConfigurationByOrderIdQuery from '@src/graphql/query/ProductConfigurationByOrderIdQuery'
import { sessionStorage } from 'react-storage'
import { useRouter } from 'next/router'

interface FormValues {
  orderId: string
  orderItemId: string
}

interface DisplayConfigurationFormProps {
  setDisplayConfigurationData: any
  setIsSearchData: any
  setIsLoading: any
}

const DisplayConfigurationForm: React.FC<DisplayConfigurationFormProps> = (
  props
) => {
  const router = useRouter()
  const classes = useStyles()
  const [configId, setConfigId] = useState<string>('')
  const { setDisplayConfigurationData, setIsSearchData, setIsLoading } = props
  const bearerToken = sessionStorage.getItem('access_token')
  const userId = sessionStorage.getItem('userId')
  const accessToken = `Bearer ${bearerToken}`
  const [getProductConfiguration, { data: configData }] = useLazyQuery(
    ProductConfigurationQuery,
    {
      fetchPolicy: 'no-cache',
    }
  )
  const [getProductConfigurationByCartId, { data: orderIdResp }] = useLazyQuery(
    ProductConfigurationByOrderIdQuery,
    {
      fetchPolicy: 'no-cache',
    }
  )
  const initialValues: FormValues = {
    orderId: '',
    orderItemId: '',
  }

  const fetchProductByOrderId = (orderData) => {
    setIsLoading(true)
    setIsSearchData(2)
    getProductConfigurationByCartId({ variables: orderData })
  }
  const fetchProductConfig = (configData) => {
    setIsLoading(true)
    setIsSearchData(2)
    getProductConfiguration({ variables: configData })
  }

  const removeDuplicate = (arr,key)=>{
    return [...new Map(arr.map(item => [item[key], item])).values()]
  }

  const prepareConfigurationData = (data) => {
    const configuration = data.configuration
    const metaData = data.metaData
    const itemTexts = data.itemTexts
    if (data.isSessionExpired) {
      setIsSearchData(2)
      sessionStorage.removeItem('access_token')
      sessionStorage.removeItem('userId')
      router.push('/')
    } else {
      if (
        configuration.length > 0 ||
        metaData.length > 0 ||
        itemTexts.length > 0
      ) {
        setIsSearchData(1)
      } else {
        setIsSearchData(2)
      }
    }

    const listconfigurationData = [...configuration, ...itemTexts, ...metaData]
    const result=removeDuplicate(listconfigurationData,'name')
    setDisplayConfigurationData(result)
  }

  React.useEffect(() => {
    if (configData) {
      setIsLoading(false)
      prepareConfigurationData(configData.getProductConfiguration)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [configData])

  React.useEffect(() => {
    if (orderIdResp) {
      setIsLoading(false)
      prepareConfigurationData(orderIdResp.getProductConfigurationByCartId)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderIdResp])

  const fetchByOrderIDAndItemId = (formData) => {
    setConfigId('')
    const inputData = {
      cartId: formData.orderId,
      cartItemId: formData.orderItemId,
      accessToken: accessToken,
      userId: userId,
    }
    fetchProductByOrderId(inputData)
  }

  const handleSearchByConfigId = (props) => {
    props.handleReset()
    const inputData = {
      configID: configId,
      accessToken: accessToken,
      userId: userId,
    }
    fetchProductConfig(inputData)
  }

  return (
    <div className={classes.displayConfiguratorBox}>
      <Formik
        initialValues={initialValues}
        validationSchema={displayConfigurationSchema}
        validateOnChange={false}
        validateOnBlur={false}
        onSubmit={(values, actions) => {
          setTimeout(() => {
            actions.validateForm(values)
            fetchByOrderIDAndItemId(values)
            actions.setSubmitting(false)
          }, 1000)
        }}
      >
        {(props) => (
          <Grid
            container
            direction="row"
            justify="space-between"
            alignItems="flex-start"
          >
            <Grid item xs={5}>
              <span className={clsx(classes.headingCss)}>
                <FormattedMessage {...messages[`SEARCH_BY_CONFIGURATION_ID`]} />
              </span>
              <Grid item xs={8}>
                <div
                  className={clsx(
                    classes.paddingTop5,
                    classes.marginTop4,
                    classes.fieldWidth,
                    classes.marginBottom4
                  )}
                >
                  <Field
                    name="configId"
                    component={LiquidInputAdapter}
                    autoComplete="off"
                    label={
                      <span className={classes.fontWeight700}>
                        <FormattedMessage {...messages[`CONFIGURATION_ID`]} />
                      </span>
                    }
                    onChange={(e: any) => setConfigId(e.target.value)}
                    value={configId}
                  />
                </div>
              </Grid>
              <Grid item xs={12}>
                <div>
                  <Button
                    size="large"
                    variant="contained"
                    color="primary"
                    onClick={() => handleSearchByConfigId(props)}
                    className={clsx(classes.Button, classes.buttonSize)}
                  >
                    <FormattedMessage {...messages.SEARCH} />
                  </Button>
                </div>
              </Grid>
            </Grid>
            <Grid item>
              <div>
                <Divider
                  orientation="vertical"
                  className={clsx(
                    classes.dividerColor,
                    classes.dividerHeight100,
                    classes.dividerWidth
                  )}
                />
              </div>
              <div
                className={clsx(
                  classes.marginLeft2,
                  classes.marginBottom4,
                  classes.marginTop4
                )}
              >
                OR
              </div>
              <div>
                <Divider
                  orientation="vertical"
                  className={clsx(
                    classes.dividerColor,
                    classes.dividerHeight100,
                    classes.dividerWidth
                  )}
                />
              </div>
            </Grid>

            <Grid item xs={5}>
              <form onSubmit={props.handleSubmit}>
                <>
                  <span className={clsx(classes.headingCss)}>
                    <FormattedMessage
                      {...messages[`SEARCH_BY_ORDER_ITEM_ID`]}
                    />
                  </span>
                  <Grid item xs={8}>
                    <div
                      className={clsx(
                        classes.paddingTop5,
                        classes.marginTop4,
                        classes.fieldWidth,
                        classes.marginBottom4
                      )}
                    >
                      <Field
                        name="orderId"
                        component={LiquidInputAdapter}
                        autoComplete="off"
                        label={
                          <span
                            className={
                              props.errors.orderId
                                ? classes.errorField
                                : classes.fontWeight700
                            }
                          >
                            <FormattedMessage {...messages[`ORDER_ID`]} />
                          </span>
                        }
                        onChange={props.handleChange}
                        value={props.values.orderId}
                      />
                    </div>
                  </Grid>
                  <Grid item xs={8}>
                    <div
                      className={clsx(
                        classes.paddingTop5,
                        classes.marginTop4,
                        classes.fieldWidth,
                        classes.marginBottom4
                      )}
                    >
                      <Field
                        name="orderItemId"
                        component={LiquidInputAdapter}
                        autoComplete="off"
                        label={
                          <span
                            className={
                              props.errors.orderItemId
                                ? classes.errorField
                                : classes.fontWeight700
                            }
                          >
                            <FormattedMessage {...messages[`ORDER_ITEM_ID`]} />
                          </span>
                        }
                        onChange={props.handleChange}
                        value={props.values.orderItemId}
                      />
                    </div>
                  </Grid>
                  <Grid item xs={12}>
                    <div>
                      <Button
                        size="large"
                        variant="contained"
                        color="primary"
                        type="submit"
                        className={clsx(classes.Button, classes.buttonSize)}
                      >
                        <FormattedMessage {...messages.SEARCH} />
                      </Button>
                    </div>
                  </Grid>
                </>
              </form>
            </Grid>
          </Grid>
        )}
      </Formik>
    </div>
  )
}

export default DisplayConfigurationForm
