import React from 'react'
import { Container, Grid } from '@material-ui/core'
import { useRouter as useNextRouter } from 'next/router'
import { RouteComponentProps } from 'react-router-dom'
import Sidebar from './Component/Sidebar'
import { FormattedMessage } from 'react-intl'
import messages from '@src/utils/messages'
import Constants from '@src/utils/Constants'
import DisplayConfiguration from './DisplayConfiguration'
import useStyles from '@src/theme/style'
import PriceLogic from './priceLogic'
import PriceList from './PriceList'

const AdminTool: React.FC<RouteComponentProps> = () => {
  const classes = useStyles()
  const router = useNextRouter()
  const { page = '' } = router ? router.query : {}

  const sidebarItems = [
    {
      label: <FormattedMessage {...messages[`DISPLAY_CONFIGURATION`]} />,
      activeLink: page === Constants.DISPLAY_CONFIGURATION,
      url: `/${Constants.ADMIN_TOOL}/${Constants.DISPLAY_CONFIGURATION}`,
    },
    {
      label: <FormattedMessage {...messages[`PRICE_LOGIC`]} />,
      activeLink: page === Constants.PRICE_LOGIC,
      url: `/${Constants.ADMIN_TOOL}/${Constants.PRICE_LOGIC}`,
    },
    {
      label: <FormattedMessage {...messages[`PRICE_LIST`]} />,
      activeLink: page === Constants.PRICE_LIST,
      url: `/${Constants.ADMIN_TOOL}/${Constants.PRICE_LIST}`,
    },
  ]

  const callAdminToolComponent = () => {
    switch (page) {
      case Constants.DISPLAY_CONFIGURATION:
        return <DisplayConfiguration />
      case Constants.PRICE_LOGIC:
        return <PriceLogic />
      case Constants.PRICE_LIST:
        return <PriceList />
      default:
        return <></>
    }
  }

  return (
    <Container>
      <div>
        <div className={classes.title}>
          <FormattedMessage {...messages[`CONFIGURATOR_ADMIN_TOOL`]} />
        </div>
        <Grid container spacing={2}>
          <Grid className={classes.sideNavWidth}>
            <Sidebar items={sidebarItems} />
          </Grid>
          <Grid item xs={9}>
            {callAdminToolComponent()}
          </Grid>
        </Grid>
      </div>
    </Container>
  )
}

export default AdminTool
