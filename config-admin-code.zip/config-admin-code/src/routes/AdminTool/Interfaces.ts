export interface PriceLogicDataTableData {
  soQuoteNumber: string
  type: string
  salesOrg: string
  soldTo: string
  shipTo: string
  billTo: string
  payer: string
  dateCreated: string
  soQuoteStatus: string
}

export interface PriceLogicPanelData {
  webOrderNumber: string
  orderItemId: string
  productType: string
  type: string
  configuration: string
  specification: string
  shipTo: string
  soldTo: string
  billTo: string
  payer: string
  customerPricing: string
  price: string
  currency: string
  sapOrderNumber: string
  priority: string
}
export interface PriceLogicData {
  priceLogicPanelData: PriceLogicPanelData[]
  priceLogicTableData: PriceLogicDataTableData[]
}

export interface SearchByPONumber {
  poNumber: string
  countryCode: string
  soldToNumber: string
  startDate: string
  endDate: string
}
export interface SearchByOrderNumber {
  orderNumber: string
}


