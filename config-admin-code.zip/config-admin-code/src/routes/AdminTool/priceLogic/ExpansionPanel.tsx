import React, { useState } from 'react'
import { Theme, createStyles, withStyles } from '@material-ui/core/styles'
import AccordionDetails from '@material-ui/core/AccordionDetails'
import Typography from '@material-ui/core/Typography'
import Accordion from '@material-ui/core/Accordion'
import AccordionSummary from '@material-ui/core/AccordionSummary'
import KeyboardArrowRightIcon from '@material-ui/icons/KeyboardArrowRight'
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown'
import Table from '@material-ui/core/Table'
import TableBody from '@material-ui/core/TableBody'
import TableCell from '@material-ui/core/TableCell'
import TableContainer from '@material-ui/core/TableContainer'
import TableHead from '@material-ui/core/TableHead'
import TableRow from '@material-ui/core/TableRow'
import Paper from '@material-ui/core/Paper'
import { FormattedMessage } from 'react-intl'
import clsx from 'clsx'
import useStyles from '../../../theme/style'
import messages from '../../../utils/messages'
import { productsMap, headerMap } from '../utils/MappingFiles'
const StyledTableCell = withStyles((theme: Theme) =>
  createStyles({
    head: {
      backgroundColor: '#f8f8fc',
      fontSize: 12,
      fontWeight: 900,
      fontStretch: 'normal',
      fontStyle: 'normal',
      lineHeight: '1.25',
      letterSpacing: 'normal',
      textAlign: 'left',
      borderBottom: '1px solid #949494',
      borderTop: '1px solid #949494',
      color: theme.palette.common.black
    },
    body: {
      fontSize: 12
    }
  })
)(TableCell)

const StyledTableRow = withStyles((theme: Theme) =>
  createStyles({
    root: {
      '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.common.white
      }
    }
  })
)(TableRow)

interface ExpansionPanelProps {
  orderNumberData: any
}

const ExpansionPanel: React.FC<ExpansionPanelProps> = props => {
  const classes = useStyles()
  const { orderNumberData } = props
  const [open, setOpen] = useState<number>(-1)

  const renderPanelData = (panelData: any) => {
    return (
      <div>
        <div>
          <TableContainer
            component={Paper}
            className={clsx(classes.table)}
          >
            <Table aria-label="customized table">
              <TableHead>
                <TableRow>
                  <StyledTableCell className={clsx(classes.panelBorder)}>
                    <FormattedMessage {...messages[`TYPE`]} />
                  </StyledTableCell>
                  <StyledTableCell className={clsx(classes.panelBorder)}>
                    <FormattedMessage {...messages[`CONFIGURATION`]} />
                  </StyledTableCell>
                  <StyledTableCell
                    align="left"
                    className={clsx(classes.panelBorder)}
                  >
                    <FormattedMessage {...messages[`SPECIFICATION`]} />
                  </StyledTableCell>
                  <StyledTableCell
                    align="left"
                    className={clsx(classes.panelBorder)}
                  >
                    <FormattedMessage {...messages[`DISCOUNT_PRICE`]} />
                  </StyledTableCell>
                  <StyledTableCell
                    align="left"
                    className={clsx(classes.panelPriceBorder)}
                  >
                    <FormattedMessage {...messages[`PRICE`]} />
                  </StyledTableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {panelData.map((item: any, index: number) => (
                  <StyledTableRow key={index}>
                    <StyledTableCell
                      component="th"
                      scope="row"
                      className={clsx(classes.panelBorder)}
                    >
                      {item.type === 'totalBasePrice'
                        ? `${
                            headerMap.get(item.type)
                              ? headerMap.get(item.type)
                              : item.type
                          } (${item.configuration})`
                        : headerMap.get(item.type)
                        ? headerMap.get(item.type)
                        : item.type}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={clsx(classes.panelBorder)}
                    >
                      {item.type === 'totalBasePrice'
                        ? '--'
                        : item.configuration
                        ? item.configuration
                        : '--'}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={clsx(classes.panelBorder)}
                    >
                      {item.specification ? item.specification : '--'}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={clsx(classes.panelBorder)}
                    >
                      {item.customerPricing ? item.customerPricing : '--'}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={clsx(classes.panelPriceBorder)}
                    >
                      {item.price}
                    </StyledTableCell>
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      </div>
    )
  }

  return (
    <div className={classes.table}>
      {orderNumberData.map((item: any, index: number) => (
        <Accordion
          key={index}
          onChange={() => {
            index === open ? setOpen(-1) : setOpen(index)
          }}
          expanded={index === open ? true : false}
        >
          <AccordionSummary aria-controls="panel1a-content" id="panel1a-header">
            {index === open ? (
              <KeyboardArrowDownIcon className={classes.blueColor} />
            ) : (
              <KeyboardArrowRightIcon className={classes.blueColor} />
            )}

            <Typography className={classes.AccordionSummary}>
              {index + 1}
            </Typography>
            <Typography className={classes.AccordionSummary}>
              {productsMap.get(item.productType)
                ? productsMap.get(item.productType)
                : item.productType}
            </Typography>
            <Typography className={classes.AccordionSummary}>
              <span>
                <FormattedMessage {...messages[`OLIGO_NAME`]} />
                &nbsp;= &nbsp;
                {item.oligoName}
              </span>
            </Typography>
            <Typography className={classes.AccordionSummary}>
              <FormattedMessage {...messages[`TOTAL_PRICE`]} />
              &nbsp; =&nbsp;
              {item.totalPrice}
            </Typography>
          </AccordionSummary>
          <AccordionDetails className={classes.noPadding}>
            <Typography component={'div'}>
              {renderPanelData(item.panel)}
            </Typography>
          </AccordionDetails>
        </Accordion>
      ))}
    </div>
  )
}

export default ExpansionPanel
