import React from 'react'
import { Tooltip, Button, Grid, Divider } from '@material-ui/core'
import useStyles from '../../../theme/style'
import { FormattedMessage } from 'react-intl'
import messages from '../../../utils/messages'
import InfoIcon from '@material-ui/icons/Info'
import LiquidInputAdapter from '../../../components/LiquidInputAdapter'
import { Formik, Field } from 'formik'
import clsx from 'clsx'
import { orderNumberSchema, poNumberSchema } from '../utils/ValidationSchema'
import { isIEBrowser } from '../utils/util'
import { initSearchByPOForm, initTableData } from '../InitialValues'
import moment from 'moment'
import { SearchByOrderNumber } from '../Interfaces'
import { useLazyQuery } from '@apollo/client'
import SearchByPONumberQuery from '@src/graphql/query/SearchByPONumberQuery'
import SearchByOrderNumberOuery from '@src/graphql/query/SearchByOrderNumberOuery'
import { sessionStorage } from 'react-storage'
import { useRouter } from 'next/router'

interface PriceLogicFormProps {
  setOrderNumberData: any
  setPriceLogicTableData: any
  setIsSearchData: any
  setIsLoading: any
  odNumber: any
  buttonType: any
}
const PriceLogicForm: React.FC<PriceLogicFormProps> = (props) => {
  const router = useRouter()
  const classes = useStyles()
  const {
    setPriceLogicTableData,
    setOrderNumberData,
    setIsSearchData,
    setIsLoading,
    odNumber,
    buttonType,
  } = props
  const priceLogicTableData = [initTableData]

  const [orderNum, setOrderNum] = React.useState('')
  const bearerToken = sessionStorage.getItem('access_token')
  const userId = sessionStorage.getItem('userId')
  const accessToken = `Bearer ${bearerToken}`
  const [getSearchByPONumber, { data: searchByPOData }] = useLazyQuery(
    SearchByPONumberQuery,
    {
      fetchPolicy: 'no-cache',
    }
  )
  const [
    getSearchByOrderNumber,
    { data: searchByOrderNumberData },
  ] = useLazyQuery(SearchByOrderNumberOuery, {
    fetchPolicy: 'no-cache',
  })

  const initSearchByOrderNumberForm: SearchByOrderNumber = {
    orderNumber: odNumber,
  }

  // This function is used to filter the data based on the response coming from search by order number api.
  const prepareOrderNumberData = (data: any, orderNumber: string) => {
    let listOrderNumber: any = []
    const orderNumberData: any = []
    let shipTo = ''
    let soldTo = ''
    let billTo = ''
    let payer = ''
    let statusData = ''
    let salesOrg = ''
    let date = ''
    const keys = Object.keys(data)
    keys.forEach((element: any) => {
      if (
        element !== 'status' &&
        element !== 'date' &&
        element !== 'salesOrg'
      ) {
        const orderNumberObject = data[element]
        const hiphen = '--'
        listOrderNumber = orderNumberObject[hiphen] // getting array inside --
        const orderNumberDisplayData: any = {
          oligoName: '',
          productType: '',
          totalPrice: '',
          panel: [],
        }

        const listBase = listOrderNumber.filter(
          (item: any) => item.type === 'base'
        )
        listOrderNumber = listOrderNumber.filter(
          (item: any) => item.type !== 'base'
        )
        if (listBase && listBase.length > 0) {
          listBase[0].configuration = '--'
          orderNumberDisplayData.panel.push(listBase[0])
        }
        listOrderNumber.forEach((item: any) => {
          if (item.type === 'name') {
            orderNumberDisplayData.oligoName = item.configuration
              ? item.configuration
              : '--'
            orderNumberDisplayData.productType = item.productType
              ? item.productType
              : '--'
            shipTo = item.shipTo ? item.shipTo : '--'
            soldTo = item.soldTo ? item.soldTo : '--'
            billTo = item.billTo ? item.billTo : '--'
            payer = item.payer ? item.payer : ''
          } else if (item.type === 'totalPrice') {
            orderNumberDisplayData.totalPrice = `${
              item.price ? item.price : '--'
            } (${item.currency ? item.currency : '--'})`
          } else {
            orderNumberDisplayData.panel.push(item)
          }
        })
        orderNumberData.push(orderNumberDisplayData)
      } else if (element === 'date') {
        const dateArr = Object.keys(data[element])
        date = dateArr[0]
      } else if (element === 'salesOrg') {
        const salesArr = Object.keys(data[element])
        salesOrg = salesArr[0]
      } else {
        const status = Object.keys(data[element])
        statusData = status[0]
      }
    })
    priceLogicTableData[0].soQuoteNumber = orderNumber
    priceLogicTableData[0].soQuoteStatus = statusData ? statusData : '--'
    priceLogicTableData[0].salesOrg = salesOrg ? salesOrg : '--'
    priceLogicTableData[0].billTo = billTo ? billTo : '--'
    priceLogicTableData[0].shipTo = shipTo ? shipTo : '--'
    priceLogicTableData[0].soldTo = soldTo ? soldTo : '--'
    priceLogicTableData[0].payer = payer ? payer : '--'
    priceLogicTableData[0].dateCreated = date ? date : ''
    priceLogicTableData[0].type = '--'
    setOrderNumberData(orderNumberData)
    setPriceLogicTableData(priceLogicTableData)
  }

  const fetchOrderNumberData = async (orderNumber: string) => {
    setIsLoading(true)
    setIsSearchData(2)
    setOrderNum(orderNumber)
    try {
      getSearchByOrderNumber({ variables: { orderNumber } })
    } catch (error) {
      console.log(error)
      setIsLoading(false)
      setIsSearchData(2)
    }
  }

  React.useEffect(() => {
    if (buttonType && odNumber && buttonType === 'search') {
      fetchOrderNumberData(odNumber)
    }
    // eslint-disable-next-line
  }, [buttonType])

  React.useEffect(() => {
    if (
      searchByOrderNumberData &&
      searchByOrderNumberData.getSearchByOrderNumber
    ) {
      setOrderNumberData([])
      setPriceLogicTableData([])
      const data = searchByOrderNumberData.getSearchByOrderNumber.result
      const res = JSON.parse(data)
      if (res) {
        prepareOrderNumberData(res, orderNum)
        setIsSearchData(1)
        setIsLoading(false)
      } else {
        setIsLoading(false)
        setIsSearchData(2)
      }
    }
  }, [searchByOrderNumberData])
  React.useEffect(() => {
    if (searchByPOData && searchByPOData.getSearchByPONumber) {
      const listpriceLogicTableData: any = []
      setOrderNumberData([])
      setPriceLogicTableData([])
      const data = searchByPOData.getSearchByPONumber.result
      if (data !== 'no result found') {
        const res = JSON.parse(data)
        if (res) {
          if (res.count === 1) {
            fetchOrderNumberData(res.orders[0].salesDocNumber)
          } else if (res.count === 0) {
            setIsLoading(false)
            setIsSearchData(2)
          } else {
            if (res && res.orders) {
              const orders = res.orders
              orders.forEach((item) => {
                const poNumberItem: any = {}
                poNumberItem.soQuoteNumber = item.salesDocNumber
                  ? item.salesDocNumber
                  : '--'
                poNumberItem.soQuoteStatus = item.status ? item.status : '--'
                poNumberItem.salesOrg = item.salesOrganization
                  ? item.salesOrganization
                  : '--'
                poNumberItem.billTo =
                  item.billTo && item.billTo !== 'null' ? item.billTo : '--'
                poNumberItem.shipTo =
                  item.shipTo && item.shipTo !== 'null' ? item.shipTo : '--'
                poNumberItem.soldTo =
                  item.soldTo && item.soldTo !== 'null' ? item.soldTo : '--'
                poNumberItem.payer =
                  item.payer && item.payer !== 'null' ? item.payer : '--'
                poNumberItem.dateCreated = item.orderDate ? item.orderDate : ''
                poNumberItem.type = item.type ? item.type : '--'
                listpriceLogicTableData.push(poNumberItem)
              })
              setPriceLogicTableData(listpriceLogicTableData)
              setIsSearchData(1)
            } else {
              setIsSearchData(2)
            }
            setIsLoading(false)
          }
        } else {
          setIsLoading(false)
          setIsSearchData(2)
        }
      } else {
        setIsLoading(false)
        setIsSearchData(2)
        if(searchByPOData.getSearchByPONumber.isSessionExpired){
          sessionStorage.removeItem('access_token')
          sessionStorage.removeItem('userId')
          router.push('/')
        }
      }
    }
  }, [searchByPOData])

  const fetchPONumberData = async (formData: any) => {
    setIsLoading(true)
    setIsSearchData(2)
    const inputData = {
      ponumber: formData.poNumber,
      soldTo: formData.soldToNumber,
      toDate: formData.startDate
        ? String(moment(formData.startDate).unix())
        : formData.startDate,
      fromDate: formData.endDate
        ? String(moment(formData.endDate).unix())
        : formData.endDate,
      country: formData.countryCode.toLocaleUpperCase(),
      accessToken: accessToken,
      userId: userId,
    }
    try {
      getSearchByPONumber({ variables: inputData })
    } catch (error) {
      console.log(error)
      setIsLoading(false)
      setIsSearchData(2)
    }
  }

  return (
    <div className={classes.boxCss}>
      <Grid
        container
        direction="row"
        justify="space-between"
        alignItems="flex-start"
      >
        <Grid item xs={5}>
          <Formik
            initialValues={initSearchByOrderNumberForm}
            validationSchema={orderNumberSchema}
            validateOnChange={false}
            validateOnBlur={false}
            onSubmit={(values, actions) => {
              setTimeout(() => {
                actions.validateForm(values)
                fetchOrderNumberData(values.orderNumber)
                actions.setSubmitting(false)
              }, 100)
            }}
          >
            {({ handleChange, handleSubmit, errors, values }) => (
              <form onSubmit={handleSubmit}>
                <Grid
                  container
                  direction="row"
                  justify="space-between"
                  alignItems="flex-start"
                >
                  <Grid item xs={8}>
                    <span className={clsx(classes.headingCss)}>
                      <FormattedMessage {...messages[`SEARCH_BY_ORDER_NO`]} />
                    </span>
                    <div
                      className={clsx(classes.paddingTop5, classes.marginTop3)}
                    >
                      <Field
                        name="orderNumber"
                        component={LiquidInputAdapter}
                        autoComplete="off"
                        label={
                          <span
                            className={
                              errors.orderNumber
                                ? classes.errorField
                                : classes.fontWeight700
                            }
                          >
                            <FormattedMessage {...messages[`ORDER_NUMBER`]} />
                          </span>
                        }
                        onChange={handleChange}
                        value={values.orderNumber}
                      />
                    </div>
                    <div>
                      <Button
                        size="large"
                        variant="contained"
                        color="primary"
                        type="submit"
                        className={clsx(classes.Button, classes.buttonSize)}
                      >
                        <FormattedMessage {...messages.SEARCH} />
                      </Button>
                    </div>
                  </Grid>
                  <Grid item xs={2}>
                    <div>
                      <Divider
                        orientation="vertical"
                        className={clsx(
                          classes.dividerColor,
                          classes.dividerHeight,
                          classes.dividerWidth
                        )}
                      />
                    </div>
                    <div
                      className={clsx(
                        classes.marginBottom4,
                        isIEBrowser()
                          ? classes.marginLeft20
                          : classes.marginLeft2,
                        classes.marginTop4
                      )}
                    >
                      OR
                    </div>
                    <div>
                      <Divider
                        orientation="vertical"
                        className={clsx(
                          classes.dividerColor,
                          classes.dividerHeight,
                          classes.dividerWidth
                        )}
                      />
                    </div>
                  </Grid>
                </Grid>
              </form>
            )}
          </Formik>
        </Grid>
        <Grid item xs={7}>
          <Formik
            initialValues={initSearchByPOForm}
            validationSchema={poNumberSchema}
            validateOnChange={false}
            validateOnBlur={false}
            onSubmit={(values, actions) => {
              setTimeout(() => {
                setIsSearchData(0)
                actions.validateForm(values)
                fetchPONumberData(values)
                actions.setSubmitting(false)
              }, 100)
            }}
          >
            {(props) => (
              <form onSubmit={props.handleSubmit}>
                <span className={classes.headingCss}>
                  <FormattedMessage {...messages[`SEARCH_BY_PO_NO`]} />
                </span>
                <Grid container spacing={2} direction="row">
                  <Grid item xs={6}>
                    <div
                      className={clsx(classes.paddingTop5, classes.marginTop3)}
                    >
                      <Field
                        name="poNumber"
                        component={LiquidInputAdapter}
                        autoComplete="off"
                        label={
                          <span
                            className={
                              props.errors.poNumber
                                ? classes.errorField
                                : classes.fontWeight700
                            }
                          >
                            <FormattedMessage {...messages[`PO_NUMBER`]} />
                          </span>
                        }
                        onChange={props.handleChange}
                        value={props.values.poNumber}
                      />
                    </div>
                  </Grid>
                  <Grid item xs={6} className={clsx(classes.marginTop3)}>
                    <Field
                      name="countryCode"
                      component={LiquidInputAdapter}
                      autoComplete="off"
                      className={classes.placeholder}
                      placeholder={'i.e JP'}
                      inputProps={{ maxLength: 2 }}
                      label={
                        <span>
                          <span
                            className={
                              props.errors.countryCode
                                ? classes.errorField
                                : classes.fontWeight700
                            }
                          >
                            <FormattedMessage {...messages[`COUNTRY_CODE`]} />
                          </span>

                          <Tooltip
                            title={
                              <FormattedMessage
                                {...messages.COUNTRY_CODE_POPOVER_MSG}
                              />
                            }
                            classes={{
                              tooltip: classes.InfoPopup,
                              arrow: classes.arrowColor,
                            }}
                            arrow
                            placement="bottom-start"
                          >
                            <InfoIcon
                              aria-label="info"
                              className={classes.InfoIcon}
                              color="primary"
                            ></InfoIcon>
                          </Tooltip>
                        </span>
                      }
                      onChange={props.handleChange}
                      value={props.values.countryCode.toLocaleUpperCase()}
                    />
                  </Grid>
                </Grid>

                <Grid
                  container
                  spacing={2}
                  direction="row"
                  className={clsx(classes.marginTop3)}
                >
                  <Grid item xs={6} className={clsx(classes.paddingTop5)}>
                    <Field
                      name="soldToNumber"
                      component={LiquidInputAdapter}
                      autoComplete="off"
                      label={
                        <span
                          className={
                            props.errors.soldToNumber
                              ? classes.errorField
                              : classes.fontWeight700
                          }
                        >
                          <FormattedMessage {...messages[`SOLD_TO_NUMBER`]} />
                        </span>
                      }
                      onChange={props.handleChange}
                      value={props.values.soldToNumber}
                    />
                  </Grid>
                  <Grid item xs={6} className={clsx(classes.paddingTop5)}>
                    <Field
                      name="startDate"
                      component={LiquidInputAdapter}
                      type="date"
                      className={classes.calender}
                      label={
                        <span
                          className={
                            props.errors.startDate
                              ? classes.errorField
                              : classes.fontWeight700
                          }
                        >
                          <FormattedMessage {...messages[`START_DATE`]} />
                        </span>
                      }
                      onChange={props.handleChange}
                      value={props.values.startDate}
                    />
                  </Grid>
                </Grid>

                <Grid
                  container
                  spacing={2}
                  direction="row"
                  className={clsx(classes.marginTop3)}
                >
                  <Grid item xs={6} className={clsx(classes.paddingTop5)}>
                    <Field
                      name="endDate"
                      component={LiquidInputAdapter}
                      type="date"
                      className={classes.calender}
                      label={
                        <span
                          className={
                            props.errors.endDate
                              ? classes.errorField
                              : classes.fontWeight700
                          }
                        >
                          <FormattedMessage {...messages[`END_DATE`]} />
                        </span>
                      }
                      onChange={props.handleChange}
                      value={props.values.endDate}
                    />
                  </Grid>
                </Grid>
                <Grid
                  container
                  spacing={4}
                  direction="row"
                  className={clsx(classes.marginTop3)}
                >
                  <Grid item xs={3} className={clsx(classes.paddingTop5)}>
                    <Button
                      variant="contained"
                      color="primary"
                      type="submit"
                      className={classes.Button}
                    >
                      <FormattedMessage {...messages.SEARCH} />
                    </Button>
                  </Grid>
                  <Grid item xs={3} className={clsx(classes.paddingTop5)}>
                    <Button
                      variant="outlined"
                      className={clsx(
                        classes.Button,
                        classes.greyColor,
                        classes.width20
                      )}
                      onClick={() => {
                        setPriceLogicTableData([])
                        setOrderNumberData([])
                        props.handleReset()
                        setIsSearchData(0)
                      }}
                    >
                      <FormattedMessage {...messages.RESET} />
                    </Button>
                  </Grid>
                </Grid>
              </form>
            )}
          </Formik>
        </Grid>
      </Grid>
    </div>
  )
}

export default PriceLogicForm
