import React from 'react'
import clsx from 'clsx'
import useStyles from '../../../theme/style'
import { FormattedMessage } from 'react-intl'
import messages from '../../../utils/messages'
import { withStyles, Theme, createStyles } from '@material-ui/core/styles'
import Table from '@material-ui/core/Table'
import TableBody from '@material-ui/core/TableBody'
import TableCell from '@material-ui/core/TableCell'
import TableContainer from '@material-ui/core/TableContainer'
import TableHead from '@material-ui/core/TableHead'
import TableRow from '@material-ui/core/TableRow'
import Paper from '@material-ui/core/Paper'
import ExpansionPanel from './ExpansionPanel'
import moment from 'moment'

const StyledTableCell = withStyles((theme: Theme) =>
  createStyles({
    head: {
      backgroundColor: '#f8f8fc',
      fontSize: 12,
      fontWeight: 900,
      fontStretch: 'normal',
      fontStyle: 'normal',
      lineHeight: '1.25',
      letterSpacing: 'normal',
      textAlign: 'left',
      borderBottom: '1px solid #949494',
      borderTop: '1px solid #949494',
      color: theme.palette.common.black
    },
    body: {
      fontSize: 12
    }
  })
)(TableCell)

const StyledTableRow = withStyles((theme: Theme) =>
  createStyles({
    root: {
      '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.common.white
      }
    }
  })
)(TableRow)

interface SearchResultProps {
  priceLogicTableData: any
  orderNumberData: any
}

const SearchResult: React.FC<SearchResultProps> = props => {
  const classes = useStyles()
  const { priceLogicTableData, orderNumberData } = props

  return (
    <div className={clsx(classes.priceLogicSearchBox, classes.marginTop4)}>
      <div>
        <span className={clsx(classes.headingCss)}>
          <FormattedMessage {...messages[`SEARCH_RESULTS`]} />
        </span>
        <div>
          <TableContainer
            component={Paper}
            className={clsx(classes.marginTop4, classes.table)}
          >
            <Table aria-label="customized table">
              <TableHead>
                <TableRow>
                  <StyledTableCell>
                    <FormattedMessage {...messages[`SO_QUOTE_NUMBER`]} />
                  </StyledTableCell>
                  <StyledTableCell>
                    <FormattedMessage {...messages[`TYPE`]} />
                  </StyledTableCell>
                  <StyledTableCell>
                    <FormattedMessage {...messages[`Sales_ORG`]} />
                  </StyledTableCell>
                  <StyledTableCell align="right">
                    <FormattedMessage {...messages[`SOLD_TO`]} />
                  </StyledTableCell>
                  <StyledTableCell align="right">
                    <FormattedMessage {...messages[`SHIP_TO`]} />
                  </StyledTableCell>
                  <StyledTableCell align="right">
                    <FormattedMessage {...messages[`BILL_TO`]} />
                  </StyledTableCell>
                  <StyledTableCell align="right">
                    <FormattedMessage {...messages[`PAYER`]} />
                  </StyledTableCell>
                  <StyledTableCell align="right">
                    <FormattedMessage {...messages[`DATE_CREATED`]} />
                  </StyledTableCell>
                  <StyledTableCell align="right">
                    <FormattedMessage {...messages[`SO_QUOTE_STATUS`]} />
                  </StyledTableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {priceLogicTableData.map((row: any, index: any) => (
                  <StyledTableRow key={index}>
                    <StyledTableCell
                      component="th"
                      scope="row"
                      className={classes.borderBottom}
                    >
                      {priceLogicTableData.length === 1 ? (
                        row.soQuoteNumber
                      ) : (
                        <a
                          className={clsx(classes.blueColor,classes.fontWeight700)}
                          href={`?orderNumber=${row.soQuoteNumber}&type=search`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {row.soQuoteNumber}
                        </a>
                      )}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={classes.borderBottom}
                    >
                      {row.type}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={classes.borderBottom}
                    >
                      {row.salesOrg}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={classes.borderBottom}
                    >
                      {row.soldTo}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={classes.borderBottom}
                    >
                      {row.shipTo}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={classes.borderBottom}
                    >
                      {row.billTo}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={classes.borderBottom}
                    >
                      {row.payer}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={classes.borderBottom}
                    >
                      {row.dateCreated
                        ? moment(row.dateCreated).format('DD/MM/YYYY')
                        : '--'}
                    </StyledTableCell>
                    <StyledTableCell
                      align="left"
                      className={classes.borderBottom}
                    >
                      {row.soQuoteStatus}
                    </StyledTableCell>
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
        <ExpansionPanel orderNumberData={orderNumberData} />
      </div>
    </div>
  )
}

export default SearchResult
