import React from 'react'
import PriceLogicForm from './PriceLogicForm'
import SearchResult from './SearchResult'
import { initTableData } from '../InitialValues'
import NoResult from '../Component/NoResultFound'
import { useIntl } from 'react-intl'
import messages from '../../../utils/messages'
import * as querySearch from 'query-string'

const PriceLogic: React.FC<{}> = () => {
  const intl = useIntl()

  let odrNumber: any = ''
  let bType: any = ''
  // eslint-disable-next-line no-restricted-globals
  const parsed = querySearch.parse(location.search)
  if (parsed) {
    odrNumber = parsed.orderNumber
    bType = parsed.type
    // eslint-disable-next-line no-restricted-globals
    history.pushState('', '', './price-logic')
  }

  // This is to display the data on table
  const [priceLogicTableData, setPriceLogicTableData] = React.useState([
    initTableData,
  ])

  // 0 - hide search table
  // 1 - display with data
  // 2- No resutl found
  const [isSearchData, setIsSearchData] = React.useState(0)

  // This contains the order number
  const [orderNumberData, setOrderNumberData] = React.useState([])

  // This is to set the status of loading
  const [isLoading, setIsLoading] = React.useState(false)


  return (
    <div>
      <PriceLogicForm
        setOrderNumberData={setOrderNumberData}
        setPriceLogicTableData={setPriceLogicTableData}
        setIsSearchData={setIsSearchData}
        setIsLoading={setIsLoading}
        odNumber={odrNumber ? odrNumber : ''}
        buttonType={bType ? bType : ''}
      />
      {isSearchData === 0 ? (
        ''
      ) : isSearchData === 1 ? (
        <SearchResult
          orderNumberData={orderNumberData}
          priceLogicTableData={priceLogicTableData}
        />
      ) : (
        <NoResult
          heading={intl.formatMessage(messages[`SEARCH_RESULTS`])}
          message={intl.formatMessage(messages[`PRICE_LOGIC_NO_RESULT_FOUND`])}
          isLoading={isLoading}
        />
      )}
    </div>
  )
}

export default PriceLogic
