import {
  PriceLogicData,
  PriceLogicPanelData,
  PriceLogicDataTableData,
  SearchByPONumber
} from './Interfaces'

export const initPanelData: PriceLogicPanelData = {
  webOrderNumber: '',
  orderItemId: '',
  productType: '',
  type: '',
  configuration: '',
  specification: '',
  shipTo: '',
  soldTo: '',
  billTo: '',
  payer: '',
  customerPricing: '',
  price: '',
  currency: '',
  sapOrderNumber: '',
  priority: ''
}

export const initTableData: PriceLogicDataTableData = {
  soQuoteNumber: '',
  type: '',
  salesOrg: '',
  soldTo: '',
  shipTo: '',
  billTo: '',
  payer: '',
  dateCreated: '',
  soQuoteStatus: ''
}
export const initPriceLogic: PriceLogicData = {
  priceLogicPanelData: [initPanelData],
  priceLogicTableData: [initTableData]
}

export const initSearchByPOForm: SearchByPONumber = {
  poNumber: '',
  countryCode: '',
  soldToNumber: '',
  startDate: '',
  endDate: ''
}

