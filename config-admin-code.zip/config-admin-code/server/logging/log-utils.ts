export const scrubObject = (
  obj: {} | Array<any>,
  blacklist: string[]
): {} | [] => {
  if (obj instanceof Array) {
    // Handle Arrays
    return obj.map((item) => scrubObject(item, blacklist))
  } else if (obj) {
    // Handle Objects
    return Object.keys(obj).reduce((acc, key) => {
      if (obj[key] && obj[key] instanceof Object) {
        return {
          ...acc,
          ...{ [key]: scrubObject(obj[key], blacklist) },
        }
      } else {
        return blacklist.includes(key as string)
          ? {
              ...acc,
              ...{ [key]: '[REDACTED]' },
            }
          : acc
      }
    }, obj)
  } else {
    // Handle `typeof null === 'object'`
    return obj
  }
}
