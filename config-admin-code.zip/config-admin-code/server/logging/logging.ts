import pino, { PrettyOptions, Logger } from 'pino'
import { scrubObject } from './log-utils'

const isDevelopment = process.env.NODE_ENV === 'development'

// Configuration options via http://getpino.io/#/docs/api

export const logger: Logger = pino({
  name: 'nodejs-config-admin-tool',
  level: 'error',
  prettyPrint: isDevelopment
    ? ({
        ignore: 'pid,hostname',
        translateTime: true,
        levelFirst: true,
      } as PrettyOptions)
    : false,
})

const blacklist = [
  'password',
  'confirmPassword',
  'newPassword',
  'newPasswordConfirm',
  'passwordConfirmation',
  'accessToken',
]

export const logLevels = Object.values(logger.levels.labels)
/**
 * Pino's redaction capability is limited because it requires
 * you to know the path to all sensitive keys which isn't ideal.
 *
 *  e.g. ['path.to[*].sensitive.key','data.password']
 *  see: http://getpino.io/#/docs/redaction
 *
 * Also, you must pass this list in when initializing the logger.
 * Instead, we create a proxy object to override the logging functions to
 * enable scrubbing nested, sensitive information. With this, we
 * can look for sensitive keys anywhere in the object that is passed,
 * without knowing the path ahead of time.
 *
 *   e.g.
 *    log.info({
 *      normal: "information",
 *      password: "scrubthis",
 *      nestedObj: {
 *        passwordConfirmation: "scrubthistoo",
 *        email: "me@example.com"
 *      }
 *    })
 **/
export const log = new Proxy(logger, {
  get(target: Logger, prop: string) {
    if (logLevels.includes(prop as string)) {
      // It's a logging call, return our own function
      return (
        mergingObjectOrMessage: string | {},
        message?: string,
        ...interpolationValues: []
      ): void =>
        target[prop as string](
          typeof mergingObjectOrMessage === 'object'
            ? scrubObject(mergingObjectOrMessage, blacklist)
            : mergingObjectOrMessage,
          message || '',
          ...interpolationValues
        )
    } else {
      // It's an internal/other call in Pino, return the original
      return target[prop as string]
    }
  },
})
