import next from 'next'
import Router from 'koa-router'
import Koa from 'koa'
import attachGraphQLServer from './graphql'
import http, { Server as HttpServer } from 'http'
import { configuratorProxyMiddleware } from './ConfiguratorProxy'
import { healthCheckMiddleware } from './HealthCheck'
import config from 'config'


const {
  port
} = config.get('app')

const router = new Router()
const app = new Koa()
attachGraphQLServer(app)
const isDev = process.env.NODE_ENV !== 'production'
const nextApp = next({ dev: isDev })
const handle = nextApp.getRequestHandler()

async function init() {
  try {
    await nextApp.prepare()

    app.use(healthCheckMiddleware())
    app.use(configuratorProxyMiddleware())
    router.get('/auth/openid/return', async (ctx) => {
      await nextApp.render(ctx.req, ctx.res, '/auth', ctx.query)
      ctx.respond = false
    })

    router.get('(.*)', async (ctx) => {
      await handle(ctx.req, ctx.res)
      ctx.respond = false
    })
    app.use(router.routes())
    let serverApp: HttpServer
    serverApp = http.createServer(app.callback())
    serverApp.listen(port, () => console.info(`> Ready on http://localhost:${port} 🚀`))
  } catch (err) {
    console.error(err)
  }
}


init()
