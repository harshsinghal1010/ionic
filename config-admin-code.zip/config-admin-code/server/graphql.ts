import Koa from 'koa'
import { ApolloServer } from 'apollo-server-koa'
import typeDefs from './graphql/types'
import {adminToolResolver} from './graphql/resolvers'

/**
 * Configure a new Apollo Server and attach it to the existing Koa server
 */
const attachGraphQLServer = (app: Koa) => {
  const server = new ApolloServer({
    typeDefs: typeDefs,
    resolvers: adminToolResolver as any,
  })

  server.applyMiddleware({
    path: '/api',
    cors: {
      origin: '*',
      credentials: true,
    },
    app,
  })
}

export default attachGraphQLServer
