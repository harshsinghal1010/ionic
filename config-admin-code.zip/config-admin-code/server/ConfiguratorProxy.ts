import config from 'config'
import Router from '@koa/router'
import koaProxy from 'koa-proxy'
import { log } from './logging'
import url from 'url'

const { scheme, host, port, version } = config.get('configurators')

export const configuratorProxyMiddleware = () => {
  const router = new Router()
  //http://uc1a-ecomdev-mlb01.sial.com:30012/pc/price/api/v2/pricedata/US?soldTo=&shipTo=&billTo=&payer=&isSapNextEnabled=true

  router.get('/config/priceList/:path*', async (ctx, next) => {
    const { soldTo, shipTo, billTo, payer } = ctx.request.query

    const proxyUrl = url.format({
      protocol: scheme,
      hostname: host,
      port: port,
      pathname: `pc/price/api/${version}/pricedata/${ctx.params.path}`,
      query: {
        soldTo,
        shipTo,
        billTo,
        payer,
      },
    })
    const proxy = koaProxy({
      url: proxyUrl,
      // trust self-signed certificates
      requestOptions: {
        strictSSL: false,
      },
    })
    try {
      await proxy(ctx, next)
    } catch (e) {
      log.error(e, `Error proxying from ${proxyUrl}`)
    }
  })
  return router.routes()
}
