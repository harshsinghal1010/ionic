import Router from '@koa/router'
import os from 'os'

export const healthCheckMiddleware = () => {
  const router = new Router()

  router.get('/health-check', async (ctx) => {
    const [one, five, fifteen] = os.loadavg()
    ctx.status = 200
    ctx.body = {
      status: 'up',
      timestamp: new Date().toISOString(),
      nodeProcess: {
        uptime: process.uptime(),
        cpu: process.cpuUsage(),
        memory: process.memoryUsage(),
      },
      system: {
        uptime: os.uptime(),
        freemem: os.freemem(),
        loadavg: { 1: one, 5: five, 15: fifteen },
      },
    }
  })

  return router.routes()
}
