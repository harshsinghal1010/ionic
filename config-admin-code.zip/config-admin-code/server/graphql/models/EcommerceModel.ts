import {
  login,
  getProductConfiguration,
  getProductConfigurationByCartId,
  getSearchByPONumber,
  getMetadata,
} from '../api/EcommerceAPI'

import { getBearerToken } from '../api/AuthAPI'
import { getSearchByOrderNumber } from '../api/ConfiguratorAPI'

interface EcommerceModel {
  loginModel(data: any): Promise<any>
  getProductConfiguration(input: any): Promise<any>
  getProductConfigurationByCartId(input: any): Promise<any>
  getSearchByPONumber(input: any): Promise<any>
  getBearerToken(input: any): Promise<any>
  getSearchByOrderNumber(input: any): Promise<any>
  getMetadata(input: any): Promise<any>
}

export const ecommerceModel: EcommerceModel = {
  loginModel: async (data) => {
    const res = await login(data)
    if (!res.error) {
      return {
        accessToken: res.accessToken,
      }
    } else {
      return {
        accessToken: 'no result found',
      }
    }
  },
  getProductConfiguration: async (input) => {
    const res = await getProductConfiguration(input)
    if (!res.error) {
      return {
        isSessionExpired: false,
        configuration: res.productConfiguration.configuration.map((data) => ({
          name: data.name,
          sapCharc: data.sapCharc,
          value: data.value,
        })),
        metaData: res.productConfiguration.metaData.map((data) => ({
          name: data.name,
          value: data.value,
        })),
        itemTexts: res.productConfiguration.itemTexts.map((data) => ({
          name: data.key,
          value: data.value,
        })),
      }
    } else {
      if (res.error.value === 'USER_JWT_TOKEN_INVALID_OR_EXPIRED') {
        return {
          isSessionExpired: true,
          configuration: [],
          metaData: [],
          itemTexts: [],
        }
      } else {
        return {
          isSessionExpired: false,
          configuration: [],
          metaData: [],
          itemTexts: [],
        }
      }
    }
  },
  getProductConfigurationByCartId: async (input) => {
    const res = await getProductConfigurationByCartId(input)
    if (!res.error) {
      return {
        isSessionExpired: false,
        configuration: res[0].productConfiguration.configuration.map((data) => ({
          name: data.name,
          sapCharc: data.sapCharc,
          value: data.value,
        })),
        metaData: res[0].productConfiguration.metaData.map((data) => ({
          name: data.name,
          value: data.value,
        })),
        itemTexts: res[0].productConfiguration.itemTexts.map((data) => ({
          name: data.key,
          value: data.value,
        })),
      }
    } else {
      if (res.error.value === 'USER_JWT_TOKEN_INVALID_OR_EXPIRED') {
        return {
          isSessionExpired: true,
          configuration: [],
          metaData: [],
          itemTexts: [],
        }
      } else {
        return {
          isSessionExpired: false,
          configuration: [],
          metaData: [],
          itemTexts: [],
        }
      }
    }
  },
  getSearchByPONumber: async (data) => {
    const res = await getSearchByPONumber(data)
    if (!res.error) {
      return {
        isSessionExpired: false,
        result: JSON.stringify(res),
      }
    }
    else {
      if (res.error.value === 'USER_JWT_TOKEN_INVALID_OR_EXPIRED') {
        return {
          isSessionExpired: true,
          result: 'no result found',
        }
      } else {
        return {
          isSessionExpired: false,
          result: 'no result found',
        }
      }
    }



  },
  getSearchByOrderNumber: async (data) => {
    const res = await getSearchByOrderNumber(data)
    if (!res.error) {
      return {
        result: JSON.stringify(res),
      }
    } else {
      return {
        result: 'no result found',
      }
    }
  },
  getBearerToken: async (data) => {
    const res = await getBearerToken(data)
    if (!res.error) {
      return {
        access_token: res.access_token,
        token_type: res.token_type,
        expires_in: res.expires_in,
        refresh_token: res.refresh_token,
        scope: res.scope,
      }
    } else {
      return null
    }
  },
  getMetadata: async (data) => {
    const res = await getMetadata(data)
    if (!res.error) {
      return {
        adEmailId: res.adEmailId,
        appMetaDataList: res.appMetaDataList.map((data) => ({
          appName: data.appName,
          contextPath: data.contextPath,
          altPersonas: data.altPersonas.map((item) => ({
            name: item.name,
            userId: item.userId,
            logonId: item.logonId,
            email: item.email,
          })),
        })),
      }
    } else {
      return 'Invalid User'
    }
  },
}
