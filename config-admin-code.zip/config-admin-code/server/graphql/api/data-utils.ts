import http from 'http'
import https from 'https'
import axios, { AxiosRequestConfig, AxiosInstance, AxiosError } from 'axios'
import { HttpError } from './errors/HttpError'
import { pick } from 'lodash'
import { ErrorCodes } from './error-codes'
import { log } from '../../logging'

export const DEFAULT_TIMEOUT = 300000

export interface ParsedResponse {
  message: string
  code: string
  status: number
  stack?: string
  responseData: any
  request: {
    url?: string
    path?: string
    method?: string
    params?: { [index: string]: string }
    data?: any
    headers?: { [index: string]: string }
  }
  ecommerceErrors?: any[]
  catalogError?: any
}

export type AxiosResponseParser = (axiosError: AxiosError) => ParsedResponse

/**
 * Factory function to generate an axios instance with error interceptors already added. Use
 * this anytime you need to make a network call instead of invoking axios directly.
 */
export const httpFactory = (
  options: AxiosRequestConfig,
  responseParser: AxiosResponseParser = defaultAxiosResponseParser
) => (functionCalled: string): AxiosInstance => {
  const httpHandler = axios.create({
    ...{
      httpAgent: new http.Agent({
        timeout: DEFAULT_TIMEOUT,
      }),
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
        timeout: DEFAULT_TIMEOUT,
      }),
      timeout: DEFAULT_TIMEOUT,
      defaultTimeout: DEFAULT_TIMEOUT,
      maxRedirects: 0,
    },
    ...options,
  })
  let request
  let start
  let time
  httpHandler.interceptors.request.use((req) => {
    start = Date.now()
    request = req
    return req
  })

  httpHandler.defaults.timeout = DEFAULT_TIMEOUT
  httpHandler.interceptors.response.use(
    (res) => {
      time = Date.now() - start
      log.info(
        `✅ ${functionCalled} ${
          res.status
        }: ${res.config.method?.toUpperCase()} ${time}ms ${
          res.config.url
        }?${decodeURIComponent(new URLSearchParams(request.params).toString())}
        `
      )
      return res
    },
    (axiosError) => {
      time = Date.now() - start
      const errorStr = `
         ⛔️ ${axiosError}
         URL: ${request.method.toUpperCase()} ${request.url} ${time}ms
         Params: ${JSON.stringify(request.params)}
         Headers: ${JSON.stringify(request.headers)}
        `
      log.error(errorStr)
      throw new HttpError(axiosError, responseParser)
    }
  )

  return httpHandler
}

/**
 * Utility function to extract the relevant information from an Axios error. If
 * no axios response parser is provided to HttpError, this one is used by default.
 */
export function defaultAxiosResponseParser({
  response,
  stack,
}: AxiosError): ParsedResponse {
  if (!response) throw new Error('Missing response')

  return {
    message: 'HTTP Request Error',
    code: ErrorCodes.HTTP_ERROR,
    status: response.status,
    responseData: response.data,
    stack: stack,
    request: {
      ...pick(response.config, ['url', 'params', 'method', 'data', 'headers']),
      path: response.request && response.request.path,
    },
  }
}

