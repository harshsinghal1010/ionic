import { httpFactory } from './data-utils'
import config from 'config'
const { scheme, host, port, version } = config.get('configurators')
const options = {
  baseURL: `${scheme}://${host}:${port}/pc/price/api/${version}`,
}
const http = httpFactory(options)

export const getSearchByOrderNumber = async (input) => {
  let res
  try {
    res = await http('getSearchByOrderNumber').get(
      `/priceaudit/${input.orderNumber}`,
      {}
    )
  } catch (error) {
    res = {
      data: {
        error: {
          key: error.response.status,
          value: 'HTTP_ERROR',
        },
      },
    }
  }
  return res.data
}
