import { httpFactory } from './data-utils'
import config from 'config'
const { scheme, host, port } = config.get('ecom')
const options = {
  baseURL: `${scheme}://${host}:${port}/ecommerce`,
}
const http = httpFactory(options)

export const login = async (data) => {
  let res
  try {
    res = await http('login').post(`/v3/login`, data)
  } catch (error) {
    res = {
      data: {
        error: {
          key: error.response.status,
          value: 'HTTP_ERROR',
        },
      },
    }
  }
  return res.data
}

export const getProductConfiguration = async (input) => {
  let res
  try {
    res = await http('getProductConfiguration').get(
      `/v3/productconfigurations/${input.configID}`, {
        headers: {
          'Authorization': input.accessToken ,
          'x-ms-run-as': input.userId
        },
      }
    )
  } catch (error) {
    if(error.response.status===403){
      res = {
        data: {
          error: {
            key: error.response.status,
            value: error.response.data.errorCodes[0].errorCode,
          },
        },
      }
    }else{
      res = {
        data: {
          error: {
            key: error.response.status,
            value: 'HTTP_ERROR',
          },
        },
      }
    }
   
  }
  return res.data
}
export const getProductConfigurationByCartId = async (input) => {
  let res
  try {
    res = await http('getProductConfigurationByCartId').get(
      `/v3/orders/${input.cartId}/items?item=${input.cartItemId}`, {
        headers: {
          'Authorization': input.accessToken ,
          'x-ms-run-as': input.userId
        },
      }
    )
  } catch (error) {
    if(error.response.status===403){
      res = {
        data: {
          error: {
            key: error.response.status,
            value: error.response.data.errorCodes[0].errorCode,
          },
        },
      }
    }else{
      res = {
        data: {
          error: {
            key: error.response.status,
            value: 'HTTP_ERROR',
          },
        },
      }
    }
  }
  return res.data
}
export const getSearchByPONumber = async (input) => {
  let res
  try {
    res = await http('getSearchByPONumber').get(
      `/v3/orders?requesttype=erp&ponumber=${input.poNumber}&soldTo=${input.soldTo}&toDate=${input.toDate}&fromDate=${input.fromDate}`, {
        headers: {
          'Authorization': input.accessToken,
          'x-ms-run-as': input.userId,
          'country': input.country
        },
      }
    )
  } catch (error) {
    if(error.response.status===403){
      res = {
        data: {
          error: {
            key: error.response.status,
            value: error.response.data.errorCodes[0].errorCode,
          },
        },
      }
    }else{
      res = {
        data: {
          error: {
            key: error.response.status,
            value: 'HTTP_ERROR',
          },
        },
      }
    }
  }
  return res.data
}
export const getMetadata = async (input) => {
  let res
  try {
    res = await http('getMetadata').get(
      `/v3/internalapps/metdata`, {
        headers: {
          'Authorization': `Bearer ${input.token}`,
        },
      }
    )
  } catch (error) {
    res = {
      data: {
        error: {
          key: error.response.status,
          value: 'HTTP_ERROR',
        },
      },
    }
  }
  return res.data
}
