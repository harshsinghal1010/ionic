import { ApolloError } from 'apollo-server-koa'
import { AxiosError } from 'axios'
import pick from 'lodash/pick'
import { ParsedResponse, AxiosResponseParser } from '../data-utils'
import { ErrorCodes } from '../error-codes'

const  enableTracing  = true
export const DEFAULT_MESSAGE = 'HTTP Request Error'

/**
 * Converts an Axios-generated error into an error that Apollo can handle automatically.
 *
 * Axios can return three types of errors:
 *
 * 1. The server responded with a status code that falls out of the range of 2xx. We can
 *    use the response body to get more insight into the failure because the server responded.
 * 2. The request was made but no response was received (maybe a timeout?)
 * 3. Something happened in setting up the request that triggered an error
 *
 * TODO: This cannot currently be unit tested because of a Babel configuration issue.
 * TypeError: Class constructor ApolloError cannot be invoked without 'new'.
 *
 * Related issues:
 *    https://github.com/apollographql/apollo-server/issues/1304
 *    https://github.com/babel/babel/issues/4269
 */
export class HttpError extends ApolloError {
  constructor(originalError: AxiosError, responseParser: AxiosResponseParser) {
    if (originalError.response) {
      // The server responded with a status code that falls out of the range of 2xx

      let parsedResponse: ParsedResponse
      try {
        parsedResponse = responseParser(originalError)
      } catch (e) {
        super(DEFAULT_MESSAGE, ErrorCodes.HTTP_ERROR, {
          stack: enableTracing ? originalError.stack : null,
        })
        return
      }

      super(parsedResponse.message, parsedResponse.code, {
        stack: enableTracing ? parsedResponse.stack : null,
        response: {
          status: parsedResponse.status,
          data: parsedResponse.responseData,
        },
        request: parsedResponse.request,
        ecommerceErrors: parsedResponse.ecommerceErrors,
        catalogError: parsedResponse.catalogError,
      })
    } else if (originalError.request) {
      // The request was made but no response was received
      super(DEFAULT_MESSAGE, ErrorCodes.HTTP_ERROR, {
        stack: enableTracing ? originalError.stack : null,
        request: pick(originalError.request._options, [
          'protocol',
          'path',
          'method',
          'headers',
          'hostname',
          'port',
        ]),
      })
    } else {
      // Something happened in setting up the request that triggered an error
      super(DEFAULT_MESSAGE, ErrorCodes.HTTP_ERROR, {
        stack: enableTracing ? originalError.stack : null,
        errorMessage: originalError.message,
      })
    }
  }
}
