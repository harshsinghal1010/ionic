import { httpFactory } from './data-utils'
import config from 'config'
const { scheme, host } = config.get('sso')
const options = {
  baseURL: `${scheme}://${host}/auth`,
}
const http = httpFactory(options)

export const getBearerToken = async (input) => {
  let res
  const params = `code=${input.code}&state=${input.state}&session_state=${input.session_state}`
  try {
    res = await http('getBearerToken').get(`/v1/oauth2/token?${params}`, {})
  } catch (error) {
    console.log("Error in getBearerToken", error)
    res = {
      data: {
        error: {
          key: error,
          value: 'HTTP_ERROR',
        },
      },
    }
  }
  return res.data
}
