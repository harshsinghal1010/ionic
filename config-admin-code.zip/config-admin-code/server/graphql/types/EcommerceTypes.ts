import gql from 'graphql-tag'

export const EcommerceSchema = gql`
  type Query {
    getProductConfiguration(
      configID: String
      accessToken: String
      userId: String
    ): ProductConfigurations
    getProductConfigurationByCartId(
      cartId: String
      cartItemId: String
      accessToken: String
      userId: String
    ): ProductConfigurations
    getSearchByOrderNumber(
      orderNumber: String
    ): SearchData
    getSearchByPONumber(
      country: String
      soldTo: String
      toDate: String
      fromDate: String
      ponumber: String
      accessToken: String
      userId: String
    ): SearchData
    getURL: ConfiguratorURL
    getAuthURL: authURL
    getBearerToken(
      code: String!
      state: String!
      session_state: String!
    ): AzureTokenResponse
    getMetadata(token: String): userData
  }
  type Mutation {
    login(userName: String, password: String): Login!
  }
  type SearchData {
    isSessionExpired: Boolean
    result: String
  }
  type Login {
    accessToken: String
  }
  type ConfiguratorURL {
    host: String
    scheme: String
    port: String
    version: String
  }

  type AzureTokenResponse {
    access_token: String
    token_type: String
    expires_in: Int
    refresh_token: String
    scope: String
  }

  type authURL {
    host: String
    scheme: String
  }

  type Configurations {
    name: String
    sapCharc: String
    value: String
  }

  type KeyValue {
    name: String
    value: String
  }

  type ProductConfigurations {
    isSessionExpired: Boolean
    configuration: [Configurations]
    itemTexts: [KeyValue]
    metaData: [KeyValue]
  }

  type AltPersonas {
    name: String
    userId: String
    logonId: String
    email: String
  }
  type AppMetaData {
    appName: String
    contextPath: String
    altPersonas: [AltPersonas]
  }
  type userData {
    adEmailId: String
    appMetaDataList: [AppMetaData]
  }
`
