import { EcommerceSchema } from './EcommerceTypes'

export default [EcommerceSchema]
