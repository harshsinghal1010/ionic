import { ecommerceModel } from '../models/EcommerceModel'
import config from 'config'

const { scheme, host, port, version } = config.get('configurators')
const { scheme:ssoSchema, host:ssoHost } = config.get('sso')

const configuratorURL = {
  scheme: scheme,
  host: host,
  port: port,
  version: version,
}

const ssoURL = {
  scheme: ssoSchema,
  host: ssoHost
}

// Query
const getProductConfiguration = (_, input) =>
  ecommerceModel.getProductConfiguration(input)
const getProductConfigurationByCartId = (_, input) =>
  ecommerceModel.getProductConfigurationByCartId(input)
const getSearchByPONumber = (_, input) =>
  ecommerceModel.getSearchByPONumber(input)
const getURL = () => configuratorURL
const getAuthURL = () => ssoURL
const getBearerToken = (_,input) => ecommerceModel.getBearerToken(input)
const getSearchByOrderNumber = (_,input) => ecommerceModel.getSearchByOrderNumber(input)
const getMetadata = (_,input) => ecommerceModel.getMetadata(input)


// Mutation
const login = (_, data) => ecommerceModel.loginModel(data)

export const resolvers = {
  Query: {
    getProductConfigurationByCartId,
    getProductConfiguration,
    getSearchByPONumber,
    getURL,
    getAuthURL,
    getBearerToken,
    getSearchByOrderNumber,
    getMetadata
  },
  Mutation: {
    login,
  },
}
