import { resolvers } from './EcommerceResolver'
import merge from 'lodash/merge'

export const adminToolResolver = merge(resolvers)
