// Local development configuration for `next-commerce-china`
// Takes precedence when process.env.NODE_ENV=development
// See https://github.com/lorenwest/node-config/wiki for additional documentation
//
// Any values added/removed here should also be aliased to an environment variable in `custom-environment-variables.yaml`
//
// Access config variables from '/src' directory
// For example,
//
// import getConfig from 'next/config'
// const {
//   publicRuntimeConfig: {
//     sourcingServer: { host, scheme, port },
//   },
// } = getConfig()
//
// --------------------------------------
//
// Access config variables from '/server' directory
// For example,
//
// import config from 'config'
// const { scheme, host, port } = config.get('ecom')
const US_DEV_ECOM_LB = 'uc1a-ecomdev-mlb01.sial.com'
const SSO_HOST = 'sialauthservice-ud.milliporesigma.io'

const config = {
  ecom: {
    scheme: 'http',
    host: 'ecommerceweb-ud.milliporesigma.io',
    port: '80'
  },
  configurators: {
    scheme: 'http',
    host: 'configurator-ud.milliporesigma.io',
    port: '80',
    version: 'v2',
  },   
  sso: {
    scheme: 'https',
    host: SSO_HOST
  },  
  app: {
    port: 4000
  }
}

module.exports = config
