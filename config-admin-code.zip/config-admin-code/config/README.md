# Next Commerce Config

Most often you will reference this document when testing a feature in a specific
region and environment.

## Steps to Change Dev/QA/Prod Configuration

See the steps to make configuration changes in the
`config/custom-environment-variables.js` file.

## Configuration Management

The configuration files are located in `/config` and correspond to the relating
'NODE_ENV' that they are run in.

- `development.js` is referenced when `process.env.NODE_ENV=development`, or
  when you as a developer are doing local development.

- `test.js` is referenced when `process.env.NODE_ENV=test`.

- `default.js` is _always_ referenced as the base config file that will be
  overridden. Anything that is a constant or application default should be
  described here.

- `custom-environment-variables.js` is a mapper file that reads the global
  `process.ENV` and maps values to their corresponding keys. For example,
  `process.ENV.PORT` will change depending on the final deployment target, so we
  map it to `config.port` here.

- `local.js` or `*env.local.js` are optional files you can create and will be
  gitignored. This can be for any config you want to describe locally for your
  own development purposes.

For more information about the `config` module, see the
[official node-config docs](https://github.com/lorenwest/node-config)

## local.js

First, create the `local.js`

```bash
touch local.js
```

Then paste the following into `local.js` at this point, you can make any
required overrides.

```javascript
/* eslint-disable-next-line @typescript-eslint/no-var-requires */
const devConfig = require('./development.js')
const config = {
  ...devConfig,
}

module.exports = config
```

### Environments and Regions

Often will need to set our `local.js` to other environments and or regions.

We can copy the relevant section (or all of them) and replace `US_DEV_ECOM_LB`
value with our required values.
