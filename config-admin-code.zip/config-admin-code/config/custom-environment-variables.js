// This file associates application configuration with environment variables. These variables are injected into
// both `nodejs-ecom` and `nodejs-ecomchina` for the `development`, `qa`, and `production` deployments
// See https://github.com/lorenwest/node-config/wiki/Environment-Variables#custom-environment-variables
//
// Ensure any configuration changes are communicated to the web admin teams by following these steps:
// 1. Create a new ticket for the IIWA board here https://stljirap.sial.com/projects/IIWA
// 2. Assign to Mike Clark or Zynna santoshi kumari Makarla
// 3. Use a template similar to this:
//  Description: {description of request}
//  Environment Variable: {name of environment variable, ie 'FEATURE_FLAG_AEM_CMS'}
//  B&D Environments:
//     nodejs-ecom QA - FALSE
//     nodejs-ecom Prod - FALSE
//     nodejs-ecomchina QA - FALSE
//     nodejs-ecomchina Prod - FALSE
//
// 4. After ticket creation, send a DM w/ link to ticket to the assignee
// 5. To make the configuration change for DEV environments, submit a PR here for the corresponding ADC/UDC environments https://stldgitlab.sial.com/ms/ecom/devops
//
// If you are removing a variable from here, you should also ensure that it is communicated to the web team for removal
//
// You can also test this mapping by prefixing your dev/start command. For example:
// `FEATURE_FLAG_BUILDING_BLOCKS=true yarn start`

const config = {
  ecom: {
    scheme: 'ECOM_SCHEME',
    host: 'ECOM_HOST',
    port: 'ECOM_PORT',
    version: 'ECOM_VERSION',
  },
  configurators: {
    scheme: 'CONFIGURATORS_SCHEME',
    host: 'CONFIGURATORS_HOST',
    port: 'CONFIGURATORS_PORT',
    version: 'CONFIGURATORS_VERSION',
  },
  sso: {
    scheme:'SSO_AUTH_SERVICE_SCHEME',
    host:'SSO_AUTH_SERVICE_HOST',
  }, 
  app: {
    port: 'PORT'
  },
}

module.exports = config
