// Default configuration for `next-commerce-china`
// See https://github.com/lorenwest/node-config/wiki for additional documentation

const config = {
  ecom: {
    version: 'v3',
  },
  configurators: {},
  sso: {},
  app: {},
  timeout: 300000,
}

module.exports = config
