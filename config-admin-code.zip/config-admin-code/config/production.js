// preventing warnings during build.
// https://github.com/lorenwest/node-config/wiki/Strict-Mode
// Don't put anything in here.
// To configuration the application visit the relevent release in
// https://stldgitlab.sial.com/ms/ecom/devops/-/tree/master/clusters

module.exports = {}
