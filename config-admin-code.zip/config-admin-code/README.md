# Configurator Admin

An admin tool for configurator
https://stldgitlab.sial.com/ms/ecom/deep/presentation-react/-/tree/release/integration/apps/config-admin
