package okio;

import java.io.IOException;
import java.util.zip.Inflater;

public final class InflaterSource implements Source {
    private int bufferBytesHeldByInflater;
    private boolean closed;
    private final Inflater inflater;
    private final BufferedSource source;

    public long read(okio.Buffer r7, long r8) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:34:0x0091 in {6, 12, 17, 19, 21, 24, 26, 29, 31, 33} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r6 = this;
        r0 = 0;
        r2 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1));
        if (r2 < 0) goto L_0x007a;
    L_0x0006:
        r2 = r6.closed;
        if (r2 != 0) goto L_0x0072;
    L_0x000a:
        r2 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1));
        if (r2 != 0) goto L_0x000f;
    L_0x000e:
        return r0;
    L_0x000f:
        r0 = r6.refill();
        r1 = 1;
        r1 = r7.writableSegment(r1);	 Catch:{ DataFormatException -> 0x006b }
        r2 = r1.limit;	 Catch:{ DataFormatException -> 0x006b }
        r2 = 8192 - r2;	 Catch:{ DataFormatException -> 0x006b }
        r2 = (long) r2;	 Catch:{ DataFormatException -> 0x006b }
        r2 = java.lang.Math.min(r8, r2);	 Catch:{ DataFormatException -> 0x006b }
        r2 = (int) r2;	 Catch:{ DataFormatException -> 0x006b }
        r3 = r6.inflater;	 Catch:{ DataFormatException -> 0x006b }
        r4 = r1.data;	 Catch:{ DataFormatException -> 0x006b }
        r5 = r1.limit;	 Catch:{ DataFormatException -> 0x006b }
        r2 = r3.inflate(r4, r5, r2);	 Catch:{ DataFormatException -> 0x006b }
        if (r2 <= 0) goto L_0x003a;	 Catch:{ DataFormatException -> 0x006b }
    L_0x002e:
        r8 = r1.limit;	 Catch:{ DataFormatException -> 0x006b }
        r8 = r8 + r2;	 Catch:{ DataFormatException -> 0x006b }
        r1.limit = r8;	 Catch:{ DataFormatException -> 0x006b }
        r8 = r7.size;	 Catch:{ DataFormatException -> 0x006b }
        r0 = (long) r2;	 Catch:{ DataFormatException -> 0x006b }
        r8 = r8 + r0;	 Catch:{ DataFormatException -> 0x006b }
        r7.size = r8;	 Catch:{ DataFormatException -> 0x006b }
        return r0;	 Catch:{ DataFormatException -> 0x006b }
    L_0x003a:
        r2 = r6.inflater;	 Catch:{ DataFormatException -> 0x006b }
        r2 = r2.finished();	 Catch:{ DataFormatException -> 0x006b }
        if (r2 != 0) goto L_0x0056;	 Catch:{ DataFormatException -> 0x006b }
    L_0x0042:
        r2 = r6.inflater;	 Catch:{ DataFormatException -> 0x006b }
        r2 = r2.needsDictionary();	 Catch:{ DataFormatException -> 0x006b }
        if (r2 == 0) goto L_0x004b;	 Catch:{ DataFormatException -> 0x006b }
    L_0x004a:
        goto L_0x0056;	 Catch:{ DataFormatException -> 0x006b }
    L_0x004b:
        if (r0 != 0) goto L_0x004e;	 Catch:{ DataFormatException -> 0x006b }
    L_0x004d:
        goto L_0x000f;	 Catch:{ DataFormatException -> 0x006b }
    L_0x004e:
        r7 = new java.io.EOFException;	 Catch:{ DataFormatException -> 0x006b }
        r8 = "source exhausted prematurely";	 Catch:{ DataFormatException -> 0x006b }
        r7.<init>(r8);	 Catch:{ DataFormatException -> 0x006b }
        throw r7;	 Catch:{ DataFormatException -> 0x006b }
    L_0x0056:
        r6.releaseInflatedBytes();	 Catch:{ DataFormatException -> 0x006b }
        r8 = r1.pos;	 Catch:{ DataFormatException -> 0x006b }
        r9 = r1.limit;	 Catch:{ DataFormatException -> 0x006b }
        if (r8 != r9) goto L_0x0068;	 Catch:{ DataFormatException -> 0x006b }
    L_0x005f:
        r8 = r1.pop();	 Catch:{ DataFormatException -> 0x006b }
        r7.head = r8;	 Catch:{ DataFormatException -> 0x006b }
        okio.SegmentPool.recycle(r1);	 Catch:{ DataFormatException -> 0x006b }
    L_0x0068:
        r7 = -1;
        return r7;
    L_0x006b:
        r7 = move-exception;
        r8 = new java.io.IOException;
        r8.<init>(r7);
        throw r8;
    L_0x0072:
        r7 = new java.lang.IllegalStateException;
        r8 = "closed";
        r7.<init>(r8);
        throw r7;
    L_0x007a:
        r7 = new java.lang.IllegalArgumentException;
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r1 = "byteCount < 0: ";
        r0.append(r1);
        r0.append(r8);
        r8 = r0.toString();
        r7.<init>(r8);
        throw r7;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: okio.InflaterSource.read(okio.Buffer, long):long");
    }

    public InflaterSource(Source source, Inflater inflater) {
        this(Okio.buffer(source), inflater);
    }

    InflaterSource(BufferedSource bufferedSource, Inflater inflater) {
        if (bufferedSource == null) {
            throw new IllegalArgumentException("source == null");
        } else if (inflater != null) {
            this.source = bufferedSource;
            this.inflater = inflater;
        } else {
            throw new IllegalArgumentException("inflater == null");
        }
    }

    public boolean refill() throws IOException {
        if (!this.inflater.needsInput()) {
            return false;
        }
        releaseInflatedBytes();
        if (this.inflater.getRemaining() != 0) {
            throw new IllegalStateException("?");
        } else if (this.source.exhausted()) {
            return true;
        } else {
            Segment segment = this.source.buffer().head;
            this.bufferBytesHeldByInflater = segment.limit - segment.pos;
            this.inflater.setInput(segment.data, segment.pos, this.bufferBytesHeldByInflater);
            return false;
        }
    }

    private void releaseInflatedBytes() throws IOException {
        int i = this.bufferBytesHeldByInflater;
        if (i != 0) {
            i -= this.inflater.getRemaining();
            this.bufferBytesHeldByInflater -= i;
            this.source.skip((long) i);
        }
    }

    public Timeout timeout() {
        return this.source.timeout();
    }

    public void close() throws IOException {
        if (!this.closed) {
            this.inflater.end();
            this.closed = true;
            this.source.close();
        }
    }
}
