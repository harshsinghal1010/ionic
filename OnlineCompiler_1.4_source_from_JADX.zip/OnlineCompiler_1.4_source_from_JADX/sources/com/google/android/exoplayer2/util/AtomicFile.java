package com.google.android.exoplayer2.util;

import android.support.annotation.NonNull;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public final class AtomicFile {
    private static final String TAG = "AtomicFile";
    private final File backupName;
    private final File baseName;

    private static final class AtomicFileOutputStream extends OutputStream {
        private boolean closed = false;
        private final FileOutputStream fileOutputStream;

        public AtomicFileOutputStream(File file) throws FileNotFoundException {
            this.fileOutputStream = new FileOutputStream(file);
        }

        public void close() throws IOException {
            if (!this.closed) {
                this.closed = true;
                flush();
                try {
                    this.fileOutputStream.getFD().sync();
                } catch (Throwable e) {
                    Log.w(AtomicFile.TAG, "Failed to sync file descriptor:", e);
                }
                this.fileOutputStream.close();
            }
        }

        public void flush() throws IOException {
            this.fileOutputStream.flush();
        }

        public void write(int i) throws IOException {
            this.fileOutputStream.write(i);
        }

        public void write(@NonNull byte[] bArr) throws IOException {
            this.fileOutputStream.write(bArr);
        }

        public void write(@NonNull byte[] bArr, int i, int i2) throws IOException {
            this.fileOutputStream.write(bArr, i, i2);
        }
    }

    public AtomicFile(File file) {
        this.baseName = file;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(file.getPath());
        stringBuilder.append(".bak");
        this.backupName = new File(stringBuilder.toString());
    }

    public void delete() {
        this.baseName.delete();
        this.backupName.delete();
    }

    public java.io.OutputStream startWrite() throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r3 = this;
        r0 = r3.baseName;
        r0 = r0.exists();
        if (r0 == 0) goto L_0x0042;
    L_0x0008:
        r0 = r3.backupName;
        r0 = r0.exists();
        if (r0 != 0) goto L_0x003d;
    L_0x0010:
        r0 = r3.baseName;
        r1 = r3.backupName;
        r0 = r0.renameTo(r1);
        if (r0 != 0) goto L_0x0042;
    L_0x001a:
        r0 = "AtomicFile";
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Couldn't rename file ";
        r1.append(r2);
        r2 = r3.baseName;
        r1.append(r2);
        r2 = " to backup file ";
        r1.append(r2);
        r2 = r3.backupName;
        r1.append(r2);
        r1 = r1.toString();
        android.util.Log.w(r0, r1);
        goto L_0x0042;
    L_0x003d:
        r0 = r3.baseName;
        r0.delete();
    L_0x0042:
        r0 = new com.google.android.exoplayer2.util.AtomicFile$AtomicFileOutputStream;	 Catch:{ FileNotFoundException -> 0x004a }
        r1 = r3.baseName;	 Catch:{ FileNotFoundException -> 0x004a }
        r0.<init>(r1);	 Catch:{ FileNotFoundException -> 0x004a }
        goto L_0x005e;
        r0 = r3.baseName;
        r0 = r0.getParentFile();
        r0 = r0.mkdirs();
        if (r0 == 0) goto L_0x0078;
    L_0x0057:
        r0 = new com.google.android.exoplayer2.util.AtomicFile$AtomicFileOutputStream;	 Catch:{ FileNotFoundException -> 0x005f }
        r1 = r3.baseName;	 Catch:{ FileNotFoundException -> 0x005f }
        r0.<init>(r1);	 Catch:{ FileNotFoundException -> 0x005f }
    L_0x005e:
        return r0;
    L_0x005f:
        r0 = new java.io.IOException;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Couldn't create ";
        r1.append(r2);
        r2 = r3.baseName;
        r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0078:
        r0 = new java.io.IOException;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Couldn't create directory ";
        r1.append(r2);
        r2 = r3.baseName;
        r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.util.AtomicFile.startWrite():java.io.OutputStream");
    }

    public void endWrite(OutputStream outputStream) throws IOException {
        outputStream.close();
        this.backupName.delete();
    }

    public InputStream openRead() throws FileNotFoundException {
        restoreBackup();
        return new FileInputStream(this.baseName);
    }

    private void restoreBackup() {
        if (this.backupName.exists()) {
            this.baseName.delete();
            this.backupName.renameTo(this.baseName);
        }
    }
}
