package com.google.android.exoplayer2.util;

public interface Predicate<T> {
    boolean evaluate(T t);
}
