package com.google.android.exoplayer2.util;

public final class ParsableBitArray {
    private int bitOffset;
    private int byteLimit;
    private int byteOffset;
    public byte[] data;

    public ParsableBitArray(byte[] bArr) {
        this(bArr, bArr.length);
    }

    public ParsableBitArray(byte[] bArr, int i) {
        this.data = bArr;
        this.byteLimit = i;
    }

    public void reset(byte[] bArr) {
        reset(bArr, bArr.length);
    }

    public void reset(byte[] bArr, int i) {
        this.data = bArr;
        this.byteOffset = 0;
        this.bitOffset = 0;
        this.byteLimit = i;
    }

    public int bitsLeft() {
        return ((this.byteLimit - this.byteOffset) * 8) - this.bitOffset;
    }

    public int getPosition() {
        return (this.byteOffset * 8) + this.bitOffset;
    }

    public int getBytePosition() {
        Assertions.checkState(this.bitOffset == 0);
        return this.byteOffset;
    }

    public void setPosition(int i) {
        this.byteOffset = i / 8;
        this.bitOffset = i - (this.byteOffset * 8);
        assertValidOffset();
    }

    public void skipBits(int i) {
        this.byteOffset += i / 8;
        this.bitOffset += i % 8;
        i = this.bitOffset;
        if (i > 7) {
            this.byteOffset++;
            this.bitOffset = i - 8;
        }
        assertValidOffset();
    }

    public boolean readBit() {
        return readBits(1) == 1;
    }

    public int readBits(int i) {
        int i2 = 0;
        if (i == 0) {
            return 0;
        }
        int i3 = i / 8;
        int i4 = 0;
        while (i2 < i3) {
            int i5;
            int i6 = this.bitOffset;
            if (i6 != 0) {
                byte[] bArr = this.data;
                int i7 = this.byteOffset;
                i5 = ((bArr[i7 + 1] & 255) >>> (8 - i6)) | ((bArr[i7] & 255) << i6);
            } else {
                i5 = this.data[this.byteOffset];
            }
            i -= 8;
            i4 |= (255 & i5) << i;
            this.byteOffset++;
            i2++;
        }
        if (i > 0) {
            i2 = this.bitOffset + i;
            i = (byte) (255 >> (8 - i));
            byte[] bArr2;
            if (i2 > 8) {
                bArr2 = this.data;
                i6 = this.byteOffset;
                i = (i & (((bArr2[i6 + 1] & 255) >> (16 - i2)) | ((bArr2[i6] & 255) << (i2 - 8)))) | i4;
                this.byteOffset = i6 + 1;
                i4 = i;
            } else {
                bArr2 = this.data;
                i6 = this.byteOffset;
                i = (i & ((bArr2[i6] & 255) >> (8 - i2))) | i4;
                if (i2 == 8) {
                    this.byteOffset = i6 + 1;
                }
                i4 = i;
            }
            this.bitOffset = i2 % 8;
        }
        assertValidOffset();
        return i4;
    }

    public void byteAlign() {
        if (this.bitOffset != 0) {
            this.bitOffset = 0;
            this.byteOffset++;
            assertValidOffset();
        }
    }

    public void readBytes(byte[] bArr, int i, int i2) {
        Assertions.checkState(this.bitOffset == 0);
        System.arraycopy(this.data, this.byteOffset, bArr, i, i2);
        this.byteOffset += i2;
        assertValidOffset();
    }

    public void skipBytes(int i) {
        Assertions.checkState(this.bitOffset == 0);
        this.byteOffset += i;
        assertValidOffset();
    }

    private void assertValidOffset() {
        boolean z;
        int i = this.byteOffset;
        if (i >= 0) {
            int i2 = this.bitOffset;
            if (i2 >= 0 && i2 < 8) {
                int i3 = this.byteLimit;
                if (i < i3 || (i == i3 && i2 == 0)) {
                    z = true;
                    Assertions.checkState(z);
                }
            }
        }
        z = false;
        Assertions.checkState(z);
    }
}
