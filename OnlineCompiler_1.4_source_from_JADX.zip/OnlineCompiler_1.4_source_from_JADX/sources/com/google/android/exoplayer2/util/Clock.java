package com.google.android.exoplayer2.util;

public interface Clock {
    long elapsedRealtime();
}
