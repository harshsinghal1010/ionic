package com.google.android.exoplayer2.util;

import android.util.Log;
import com.google.android.exoplayer2.extractor.ts.TsExtractor;
import java.nio.ByteBuffer;

public final class NalUnitUtil {
    public static final float[] ASPECT_RATIO_IDC_VALUES = new float[]{1.0f, 1.0f, 1.0909091f, 0.90909094f, 1.4545455f, 1.2121212f, 2.1818182f, 1.8181819f, 2.909091f, 2.4242425f, 1.6363636f, 1.3636364f, 1.939394f, 1.6161616f, 1.3333334f, 1.5f, 2.0f};
    public static final int EXTENDED_SAR = 255;
    private static final int H264_NAL_UNIT_TYPE_SEI = 6;
    private static final int H264_NAL_UNIT_TYPE_SPS = 7;
    private static final int H265_NAL_UNIT_TYPE_PREFIX_SEI = 39;
    public static final byte[] NAL_START_CODE = new byte[]{(byte) 0, (byte) 0, (byte) 0, (byte) 1};
    private static final String TAG = "NalUnitUtil";
    private static int[] scratchEscapePositions = new int[10];
    private static final Object scratchEscapePositionsLock = new Object();

    public static final class PpsData {
        public final boolean bottomFieldPicOrderInFramePresentFlag;
        public final int picParameterSetId;
        public final int seqParameterSetId;

        public PpsData(int i, int i2, boolean z) {
            this.picParameterSetId = i;
            this.seqParameterSetId = i2;
            this.bottomFieldPicOrderInFramePresentFlag = z;
        }
    }

    public static final class SpsData {
        public final boolean deltaPicOrderAlwaysZeroFlag;
        public final boolean frameMbsOnlyFlag;
        public final int frameNumLength;
        public final int height;
        public final int picOrderCntLsbLength;
        public final int picOrderCountType;
        public final float pixelWidthAspectRatio;
        public final boolean separateColorPlaneFlag;
        public final int seqParameterSetId;
        public final int width;

        public SpsData(int i, int i2, int i3, float f, boolean z, boolean z2, int i4, int i5, int i6, boolean z3) {
            this.seqParameterSetId = i;
            this.width = i2;
            this.height = i3;
            this.pixelWidthAspectRatio = f;
            this.separateColorPlaneFlag = z;
            this.frameMbsOnlyFlag = z2;
            this.frameNumLength = i4;
            this.picOrderCountType = i5;
            this.picOrderCntLsbLength = i6;
            this.deltaPicOrderAlwaysZeroFlag = z3;
        }
    }

    public static int unescapeStream(byte[] r8, int r9) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:21:0x0052 in {9, 10, 15, 18, 20} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = scratchEscapePositionsLock;
        monitor-enter(r0);
        r1 = 0;
        r2 = 0;
        r3 = 0;
    L_0x0006:
        if (r2 >= r9) goto L_0x002c;
    L_0x0008:
        r2 = findNextUnescapeIndex(r8, r2, r9);	 Catch:{ all -> 0x002a }
        if (r2 >= r9) goto L_0x0006;	 Catch:{ all -> 0x002a }
    L_0x000e:
        r4 = scratchEscapePositions;	 Catch:{ all -> 0x002a }
        r4 = r4.length;	 Catch:{ all -> 0x002a }
        if (r4 > r3) goto L_0x0020;	 Catch:{ all -> 0x002a }
    L_0x0013:
        r4 = scratchEscapePositions;	 Catch:{ all -> 0x002a }
        r5 = scratchEscapePositions;	 Catch:{ all -> 0x002a }
        r5 = r5.length;	 Catch:{ all -> 0x002a }
        r5 = r5 * 2;	 Catch:{ all -> 0x002a }
        r4 = java.util.Arrays.copyOf(r4, r5);	 Catch:{ all -> 0x002a }
        scratchEscapePositions = r4;	 Catch:{ all -> 0x002a }
    L_0x0020:
        r4 = scratchEscapePositions;	 Catch:{ all -> 0x002a }
        r5 = r3 + 1;	 Catch:{ all -> 0x002a }
        r4[r3] = r2;	 Catch:{ all -> 0x002a }
        r2 = r2 + 3;	 Catch:{ all -> 0x002a }
        r3 = r5;	 Catch:{ all -> 0x002a }
        goto L_0x0006;	 Catch:{ all -> 0x002a }
    L_0x002a:
        r8 = move-exception;	 Catch:{ all -> 0x002a }
        goto L_0x0050;	 Catch:{ all -> 0x002a }
    L_0x002c:
        r9 = r9 - r3;	 Catch:{ all -> 0x002a }
        r2 = 0;	 Catch:{ all -> 0x002a }
        r4 = 0;	 Catch:{ all -> 0x002a }
        r5 = 0;	 Catch:{ all -> 0x002a }
    L_0x0030:
        if (r2 >= r3) goto L_0x0049;	 Catch:{ all -> 0x002a }
    L_0x0032:
        r6 = scratchEscapePositions;	 Catch:{ all -> 0x002a }
        r6 = r6[r2];	 Catch:{ all -> 0x002a }
        r6 = r6 - r5;	 Catch:{ all -> 0x002a }
        java.lang.System.arraycopy(r8, r5, r8, r4, r6);	 Catch:{ all -> 0x002a }
        r4 = r4 + r6;	 Catch:{ all -> 0x002a }
        r7 = r4 + 1;	 Catch:{ all -> 0x002a }
        r8[r4] = r1;	 Catch:{ all -> 0x002a }
        r4 = r7 + 1;	 Catch:{ all -> 0x002a }
        r8[r7] = r1;	 Catch:{ all -> 0x002a }
        r6 = r6 + 3;	 Catch:{ all -> 0x002a }
        r5 = r5 + r6;	 Catch:{ all -> 0x002a }
        r2 = r2 + 1;	 Catch:{ all -> 0x002a }
        goto L_0x0030;	 Catch:{ all -> 0x002a }
    L_0x0049:
        r1 = r9 - r4;	 Catch:{ all -> 0x002a }
        java.lang.System.arraycopy(r8, r5, r8, r4, r1);	 Catch:{ all -> 0x002a }
        monitor-exit(r0);	 Catch:{ all -> 0x002a }
        return r9;	 Catch:{ all -> 0x002a }
    L_0x0050:
        monitor-exit(r0);	 Catch:{ all -> 0x002a }
        throw r8;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.util.NalUnitUtil.unescapeStream(byte[], int):int");
    }

    public static void discardToSps(ByteBuffer byteBuffer) {
        int position = byteBuffer.position();
        int i = 0;
        int i2 = 0;
        while (true) {
            int i3 = i + 1;
            if (i3 < position) {
                int i4 = byteBuffer.get(i) & 255;
                if (i2 == 3) {
                    if (i4 == 1 && (byteBuffer.get(i3) & 31) == 7) {
                        ByteBuffer duplicate = byteBuffer.duplicate();
                        duplicate.position(i - 3);
                        duplicate.limit(position);
                        byteBuffer.position(0);
                        byteBuffer.put(duplicate);
                        return;
                    }
                } else if (i4 == 0) {
                    i2++;
                }
                if (i4 != 0) {
                    i2 = 0;
                }
                i = i3;
            } else {
                byteBuffer.clear();
                return;
            }
        }
    }

    public static boolean isNalUnitSei(String str, byte b) {
        if (MimeTypes.VIDEO_H264.equals(str) && (b & 31) == 6) {
            return true;
        }
        if (MimeTypes.VIDEO_H265.equals(str) == null || ((b & 126) >> 1) != (byte) 39) {
            return false;
        }
        return true;
    }

    public static int getNalUnitType(byte[] bArr, int i) {
        return bArr[i + 3] & 31;
    }

    public static int getH265NalUnitType(byte[] bArr, int i) {
        return (bArr[i + 3] & 126) >> 1;
    }

    public static SpsData parseSpsNalUnit(byte[] bArr, int i, int i2) {
        boolean z;
        int readUnsignedExpGolombCodedInt;
        int readUnsignedExpGolombCodedInt2;
        int readUnsignedExpGolombCodedInt3;
        boolean z2;
        boolean readBit;
        long readUnsignedExpGolombCodedInt4;
        int i3;
        int readUnsignedExpGolombCodedInt5;
        boolean readBit2;
        int i4;
        int i5;
        int i6;
        float f;
        int readBits;
        int readBits2;
        float f2;
        float[] fArr;
        ParsableNalUnitBitArray parsableNalUnitBitArray = new ParsableNalUnitBitArray(bArr, i, i2);
        parsableNalUnitBitArray.skipBits(8);
        int readBits3 = parsableNalUnitBitArray.readBits(8);
        parsableNalUnitBitArray.skipBits(16);
        int readUnsignedExpGolombCodedInt6 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
        int i7 = 1;
        if (!(readBits3 == 100 || readBits3 == 110 || readBits3 == 122 || readBits3 == 244 || readBits3 == 44 || readBits3 == 83 || readBits3 == 86 || readBits3 == 118 || readBits3 == 128)) {
            if (readBits3 != TsExtractor.TS_STREAM_TYPE_DTS) {
                readBits3 = 1;
                z = false;
                readUnsignedExpGolombCodedInt = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt() + 4;
                readUnsignedExpGolombCodedInt2 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
                if (readUnsignedExpGolombCodedInt2 == 0) {
                    bArr = readUnsignedExpGolombCodedInt6;
                    readUnsignedExpGolombCodedInt3 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt() + 4;
                    z2 = false;
                } else if (readUnsignedExpGolombCodedInt2 != 1) {
                    readBit = parsableNalUnitBitArray.readBit();
                    parsableNalUnitBitArray.readSignedExpGolombCodedInt();
                    parsableNalUnitBitArray.readSignedExpGolombCodedInt();
                    readUnsignedExpGolombCodedInt4 = (long) parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
                    bArr = readUnsignedExpGolombCodedInt6;
                    for (i3 = 0; ((long) i3) < readUnsignedExpGolombCodedInt4; i3++) {
                        parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
                    }
                    z2 = readBit;
                    readUnsignedExpGolombCodedInt3 = 0;
                } else {
                    bArr = readUnsignedExpGolombCodedInt6;
                    readUnsignedExpGolombCodedInt3 = 0;
                    z2 = false;
                }
                parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
                parsableNalUnitBitArray.skipBits(1);
                readUnsignedExpGolombCodedInt5 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt() + 1;
                readUnsignedExpGolombCodedInt6 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt() + 1;
                readBit2 = parsableNalUnitBitArray.readBit();
                i4 = (2 - readBit2) * readUnsignedExpGolombCodedInt6;
                if (!readBit2) {
                    parsableNalUnitBitArray.skipBits(1);
                }
                parsableNalUnitBitArray.skipBits(1);
                readUnsignedExpGolombCodedInt5 *= 16;
                i4 *= 16;
                if (parsableNalUnitBitArray.readBit()) {
                    i5 = readUnsignedExpGolombCodedInt5;
                    i7 = i4;
                } else {
                    readUnsignedExpGolombCodedInt6 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
                    int readUnsignedExpGolombCodedInt7 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
                    int readUnsignedExpGolombCodedInt8 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
                    int readUnsignedExpGolombCodedInt9 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
                    if (readBits3 != 0) {
                        i5 = 2 - readBit2;
                        i6 = 1;
                    } else {
                        i6 = readBits3 != 3 ? 1 : 2;
                        if (readBits3 == 1) {
                            i7 = 2;
                        }
                        i5 = (2 - readBit2) * i7;
                    }
                    i5 = readUnsignedExpGolombCodedInt5 - ((readUnsignedExpGolombCodedInt6 + readUnsignedExpGolombCodedInt7) * i6);
                    i7 = i4 - ((readUnsignedExpGolombCodedInt8 + readUnsignedExpGolombCodedInt9) * i5);
                }
                f = 1.0f;
                if (parsableNalUnitBitArray.readBit() && parsableNalUnitBitArray.readBit()) {
                    readBits = parsableNalUnitBitArray.readBits(8);
                    if (readBits != 255) {
                        readBits = parsableNalUnitBitArray.readBits(16);
                        readBits2 = parsableNalUnitBitArray.readBits(16);
                        if (!(readBits == 0 || readBits2 == 0)) {
                            f = ((float) readBits) / ((float) readBits2);
                        }
                        f2 = f;
                    } else {
                        fArr = ASPECT_RATIO_IDC_VALUES;
                        if (readBits >= fArr.length) {
                            f2 = fArr[readBits];
                        } else {
                            String str = TAG;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Unexpected aspect_ratio_idc value: ");
                            stringBuilder.append(readBits);
                            Log.w(str, stringBuilder.toString());
                        }
                    }
                    return new SpsData(bArr, i5, i7, f2, z, readBit2, readUnsignedExpGolombCodedInt, readUnsignedExpGolombCodedInt2, readUnsignedExpGolombCodedInt3, z2);
                }
                f2 = 1.0f;
                return new SpsData(bArr, i5, i7, f2, z, readBit2, readUnsignedExpGolombCodedInt, readUnsignedExpGolombCodedInt2, readUnsignedExpGolombCodedInt3, z2);
            }
        }
        readBits3 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
        readBit = readBits3 == 3 ? parsableNalUnitBitArray.readBit() : false;
        parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
        parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
        parsableNalUnitBitArray.skipBits(1);
        if (parsableNalUnitBitArray.readBit()) {
            int i8 = readBits3 != 3 ? 8 : 12;
            i3 = 0;
            while (i3 < i8) {
                if (parsableNalUnitBitArray.readBit()) {
                    skipScalingList(parsableNalUnitBitArray, i3 < 6 ? 16 : 64);
                }
                i3++;
            }
        }
        z = readBit;
        readUnsignedExpGolombCodedInt = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt() + 4;
        readUnsignedExpGolombCodedInt2 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
        if (readUnsignedExpGolombCodedInt2 == 0) {
            bArr = readUnsignedExpGolombCodedInt6;
            readUnsignedExpGolombCodedInt3 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt() + 4;
            z2 = false;
        } else if (readUnsignedExpGolombCodedInt2 != 1) {
            bArr = readUnsignedExpGolombCodedInt6;
            readUnsignedExpGolombCodedInt3 = 0;
            z2 = false;
        } else {
            readBit = parsableNalUnitBitArray.readBit();
            parsableNalUnitBitArray.readSignedExpGolombCodedInt();
            parsableNalUnitBitArray.readSignedExpGolombCodedInt();
            readUnsignedExpGolombCodedInt4 = (long) parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
            bArr = readUnsignedExpGolombCodedInt6;
            for (i3 = 0; ((long) i3) < readUnsignedExpGolombCodedInt4; i3++) {
                parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
            }
            z2 = readBit;
            readUnsignedExpGolombCodedInt3 = 0;
        }
        parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
        parsableNalUnitBitArray.skipBits(1);
        readUnsignedExpGolombCodedInt5 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt() + 1;
        readUnsignedExpGolombCodedInt6 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt() + 1;
        readBit2 = parsableNalUnitBitArray.readBit();
        i4 = (2 - readBit2) * readUnsignedExpGolombCodedInt6;
        if (readBit2) {
            parsableNalUnitBitArray.skipBits(1);
        }
        parsableNalUnitBitArray.skipBits(1);
        readUnsignedExpGolombCodedInt5 *= 16;
        i4 *= 16;
        if (parsableNalUnitBitArray.readBit()) {
            i5 = readUnsignedExpGolombCodedInt5;
            i7 = i4;
        } else {
            readUnsignedExpGolombCodedInt6 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
            int readUnsignedExpGolombCodedInt72 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
            int readUnsignedExpGolombCodedInt82 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
            int readUnsignedExpGolombCodedInt92 = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
            if (readBits3 != 0) {
                if (readBits3 != 3) {
                }
                if (readBits3 == 1) {
                    i7 = 2;
                }
                i5 = (2 - readBit2) * i7;
            } else {
                i5 = 2 - readBit2;
                i6 = 1;
            }
            i5 = readUnsignedExpGolombCodedInt5 - ((readUnsignedExpGolombCodedInt6 + readUnsignedExpGolombCodedInt72) * i6);
            i7 = i4 - ((readUnsignedExpGolombCodedInt82 + readUnsignedExpGolombCodedInt92) * i5);
        }
        f = 1.0f;
        readBits = parsableNalUnitBitArray.readBits(8);
        if (readBits != 255) {
            fArr = ASPECT_RATIO_IDC_VALUES;
            if (readBits >= fArr.length) {
                String str2 = TAG;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Unexpected aspect_ratio_idc value: ");
                stringBuilder2.append(readBits);
                Log.w(str2, stringBuilder2.toString());
                f2 = 1.0f;
            } else {
                f2 = fArr[readBits];
            }
        } else {
            readBits = parsableNalUnitBitArray.readBits(16);
            readBits2 = parsableNalUnitBitArray.readBits(16);
            f = ((float) readBits) / ((float) readBits2);
            f2 = f;
        }
        return new SpsData(bArr, i5, i7, f2, z, readBit2, readUnsignedExpGolombCodedInt, readUnsignedExpGolombCodedInt2, readUnsignedExpGolombCodedInt3, z2);
    }

    public static PpsData parsePpsNalUnit(byte[] bArr, int i, int i2) {
        ParsableNalUnitBitArray parsableNalUnitBitArray = new ParsableNalUnitBitArray(bArr, i, i2);
        parsableNalUnitBitArray.skipBits(8);
        bArr = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
        i = parsableNalUnitBitArray.readUnsignedExpGolombCodedInt();
        parsableNalUnitBitArray.skipBits(1);
        return new PpsData(bArr, i, parsableNalUnitBitArray.readBit());
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int findNalUnit(byte[] r7, int r8, int r9, boolean[] r10) {
        /*
        r0 = r9 - r8;
        r1 = 0;
        r2 = 1;
        if (r0 < 0) goto L_0x0008;
    L_0x0006:
        r3 = 1;
        goto L_0x0009;
    L_0x0008:
        r3 = 0;
    L_0x0009:
        com.google.android.exoplayer2.util.Assertions.checkState(r3);
        if (r0 != 0) goto L_0x000f;
    L_0x000e:
        return r9;
    L_0x000f:
        r3 = 2;
        if (r10 == 0) goto L_0x0040;
    L_0x0012:
        r4 = r10[r1];
        if (r4 == 0) goto L_0x001c;
    L_0x0016:
        clearPrefixFlags(r10);
        r8 = r8 + -3;
        return r8;
    L_0x001c:
        if (r0 <= r2) goto L_0x002b;
    L_0x001e:
        r4 = r10[r2];
        if (r4 == 0) goto L_0x002b;
    L_0x0022:
        r4 = r7[r8];
        if (r4 != r2) goto L_0x002b;
    L_0x0026:
        clearPrefixFlags(r10);
        r8 = r8 - r3;
        return r8;
    L_0x002b:
        if (r0 <= r3) goto L_0x0040;
    L_0x002d:
        r4 = r10[r3];
        if (r4 == 0) goto L_0x0040;
    L_0x0031:
        r4 = r7[r8];
        if (r4 != 0) goto L_0x0040;
    L_0x0035:
        r4 = r8 + 1;
        r4 = r7[r4];
        if (r4 != r2) goto L_0x0040;
    L_0x003b:
        clearPrefixFlags(r10);
        r8 = r8 - r2;
        return r8;
    L_0x0040:
        r4 = r9 + -1;
        r8 = r8 + r3;
    L_0x0043:
        if (r8 >= r4) goto L_0x0067;
    L_0x0045:
        r5 = r7[r8];
        r5 = r5 & 254;
        if (r5 == 0) goto L_0x004c;
    L_0x004b:
        goto L_0x0064;
    L_0x004c:
        r5 = r8 + -2;
        r6 = r7[r5];
        if (r6 != 0) goto L_0x0062;
    L_0x0052:
        r6 = r8 + -1;
        r6 = r7[r6];
        if (r6 != 0) goto L_0x0062;
    L_0x0058:
        r6 = r7[r8];
        if (r6 != r2) goto L_0x0062;
    L_0x005c:
        if (r10 == 0) goto L_0x0061;
    L_0x005e:
        clearPrefixFlags(r10);
    L_0x0061:
        return r5;
    L_0x0062:
        r8 = r8 + -2;
    L_0x0064:
        r8 = r8 + 3;
        goto L_0x0043;
    L_0x0067:
        if (r10 == 0) goto L_0x00bb;
    L_0x0069:
        if (r0 <= r3) goto L_0x007e;
    L_0x006b:
        r8 = r9 + -3;
        r8 = r7[r8];
        if (r8 != 0) goto L_0x007c;
    L_0x0071:
        r8 = r9 + -2;
        r8 = r7[r8];
        if (r8 != 0) goto L_0x007c;
    L_0x0077:
        r8 = r7[r4];
        if (r8 != r2) goto L_0x007c;
    L_0x007b:
        goto L_0x0097;
    L_0x007c:
        r8 = 0;
        goto L_0x0098;
    L_0x007e:
        if (r0 != r3) goto L_0x008f;
    L_0x0080:
        r8 = r10[r3];
        if (r8 == 0) goto L_0x007c;
    L_0x0084:
        r8 = r9 + -2;
        r8 = r7[r8];
        if (r8 != 0) goto L_0x007c;
    L_0x008a:
        r8 = r7[r4];
        if (r8 != r2) goto L_0x007c;
    L_0x008e:
        goto L_0x0097;
    L_0x008f:
        r8 = r10[r2];
        if (r8 == 0) goto L_0x007c;
    L_0x0093:
        r8 = r7[r4];
        if (r8 != r2) goto L_0x007c;
    L_0x0097:
        r8 = 1;
    L_0x0098:
        r10[r1] = r8;
        if (r0 <= r2) goto L_0x00a7;
    L_0x009c:
        r8 = r9 + -2;
        r8 = r7[r8];
        if (r8 != 0) goto L_0x00b1;
    L_0x00a2:
        r8 = r7[r4];
        if (r8 != 0) goto L_0x00b1;
    L_0x00a6:
        goto L_0x00af;
    L_0x00a7:
        r8 = r10[r3];
        if (r8 == 0) goto L_0x00b1;
    L_0x00ab:
        r8 = r7[r4];
        if (r8 != 0) goto L_0x00b1;
    L_0x00af:
        r8 = 1;
        goto L_0x00b2;
    L_0x00b1:
        r8 = 0;
    L_0x00b2:
        r10[r2] = r8;
        r7 = r7[r4];
        if (r7 != 0) goto L_0x00b9;
    L_0x00b8:
        r1 = 1;
    L_0x00b9:
        r10[r3] = r1;
    L_0x00bb:
        return r9;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.util.NalUnitUtil.findNalUnit(byte[], int, int, boolean[]):int");
    }

    public static void clearPrefixFlags(boolean[] zArr) {
        zArr[0] = false;
        zArr[1] = false;
        zArr[2] = false;
    }

    private static int findNextUnescapeIndex(byte[] bArr, int i, int i2) {
        while (i < i2 - 2) {
            if (bArr[i] == (byte) 0 && bArr[i + 1] == (byte) 0 && bArr[i + 2] == (byte) 3) {
                return i;
            }
            i++;
        }
        return i2;
    }

    private static void skipScalingList(ParsableNalUnitBitArray parsableNalUnitBitArray, int i) {
        int i2 = 8;
        int i3 = 8;
        for (int i4 = 0; i4 < i; i4++) {
            if (i2 != 0) {
                i2 = ((parsableNalUnitBitArray.readSignedExpGolombCodedInt() + i3) + 256) % 256;
            }
            if (i2 != 0) {
                i3 = i2;
            }
        }
    }

    private NalUnitUtil() {
    }
}
