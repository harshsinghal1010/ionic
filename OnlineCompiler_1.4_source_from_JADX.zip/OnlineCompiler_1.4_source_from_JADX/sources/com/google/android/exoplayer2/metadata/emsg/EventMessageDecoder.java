package com.google.android.exoplayer2.metadata.emsg;

import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.MetadataDecoder;
import com.google.android.exoplayer2.metadata.MetadataInputBuffer;
import com.google.android.exoplayer2.util.ParsableByteArray;
import java.util.Arrays;

public final class EventMessageDecoder implements MetadataDecoder {
    public Metadata decode(MetadataInputBuffer metadataInputBuffer) {
        metadataInputBuffer = metadataInputBuffer.data;
        byte[] array = metadataInputBuffer.array();
        metadataInputBuffer = metadataInputBuffer.limit();
        ParsableByteArray parsableByteArray = new ParsableByteArray(array, metadataInputBuffer);
        String readNullTerminatedString = parsableByteArray.readNullTerminatedString();
        String readNullTerminatedString2 = parsableByteArray.readNullTerminatedString();
        long readUnsignedInt = parsableByteArray.readUnsignedInt();
        parsableByteArray.skipBytes(4);
        readUnsignedInt = (parsableByteArray.readUnsignedInt() * 1000) / readUnsignedInt;
        long readUnsignedInt2 = parsableByteArray.readUnsignedInt();
        byte[] copyOfRange = Arrays.copyOfRange(array, parsableByteArray.getPosition(), metadataInputBuffer);
        return new Metadata(new EventMessage(readNullTerminatedString, readNullTerminatedString2, readUnsignedInt, readUnsignedInt2, copyOfRange));
    }
}
