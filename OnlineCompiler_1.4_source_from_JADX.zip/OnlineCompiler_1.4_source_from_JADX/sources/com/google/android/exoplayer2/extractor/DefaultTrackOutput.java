package com.google.android.exoplayer2.extractor;

import com.google.android.exoplayer2.C0361C;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.FormatHolder;
import com.google.android.exoplayer2.decoder.DecoderInputBuffer;
import com.google.android.exoplayer2.upstream.Allocation;
import com.google.android.exoplayer2.upstream.Allocator;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.ParsableByteArray;
import com.google.android.exoplayer2.util.Util;
import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicInteger;

public final class DefaultTrackOutput implements TrackOutput {
    private static final int INITIAL_SCRATCH_SIZE = 32;
    private static final int STATE_DISABLED = 2;
    private static final int STATE_ENABLED = 0;
    private static final int STATE_ENABLED_WRITING = 1;
    private final int allocationLength;
    private final Allocator allocator;
    private final LinkedBlockingDeque<Allocation> dataQueue = new LinkedBlockingDeque();
    private Format downstreamFormat;
    private final BufferExtrasHolder extrasHolder = new BufferExtrasHolder();
    private final InfoQueue infoQueue = new InfoQueue();
    private Allocation lastAllocation;
    private int lastAllocationOffset = this.allocationLength;
    private Format lastUnadjustedFormat;
    private boolean pendingFormatAdjustment;
    private boolean pendingSplice;
    private long sampleOffsetUs;
    private final ParsableByteArray scratch = new ParsableByteArray(32);
    private final AtomicInteger state = new AtomicInteger();
    private long totalBytesDropped;
    private long totalBytesWritten;
    private UpstreamFormatChangedListener upstreamFormatChangeListener;

    private static final class BufferExtrasHolder {
        public byte[] encryptionKeyId;
        public long nextOffset;
        public long offset;
        public int size;

        private BufferExtrasHolder() {
        }
    }

    private static final class InfoQueue {
        private static final int SAMPLE_CAPACITY_INCREMENT = 1000;
        private int absoluteReadIndex;
        private int capacity = 1000;
        private byte[][] encryptionKeys;
        private int[] flags;
        private Format[] formats;
        private long largestDequeuedTimestampUs;
        private long largestQueuedTimestampUs;
        private long[] offsets;
        private int queueSize;
        private int relativeReadIndex;
        private int relativeWriteIndex;
        private int[] sizes;
        private int[] sourceIds;
        private long[] timesUs;
        private Format upstreamFormat;
        private boolean upstreamFormatRequired;
        private boolean upstreamKeyframeRequired;
        private int upstreamSourceId;

        public synchronized boolean attemptSplice(long r6) {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:21:0x002c in {7, 14, 17, 20} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
            /*
            r5 = this;
            monitor-enter(r5);
            r0 = r5.largestDequeuedTimestampUs;	 Catch:{ all -> 0x0029 }
            r2 = (r0 > r6 ? 1 : (r0 == r6 ? 0 : -1));
            if (r2 < 0) goto L_0x000a;
        L_0x0007:
            r6 = 0;
            monitor-exit(r5);
            return r6;
        L_0x000a:
            r0 = r5.queueSize;	 Catch:{ all -> 0x0029 }
        L_0x000c:
            r1 = 1;	 Catch:{ all -> 0x0029 }
            if (r0 <= 0) goto L_0x0021;	 Catch:{ all -> 0x0029 }
        L_0x000f:
            r2 = r5.timesUs;	 Catch:{ all -> 0x0029 }
            r3 = r5.relativeReadIndex;	 Catch:{ all -> 0x0029 }
            r3 = r3 + r0;	 Catch:{ all -> 0x0029 }
            r3 = r3 - r1;	 Catch:{ all -> 0x0029 }
            r4 = r5.capacity;	 Catch:{ all -> 0x0029 }
            r3 = r3 % r4;	 Catch:{ all -> 0x0029 }
            r3 = r2[r3];	 Catch:{ all -> 0x0029 }
            r2 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1));	 Catch:{ all -> 0x0029 }
            if (r2 < 0) goto L_0x0021;	 Catch:{ all -> 0x0029 }
        L_0x001e:
            r0 = r0 + -1;	 Catch:{ all -> 0x0029 }
            goto L_0x000c;	 Catch:{ all -> 0x0029 }
        L_0x0021:
            r6 = r5.absoluteReadIndex;	 Catch:{ all -> 0x0029 }
            r6 = r6 + r0;	 Catch:{ all -> 0x0029 }
            r5.discardUpstreamSamples(r6);	 Catch:{ all -> 0x0029 }
            monitor-exit(r5);
            return r1;
        L_0x0029:
            r6 = move-exception;
            monitor-exit(r5);
            throw r6;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.DefaultTrackOutput.InfoQueue.attemptSplice(long):boolean");
        }

        public synchronized long skipToKeyframeBefore(long r9, boolean r11) {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:38:0x0063 in {6, 12, 20, 23, 25, 28, 32, 34, 37} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
            /*
            r8 = this;
            monitor-enter(r8);
            r0 = r8.queueSize;	 Catch:{ all -> 0x0060 }
            r1 = -1;	 Catch:{ all -> 0x0060 }
            if (r0 == 0) goto L_0x005e;	 Catch:{ all -> 0x0060 }
        L_0x0007:
            r0 = r8.timesUs;	 Catch:{ all -> 0x0060 }
            r3 = r8.relativeReadIndex;	 Catch:{ all -> 0x0060 }
            r3 = r0[r3];	 Catch:{ all -> 0x0060 }
            r0 = (r9 > r3 ? 1 : (r9 == r3 ? 0 : -1));	 Catch:{ all -> 0x0060 }
            if (r0 >= 0) goto L_0x0012;	 Catch:{ all -> 0x0060 }
        L_0x0011:
            goto L_0x005e;	 Catch:{ all -> 0x0060 }
        L_0x0012:
            r3 = r8.largestQueuedTimestampUs;	 Catch:{ all -> 0x0060 }
            r0 = (r9 > r3 ? 1 : (r9 == r3 ? 0 : -1));
            if (r0 <= 0) goto L_0x001c;
        L_0x0018:
            if (r11 != 0) goto L_0x001c;
        L_0x001a:
            monitor-exit(r8);
            return r1;
        L_0x001c:
            r11 = 0;
            r0 = r8.relativeReadIndex;	 Catch:{ all -> 0x0060 }
            r3 = -1;	 Catch:{ all -> 0x0060 }
            r11 = -1;	 Catch:{ all -> 0x0060 }
            r4 = 0;	 Catch:{ all -> 0x0060 }
        L_0x0022:
            r5 = r8.relativeWriteIndex;	 Catch:{ all -> 0x0060 }
            if (r0 == r5) goto L_0x0040;	 Catch:{ all -> 0x0060 }
        L_0x0026:
            r5 = r8.timesUs;	 Catch:{ all -> 0x0060 }
            r6 = r5[r0];	 Catch:{ all -> 0x0060 }
            r5 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1));	 Catch:{ all -> 0x0060 }
            if (r5 <= 0) goto L_0x002f;	 Catch:{ all -> 0x0060 }
        L_0x002e:
            goto L_0x0040;	 Catch:{ all -> 0x0060 }
        L_0x002f:
            r5 = r8.flags;	 Catch:{ all -> 0x0060 }
            r5 = r5[r0];	 Catch:{ all -> 0x0060 }
            r5 = r5 & 1;	 Catch:{ all -> 0x0060 }
            if (r5 == 0) goto L_0x0038;	 Catch:{ all -> 0x0060 }
        L_0x0037:
            r11 = r4;	 Catch:{ all -> 0x0060 }
        L_0x0038:
            r0 = r0 + 1;	 Catch:{ all -> 0x0060 }
            r5 = r8.capacity;	 Catch:{ all -> 0x0060 }
            r0 = r0 % r5;	 Catch:{ all -> 0x0060 }
            r4 = r4 + 1;
            goto L_0x0022;
        L_0x0040:
            if (r11 != r3) goto L_0x0044;
        L_0x0042:
            monitor-exit(r8);
            return r1;
        L_0x0044:
            r9 = r8.relativeReadIndex;	 Catch:{ all -> 0x0060 }
            r9 = r9 + r11;	 Catch:{ all -> 0x0060 }
            r10 = r8.capacity;	 Catch:{ all -> 0x0060 }
            r9 = r9 % r10;	 Catch:{ all -> 0x0060 }
            r8.relativeReadIndex = r9;	 Catch:{ all -> 0x0060 }
            r9 = r8.absoluteReadIndex;	 Catch:{ all -> 0x0060 }
            r9 = r9 + r11;	 Catch:{ all -> 0x0060 }
            r8.absoluteReadIndex = r9;	 Catch:{ all -> 0x0060 }
            r9 = r8.queueSize;	 Catch:{ all -> 0x0060 }
            r9 = r9 - r11;	 Catch:{ all -> 0x0060 }
            r8.queueSize = r9;	 Catch:{ all -> 0x0060 }
            r9 = r8.offsets;	 Catch:{ all -> 0x0060 }
            r10 = r8.relativeReadIndex;	 Catch:{ all -> 0x0060 }
            r10 = r9[r10];	 Catch:{ all -> 0x0060 }
            monitor-exit(r8);
            return r10;
        L_0x005e:
            monitor-exit(r8);
            return r1;
        L_0x0060:
            r9 = move-exception;
            monitor-exit(r8);
            throw r9;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.DefaultTrackOutput.InfoQueue.skipToKeyframeBefore(long, boolean):long");
        }

        public InfoQueue() {
            int i = this.capacity;
            this.sourceIds = new int[i];
            this.offsets = new long[i];
            this.timesUs = new long[i];
            this.flags = new int[i];
            this.sizes = new int[i];
            this.encryptionKeys = new byte[i][];
            this.formats = new Format[i];
            this.largestDequeuedTimestampUs = Long.MIN_VALUE;
            this.largestQueuedTimestampUs = Long.MIN_VALUE;
            this.upstreamFormatRequired = true;
            this.upstreamKeyframeRequired = true;
        }

        public void clearSampleData() {
            this.absoluteReadIndex = 0;
            this.relativeReadIndex = 0;
            this.relativeWriteIndex = 0;
            this.queueSize = 0;
            this.upstreamKeyframeRequired = true;
        }

        public void resetLargestParsedTimestamps() {
            this.largestDequeuedTimestampUs = Long.MIN_VALUE;
            this.largestQueuedTimestampUs = Long.MIN_VALUE;
        }

        public int getWriteIndex() {
            return this.absoluteReadIndex + this.queueSize;
        }

        public long discardUpstreamSamples(int i) {
            int writeIndex = getWriteIndex() - i;
            boolean z = writeIndex >= 0 && writeIndex <= this.queueSize;
            Assertions.checkArgument(z);
            if (writeIndex != 0) {
                this.queueSize -= writeIndex;
                int i2 = this.relativeWriteIndex;
                int i3 = this.capacity;
                this.relativeWriteIndex = ((i2 + i3) - writeIndex) % i3;
                this.largestQueuedTimestampUs = Long.MIN_VALUE;
                for (writeIndex = this.queueSize - 1; writeIndex >= 0; writeIndex--) {
                    i2 = (this.relativeReadIndex + writeIndex) % this.capacity;
                    this.largestQueuedTimestampUs = Math.max(this.largestQueuedTimestampUs, this.timesUs[i2]);
                    if ((this.flags[i2] & 1) != 0) {
                        break;
                    }
                }
                return this.offsets[this.relativeWriteIndex];
            } else if (this.absoluteReadIndex == 0) {
                return 0;
            } else {
                writeIndex = this.relativeWriteIndex;
                if (writeIndex == 0) {
                    writeIndex = this.capacity;
                }
                writeIndex--;
                return this.offsets[writeIndex] + ((long) this.sizes[writeIndex]);
            }
        }

        public void sourceId(int i) {
            this.upstreamSourceId = i;
        }

        public int getReadIndex() {
            return this.absoluteReadIndex;
        }

        public int peekSourceId() {
            return this.queueSize == 0 ? this.upstreamSourceId : this.sourceIds[this.relativeReadIndex];
        }

        public synchronized boolean isEmpty() {
            return this.queueSize == 0;
        }

        public synchronized Format getUpstreamFormat() {
            return this.upstreamFormatRequired ? null : this.upstreamFormat;
        }

        public synchronized long getLargestQueuedTimestampUs() {
            return Math.max(this.largestDequeuedTimestampUs, this.largestQueuedTimestampUs);
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public synchronized int readData(com.google.android.exoplayer2.FormatHolder r5, com.google.android.exoplayer2.decoder.DecoderInputBuffer r6, boolean r7, boolean r8, com.google.android.exoplayer2.Format r9, com.google.android.exoplayer2.extractor.DefaultTrackOutput.BufferExtrasHolder r10) {
            /*
            r4 = this;
            monitor-enter(r4);
            r0 = r4.queueSize;	 Catch:{ all -> 0x00a3 }
            r1 = -5;
            r2 = -3;
            r3 = -4;
            if (r0 != 0) goto L_0x0022;
        L_0x0008:
            if (r8 == 0) goto L_0x0010;
        L_0x000a:
            r5 = 4;
            r6.setFlags(r5);	 Catch:{ all -> 0x00a3 }
            monitor-exit(r4);
            return r3;
        L_0x0010:
            r6 = r4.upstreamFormat;	 Catch:{ all -> 0x00a3 }
            if (r6 == 0) goto L_0x0020;
        L_0x0014:
            if (r7 != 0) goto L_0x001a;
        L_0x0016:
            r6 = r4.upstreamFormat;	 Catch:{ all -> 0x00a3 }
            if (r6 == r9) goto L_0x0020;
        L_0x001a:
            r6 = r4.upstreamFormat;	 Catch:{ all -> 0x00a3 }
            r5.format = r6;	 Catch:{ all -> 0x00a3 }
            monitor-exit(r4);
            return r1;
        L_0x0020:
            monitor-exit(r4);
            return r2;
        L_0x0022:
            if (r7 != 0) goto L_0x0099;
        L_0x0024:
            r7 = r4.formats;	 Catch:{ all -> 0x00a3 }
            r8 = r4.relativeReadIndex;	 Catch:{ all -> 0x00a3 }
            r7 = r7[r8];	 Catch:{ all -> 0x00a3 }
            if (r7 == r9) goto L_0x002d;
        L_0x002c:
            goto L_0x0099;
        L_0x002d:
            r5 = r6.isFlagsOnly();	 Catch:{ all -> 0x00a3 }
            if (r5 == 0) goto L_0x0035;
        L_0x0033:
            monitor-exit(r4);
            return r2;
        L_0x0035:
            r5 = r4.timesUs;	 Catch:{ all -> 0x00a3 }
            r7 = r4.relativeReadIndex;	 Catch:{ all -> 0x00a3 }
            r7 = r5[r7];	 Catch:{ all -> 0x00a3 }
            r6.timeUs = r7;	 Catch:{ all -> 0x00a3 }
            r5 = r4.flags;	 Catch:{ all -> 0x00a3 }
            r7 = r4.relativeReadIndex;	 Catch:{ all -> 0x00a3 }
            r5 = r5[r7];	 Catch:{ all -> 0x00a3 }
            r6.setFlags(r5);	 Catch:{ all -> 0x00a3 }
            r5 = r4.sizes;	 Catch:{ all -> 0x00a3 }
            r7 = r4.relativeReadIndex;	 Catch:{ all -> 0x00a3 }
            r5 = r5[r7];	 Catch:{ all -> 0x00a3 }
            r10.size = r5;	 Catch:{ all -> 0x00a3 }
            r5 = r4.offsets;	 Catch:{ all -> 0x00a3 }
            r7 = r4.relativeReadIndex;	 Catch:{ all -> 0x00a3 }
            r7 = r5[r7];	 Catch:{ all -> 0x00a3 }
            r10.offset = r7;	 Catch:{ all -> 0x00a3 }
            r5 = r4.encryptionKeys;	 Catch:{ all -> 0x00a3 }
            r7 = r4.relativeReadIndex;	 Catch:{ all -> 0x00a3 }
            r5 = r5[r7];	 Catch:{ all -> 0x00a3 }
            r10.encryptionKeyId = r5;	 Catch:{ all -> 0x00a3 }
            r7 = r4.largestDequeuedTimestampUs;	 Catch:{ all -> 0x00a3 }
            r5 = r6.timeUs;	 Catch:{ all -> 0x00a3 }
            r5 = java.lang.Math.max(r7, r5);	 Catch:{ all -> 0x00a3 }
            r4.largestDequeuedTimestampUs = r5;	 Catch:{ all -> 0x00a3 }
            r5 = r4.queueSize;	 Catch:{ all -> 0x00a3 }
            r5 = r5 + -1;
            r4.queueSize = r5;	 Catch:{ all -> 0x00a3 }
            r5 = r4.relativeReadIndex;	 Catch:{ all -> 0x00a3 }
            r5 = r5 + 1;
            r4.relativeReadIndex = r5;	 Catch:{ all -> 0x00a3 }
            r5 = r4.absoluteReadIndex;	 Catch:{ all -> 0x00a3 }
            r5 = r5 + 1;
            r4.absoluteReadIndex = r5;	 Catch:{ all -> 0x00a3 }
            r5 = r4.relativeReadIndex;	 Catch:{ all -> 0x00a3 }
            r6 = r4.capacity;	 Catch:{ all -> 0x00a3 }
            if (r5 != r6) goto L_0x0083;
        L_0x0080:
            r5 = 0;
            r4.relativeReadIndex = r5;	 Catch:{ all -> 0x00a3 }
        L_0x0083:
            r5 = r4.queueSize;	 Catch:{ all -> 0x00a3 }
            if (r5 <= 0) goto L_0x008f;
        L_0x0087:
            r5 = r4.offsets;	 Catch:{ all -> 0x00a3 }
            r6 = r4.relativeReadIndex;	 Catch:{ all -> 0x00a3 }
            r6 = r5[r6];	 Catch:{ all -> 0x00a3 }
            r5 = r6;
            goto L_0x0095;
        L_0x008f:
            r5 = r10.offset;	 Catch:{ all -> 0x00a3 }
            r7 = r10.size;	 Catch:{ all -> 0x00a3 }
            r7 = (long) r7;	 Catch:{ all -> 0x00a3 }
            r5 = r5 + r7;
        L_0x0095:
            r10.nextOffset = r5;	 Catch:{ all -> 0x00a3 }
            monitor-exit(r4);
            return r3;
        L_0x0099:
            r6 = r4.formats;	 Catch:{ all -> 0x00a3 }
            r7 = r4.relativeReadIndex;	 Catch:{ all -> 0x00a3 }
            r6 = r6[r7];	 Catch:{ all -> 0x00a3 }
            r5.format = r6;	 Catch:{ all -> 0x00a3 }
            monitor-exit(r4);
            return r1;
        L_0x00a3:
            r5 = move-exception;
            monitor-exit(r4);
            throw r5;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.DefaultTrackOutput.InfoQueue.readData(com.google.android.exoplayer2.FormatHolder, com.google.android.exoplayer2.decoder.DecoderInputBuffer, boolean, boolean, com.google.android.exoplayer2.Format, com.google.android.exoplayer2.extractor.DefaultTrackOutput$BufferExtrasHolder):int");
        }

        public synchronized long skipAll() {
            if (this.queueSize == 0) {
                return -1;
            }
            int i = ((this.relativeReadIndex + this.queueSize) - 1) % this.capacity;
            this.relativeReadIndex = (this.relativeReadIndex + this.queueSize) % this.capacity;
            this.absoluteReadIndex += this.queueSize;
            this.queueSize = 0;
            return this.offsets[i] + ((long) this.sizes[i]);
        }

        public synchronized boolean format(Format format) {
            if (format == null) {
                this.upstreamFormatRequired = true;
                return false;
            }
            this.upstreamFormatRequired = false;
            if (Util.areEqual(format, this.upstreamFormat)) {
                return false;
            }
            this.upstreamFormat = format;
            return true;
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public synchronized void commitSample(long r6, int r8, long r9, int r11, byte[] r12) {
            /*
            r5 = this;
            monitor-enter(r5);
            r0 = r5.upstreamKeyframeRequired;	 Catch:{ all -> 0x00ec }
            r1 = 0;
            if (r0 == 0) goto L_0x000e;
        L_0x0006:
            r0 = r8 & 1;
            if (r0 != 0) goto L_0x000c;
        L_0x000a:
            monitor-exit(r5);
            return;
        L_0x000c:
            r5.upstreamKeyframeRequired = r1;	 Catch:{ all -> 0x00ec }
        L_0x000e:
            r0 = r5.upstreamFormatRequired;	 Catch:{ all -> 0x00ec }
            r2 = 1;
            if (r0 != 0) goto L_0x0015;
        L_0x0013:
            r0 = 1;
            goto L_0x0016;
        L_0x0015:
            r0 = 0;
        L_0x0016:
            com.google.android.exoplayer2.util.Assertions.checkState(r0);	 Catch:{ all -> 0x00ec }
            r5.commitSampleTimestamp(r6);	 Catch:{ all -> 0x00ec }
            r0 = r5.timesUs;	 Catch:{ all -> 0x00ec }
            r3 = r5.relativeWriteIndex;	 Catch:{ all -> 0x00ec }
            r0[r3] = r6;	 Catch:{ all -> 0x00ec }
            r6 = r5.offsets;	 Catch:{ all -> 0x00ec }
            r7 = r5.relativeWriteIndex;	 Catch:{ all -> 0x00ec }
            r6[r7] = r9;	 Catch:{ all -> 0x00ec }
            r6 = r5.sizes;	 Catch:{ all -> 0x00ec }
            r7 = r5.relativeWriteIndex;	 Catch:{ all -> 0x00ec }
            r6[r7] = r11;	 Catch:{ all -> 0x00ec }
            r6 = r5.flags;	 Catch:{ all -> 0x00ec }
            r7 = r5.relativeWriteIndex;	 Catch:{ all -> 0x00ec }
            r6[r7] = r8;	 Catch:{ all -> 0x00ec }
            r6 = r5.encryptionKeys;	 Catch:{ all -> 0x00ec }
            r7 = r5.relativeWriteIndex;	 Catch:{ all -> 0x00ec }
            r6[r7] = r12;	 Catch:{ all -> 0x00ec }
            r6 = r5.formats;	 Catch:{ all -> 0x00ec }
            r7 = r5.relativeWriteIndex;	 Catch:{ all -> 0x00ec }
            r8 = r5.upstreamFormat;	 Catch:{ all -> 0x00ec }
            r6[r7] = r8;	 Catch:{ all -> 0x00ec }
            r6 = r5.sourceIds;	 Catch:{ all -> 0x00ec }
            r7 = r5.relativeWriteIndex;	 Catch:{ all -> 0x00ec }
            r8 = r5.upstreamSourceId;	 Catch:{ all -> 0x00ec }
            r6[r7] = r8;	 Catch:{ all -> 0x00ec }
            r6 = r5.queueSize;	 Catch:{ all -> 0x00ec }
            r6 = r6 + r2;
            r5.queueSize = r6;	 Catch:{ all -> 0x00ec }
            r6 = r5.queueSize;	 Catch:{ all -> 0x00ec }
            r7 = r5.capacity;	 Catch:{ all -> 0x00ec }
            if (r6 != r7) goto L_0x00dd;
        L_0x0055:
            r6 = r5.capacity;	 Catch:{ all -> 0x00ec }
            r6 = r6 + 1000;
            r7 = new int[r6];	 Catch:{ all -> 0x00ec }
            r8 = new long[r6];	 Catch:{ all -> 0x00ec }
            r9 = new long[r6];	 Catch:{ all -> 0x00ec }
            r10 = new int[r6];	 Catch:{ all -> 0x00ec }
            r11 = new int[r6];	 Catch:{ all -> 0x00ec }
            r12 = new byte[r6][];	 Catch:{ all -> 0x00ec }
            r0 = new com.google.android.exoplayer2.Format[r6];	 Catch:{ all -> 0x00ec }
            r2 = r5.capacity;	 Catch:{ all -> 0x00ec }
            r3 = r5.relativeReadIndex;	 Catch:{ all -> 0x00ec }
            r2 = r2 - r3;
            r3 = r5.offsets;	 Catch:{ all -> 0x00ec }
            r4 = r5.relativeReadIndex;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r3, r4, r8, r1, r2);	 Catch:{ all -> 0x00ec }
            r3 = r5.timesUs;	 Catch:{ all -> 0x00ec }
            r4 = r5.relativeReadIndex;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r3, r4, r9, r1, r2);	 Catch:{ all -> 0x00ec }
            r3 = r5.flags;	 Catch:{ all -> 0x00ec }
            r4 = r5.relativeReadIndex;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r3, r4, r10, r1, r2);	 Catch:{ all -> 0x00ec }
            r3 = r5.sizes;	 Catch:{ all -> 0x00ec }
            r4 = r5.relativeReadIndex;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r3, r4, r11, r1, r2);	 Catch:{ all -> 0x00ec }
            r3 = r5.encryptionKeys;	 Catch:{ all -> 0x00ec }
            r4 = r5.relativeReadIndex;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r3, r4, r12, r1, r2);	 Catch:{ all -> 0x00ec }
            r3 = r5.formats;	 Catch:{ all -> 0x00ec }
            r4 = r5.relativeReadIndex;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r3, r4, r0, r1, r2);	 Catch:{ all -> 0x00ec }
            r3 = r5.sourceIds;	 Catch:{ all -> 0x00ec }
            r4 = r5.relativeReadIndex;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r3, r4, r7, r1, r2);	 Catch:{ all -> 0x00ec }
            r3 = r5.relativeReadIndex;	 Catch:{ all -> 0x00ec }
            r4 = r5.offsets;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r4, r1, r8, r2, r3);	 Catch:{ all -> 0x00ec }
            r4 = r5.timesUs;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r4, r1, r9, r2, r3);	 Catch:{ all -> 0x00ec }
            r4 = r5.flags;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r4, r1, r10, r2, r3);	 Catch:{ all -> 0x00ec }
            r4 = r5.sizes;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r4, r1, r11, r2, r3);	 Catch:{ all -> 0x00ec }
            r4 = r5.encryptionKeys;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r4, r1, r12, r2, r3);	 Catch:{ all -> 0x00ec }
            r4 = r5.formats;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r4, r1, r0, r2, r3);	 Catch:{ all -> 0x00ec }
            r4 = r5.sourceIds;	 Catch:{ all -> 0x00ec }
            java.lang.System.arraycopy(r4, r1, r7, r2, r3);	 Catch:{ all -> 0x00ec }
            r5.offsets = r8;	 Catch:{ all -> 0x00ec }
            r5.timesUs = r9;	 Catch:{ all -> 0x00ec }
            r5.flags = r10;	 Catch:{ all -> 0x00ec }
            r5.sizes = r11;	 Catch:{ all -> 0x00ec }
            r5.encryptionKeys = r12;	 Catch:{ all -> 0x00ec }
            r5.formats = r0;	 Catch:{ all -> 0x00ec }
            r5.sourceIds = r7;	 Catch:{ all -> 0x00ec }
            r5.relativeReadIndex = r1;	 Catch:{ all -> 0x00ec }
            r7 = r5.capacity;	 Catch:{ all -> 0x00ec }
            r5.relativeWriteIndex = r7;	 Catch:{ all -> 0x00ec }
            r7 = r5.capacity;	 Catch:{ all -> 0x00ec }
            r5.queueSize = r7;	 Catch:{ all -> 0x00ec }
            r5.capacity = r6;	 Catch:{ all -> 0x00ec }
            goto L_0x00ea;
        L_0x00dd:
            r6 = r5.relativeWriteIndex;	 Catch:{ all -> 0x00ec }
            r6 = r6 + r2;
            r5.relativeWriteIndex = r6;	 Catch:{ all -> 0x00ec }
            r6 = r5.relativeWriteIndex;	 Catch:{ all -> 0x00ec }
            r7 = r5.capacity;	 Catch:{ all -> 0x00ec }
            if (r6 != r7) goto L_0x00ea;
        L_0x00e8:
            r5.relativeWriteIndex = r1;	 Catch:{ all -> 0x00ec }
        L_0x00ea:
            monitor-exit(r5);
            return;
        L_0x00ec:
            r6 = move-exception;
            monitor-exit(r5);
            throw r6;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.DefaultTrackOutput.InfoQueue.commitSample(long, int, long, int, byte[]):void");
        }

        public synchronized void commitSampleTimestamp(long j) {
            this.largestQueuedTimestampUs = Math.max(this.largestQueuedTimestampUs, j);
        }
    }

    public interface UpstreamFormatChangedListener {
        void onUpstreamFormatChanged(Format format);
    }

    public DefaultTrackOutput(Allocator allocator) {
        this.allocator = allocator;
        this.allocationLength = allocator.getIndividualAllocationLength();
    }

    public void reset(boolean z) {
        z = this.state.getAndSet(z ? false : true);
        clearSampleData();
        this.infoQueue.resetLargestParsedTimestamps();
        if (z) {
            this.downstreamFormat = false;
        }
    }

    public void sourceId(int i) {
        this.infoQueue.sourceId(i);
    }

    public void splice() {
        this.pendingSplice = true;
    }

    public int getWriteIndex() {
        return this.infoQueue.getWriteIndex();
    }

    public void discardUpstreamSamples(int i) {
        this.totalBytesWritten = this.infoQueue.discardUpstreamSamples(i);
        dropUpstreamFrom(this.totalBytesWritten);
    }

    private void dropUpstreamFrom(long j) {
        j = (int) (j - this.totalBytesDropped);
        int i = this.allocationLength;
        int i2 = j / i;
        j %= i;
        i = (this.dataQueue.size() - i2) - 1;
        if (j == null) {
            i++;
        }
        for (i2 = 0; i2 < i; i2++) {
            this.allocator.release((Allocation) this.dataQueue.removeLast());
        }
        this.lastAllocation = (Allocation) this.dataQueue.peekLast();
        if (j == null) {
            j = this.allocationLength;
        }
        this.lastAllocationOffset = j;
    }

    public void disable() {
        if (this.state.getAndSet(2) == 0) {
            clearSampleData();
        }
    }

    public boolean isEmpty() {
        return this.infoQueue.isEmpty();
    }

    public int getReadIndex() {
        return this.infoQueue.getReadIndex();
    }

    public int peekSourceId() {
        return this.infoQueue.peekSourceId();
    }

    public Format getUpstreamFormat() {
        return this.infoQueue.getUpstreamFormat();
    }

    public long getLargestQueuedTimestampUs() {
        return this.infoQueue.getLargestQueuedTimestampUs();
    }

    public void skipAll() {
        long skipAll = this.infoQueue.skipAll();
        if (skipAll != -1) {
            dropDownstreamTo(skipAll);
        }
    }

    public boolean skipToKeyframeBefore(long j, boolean z) {
        j = this.infoQueue.skipToKeyframeBefore(j, z);
        if (j == -1) {
            return 0;
        }
        dropDownstreamTo(j);
        return 1;
    }

    public int readData(FormatHolder formatHolder, DecoderInputBuffer decoderInputBuffer, boolean z, boolean z2, long j) {
        switch (this.infoQueue.readData(formatHolder, decoderInputBuffer, z, z2, this.downstreamFormat, this.extrasHolder)) {
            case C0361C.RESULT_FORMAT_READ /*-5*/:
                this.downstreamFormat = formatHolder.format;
                return -5;
            case true:
                if (decoderInputBuffer.isEndOfStream() == null) {
                    if (decoderInputBuffer.timeUs < j) {
                        decoderInputBuffer.addFlag(Integer.MIN_VALUE);
                    }
                    if (decoderInputBuffer.isEncrypted() != null) {
                        readEncryptionData(decoderInputBuffer, this.extrasHolder);
                    }
                    decoderInputBuffer.ensureSpaceForWrite(this.extrasHolder.size);
                    readData(this.extrasHolder.offset, decoderInputBuffer.data, this.extrasHolder.size);
                    dropDownstreamTo(this.extrasHolder.nextOffset);
                }
                return -4;
            case true:
                return -3;
            default:
                throw new IllegalStateException();
        }
    }

    private void readEncryptionData(DecoderInputBuffer decoderInputBuffer, BufferExtrasHolder bufferExtrasHolder) {
        int readUnsignedShort;
        int[] iArr;
        int[] iArr2;
        long j = bufferExtrasHolder.offset;
        this.scratch.reset(1);
        readData(j, this.scratch.data, 1);
        j++;
        int i = 0;
        byte b = this.scratch.data[0];
        Object obj = (b & 128) != 0 ? 1 : null;
        int i2 = b & 127;
        if (decoderInputBuffer.cryptoInfo.iv == null) {
            decoderInputBuffer.cryptoInfo.iv = new byte[16];
        }
        readData(j, decoderInputBuffer.cryptoInfo.iv, i2);
        j += (long) i2;
        if (obj != null) {
            this.scratch.reset(2);
            readData(j, this.scratch.data, 2);
            j += 2;
            readUnsignedShort = this.scratch.readUnsignedShort();
        } else {
            readUnsignedShort = 1;
        }
        int[] iArr3 = decoderInputBuffer.cryptoInfo.numBytesOfClearData;
        if (iArr3 != null) {
            if (iArr3.length >= readUnsignedShort) {
                iArr = iArr3;
                iArr3 = decoderInputBuffer.cryptoInfo.numBytesOfEncryptedData;
                if (iArr3 != null) {
                    if (iArr3.length < readUnsignedShort) {
                        iArr2 = iArr3;
                        if (obj == null) {
                            i2 = readUnsignedShort * 6;
                            this.scratch.reset(i2);
                            readData(j, this.scratch.data, i2);
                            j += (long) i2;
                            this.scratch.setPosition(0);
                            while (i < readUnsignedShort) {
                                iArr[i] = this.scratch.readUnsignedShort();
                                iArr2[i] = this.scratch.readUnsignedIntToInt();
                                i++;
                            }
                        } else {
                            iArr[0] = 0;
                            iArr2[0] = bufferExtrasHolder.size - ((int) (j - bufferExtrasHolder.offset));
                        }
                        decoderInputBuffer.cryptoInfo.set(readUnsignedShort, iArr, iArr2, bufferExtrasHolder.encryptionKeyId, decoderInputBuffer.cryptoInfo.iv, 1);
                        decoderInputBuffer = (int) (j - bufferExtrasHolder.offset);
                        bufferExtrasHolder.offset += (long) decoderInputBuffer;
                        bufferExtrasHolder.size -= decoderInputBuffer;
                    }
                }
                iArr2 = new int[readUnsignedShort];
                if (obj == null) {
                    iArr[0] = 0;
                    iArr2[0] = bufferExtrasHolder.size - ((int) (j - bufferExtrasHolder.offset));
                } else {
                    i2 = readUnsignedShort * 6;
                    this.scratch.reset(i2);
                    readData(j, this.scratch.data, i2);
                    j += (long) i2;
                    this.scratch.setPosition(0);
                    while (i < readUnsignedShort) {
                        iArr[i] = this.scratch.readUnsignedShort();
                        iArr2[i] = this.scratch.readUnsignedIntToInt();
                        i++;
                    }
                }
                decoderInputBuffer.cryptoInfo.set(readUnsignedShort, iArr, iArr2, bufferExtrasHolder.encryptionKeyId, decoderInputBuffer.cryptoInfo.iv, 1);
                decoderInputBuffer = (int) (j - bufferExtrasHolder.offset);
                bufferExtrasHolder.offset += (long) decoderInputBuffer;
                bufferExtrasHolder.size -= decoderInputBuffer;
            }
        }
        iArr = new int[readUnsignedShort];
        iArr3 = decoderInputBuffer.cryptoInfo.numBytesOfEncryptedData;
        if (iArr3 != null) {
            if (iArr3.length < readUnsignedShort) {
                iArr2 = iArr3;
                if (obj == null) {
                    i2 = readUnsignedShort * 6;
                    this.scratch.reset(i2);
                    readData(j, this.scratch.data, i2);
                    j += (long) i2;
                    this.scratch.setPosition(0);
                    while (i < readUnsignedShort) {
                        iArr[i] = this.scratch.readUnsignedShort();
                        iArr2[i] = this.scratch.readUnsignedIntToInt();
                        i++;
                    }
                } else {
                    iArr[0] = 0;
                    iArr2[0] = bufferExtrasHolder.size - ((int) (j - bufferExtrasHolder.offset));
                }
                decoderInputBuffer.cryptoInfo.set(readUnsignedShort, iArr, iArr2, bufferExtrasHolder.encryptionKeyId, decoderInputBuffer.cryptoInfo.iv, 1);
                decoderInputBuffer = (int) (j - bufferExtrasHolder.offset);
                bufferExtrasHolder.offset += (long) decoderInputBuffer;
                bufferExtrasHolder.size -= decoderInputBuffer;
            }
        }
        iArr2 = new int[readUnsignedShort];
        if (obj == null) {
            iArr[0] = 0;
            iArr2[0] = bufferExtrasHolder.size - ((int) (j - bufferExtrasHolder.offset));
        } else {
            i2 = readUnsignedShort * 6;
            this.scratch.reset(i2);
            readData(j, this.scratch.data, i2);
            j += (long) i2;
            this.scratch.setPosition(0);
            while (i < readUnsignedShort) {
                iArr[i] = this.scratch.readUnsignedShort();
                iArr2[i] = this.scratch.readUnsignedIntToInt();
                i++;
            }
        }
        decoderInputBuffer.cryptoInfo.set(readUnsignedShort, iArr, iArr2, bufferExtrasHolder.encryptionKeyId, decoderInputBuffer.cryptoInfo.iv, 1);
        decoderInputBuffer = (int) (j - bufferExtrasHolder.offset);
        bufferExtrasHolder.offset += (long) decoderInputBuffer;
        bufferExtrasHolder.size -= decoderInputBuffer;
    }

    private void readData(long j, ByteBuffer byteBuffer, int i) {
        while (i > 0) {
            dropDownstreamTo(j);
            int i2 = (int) (j - this.totalBytesDropped);
            int min = Math.min(i, this.allocationLength - i2);
            Allocation allocation = (Allocation) this.dataQueue.peek();
            byteBuffer.put(allocation.data, allocation.translateOffset(i2), min);
            j += (long) min;
            i -= min;
        }
    }

    private void readData(long j, byte[] bArr, int i) {
        int i2 = 0;
        while (i2 < i) {
            dropDownstreamTo(j);
            int i3 = (int) (j - this.totalBytesDropped);
            int min = Math.min(i - i2, this.allocationLength - i3);
            Allocation allocation = (Allocation) this.dataQueue.peek();
            System.arraycopy(allocation.data, allocation.translateOffset(i3), bArr, i2, min);
            j += (long) min;
            i2 += min;
        }
    }

    private void dropDownstreamTo(long j) {
        j = ((int) (j - this.totalBytesDropped)) / this.allocationLength;
        for (int i = 0; i < j; i++) {
            this.allocator.release((Allocation) this.dataQueue.remove());
            this.totalBytesDropped += (long) this.allocationLength;
        }
    }

    public void setUpstreamFormatChangeListener(UpstreamFormatChangedListener upstreamFormatChangedListener) {
        this.upstreamFormatChangeListener = upstreamFormatChangedListener;
    }

    public void setSampleOffsetUs(long j) {
        if (this.sampleOffsetUs != j) {
            this.sampleOffsetUs = j;
            this.pendingFormatAdjustment = 1;
        }
    }

    public void format(Format format) {
        Format adjustedSampleFormat = getAdjustedSampleFormat(format, this.sampleOffsetUs);
        boolean format2 = this.infoQueue.format(adjustedSampleFormat);
        this.lastUnadjustedFormat = format;
        this.pendingFormatAdjustment = null;
        format = this.upstreamFormatChangeListener;
        if (format != null && format2) {
            format.onUpstreamFormatChanged(adjustedSampleFormat);
        }
    }

    public int sampleData(ExtractorInput extractorInput, int i, boolean z) throws IOException, InterruptedException {
        if (startWriteOperation()) {
            try {
                extractorInput = extractorInput.read(this.lastAllocation.data, this.lastAllocation.translateOffset(this.lastAllocationOffset), prepareForAppend(i));
                if (extractorInput != -1) {
                    this.lastAllocationOffset += extractorInput;
                    this.totalBytesWritten += (long) extractorInput;
                    endWriteOperation();
                    return extractorInput;
                } else if (z) {
                    return -1;
                } else {
                    throw new EOFException();
                }
            } finally {
                endWriteOperation();
            }
        } else {
            extractorInput = extractorInput.skip(i);
            if (extractorInput != -1) {
                return extractorInput;
            }
            if (z) {
                return -1;
            }
            throw new EOFException();
        }
    }

    public void sampleData(ParsableByteArray parsableByteArray, int i) {
        if (startWriteOperation()) {
            while (i > 0) {
                int prepareForAppend = prepareForAppend(i);
                parsableByteArray.readBytes(this.lastAllocation.data, this.lastAllocation.translateOffset(this.lastAllocationOffset), prepareForAppend);
                this.lastAllocationOffset += prepareForAppend;
                this.totalBytesWritten += (long) prepareForAppend;
                i -= prepareForAppend;
            }
            endWriteOperation();
            return;
        }
        parsableByteArray.skipBytes(i);
    }

    public void sampleMetadata(long j, int i, int i2, int i3, byte[] bArr) {
        long j2 = j;
        if (this.pendingFormatAdjustment) {
            format(r1.lastUnadjustedFormat);
        }
        if (startWriteOperation()) {
            try {
                if (r1.pendingSplice) {
                    if ((i & 1) != 0) {
                        if (r1.infoQueue.attemptSplice(j)) {
                            r1.pendingSplice = false;
                        }
                    }
                    endWriteOperation();
                    return;
                }
                r1.infoQueue.commitSample(r1.sampleOffsetUs + j2, i, (r1.totalBytesWritten - ((long) i2)) - ((long) i3), i2, bArr);
                endWriteOperation();
            } catch (Throwable th) {
                endWriteOperation();
            }
        } else {
            r1.infoQueue.commitSampleTimestamp(j);
        }
    }

    private boolean startWriteOperation() {
        return this.state.compareAndSet(0, 1);
    }

    private void endWriteOperation() {
        if (!this.state.compareAndSet(1, 0)) {
            clearSampleData();
        }
    }

    private void clearSampleData() {
        this.infoQueue.clearSampleData();
        Allocator allocator = this.allocator;
        LinkedBlockingDeque linkedBlockingDeque = this.dataQueue;
        allocator.release((Allocation[]) linkedBlockingDeque.toArray(new Allocation[linkedBlockingDeque.size()]));
        this.dataQueue.clear();
        this.allocator.trim();
        this.totalBytesDropped = 0;
        this.totalBytesWritten = 0;
        this.lastAllocation = null;
        this.lastAllocationOffset = this.allocationLength;
    }

    private int prepareForAppend(int i) {
        if (this.lastAllocationOffset == this.allocationLength) {
            this.lastAllocationOffset = 0;
            this.lastAllocation = this.allocator.allocate();
            this.dataQueue.add(this.lastAllocation);
        }
        return Math.min(i, this.allocationLength - this.lastAllocationOffset);
    }

    private static Format getAdjustedSampleFormat(Format format, long j) {
        if (format == null) {
            return null;
        }
        if (!(j == 0 || format.subsampleOffsetUs == Long.MAX_VALUE)) {
            format = format.copyWithSubsampleOffsetUs(format.subsampleOffsetUs + j);
        }
        return format;
    }
}
