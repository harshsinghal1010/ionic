package com.google.android.exoplayer2.extractor.ogg;

import com.google.android.exoplayer2.util.Assertions;

final class VorbisBitArray {
    private int bitOffset;
    private int byteOffset;
    public final byte[] data;
    private final int limit;

    public VorbisBitArray(byte[] bArr) {
        this(bArr, bArr.length);
    }

    public VorbisBitArray(byte[] bArr, int i) {
        this.data = bArr;
        this.limit = i * 8;
    }

    public void reset() {
        this.byteOffset = 0;
        this.bitOffset = 0;
    }

    public boolean readBit() {
        return readBits(1) == 1;
    }

    public int readBits(int i) {
        int i2 = 0;
        Assertions.checkState(getPosition() + i <= this.limit);
        if (i == 0) {
            return 0;
        }
        int i3;
        int i4 = this.bitOffset;
        if (i4 != 0) {
            i4 = Math.min(i, 8 - i4);
            i3 = 255 >>> (8 - i4);
            byte[] bArr = this.data;
            int i5 = this.byteOffset;
            byte b = bArr[i5];
            int i6 = this.bitOffset;
            i3 &= b >>> i6;
            this.bitOffset = i6 + i4;
            if (this.bitOffset == 8) {
                this.byteOffset = i5 + 1;
                this.bitOffset = 0;
            }
        } else {
            i4 = 0;
            i3 = 0;
        }
        int i7 = i - i4;
        if (i7 > 7) {
            i7 /= 8;
            while (i2 < i7) {
                long j = (long) i3;
                byte[] bArr2 = this.data;
                i6 = this.byteOffset;
                this.byteOffset = i6 + 1;
                i3 = (int) (j | ((((long) bArr2[i6]) & 255) << i4));
                i4 += 8;
                i2++;
            }
        }
        if (i > i4) {
            i -= i4;
            i3 |= ((255 >>> (8 - i)) & this.data[this.byteOffset]) << i4;
            this.bitOffset += i;
        }
        return i3;
    }

    public void skipBits(int i) {
        Assertions.checkState(getPosition() + i <= this.limit);
        this.byteOffset += i / 8;
        this.bitOffset += i % 8;
        i = this.bitOffset;
        if (i > 7) {
            this.byteOffset++;
            this.bitOffset = i - 8;
        }
    }

    public int getPosition() {
        return (this.byteOffset * 8) + this.bitOffset;
    }

    public void setPosition(int i) {
        boolean z = i < this.limit && i >= 0;
        Assertions.checkArgument(z);
        this.byteOffset = i / 8;
        this.bitOffset = i - (this.byteOffset * 8);
    }

    public int bitsLeft() {
        return this.limit - getPosition();
    }

    public int limit() {
        return this.limit;
    }
}
