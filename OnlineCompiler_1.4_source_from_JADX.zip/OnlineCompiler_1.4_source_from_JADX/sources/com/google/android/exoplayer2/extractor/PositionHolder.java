package com.google.android.exoplayer2.extractor;

public final class PositionHolder {
    public long position;
}
