package com.google.android.exoplayer2.extractor.ogg;

import com.google.android.exoplayer2.extractor.Extractor;
import com.google.android.exoplayer2.extractor.ExtractorInput;
import com.google.android.exoplayer2.extractor.ExtractorOutput;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.extractor.PositionHolder;
import com.google.android.exoplayer2.extractor.TrackOutput;
import com.google.android.exoplayer2.util.ParsableByteArray;
import java.io.IOException;

public class OggExtractor implements Extractor {
    public static final ExtractorsFactory FACTORY = new C08581();
    private static final int MAX_VERIFICATION_BYTES = 8;
    private StreamReader streamReader;

    /* renamed from: com.google.android.exoplayer2.extractor.ogg.OggExtractor$1 */
    static class C08581 implements ExtractorsFactory {
        C08581() {
        }

        public Extractor[] createExtractors() {
            return new Extractor[]{new OggExtractor()};
        }
    }

    public void release() {
    }

    public boolean sniff(com.google.android.exoplayer2.extractor.ExtractorInput r6) throws java.io.IOException, java.lang.InterruptedException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = 0;
        r1 = new com.google.android.exoplayer2.extractor.ogg.OggPageHeader;	 Catch:{ ParserException -> 0x005e }
        r1.<init>();	 Catch:{ ParserException -> 0x005e }
        r2 = 1;	 Catch:{ ParserException -> 0x005e }
        r3 = r1.populate(r6, r2);	 Catch:{ ParserException -> 0x005e }
        if (r3 == 0) goto L_0x005d;	 Catch:{ ParserException -> 0x005e }
    L_0x000d:
        r3 = r1.type;	 Catch:{ ParserException -> 0x005e }
        r4 = 2;	 Catch:{ ParserException -> 0x005e }
        r3 = r3 & r4;	 Catch:{ ParserException -> 0x005e }
        if (r3 == r4) goto L_0x0014;	 Catch:{ ParserException -> 0x005e }
    L_0x0013:
        goto L_0x005d;	 Catch:{ ParserException -> 0x005e }
    L_0x0014:
        r1 = r1.bodySize;	 Catch:{ ParserException -> 0x005e }
        r3 = 8;	 Catch:{ ParserException -> 0x005e }
        r1 = java.lang.Math.min(r1, r3);	 Catch:{ ParserException -> 0x005e }
        r3 = new com.google.android.exoplayer2.util.ParsableByteArray;	 Catch:{ ParserException -> 0x005e }
        r3.<init>(r1);	 Catch:{ ParserException -> 0x005e }
        r4 = r3.data;	 Catch:{ ParserException -> 0x005e }
        r6.peekFully(r4, r0, r1);	 Catch:{ ParserException -> 0x005e }
        r6 = resetPosition(r3);	 Catch:{ ParserException -> 0x005e }
        r6 = com.google.android.exoplayer2.extractor.ogg.FlacReader.verifyBitstreamType(r6);	 Catch:{ ParserException -> 0x005e }
        if (r6 == 0) goto L_0x0038;	 Catch:{ ParserException -> 0x005e }
    L_0x0030:
        r6 = new com.google.android.exoplayer2.extractor.ogg.FlacReader;	 Catch:{ ParserException -> 0x005e }
        r6.<init>();	 Catch:{ ParserException -> 0x005e }
        r5.streamReader = r6;	 Catch:{ ParserException -> 0x005e }
        goto L_0x005b;	 Catch:{ ParserException -> 0x005e }
    L_0x0038:
        r6 = resetPosition(r3);	 Catch:{ ParserException -> 0x005e }
        r6 = com.google.android.exoplayer2.extractor.ogg.VorbisReader.verifyBitstreamType(r6);	 Catch:{ ParserException -> 0x005e }
        if (r6 == 0) goto L_0x004a;	 Catch:{ ParserException -> 0x005e }
    L_0x0042:
        r6 = new com.google.android.exoplayer2.extractor.ogg.VorbisReader;	 Catch:{ ParserException -> 0x005e }
        r6.<init>();	 Catch:{ ParserException -> 0x005e }
        r5.streamReader = r6;	 Catch:{ ParserException -> 0x005e }
        goto L_0x005b;	 Catch:{ ParserException -> 0x005e }
    L_0x004a:
        r6 = resetPosition(r3);	 Catch:{ ParserException -> 0x005e }
        r6 = com.google.android.exoplayer2.extractor.ogg.OpusReader.verifyBitstreamType(r6);	 Catch:{ ParserException -> 0x005e }
        if (r6 == 0) goto L_0x005c;	 Catch:{ ParserException -> 0x005e }
    L_0x0054:
        r6 = new com.google.android.exoplayer2.extractor.ogg.OpusReader;	 Catch:{ ParserException -> 0x005e }
        r6.<init>();	 Catch:{ ParserException -> 0x005e }
        r5.streamReader = r6;	 Catch:{ ParserException -> 0x005e }
    L_0x005b:
        return r2;
    L_0x005c:
        return r0;
    L_0x005d:
        return r0;
    L_0x005e:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.ogg.OggExtractor.sniff(com.google.android.exoplayer2.extractor.ExtractorInput):boolean");
    }

    public void init(ExtractorOutput extractorOutput) {
        TrackOutput track = extractorOutput.track(0, 1);
        extractorOutput.endTracks();
        this.streamReader.init(extractorOutput, track);
    }

    public void seek(long j, long j2) {
        this.streamReader.seek(j, j2);
    }

    public int read(ExtractorInput extractorInput, PositionHolder positionHolder) throws IOException, InterruptedException {
        return this.streamReader.read(extractorInput, positionHolder);
    }

    StreamReader getStreamReader() {
        return this.streamReader;
    }

    private static ParsableByteArray resetPosition(ParsableByteArray parsableByteArray) {
        parsableByteArray.setPosition(0);
        return parsableByteArray;
    }
}
