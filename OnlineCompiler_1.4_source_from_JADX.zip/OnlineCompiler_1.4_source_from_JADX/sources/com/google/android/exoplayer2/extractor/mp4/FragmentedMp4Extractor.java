package com.google.android.exoplayer2.extractor.mp4;

import android.util.Log;
import android.util.Pair;
import android.util.SparseArray;
import com.google.android.exoplayer2.C0361C;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.drm.DrmInitData.SchemeData;
import com.google.android.exoplayer2.extractor.ChunkIndex;
import com.google.android.exoplayer2.extractor.Extractor;
import com.google.android.exoplayer2.extractor.ExtractorInput;
import com.google.android.exoplayer2.extractor.ExtractorOutput;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.extractor.PositionHolder;
import com.google.android.exoplayer2.extractor.SeekMap;
import com.google.android.exoplayer2.extractor.TrackOutput;
import com.google.android.exoplayer2.text.cea.CeaUtil;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.exoplayer2.util.NalUnitUtil;
import com.google.android.exoplayer2.util.ParsableByteArray;
import com.google.android.exoplayer2.util.TimestampAdjuster;
import com.google.android.exoplayer2.util.Util;
import java.io.IOException;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.UUID;

public final class FragmentedMp4Extractor implements Extractor {
    public static final ExtractorsFactory FACTORY = new C08561();
    public static final int FLAG_ENABLE_CEA608_TRACK = 8;
    public static final int FLAG_ENABLE_EMSG_TRACK = 4;
    private static final int FLAG_SIDELOADED = 16;
    public static final int FLAG_WORKAROUND_EVERY_VIDEO_FRAME_IS_SYNC_FRAME = 1;
    public static final int FLAG_WORKAROUND_IGNORE_TFDT_BOX = 2;
    private static final byte[] PIFF_SAMPLE_ENCRYPTION_BOX_EXTENDED_TYPE = new byte[]{(byte) -94, (byte) 57, (byte) 79, (byte) 82, (byte) 90, (byte) -101, (byte) 79, (byte) 20, (byte) -94, (byte) 68, (byte) 108, (byte) 66, (byte) 124, (byte) 100, (byte) -115, (byte) -12};
    private static final int SAMPLE_GROUP_TYPE_seig = Util.getIntegerCodeForString("seig");
    private static final int STATE_READING_ATOM_HEADER = 0;
    private static final int STATE_READING_ATOM_PAYLOAD = 1;
    private static final int STATE_READING_ENCRYPTION_DATA = 2;
    private static final int STATE_READING_SAMPLE_CONTINUE = 4;
    private static final int STATE_READING_SAMPLE_START = 3;
    private static final String TAG = "FragmentedMp4Extractor";
    private ParsableByteArray atomData;
    private final ParsableByteArray atomHeader;
    private int atomHeaderBytesRead;
    private long atomSize;
    private int atomType;
    private TrackOutput[] cea608TrackOutputs;
    private final Stack<ContainerAtom> containerAtoms;
    private TrackBundle currentTrackBundle;
    private long durationUs;
    private final ParsableByteArray encryptionSignalByte;
    private long endOfMdatPosition;
    private TrackOutput eventMessageTrackOutput;
    private final byte[] extendedTypeScratch;
    private ExtractorOutput extractorOutput;
    private final int flags;
    private boolean haveOutputSeekMap;
    private final ParsableByteArray nalBuffer;
    private final ParsableByteArray nalPrefix;
    private final ParsableByteArray nalStartCode;
    private int parserState;
    private int pendingMetadataSampleBytes;
    private final LinkedList<MetadataSampleInfo> pendingMetadataSampleInfos;
    private boolean processSeiNalUnitPayload;
    private int sampleBytesWritten;
    private int sampleCurrentNalBytesRemaining;
    private int sampleSize;
    private long segmentIndexEarliestPresentationTimeUs;
    private final Track sideloadedTrack;
    private final TimestampAdjuster timestampAdjuster;
    private final SparseArray<TrackBundle> trackBundles;

    @Retention(RetentionPolicy.SOURCE)
    public @interface Flags {
    }

    private static final class MetadataSampleInfo {
        public final long presentationTimeDeltaUs;
        public final int size;

        public MetadataSampleInfo(long j, int i) {
            this.presentationTimeDeltaUs = j;
            this.size = i;
        }
    }

    private static final class TrackBundle {
        public int currentSampleInTrackRun;
        public int currentSampleIndex;
        public int currentTrackRunIndex;
        public DefaultSampleValues defaultSampleValues;
        public final TrackFragment fragment = new TrackFragment();
        public final TrackOutput output;
        public Track track;

        public TrackBundle(TrackOutput trackOutput) {
            this.output = trackOutput;
        }

        public void init(Track track, DefaultSampleValues defaultSampleValues) {
            this.track = (Track) Assertions.checkNotNull(track);
            this.defaultSampleValues = (DefaultSampleValues) Assertions.checkNotNull(defaultSampleValues);
            this.output.format(track.format);
            reset();
        }

        public void reset() {
            this.fragment.reset();
            this.currentSampleIndex = 0;
            this.currentTrackRunIndex = 0;
            this.currentSampleInTrackRun = 0;
        }

        public void updateDrmInitData(DrmInitData drmInitData) {
            this.output.format(this.track.format.copyWithDrmInitData(drmInitData));
        }
    }

    /* renamed from: com.google.android.exoplayer2.extractor.mp4.FragmentedMp4Extractor$1 */
    static class C08561 implements ExtractorsFactory {
        C08561() {
        }

        public Extractor[] createExtractors() {
            return new Extractor[]{new FragmentedMp4Extractor()};
        }
    }

    private static void parseSaiz(com.google.android.exoplayer2.extractor.mp4.TrackEncryptionBox r7, com.google.android.exoplayer2.util.ParsableByteArray r8, com.google.android.exoplayer2.extractor.mp4.TrackFragment r9) throws com.google.android.exoplayer2.ParserException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:22:0x006c in {2, 11, 12, 13, 15, 16, 17, 19, 21} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r7 = r7.initializationVectorSize;
        r0 = 8;
        r8.setPosition(r0);
        r1 = r8.readInt();
        r1 = com.google.android.exoplayer2.extractor.mp4.Atom.parseFullAtomFlags(r1);
        r2 = 1;
        r1 = r1 & r2;
        if (r1 != r2) goto L_0x0016;
    L_0x0013:
        r8.skipBytes(r0);
    L_0x0016:
        r0 = r8.readUnsignedByte();
        r1 = r8.readUnsignedIntToInt();
        r3 = r9.sampleCount;
        if (r1 != r3) goto L_0x004b;
    L_0x0022:
        r3 = 0;
        if (r0 != 0) goto L_0x003a;
    L_0x0025:
        r0 = r9.sampleHasSubsampleEncryptionTable;
        r4 = 0;
        r5 = 0;
    L_0x0029:
        if (r4 >= r1) goto L_0x0047;
    L_0x002b:
        r6 = r8.readUnsignedByte();
        r5 = r5 + r6;
        if (r6 <= r7) goto L_0x0034;
    L_0x0032:
        r6 = 1;
        goto L_0x0035;
    L_0x0034:
        r6 = 0;
    L_0x0035:
        r0[r4] = r6;
        r4 = r4 + 1;
        goto L_0x0029;
    L_0x003a:
        if (r0 <= r7) goto L_0x003d;
    L_0x003c:
        goto L_0x003e;
    L_0x003d:
        r2 = 0;
    L_0x003e:
        r0 = r0 * r1;
        r5 = r0 + 0;
        r7 = r9.sampleHasSubsampleEncryptionTable;
        java.util.Arrays.fill(r7, r3, r1, r2);
    L_0x0047:
        r9.initEncryptionData(r5);
        return;
    L_0x004b:
        r7 = new com.google.android.exoplayer2.ParserException;
        r8 = new java.lang.StringBuilder;
        r8.<init>();
        r0 = "Length mismatch: ";
        r8.append(r0);
        r8.append(r1);
        r0 = ", ";
        r8.append(r0);
        r9 = r9.sampleCount;
        r8.append(r9);
        r8 = r8.toString();
        r7.<init>(r8);
        throw r7;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.mp4.FragmentedMp4Extractor.parseSaiz(com.google.android.exoplayer2.extractor.mp4.TrackEncryptionBox, com.google.android.exoplayer2.util.ParsableByteArray, com.google.android.exoplayer2.extractor.mp4.TrackFragment):void");
    }

    private boolean readAtomHeader(com.google.android.exoplayer2.extractor.ExtractorInput r9) throws java.io.IOException, java.lang.InterruptedException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:48:0x0122 in {4, 5, 8, 15, 20, 22, 27, 28, 35, 37, 39, 42, 43, 45, 47} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r8 = this;
        r0 = r8.atomHeaderBytesRead;
        r1 = 8;
        r2 = 0;
        r3 = 1;
        if (r0 != 0) goto L_0x002a;
    L_0x0008:
        r0 = r8.atomHeader;
        r0 = r0.data;
        r0 = r9.readFully(r0, r2, r1, r3);
        if (r0 != 0) goto L_0x0013;
    L_0x0012:
        return r2;
    L_0x0013:
        r8.atomHeaderBytesRead = r1;
        r0 = r8.atomHeader;
        r0.setPosition(r2);
        r0 = r8.atomHeader;
        r4 = r0.readUnsignedInt();
        r8.atomSize = r4;
        r0 = r8.atomHeader;
        r0 = r0.readInt();
        r8.atomType = r0;
    L_0x002a:
        r4 = r8.atomSize;
        r6 = 1;
        r0 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r0 != 0) goto L_0x0046;
    L_0x0032:
        r0 = r8.atomHeader;
        r0 = r0.data;
        r9.readFully(r0, r1, r1);
        r0 = r8.atomHeaderBytesRead;
        r0 = r0 + r1;
        r8.atomHeaderBytesRead = r0;
        r0 = r8.atomHeader;
        r4 = r0.readUnsignedLongToLong();
        r8.atomSize = r4;
    L_0x0046:
        r4 = r8.atomSize;
        r0 = r8.atomHeaderBytesRead;
        r6 = (long) r0;
        r0 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r0 < 0) goto L_0x011a;
    L_0x004f:
        r4 = r9.getPosition();
        r0 = r8.atomHeaderBytesRead;
        r6 = (long) r0;
        r4 = r4 - r6;
        r0 = r8.atomType;
        r6 = com.google.android.exoplayer2.extractor.mp4.Atom.TYPE_moof;
        if (r0 != r6) goto L_0x0079;
    L_0x005d:
        r0 = r8.trackBundles;
        r0 = r0.size();
        r6 = 0;
    L_0x0064:
        if (r6 >= r0) goto L_0x0079;
    L_0x0066:
        r7 = r8.trackBundles;
        r7 = r7.valueAt(r6);
        r7 = (com.google.android.exoplayer2.extractor.mp4.FragmentedMp4Extractor.TrackBundle) r7;
        r7 = r7.fragment;
        r7.atomPosition = r4;
        r7.auxiliaryDataPosition = r4;
        r7.dataPosition = r4;
        r6 = r6 + 1;
        goto L_0x0064;
    L_0x0079:
        r0 = r8.atomType;
        r6 = com.google.android.exoplayer2.extractor.mp4.Atom.TYPE_mdat;
        r7 = 0;
        if (r0 != r6) goto L_0x009d;
    L_0x0080:
        r8.currentTrackBundle = r7;
        r0 = r8.atomSize;
        r4 = r4 + r0;
        r8.endOfMdatPosition = r4;
        r9 = r8.haveOutputSeekMap;
        if (r9 != 0) goto L_0x0099;
    L_0x008b:
        r9 = r8.extractorOutput;
        r0 = new com.google.android.exoplayer2.extractor.SeekMap$Unseekable;
        r1 = r8.durationUs;
        r0.<init>(r1);
        r9.seekMap(r0);
        r8.haveOutputSeekMap = r3;
    L_0x0099:
        r9 = 2;
        r8.parserState = r9;
        return r3;
    L_0x009d:
        r0 = r8.atomType;
        r0 = shouldParseContainerAtom(r0);
        if (r0 == 0) goto L_0x00cc;
    L_0x00a5:
        r0 = r9.getPosition();
        r4 = r8.atomSize;
        r0 = r0 + r4;
        r4 = 8;
        r0 = r0 - r4;
        r9 = r8.containerAtoms;
        r2 = new com.google.android.exoplayer2.extractor.mp4.Atom$ContainerAtom;
        r4 = r8.atomType;
        r2.<init>(r4, r0);
        r9.add(r2);
        r4 = r8.atomSize;
        r9 = r8.atomHeaderBytesRead;
        r6 = (long) r9;
        r9 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r9 != 0) goto L_0x00c8;
    L_0x00c4:
        r8.processAtomEnded(r0);
        goto L_0x0111;
    L_0x00c8:
        r8.enterReadingAtomHeaderState();
        goto L_0x0111;
    L_0x00cc:
        r9 = r8.atomType;
        r9 = shouldParseLeafAtom(r9);
        r4 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        if (r9 == 0) goto L_0x0107;
    L_0x00d7:
        r9 = r8.atomHeaderBytesRead;
        if (r9 != r1) goto L_0x00ff;
    L_0x00db:
        r6 = r8.atomSize;
        r9 = (r6 > r4 ? 1 : (r6 == r4 ? 0 : -1));
        if (r9 > 0) goto L_0x00f7;
    L_0x00e1:
        r9 = new com.google.android.exoplayer2.util.ParsableByteArray;
        r0 = (int) r6;
        r9.<init>(r0);
        r8.atomData = r9;
        r9 = r8.atomHeader;
        r9 = r9.data;
        r0 = r8.atomData;
        r0 = r0.data;
        java.lang.System.arraycopy(r9, r2, r0, r2, r1);
        r8.parserState = r3;
        goto L_0x0111;
    L_0x00f7:
        r9 = new com.google.android.exoplayer2.ParserException;
        r0 = "Leaf atom with length > 2147483647 (unsupported).";
        r9.<init>(r0);
        throw r9;
    L_0x00ff:
        r9 = new com.google.android.exoplayer2.ParserException;
        r0 = "Leaf atom defines extended atom size (unsupported).";
        r9.<init>(r0);
        throw r9;
    L_0x0107:
        r0 = r8.atomSize;
        r9 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1));
        if (r9 > 0) goto L_0x0112;
    L_0x010d:
        r8.atomData = r7;
        r8.parserState = r3;
    L_0x0111:
        return r3;
    L_0x0112:
        r9 = new com.google.android.exoplayer2.ParserException;
        r0 = "Skipping atom with length > 2147483647 (unsupported).";
        r9.<init>(r0);
        throw r9;
    L_0x011a:
        r9 = new com.google.android.exoplayer2.ParserException;
        r0 = "Atom size less than header length (unsupported).";
        r9.<init>(r0);
        throw r9;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.mp4.FragmentedMp4Extractor.readAtomHeader(com.google.android.exoplayer2.extractor.ExtractorInput):boolean");
    }

    private void readEncryptionData(com.google.android.exoplayer2.extractor.ExtractorInput r12) throws java.io.IOException, java.lang.InterruptedException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:17:0x0052 in {6, 7, 10, 14, 16} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r11 = this;
        r0 = r11.trackBundles;
        r0 = r0.size();
        r1 = 0;
        r2 = 9223372036854775807; // 0x7fffffffffffffff float:NaN double:NaN;
        r4 = 0;
    L_0x000d:
        if (r4 >= r0) goto L_0x0033;
    L_0x000f:
        r5 = r11.trackBundles;
        r5 = r5.valueAt(r4);
        r5 = (com.google.android.exoplayer2.extractor.mp4.FragmentedMp4Extractor.TrackBundle) r5;
        r5 = r5.fragment;
        r6 = r5.sampleEncryptionDataNeedsFill;
        if (r6 == 0) goto L_0x0030;
    L_0x001d:
        r6 = r5.auxiliaryDataPosition;
        r8 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1));
        if (r8 >= 0) goto L_0x0030;
    L_0x0023:
        r1 = r5.auxiliaryDataPosition;
        r3 = r11.trackBundles;
        r3 = r3.valueAt(r4);
        r3 = (com.google.android.exoplayer2.extractor.mp4.FragmentedMp4Extractor.TrackBundle) r3;
        r9 = r1;
        r1 = r3;
        r2 = r9;
    L_0x0030:
        r4 = r4 + 1;
        goto L_0x000d;
    L_0x0033:
        if (r1 != 0) goto L_0x0039;
    L_0x0035:
        r12 = 3;
        r11.parserState = r12;
        return;
    L_0x0039:
        r4 = r12.getPosition();
        r2 = r2 - r4;
        r0 = (int) r2;
        if (r0 < 0) goto L_0x004a;
    L_0x0041:
        r12.skipFully(r0);
        r0 = r1.fragment;
        r0.fillEncryptionData(r12);
        return;
    L_0x004a:
        r12 = new com.google.android.exoplayer2.ParserException;
        r0 = "Offset to encryption data was negative.";
        r12.<init>(r0);
        throw r12;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.mp4.FragmentedMp4Extractor.readEncryptionData(com.google.android.exoplayer2.extractor.ExtractorInput):void");
    }

    public void release() {
    }

    public FragmentedMp4Extractor() {
        this(0);
    }

    public FragmentedMp4Extractor(int i) {
        this(i, null);
    }

    public FragmentedMp4Extractor(int i, TimestampAdjuster timestampAdjuster) {
        this(i, timestampAdjuster, null);
    }

    public FragmentedMp4Extractor(int i, TimestampAdjuster timestampAdjuster, Track track) {
        this.flags = i | (track != null ? 16 : 0);
        this.timestampAdjuster = timestampAdjuster;
        this.sideloadedTrack = track;
        this.atomHeader = new ParsableByteArray(16);
        this.nalStartCode = new ParsableByteArray(NalUnitUtil.NAL_START_CODE);
        this.nalPrefix = new ParsableByteArray(5);
        this.nalBuffer = new ParsableByteArray();
        this.encryptionSignalByte = new ParsableByteArray(1);
        this.extendedTypeScratch = new byte[16];
        this.containerAtoms = new Stack();
        this.pendingMetadataSampleInfos = new LinkedList();
        this.trackBundles = new SparseArray();
        this.durationUs = C0361C.TIME_UNSET;
        this.segmentIndexEarliestPresentationTimeUs = C0361C.TIME_UNSET;
        enterReadingAtomHeaderState();
    }

    public boolean sniff(ExtractorInput extractorInput) throws IOException, InterruptedException {
        return Sniffer.sniffFragmented(extractorInput);
    }

    public void init(ExtractorOutput extractorOutput) {
        this.extractorOutput = extractorOutput;
        Track track = this.sideloadedTrack;
        if (track != null) {
            TrackBundle trackBundle = new TrackBundle(extractorOutput.track(0, track.type));
            trackBundle.init(this.sideloadedTrack, new DefaultSampleValues(0, 0, 0, 0));
            this.trackBundles.put(0, trackBundle);
            maybeInitExtraTracks();
            this.extractorOutput.endTracks();
        }
    }

    public void seek(long j, long j2) {
        j = this.trackBundles.size();
        for (j2 = null; j2 < j; j2++) {
            ((TrackBundle) this.trackBundles.valueAt(j2)).reset();
        }
        this.pendingMetadataSampleInfos.clear();
        this.pendingMetadataSampleBytes = 0;
        this.containerAtoms.clear();
        enterReadingAtomHeaderState();
    }

    public int read(ExtractorInput extractorInput, PositionHolder positionHolder) throws IOException, InterruptedException {
        while (true) {
            switch (this.parserState) {
                case null:
                    if (readAtomHeader(extractorInput) != null) {
                        break;
                    }
                    return -1;
                case 1:
                    readAtomPayload(extractorInput);
                    break;
                case 2:
                    readEncryptionData(extractorInput);
                    break;
                default:
                    if (readSample(extractorInput) == null) {
                        break;
                    }
                    return null;
            }
        }
    }

    private void enterReadingAtomHeaderState() {
        this.parserState = 0;
        this.atomHeaderBytesRead = 0;
    }

    private void readAtomPayload(ExtractorInput extractorInput) throws IOException, InterruptedException {
        int i = ((int) this.atomSize) - this.atomHeaderBytesRead;
        ParsableByteArray parsableByteArray = this.atomData;
        if (parsableByteArray != null) {
            extractorInput.readFully(parsableByteArray.data, 8, i);
            onLeafAtomRead(new LeafAtom(this.atomType, this.atomData), extractorInput.getPosition());
        } else {
            extractorInput.skipFully(i);
        }
        processAtomEnded(extractorInput.getPosition());
    }

    private void processAtomEnded(long j) throws ParserException {
        while (!this.containerAtoms.isEmpty() && ((ContainerAtom) this.containerAtoms.peek()).endPosition == j) {
            onContainerAtomRead((ContainerAtom) this.containerAtoms.pop());
        }
        enterReadingAtomHeaderState();
    }

    private void onLeafAtomRead(LeafAtom leafAtom, long j) throws ParserException {
        if (!this.containerAtoms.isEmpty()) {
            ((ContainerAtom) this.containerAtoms.peek()).add(leafAtom);
        } else if (leafAtom.type == Atom.TYPE_sidx) {
            leafAtom = parseSidx(leafAtom.data, j);
            this.segmentIndexEarliestPresentationTimeUs = ((Long) leafAtom.first).longValue();
            this.extractorOutput.seekMap((SeekMap) leafAtom.second);
            this.haveOutputSeekMap = true;
        } else if (leafAtom.type == Atom.TYPE_emsg) {
            onEmsgLeafAtomRead(leafAtom.data);
        }
    }

    private void onContainerAtomRead(ContainerAtom containerAtom) throws ParserException {
        if (containerAtom.type == Atom.TYPE_moov) {
            onMoovContainerAtomRead(containerAtom);
        } else if (containerAtom.type == Atom.TYPE_moof) {
            onMoofContainerAtomRead(containerAtom);
        } else if (!this.containerAtoms.isEmpty()) {
            ((ContainerAtom) this.containerAtoms.peek()).add(containerAtom);
        }
    }

    private void onMoovContainerAtomRead(ContainerAtom containerAtom) throws ParserException {
        ContainerAtom containerAtom2 = containerAtom;
        boolean z = true;
        int i = 0;
        Assertions.checkState(this.sideloadedTrack == null, "Unexpected moov box.");
        DrmInitData drmInitDataFromAtoms = getDrmInitDataFromAtoms(containerAtom2.leafChildren);
        ContainerAtom containerAtomOfType = containerAtom2.getContainerAtomOfType(Atom.TYPE_mvex);
        SparseArray sparseArray = new SparseArray();
        int size = containerAtomOfType.leafChildren.size();
        long j = C0361C.TIME_UNSET;
        for (int i2 = 0; i2 < size; i2++) {
            LeafAtom leafAtom = (LeafAtom) containerAtomOfType.leafChildren.get(i2);
            if (leafAtom.type == Atom.TYPE_trex) {
                Pair parseTrex = parseTrex(leafAtom.data);
                sparseArray.put(((Integer) parseTrex.first).intValue(), parseTrex.second);
            } else if (leafAtom.type == Atom.TYPE_mehd) {
                j = parseMehd(leafAtom.data);
            }
        }
        SparseArray sparseArray2 = new SparseArray();
        int size2 = containerAtom2.containerChildren.size();
        int i3 = 0;
        while (i3 < size2) {
            int i4;
            containerAtomOfType = (ContainerAtom) containerAtom2.containerChildren.get(i3);
            if (containerAtomOfType.type == Atom.TYPE_trak) {
                i4 = i3;
                Track parseTrak = AtomParsers.parseTrak(containerAtomOfType, containerAtom2.getLeafAtomOfType(Atom.TYPE_mvhd), j, drmInitDataFromAtoms, false);
                if (parseTrak != null) {
                    sparseArray2.put(parseTrak.id, parseTrak);
                }
            } else {
                i4 = i3;
            }
            i3 = i4 + 1;
        }
        int size3 = sparseArray2.size();
        if (r0.trackBundles.size() == 0) {
            while (i < size3) {
                Track track = (Track) sparseArray2.valueAt(i);
                TrackBundle trackBundle = new TrackBundle(r0.extractorOutput.track(i, track.type));
                trackBundle.init(track, (DefaultSampleValues) sparseArray.get(track.id));
                r0.trackBundles.put(track.id, trackBundle);
                r0.durationUs = Math.max(r0.durationUs, track.durationUs);
                i++;
            }
            maybeInitExtraTracks();
            r0.extractorOutput.endTracks();
            return;
        }
        if (r0.trackBundles.size() != size3) {
            z = false;
        }
        Assertions.checkState(z);
        while (i < size3) {
            track = (Track) sparseArray2.valueAt(i);
            ((TrackBundle) r0.trackBundles.get(track.id)).init(track, (DefaultSampleValues) sparseArray.get(track.id));
            i++;
        }
    }

    private void onMoofContainerAtomRead(ContainerAtom containerAtom) throws ParserException {
        parseMoof(containerAtom, this.trackBundles, this.flags, this.extendedTypeScratch);
        containerAtom = getDrmInitDataFromAtoms(containerAtom.leafChildren);
        if (containerAtom != null) {
            int size = this.trackBundles.size();
            for (int i = 0; i < size; i++) {
                ((TrackBundle) this.trackBundles.valueAt(i)).updateDrmInitData(containerAtom);
            }
        }
    }

    private void maybeInitExtraTracks() {
        if ((this.flags & 4) != 0 && this.eventMessageTrackOutput == null) {
            this.eventMessageTrackOutput = this.extractorOutput.track(this.trackBundles.size(), 4);
            this.eventMessageTrackOutput.format(Format.createSampleFormat(null, MimeTypes.APPLICATION_EMSG, Long.MAX_VALUE));
        }
        if ((this.flags & 8) != 0 && this.cea608TrackOutputs == null) {
            this.extractorOutput.track(this.trackBundles.size() + 1, 3).format(Format.createTextSampleFormat(null, MimeTypes.APPLICATION_CEA608, null, -1, 0, null, null));
            this.cea608TrackOutputs = new TrackOutput[]{r0};
        }
    }

    private void onEmsgLeafAtomRead(ParsableByteArray parsableByteArray) {
        if (this.eventMessageTrackOutput != null) {
            parsableByteArray.setPosition(12);
            parsableByteArray.readNullTerminatedString();
            parsableByteArray.readNullTerminatedString();
            long scaleLargeTimestamp = Util.scaleLargeTimestamp(parsableByteArray.readUnsignedInt(), C0361C.MICROS_PER_SECOND, parsableByteArray.readUnsignedInt());
            parsableByteArray.setPosition(12);
            int bytesLeft = parsableByteArray.bytesLeft();
            this.eventMessageTrackOutput.sampleData(parsableByteArray, bytesLeft);
            long j = this.segmentIndexEarliestPresentationTimeUs;
            if (j != C0361C.TIME_UNSET) {
                this.eventMessageTrackOutput.sampleMetadata(scaleLargeTimestamp + j, 1, bytesLeft, 0, null);
            } else {
                this.pendingMetadataSampleInfos.addLast(new MetadataSampleInfo(scaleLargeTimestamp, bytesLeft));
                this.pendingMetadataSampleBytes += bytesLeft;
            }
        }
    }

    private static Pair<Integer, DefaultSampleValues> parseTrex(ParsableByteArray parsableByteArray) {
        parsableByteArray.setPosition(12);
        return Pair.create(Integer.valueOf(parsableByteArray.readInt()), new DefaultSampleValues(parsableByteArray.readUnsignedIntToInt() - 1, parsableByteArray.readUnsignedIntToInt(), parsableByteArray.readUnsignedIntToInt(), parsableByteArray.readInt()));
    }

    private static long parseMehd(ParsableByteArray parsableByteArray) {
        parsableByteArray.setPosition(8);
        return Atom.parseFullAtomVersion(parsableByteArray.readInt()) == 0 ? parsableByteArray.readUnsignedInt() : parsableByteArray.readUnsignedLongToLong();
    }

    private static void parseMoof(ContainerAtom containerAtom, SparseArray<TrackBundle> sparseArray, int i, byte[] bArr) throws ParserException {
        int size = containerAtom.containerChildren.size();
        for (int i2 = 0; i2 < size; i2++) {
            ContainerAtom containerAtom2 = (ContainerAtom) containerAtom.containerChildren.get(i2);
            if (containerAtom2.type == Atom.TYPE_traf) {
                parseTraf(containerAtom2, sparseArray, i, bArr);
            }
        }
    }

    private static void parseTraf(ContainerAtom containerAtom, SparseArray<TrackBundle> sparseArray, int i, byte[] bArr) throws ParserException {
        sparseArray = parseTfhd(containerAtom.getLeafAtomOfType(Atom.TYPE_tfhd).data, sparseArray, i);
        if (sparseArray != null) {
            TrackFragment trackFragment = sparseArray.fragment;
            long j = trackFragment.nextFragmentDecodeTime;
            sparseArray.reset();
            if (containerAtom.getLeafAtomOfType(Atom.TYPE_tfdt) != null && (i & 2) == 0) {
                j = parseTfdt(containerAtom.getLeafAtomOfType(Atom.TYPE_tfdt).data);
            }
            parseTruns(containerAtom, sparseArray, j, i);
            i = containerAtom.getLeafAtomOfType(Atom.TYPE_saiz);
            if (i != 0) {
                parseSaiz(sparseArray.track.sampleDescriptionEncryptionBoxes[trackFragment.header.sampleDescriptionIndex], i.data, trackFragment);
            }
            sparseArray = containerAtom.getLeafAtomOfType(Atom.TYPE_saio);
            if (sparseArray != null) {
                parseSaio(sparseArray.data, trackFragment);
            }
            sparseArray = containerAtom.getLeafAtomOfType(Atom.TYPE_senc);
            if (sparseArray != null) {
                parseSenc(sparseArray.data, trackFragment);
            }
            sparseArray = containerAtom.getLeafAtomOfType(Atom.TYPE_sbgp);
            i = containerAtom.getLeafAtomOfType(Atom.TYPE_sgpd);
            if (!(sparseArray == null || i == 0)) {
                parseSgpd(sparseArray.data, i.data, trackFragment);
            }
            sparseArray = containerAtom.leafChildren.size();
            for (i = 0; i < sparseArray; i++) {
                LeafAtom leafAtom = (LeafAtom) containerAtom.leafChildren.get(i);
                if (leafAtom.type == Atom.TYPE_uuid) {
                    parseUuid(leafAtom.data, trackFragment, bArr);
                }
            }
        }
    }

    private static void parseTruns(ContainerAtom containerAtom, TrackBundle trackBundle, long j, int i) {
        containerAtom = containerAtom.leafChildren;
        int size = containerAtom.size();
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        for (int i5 = 0; i5 < size; i5++) {
            LeafAtom leafAtom = (LeafAtom) containerAtom.get(i5);
            if (leafAtom.type == Atom.TYPE_trun) {
                ParsableByteArray parsableByteArray = leafAtom.data;
                parsableByteArray.setPosition(12);
                int readUnsignedIntToInt = parsableByteArray.readUnsignedIntToInt();
                if (readUnsignedIntToInt > 0) {
                    i4 += readUnsignedIntToInt;
                    i3++;
                }
            }
        }
        trackBundle.currentTrackRunIndex = 0;
        trackBundle.currentSampleInTrackRun = 0;
        trackBundle.currentSampleIndex = 0;
        trackBundle.fragment.initTables(i3, i4);
        i3 = 0;
        int i6 = 0;
        while (i2 < size) {
            LeafAtom leafAtom2 = (LeafAtom) containerAtom.get(i2);
            if (leafAtom2.type == Atom.TYPE_trun) {
                int i7 = i3 + 1;
                i6 = parseTrun(trackBundle, i3, j, i, leafAtom2.data, i6);
                i3 = i7;
            }
            i2++;
        }
    }

    private static void parseSaio(ParsableByteArray parsableByteArray, TrackFragment trackFragment) throws ParserException {
        parsableByteArray.setPosition(8);
        int readInt = parsableByteArray.readInt();
        if ((Atom.parseFullAtomFlags(readInt) & 1) == 1) {
            parsableByteArray.skipBytes(8);
        }
        int readUnsignedIntToInt = parsableByteArray.readUnsignedIntToInt();
        if (readUnsignedIntToInt == 1) {
            long readUnsignedInt;
            readUnsignedIntToInt = Atom.parseFullAtomVersion(readInt);
            long j = trackFragment.auxiliaryDataPosition;
            if (readUnsignedIntToInt == 0) {
                readUnsignedInt = parsableByteArray.readUnsignedInt();
            } else {
                readUnsignedInt = parsableByteArray.readUnsignedLongToLong();
            }
            trackFragment.auxiliaryDataPosition = j + readUnsignedInt;
            return;
        }
        trackFragment = new StringBuilder();
        trackFragment.append("Unexpected saio entry count: ");
        trackFragment.append(readUnsignedIntToInt);
        throw new ParserException(trackFragment.toString());
    }

    private static TrackBundle parseTfhd(ParsableByteArray parsableByteArray, SparseArray<TrackBundle> sparseArray, int i) {
        parsableByteArray.setPosition(8);
        int parseFullAtomFlags = Atom.parseFullAtomFlags(parsableByteArray.readInt());
        int readInt = parsableByteArray.readInt();
        if ((i & 16) != 0) {
            readInt = 0;
        }
        TrackBundle trackBundle = (TrackBundle) sparseArray.get(readInt);
        if (trackBundle == null) {
            return null;
        }
        if ((parseFullAtomFlags & 1) != 0) {
            long readUnsignedLongToLong = parsableByteArray.readUnsignedLongToLong();
            trackBundle.fragment.dataPosition = readUnsignedLongToLong;
            trackBundle.fragment.auxiliaryDataPosition = readUnsignedLongToLong;
        }
        i = trackBundle.defaultSampleValues;
        trackBundle.fragment.header = new DefaultSampleValues((parseFullAtomFlags & 2) != 0 ? parsableByteArray.readUnsignedIntToInt() - 1 : i.sampleDescriptionIndex, (parseFullAtomFlags & 8) != 0 ? parsableByteArray.readUnsignedIntToInt() : i.duration, (parseFullAtomFlags & 16) != 0 ? parsableByteArray.readUnsignedIntToInt() : i.size, (parseFullAtomFlags & 32) != 0 ? parsableByteArray.readUnsignedIntToInt() : i.flags);
        return trackBundle;
    }

    private static long parseTfdt(ParsableByteArray parsableByteArray) {
        parsableByteArray.setPosition(8);
        return Atom.parseFullAtomVersion(parsableByteArray.readInt()) == 1 ? parsableByteArray.readUnsignedLongToLong() : parsableByteArray.readUnsignedInt();
    }

    private static int parseTrun(TrackBundle trackBundle, int i, long j, int i2, ParsableByteArray parsableByteArray, int i3) {
        long[] jArr;
        long j2;
        TrackBundle trackBundle2 = trackBundle;
        parsableByteArray.setPosition(8);
        int parseFullAtomFlags = Atom.parseFullAtomFlags(parsableByteArray.readInt());
        Track track = trackBundle2.track;
        TrackFragment trackFragment = trackBundle2.fragment;
        DefaultSampleValues defaultSampleValues = trackFragment.header;
        trackFragment.trunLength[i] = parsableByteArray.readUnsignedIntToInt();
        trackFragment.trunDataPosition[i] = trackFragment.dataPosition;
        if ((parseFullAtomFlags & 1) != 0) {
            long[] jArr2 = trackFragment.trunDataPosition;
            jArr2[i] = jArr2[i] + ((long) parsableByteArray.readInt());
        }
        Object obj = (parseFullAtomFlags & 4) != 0 ? 1 : null;
        int i4 = defaultSampleValues.flags;
        if (obj != null) {
            i4 = parsableByteArray.readUnsignedIntToInt();
        }
        Object obj2 = (parseFullAtomFlags & 256) != 0 ? 1 : null;
        Object obj3 = (parseFullAtomFlags & 512) != 0 ? 1 : null;
        Object obj4 = (parseFullAtomFlags & 1024) != 0 ? 1 : null;
        Object obj5 = (parseFullAtomFlags & 2048) != 0 ? 1 : null;
        long j3 = 0;
        if (track.editListDurations != null && track.editListDurations.length == 1 && track.editListDurations[0] == 0) {
            j3 = Util.scaleLargeTimestamp(track.editListMediaTimes[0], 1000, track.timescale);
        }
        int[] iArr = trackFragment.sampleSizeTable;
        int[] iArr2 = trackFragment.sampleCompositionTimeOffsetTable;
        long[] jArr3 = trackFragment.sampleDecodingTimeTable;
        boolean[] zArr = trackFragment.sampleIsSyncFrameTable;
        int i5 = i4;
        Object obj6 = (track.type != 2 || (i2 & 1) == 0) ? null : 1;
        int i6 = i3 + trackFragment.trunLength[i];
        long j4 = j3;
        boolean[] zArr2 = zArr;
        long j5 = track.timescale;
        if (i > 0) {
            i2 = zArr2;
            jArr = jArr3;
            j2 = trackFragment.nextFragmentDecodeTime;
        } else {
            i2 = zArr2;
            jArr = jArr3;
            j2 = j;
        }
        i = j2;
        int i7 = i3;
        while (i7 < i6) {
            Object obj7;
            int readUnsignedIntToInt;
            Object obj8;
            int i8;
            Object obj9;
            Object obj10;
            Object obj11;
            int readUnsignedIntToInt2 = obj2 != null ? parsableByteArray.readUnsignedIntToInt() : defaultSampleValues.duration;
            if (obj3 != null) {
                obj7 = obj2;
                readUnsignedIntToInt = parsableByteArray.readUnsignedIntToInt();
            } else {
                obj7 = obj2;
                readUnsignedIntToInt = defaultSampleValues.size;
            }
            if (i7 == 0 && obj != null) {
                obj8 = obj;
                i8 = i5;
            } else if (obj4 != null) {
                obj8 = obj;
                i8 = parsableByteArray.readInt();
            } else {
                obj8 = obj;
                i8 = defaultSampleValues.flags;
            }
            if (obj5 != null) {
                obj9 = obj5;
                obj10 = obj3;
                obj11 = obj4;
                iArr2[i7] = (int) (((long) (parsableByteArray.readInt() * 1000)) / j5);
            } else {
                obj9 = obj5;
                obj10 = obj3;
                obj11 = obj4;
                iArr2[i7] = 0;
            }
            jArr[i7] = Util.scaleLargeTimestamp(i, 1000, j5) - j4;
            iArr[i7] = readUnsignedIntToInt;
            boolean z = ((i8 >> 16) & 1) == 0 && (obj6 == null || i7 == 0);
            i2[i7] = z;
            i7++;
            i += (long) readUnsignedIntToInt2;
            obj2 = obj7;
            obj = obj8;
            obj5 = obj9;
            obj3 = obj10;
            obj4 = obj11;
            i6 = i6;
        }
        trackBundle = i6;
        trackFragment.nextFragmentDecodeTime = i;
        return trackBundle;
    }

    private static void parseUuid(ParsableByteArray parsableByteArray, TrackFragment trackFragment, byte[] bArr) throws ParserException {
        parsableByteArray.setPosition(8);
        parsableByteArray.readBytes(bArr, 0, 16);
        if (Arrays.equals(bArr, PIFF_SAMPLE_ENCRYPTION_BOX_EXTENDED_TYPE) != null) {
            parseSenc(parsableByteArray, 16, trackFragment);
        }
    }

    private static void parseSenc(ParsableByteArray parsableByteArray, TrackFragment trackFragment) throws ParserException {
        parseSenc(parsableByteArray, 0, trackFragment);
    }

    private static void parseSenc(ParsableByteArray parsableByteArray, int i, TrackFragment trackFragment) throws ParserException {
        parsableByteArray.setPosition(i + 8);
        i = Atom.parseFullAtomFlags(parsableByteArray.readInt());
        if ((i & 1) == 0) {
            i = (i & 2) != 0 ? 1 : 0;
            int readUnsignedIntToInt = parsableByteArray.readUnsignedIntToInt();
            if (readUnsignedIntToInt == trackFragment.sampleCount) {
                Arrays.fill(trackFragment.sampleHasSubsampleEncryptionTable, 0, readUnsignedIntToInt, i);
                trackFragment.initEncryptionData(parsableByteArray.bytesLeft());
                trackFragment.fillEncryptionData(parsableByteArray);
                return;
            }
            i = new StringBuilder();
            i.append("Length mismatch: ");
            i.append(readUnsignedIntToInt);
            i.append(", ");
            i.append(trackFragment.sampleCount);
            throw new ParserException(i.toString());
        }
        throw new ParserException("Overriding TrackEncryptionBox parameters is unsupported.");
    }

    private static void parseSgpd(ParsableByteArray parsableByteArray, ParsableByteArray parsableByteArray2, TrackFragment trackFragment) throws ParserException {
        parsableByteArray.setPosition(8);
        int readInt = parsableByteArray.readInt();
        if (parsableByteArray.readInt() == SAMPLE_GROUP_TYPE_seig) {
            if (Atom.parseFullAtomVersion(readInt) == 1) {
                parsableByteArray.skipBytes(4);
            }
            if (parsableByteArray.readInt() == 1) {
                parsableByteArray2.setPosition(8);
                parsableByteArray = parsableByteArray2.readInt();
                if (parsableByteArray2.readInt() == SAMPLE_GROUP_TYPE_seig) {
                    parsableByteArray = Atom.parseFullAtomVersion(parsableByteArray);
                    if (parsableByteArray == 1) {
                        if (parsableByteArray2.readUnsignedInt() == 0) {
                            throw new ParserException("Variable length decription in sgpd found (unsupported)");
                        }
                    } else if (parsableByteArray >= 2) {
                        parsableByteArray2.skipBytes(4);
                    }
                    if (parsableByteArray2.readUnsignedInt() == 1) {
                        parsableByteArray2.skipBytes(2);
                        parsableByteArray = parsableByteArray2.readUnsignedByte() == 1 ? true : null;
                        if (parsableByteArray != null) {
                            readInt = parsableByteArray2.readUnsignedByte();
                            byte[] bArr = new byte[16];
                            parsableByteArray2.readBytes(bArr, 0, bArr.length);
                            trackFragment.definesEncryptionData = true;
                            trackFragment.trackEncryptionBox = new TrackEncryptionBox(parsableByteArray, readInt, bArr);
                            return;
                        }
                        return;
                    }
                    throw new ParserException("Entry count in sgpd != 1 (unsupported).");
                }
                return;
            }
            throw new ParserException("Entry count in sbgp != 1 (unsupported).");
        }
    }

    private static Pair<Long, ChunkIndex> parseSidx(ParsableByteArray parsableByteArray, long j) throws ParserException {
        long readUnsignedInt;
        long readUnsignedInt2;
        ParsableByteArray parsableByteArray2 = parsableByteArray;
        parsableByteArray2.setPosition(8);
        int parseFullAtomVersion = Atom.parseFullAtomVersion(parsableByteArray.readInt());
        parsableByteArray2.skipBytes(4);
        long readUnsignedInt3 = parsableByteArray.readUnsignedInt();
        if (parseFullAtomVersion == 0) {
            readUnsignedInt = parsableByteArray.readUnsignedInt();
            readUnsignedInt2 = j + parsableByteArray.readUnsignedInt();
        } else {
            readUnsignedInt = parsableByteArray.readUnsignedLongToLong();
            readUnsignedInt2 = j + parsableByteArray.readUnsignedLongToLong();
        }
        long scaleLargeTimestamp = Util.scaleLargeTimestamp(readUnsignedInt, C0361C.MICROS_PER_SECOND, readUnsignedInt3);
        parsableByteArray2.skipBytes(2);
        parseFullAtomVersion = parsableByteArray.readUnsignedShort();
        int[] iArr = new int[parseFullAtomVersion];
        long[] jArr = new long[parseFullAtomVersion];
        long[] jArr2 = new long[parseFullAtomVersion];
        long[] jArr3 = new long[parseFullAtomVersion];
        long j2 = readUnsignedInt;
        long j3 = scaleLargeTimestamp;
        int i = 0;
        while (i < parseFullAtomVersion) {
            int readInt = parsableByteArray.readInt();
            if ((readInt & Integer.MIN_VALUE) == 0) {
                long readUnsignedInt4 = parsableByteArray.readUnsignedInt();
                iArr[i] = readInt & Integer.MAX_VALUE;
                jArr[i] = readUnsignedInt2;
                jArr3[i] = j3;
                j2 += readUnsignedInt4;
                long[] jArr4 = jArr2;
                long[] jArr5 = jArr3;
                j = parseFullAtomVersion;
                int[] iArr2 = iArr;
                long[] jArr6 = jArr;
                j3 = Util.scaleLargeTimestamp(j2, C0361C.MICROS_PER_SECOND, readUnsignedInt3);
                jArr4[i] = j3 - jArr5[i];
                parsableByteArray2.skipBytes(4);
                readUnsignedInt2 += (long) iArr2[i];
                i++;
                iArr = iArr2;
                jArr3 = jArr5;
                jArr2 = jArr4;
                jArr = jArr6;
                parseFullAtomVersion = j;
            } else {
                throw new ParserException("Unhandled indirect reference");
            }
        }
        return Pair.create(Long.valueOf(scaleLargeTimestamp), new ChunkIndex(iArr, jArr, jArr2, jArr3));
    }

    private boolean readSample(ExtractorInput extractorInput) throws IOException, InterruptedException {
        byte[] bArr;
        ExtractorInput extractorInput2 = extractorInput;
        int i = 4;
        int i2 = 1;
        int i3 = 0;
        if (this.parserState == 3) {
            if (r0.currentTrackBundle == null) {
                TrackBundle nextFragmentRun = getNextFragmentRun(r0.trackBundles);
                if (nextFragmentRun == null) {
                    int position = (int) (r0.endOfMdatPosition - extractorInput.getPosition());
                    if (position >= 0) {
                        extractorInput2.skipFully(position);
                        enterReadingAtomHeaderState();
                        return false;
                    }
                    throw new ParserException("Offset to end of mdat was negative.");
                }
                int position2 = (int) (nextFragmentRun.fragment.trunDataPosition[nextFragmentRun.currentTrackRunIndex] - extractorInput.getPosition());
                if (position2 < 0) {
                    Log.w(TAG, "Ignoring negative offset to sample data.");
                    position2 = 0;
                }
                extractorInput2.skipFully(position2);
                r0.currentTrackBundle = nextFragmentRun;
            }
            r0.sampleSize = r0.currentTrackBundle.fragment.sampleSizeTable[r0.currentTrackBundle.currentSampleIndex];
            if (r0.currentTrackBundle.fragment.definesEncryptionData) {
                r0.sampleBytesWritten = appendSampleEncryptionData(r0.currentTrackBundle);
                r0.sampleSize += r0.sampleBytesWritten;
            } else {
                r0.sampleBytesWritten = 0;
            }
            if (r0.currentTrackBundle.track.sampleTransformation == 1) {
                r0.sampleSize -= 8;
                extractorInput2.skipFully(8);
            }
            r0.parserState = 4;
            r0.sampleCurrentNalBytesRemaining = 0;
        }
        TrackFragment trackFragment = r0.currentTrackBundle.fragment;
        Track track = r0.currentTrackBundle.track;
        TrackOutput trackOutput = r0.currentTrackBundle.output;
        int i4 = r0.currentTrackBundle.currentSampleIndex;
        int i5;
        if (track.nalUnitLengthFieldLength == 0) {
            while (true) {
                i5 = r0.sampleBytesWritten;
                i = r0.sampleSize;
                if (i5 >= i) {
                    break;
                }
                r0.sampleBytesWritten += trackOutput.sampleData(extractorInput2, i - i5, false);
            }
        } else {
            byte[] bArr2 = r0.nalPrefix.data;
            bArr2[0] = (byte) 0;
            bArr2[1] = (byte) 0;
            bArr2[2] = (byte) 0;
            int i6 = track.nalUnitLengthFieldLength + 1;
            int i7 = 4 - track.nalUnitLengthFieldLength;
            while (r0.sampleBytesWritten < r0.sampleSize) {
                i5 = r0.sampleCurrentNalBytesRemaining;
                if (i5 == 0) {
                    extractorInput2.readFully(bArr2, i7, i6);
                    r0.nalPrefix.setPosition(i3);
                    r0.sampleCurrentNalBytesRemaining = r0.nalPrefix.readUnsignedIntToInt() - i2;
                    r0.nalStartCode.setPosition(i3);
                    trackOutput.sampleData(r0.nalStartCode, i);
                    trackOutput.sampleData(r0.nalPrefix, i2);
                    boolean z = r0.cea608TrackOutputs != null && NalUnitUtil.isNalUnitSei(track.format.sampleMimeType, bArr2[i]);
                    r0.processSeiNalUnitPayload = z;
                    r0.sampleBytesWritten += 5;
                    r0.sampleSize += i7;
                } else {
                    if (r0.processSeiNalUnitPayload) {
                        r0.nalBuffer.reset(i5);
                        extractorInput2.readFully(r0.nalBuffer.data, i3, r0.sampleCurrentNalBytesRemaining);
                        trackOutput.sampleData(r0.nalBuffer, r0.sampleCurrentNalBytesRemaining);
                        i5 = r0.sampleCurrentNalBytesRemaining;
                        i = NalUnitUtil.unescapeStream(r0.nalBuffer.data, r0.nalBuffer.limit());
                        r0.nalBuffer.setPosition(MimeTypes.VIDEO_H265.equals(track.format.sampleMimeType));
                        r0.nalBuffer.setLimit(i);
                        CeaUtil.consume(trackFragment.getSamplePresentationTime(i4) * 1000, r0.nalBuffer, r0.cea608TrackOutputs);
                    } else {
                        i5 = trackOutput.sampleData(extractorInput2, i5, false);
                    }
                    r0.sampleBytesWritten += i5;
                    r0.sampleCurrentNalBytesRemaining -= i5;
                    i = 4;
                    i2 = 1;
                    i3 = 0;
                }
            }
        }
        long samplePresentationTime = trackFragment.getSamplePresentationTime(i4) * 1000;
        int i8 = (trackFragment.definesEncryptionData ? 1073741824 : 0) | trackFragment.sampleIsSyncFrameTable[i4];
        int i9 = trackFragment.header.sampleDescriptionIndex;
        if (trackFragment.definesEncryptionData) {
            bArr = (trackFragment.trackEncryptionBox != null ? trackFragment.trackEncryptionBox : track.sampleDescriptionEncryptionBoxes[i9]).keyId;
        } else {
            bArr = null;
        }
        TimestampAdjuster timestampAdjuster = r0.timestampAdjuster;
        if (timestampAdjuster != null) {
            samplePresentationTime = timestampAdjuster.adjustSampleTimestamp(samplePresentationTime);
        }
        trackOutput.sampleMetadata(samplePresentationTime, i8, r0.sampleSize, 0, bArr);
        while (!r0.pendingMetadataSampleInfos.isEmpty()) {
            MetadataSampleInfo metadataSampleInfo = (MetadataSampleInfo) r0.pendingMetadataSampleInfos.removeFirst();
            r0.pendingMetadataSampleBytes -= metadataSampleInfo.size;
            r0.eventMessageTrackOutput.sampleMetadata(metadataSampleInfo.presentationTimeDeltaUs + samplePresentationTime, 1, metadataSampleInfo.size, r0.pendingMetadataSampleBytes, null);
        }
        TrackBundle trackBundle = r0.currentTrackBundle;
        trackBundle.currentSampleIndex++;
        trackBundle = r0.currentTrackBundle;
        trackBundle.currentSampleInTrackRun++;
        if (r0.currentTrackBundle.currentSampleInTrackRun == trackFragment.trunLength[r0.currentTrackBundle.currentTrackRunIndex]) {
            trackBundle = r0.currentTrackBundle;
            trackBundle.currentTrackRunIndex++;
            r0.currentTrackBundle.currentSampleInTrackRun = 0;
            r0.currentTrackBundle = null;
            i9 = 3;
        } else {
            i9 = 3;
        }
        r0.parserState = i9;
        return true;
    }

    private static TrackBundle getNextFragmentRun(SparseArray<TrackBundle> sparseArray) {
        int size = sparseArray.size();
        TrackBundle trackBundle = null;
        long j = Long.MAX_VALUE;
        for (int i = 0; i < size; i++) {
            TrackBundle trackBundle2 = (TrackBundle) sparseArray.valueAt(i);
            if (trackBundle2.currentTrackRunIndex != trackBundle2.fragment.trunCount) {
                long j2 = trackBundle2.fragment.trunDataPosition[trackBundle2.currentTrackRunIndex];
                if (j2 < j) {
                    trackBundle = trackBundle2;
                    j = j2;
                }
            }
        }
        return trackBundle;
    }

    private int appendSampleEncryptionData(TrackBundle trackBundle) {
        TrackFragment trackFragment = trackBundle.fragment;
        ParsableByteArray parsableByteArray = trackFragment.sampleEncryptionData;
        int i = (trackFragment.trackEncryptionBox != null ? trackFragment.trackEncryptionBox : trackBundle.track.sampleDescriptionEncryptionBoxes[trackFragment.header.sampleDescriptionIndex]).initializationVectorSize;
        boolean z = trackFragment.sampleHasSubsampleEncryptionTable[trackBundle.currentSampleIndex];
        this.encryptionSignalByte.data[0] = (byte) ((z ? 128 : 0) | i);
        this.encryptionSignalByte.setPosition(0);
        trackBundle = trackBundle.output;
        trackBundle.sampleData(this.encryptionSignalByte, 1);
        trackBundle.sampleData(parsableByteArray, i);
        if (!z) {
            return i + 1;
        }
        int readUnsignedShort = parsableByteArray.readUnsignedShort();
        parsableByteArray.skipBytes(-2);
        readUnsignedShort = (readUnsignedShort * 6) + 2;
        trackBundle.sampleData(parsableByteArray, readUnsignedShort);
        return (i + 1) + readUnsignedShort;
    }

    private static DrmInitData getDrmInitDataFromAtoms(List<LeafAtom> list) {
        int size = list.size();
        List list2 = null;
        for (int i = 0; i < size; i++) {
            LeafAtom leafAtom = (LeafAtom) list.get(i);
            if (leafAtom.type == Atom.TYPE_pssh) {
                if (list2 == null) {
                    list2 = new ArrayList();
                }
                byte[] bArr = leafAtom.data.data;
                UUID parseUuid = PsshAtomUtil.parseUuid(bArr);
                if (parseUuid == null) {
                    Log.w(TAG, "Skipped pssh atom (failed to extract uuid)");
                } else {
                    list2.add(new SchemeData(parseUuid, MimeTypes.VIDEO_MP4, bArr));
                }
            }
        }
        if (list2 == null) {
            return null;
        }
        return new DrmInitData(list2);
    }

    private static boolean shouldParseLeafAtom(int i) {
        if (!(i == Atom.TYPE_hdlr || i == Atom.TYPE_mdhd || i == Atom.TYPE_mvhd || i == Atom.TYPE_sidx || i == Atom.TYPE_stsd || i == Atom.TYPE_tfdt || i == Atom.TYPE_tfhd || i == Atom.TYPE_tkhd || i == Atom.TYPE_trex || i == Atom.TYPE_trun || i == Atom.TYPE_pssh || i == Atom.TYPE_saiz || i == Atom.TYPE_saio || i == Atom.TYPE_senc || i == Atom.TYPE_uuid || i == Atom.TYPE_sbgp || i == Atom.TYPE_sgpd || i == Atom.TYPE_elst || i == Atom.TYPE_mehd)) {
            if (i != Atom.TYPE_emsg) {
                return false;
            }
        }
        return true;
    }

    private static boolean shouldParseContainerAtom(int i) {
        if (!(i == Atom.TYPE_moov || i == Atom.TYPE_trak || i == Atom.TYPE_mdia || i == Atom.TYPE_minf || i == Atom.TYPE_stbl || i == Atom.TYPE_moof || i == Atom.TYPE_traf || i == Atom.TYPE_mvex)) {
            if (i != Atom.TYPE_edts) {
                return false;
            }
        }
        return true;
    }
}
