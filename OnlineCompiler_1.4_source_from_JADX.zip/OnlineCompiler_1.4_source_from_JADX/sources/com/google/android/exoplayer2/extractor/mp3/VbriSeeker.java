package com.google.android.exoplayer2.extractor.mp3;

import com.google.android.exoplayer2.C0361C;
import com.google.android.exoplayer2.extractor.MpegAudioHeader;
import com.google.android.exoplayer2.util.ParsableByteArray;
import com.google.android.exoplayer2.util.Util;

final class VbriSeeker implements Seeker {
    private final long durationUs;
    private final long[] positions;
    private final long[] timesUs;

    public boolean isSeekable() {
        return true;
    }

    public static VbriSeeker create(MpegAudioHeader mpegAudioHeader, ParsableByteArray parsableByteArray, long j, long j2) {
        MpegAudioHeader mpegAudioHeader2 = mpegAudioHeader;
        ParsableByteArray parsableByteArray2 = parsableByteArray;
        long j3 = j2;
        parsableByteArray2.skipBytes(10);
        int readInt = parsableByteArray.readInt();
        VbriSeeker vbriSeeker = null;
        if (readInt <= 0) {
            return null;
        }
        int i = mpegAudioHeader2.sampleRate;
        long scaleLargeTimestamp = Util.scaleLargeTimestamp((long) readInt, C0361C.MICROS_PER_SECOND * ((long) (i >= 32000 ? 1152 : 576)), (long) i);
        readInt = parsableByteArray.readUnsignedShort();
        int readUnsignedShort = parsableByteArray.readUnsignedShort();
        int readUnsignedShort2 = parsableByteArray.readUnsignedShort();
        parsableByteArray2.skipBytes(2);
        long j4 = j + ((long) mpegAudioHeader2.frameSize);
        int i2 = readInt + 1;
        long[] jArr = new long[i2];
        long[] jArr2 = new long[i2];
        jArr[0] = 0;
        jArr2[0] = j4;
        int i3 = 1;
        while (i3 < jArr.length) {
            int readUnsignedByte;
            long j5;
            switch (readUnsignedShort2) {
                case 1:
                    readUnsignedByte = parsableByteArray.readUnsignedByte();
                    break;
                case 2:
                    readUnsignedByte = parsableByteArray.readUnsignedShort();
                    break;
                case 3:
                    readUnsignedByte = parsableByteArray.readUnsignedInt24();
                    break;
                case 4:
                    readUnsignedByte = parsableByteArray.readUnsignedIntToInt();
                    break;
                default:
                    return vbriSeeker;
            }
            j4 += (long) (readUnsignedByte * readUnsignedShort);
            long j6 = scaleLargeTimestamp;
            jArr[i3] = (((long) i3) * scaleLargeTimestamp) / ((long) readInt);
            if (j3 == -1) {
                j5 = j4;
            } else {
                j5 = Math.min(j3, j4);
            }
            jArr2[i3] = j5;
            i3++;
            scaleLargeTimestamp = j6;
            vbriSeeker = null;
        }
        return new VbriSeeker(jArr, jArr2, scaleLargeTimestamp);
    }

    private VbriSeeker(long[] jArr, long[] jArr2, long j) {
        this.timesUs = jArr;
        this.positions = jArr2;
        this.durationUs = j;
    }

    public long getPosition(long j) {
        return this.positions[Util.binarySearchFloor(this.timesUs, j, true, true)];
    }

    public long getTimeUs(long j) {
        return this.timesUs[Util.binarySearchFloor(this.positions, j, true, true)];
    }

    public long getDurationUs() {
        return this.durationUs;
    }
}
