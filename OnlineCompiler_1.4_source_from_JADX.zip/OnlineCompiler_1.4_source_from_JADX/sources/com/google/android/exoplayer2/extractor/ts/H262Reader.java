package com.google.android.exoplayer2.extractor.ts;

import android.util.Pair;
import com.google.android.exoplayer2.C0361C;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.extractor.ExtractorOutput;
import com.google.android.exoplayer2.extractor.TrackOutput;
import com.google.android.exoplayer2.extractor.ts.TsPayloadReader.TrackIdGenerator;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.exoplayer2.util.NalUnitUtil;
import com.google.android.exoplayer2.util.ParsableByteArray;
import java.util.Arrays;
import java.util.Collections;

public final class H262Reader implements ElementaryStreamReader {
    private static final double[] FRAME_RATE_VALUES = new double[]{23.976023976023978d, 24.0d, 25.0d, 29.97002997002997d, 30.0d, 50.0d, 59.94005994005994d, 60.0d};
    private static final int START_EXTENSION = 181;
    private static final int START_GROUP = 184;
    private static final int START_PICTURE = 0;
    private static final int START_SEQUENCE_HEADER = 179;
    private final CsdBuffer csdBuffer = new CsdBuffer(128);
    private String formatId;
    private boolean foundFirstFrameInGroup;
    private long frameDurationUs;
    private long framePosition;
    private long frameTimeUs;
    private boolean hasOutputFormat;
    private boolean isKeyframe;
    private TrackOutput output;
    private boolean pesPtsUsAvailable;
    private long pesTimeUs;
    private final boolean[] prefixFlags = new boolean[4];
    private long totalBytesWritten;

    private static final class CsdBuffer {
        public byte[] data;
        private boolean isFilling;
        public int length;
        public int sequenceExtensionPosition;

        public CsdBuffer(int i) {
            this.data = new byte[i];
        }

        public void reset() {
            this.isFilling = false;
            this.length = 0;
            this.sequenceExtensionPosition = 0;
        }

        public boolean onStartCode(int i, int i2) {
            if (this.isFilling) {
                if (this.sequenceExtensionPosition == 0 && i == H262Reader.START_EXTENSION) {
                    this.sequenceExtensionPosition = this.length;
                } else {
                    this.length -= i2;
                    this.isFilling = false;
                    return true;
                }
            } else if (i == H262Reader.START_SEQUENCE_HEADER) {
                this.isFilling = true;
            }
            return false;
        }

        public void onData(byte[] bArr, int i, int i2) {
            if (this.isFilling) {
                i2 -= i;
                byte[] bArr2 = this.data;
                int length = bArr2.length;
                int i3 = this.length;
                if (length < i3 + i2) {
                    this.data = Arrays.copyOf(bArr2, (i3 + i2) * 2);
                }
                System.arraycopy(bArr, i, this.data, this.length, i2);
                this.length += i2;
            }
        }
    }

    public void packetFinished() {
    }

    public void seek() {
        NalUnitUtil.clearPrefixFlags(this.prefixFlags);
        this.csdBuffer.reset();
        this.pesPtsUsAvailable = false;
        this.foundFirstFrameInGroup = false;
        this.totalBytesWritten = 0;
    }

    public void createTracks(ExtractorOutput extractorOutput, TrackIdGenerator trackIdGenerator) {
        trackIdGenerator.generateNewId();
        this.formatId = trackIdGenerator.getFormatId();
        this.output = extractorOutput.track(trackIdGenerator.getTrackId(), 2);
    }

    public void packetStarted(long j, boolean z) {
        this.pesPtsUsAvailable = j != C0361C.TIME_UNSET;
        if (this.pesPtsUsAvailable) {
            this.pesTimeUs = j;
        }
    }

    public void consume(ParsableByteArray parsableByteArray) {
        ParsableByteArray parsableByteArray2 = parsableByteArray;
        int position = parsableByteArray.getPosition();
        int limit = parsableByteArray.limit();
        byte[] bArr = parsableByteArray2.data;
        this.totalBytesWritten += (long) parsableByteArray.bytesLeft();
        this.output.sampleData(parsableByteArray2, parsableByteArray.bytesLeft());
        int i = position;
        while (true) {
            position = NalUnitUtil.findNalUnit(bArr, position, limit, r0.prefixFlags);
            if (position == limit) {
                break;
            }
            int i2;
            int i3 = position + 3;
            int i4 = parsableByteArray2.data[i3] & 255;
            if (!r0.hasOutputFormat) {
                i2 = position - i;
                if (i2 > 0) {
                    r0.csdBuffer.onData(bArr, i, position);
                }
                if (r0.csdBuffer.onStartCode(i4, i2 < 0 ? -i2 : 0)) {
                    Pair parseCsdBuffer = parseCsdBuffer(r0.csdBuffer, r0.formatId);
                    r0.output.format((Format) parseCsdBuffer.first);
                    r0.frameDurationUs = ((Long) parseCsdBuffer.second).longValue();
                    r0.hasOutputFormat = true;
                }
            }
            if (r0.hasOutputFormat && (i4 == START_GROUP || i4 == 0)) {
                i2 = limit - position;
                if (r0.foundFirstFrameInGroup) {
                    int i5 = i4;
                    r0.output.sampleMetadata(r0.frameTimeUs, r0.isKeyframe, ((int) (r0.totalBytesWritten - r0.framePosition)) - i2, i2, null);
                    r0.isKeyframe = false;
                    i = i5;
                    i4 = START_GROUP;
                } else {
                    i = i4;
                    i4 = START_GROUP;
                }
                if (i == i4) {
                    r0.foundFirstFrameInGroup = false;
                    r0.isKeyframe = true;
                } else {
                    r0.frameTimeUs = r0.pesPtsUsAvailable ? r0.pesTimeUs : r0.frameTimeUs + r0.frameDurationUs;
                    r0.framePosition = r0.totalBytesWritten - ((long) i2);
                    r0.pesPtsUsAvailable = false;
                    r0.foundFirstFrameInGroup = true;
                }
            }
            i = position;
            position = i3;
        }
        if (!r0.hasOutputFormat) {
            r0.csdBuffer.onData(bArr, i, limit);
        }
    }

    private static Pair<Format, Long> parseCsdBuffer(CsdBuffer csdBuffer, String str) {
        float f;
        CsdBuffer csdBuffer2 = csdBuffer;
        Object copyOf = Arrays.copyOf(csdBuffer2.data, csdBuffer2.length);
        int i = copyOf[5] & 255;
        int i2 = ((copyOf[4] & 255) << 4) | (i >> 4);
        int i3 = ((i & 15) << 8) | (copyOf[6] & 255);
        switch ((copyOf[7] & PsExtractor.VIDEO_STREAM_MASK) >> 4) {
            case 2:
                f = ((float) (i3 * 4)) / ((float) (i2 * 3));
                break;
            case 3:
                f = ((float) (i3 * 16)) / ((float) (i2 * 9));
                break;
            case 4:
                f = ((float) (i3 * 121)) / ((float) (i2 * 100));
                break;
            default:
                f = 1.0f;
                break;
        }
        Format createVideoSampleFormat = Format.createVideoSampleFormat(str, MimeTypes.VIDEO_MPEG2, null, -1, -1, i2, i3, -1.0f, Collections.singletonList(copyOf), -1, f, null);
        long j = 0;
        int i4 = (copyOf[7] & 15) - 1;
        if (i4 >= 0) {
            double[] dArr = FRAME_RATE_VALUES;
            if (i4 < dArr.length) {
                double d = dArr[i4];
                int i5 = csdBuffer2.sequenceExtensionPosition + 9;
                i4 = (copyOf[i5] & 96) >> 5;
                i5 = copyOf[i5] & 31;
                if (i4 != i5) {
                    double d2 = (double) i4;
                    Double.isNaN(d2);
                    d2 += 1.0d;
                    double d3 = (double) (i5 + 1);
                    Double.isNaN(d3);
                    d *= d2 / d3;
                }
                j = (long) (1000000.0d / d);
            }
        }
        return Pair.create(createVideoSampleFormat, Long.valueOf(j));
    }
}
