package com.google.android.exoplayer2.extractor.wav;

import android.util.Log;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.extractor.ExtractorInput;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.ParsableByteArray;
import com.google.android.exoplayer2.util.Util;
import com.google.android.gms.common.data.DataBufferSafeParcelable;
import java.io.IOException;

final class WavHeaderReader {
    private static final String TAG = "WavHeaderReader";
    private static final int TYPE_PCM = 1;
    private static final int TYPE_WAVE_FORMAT_EXTENSIBLE = 65534;

    private static final class ChunkHeader {
        public static final int SIZE_IN_BYTES = 8;
        public final int id;
        public final long size;

        private ChunkHeader(int i, long j) {
            this.id = i;
            this.size = j;
        }

        public static ChunkHeader peek(ExtractorInput extractorInput, ParsableByteArray parsableByteArray) throws IOException, InterruptedException {
            extractorInput.peekFully(parsableByteArray.data, 0, 8);
            parsableByteArray.setPosition(0);
            return new ChunkHeader(parsableByteArray.readInt(), parsableByteArray.readLittleEndianUnsignedInt());
        }
    }

    public static com.google.android.exoplayer2.extractor.wav.WavHeader peek(com.google.android.exoplayer2.extractor.ExtractorInput r13) throws java.io.IOException, java.lang.InterruptedException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:30:0x00fd in {2, 6, 10, 13, 14, 20, 25, 27, 29} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        com.google.android.exoplayer2.util.Assertions.checkNotNull(r13);
        r0 = new com.google.android.exoplayer2.util.ParsableByteArray;
        r1 = 16;
        r0.<init>(r1);
        r2 = com.google.android.exoplayer2.extractor.wav.WavHeaderReader.ChunkHeader.peek(r13, r0);
        r2 = r2.id;
        r3 = "RIFF";
        r3 = com.google.android.exoplayer2.util.Util.getIntegerCodeForString(r3);
        r4 = 0;
        if (r2 == r3) goto L_0x001a;
    L_0x0019:
        return r4;
    L_0x001a:
        r2 = r0.data;
        r3 = 4;
        r5 = 0;
        r13.peekFully(r2, r5, r3);
        r0.setPosition(r5);
        r2 = r0.readInt();
        r3 = "WAVE";
        r3 = com.google.android.exoplayer2.util.Util.getIntegerCodeForString(r3);
        if (r2 == r3) goto L_0x0047;
    L_0x0030:
        r13 = "WavHeaderReader";
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r1 = "Unsupported RIFF format: ";
        r0.append(r1);
        r0.append(r2);
        r0 = r0.toString();
        android.util.Log.e(r13, r0);
        return r4;
    L_0x0047:
        r2 = com.google.android.exoplayer2.extractor.wav.WavHeaderReader.ChunkHeader.peek(r13, r0);
    L_0x004b:
        r3 = r2.id;
        r6 = "fmt ";
        r6 = com.google.android.exoplayer2.util.Util.getIntegerCodeForString(r6);
        if (r3 == r6) goto L_0x0060;
    L_0x0055:
        r2 = r2.size;
        r2 = (int) r2;
        r13.advancePeekPosition(r2);
        r2 = com.google.android.exoplayer2.extractor.wav.WavHeaderReader.ChunkHeader.peek(r13, r0);
        goto L_0x004b;
    L_0x0060:
        r6 = r2.size;
        r8 = 16;
        r3 = 1;
        r10 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1));
        if (r10 < 0) goto L_0x006b;
    L_0x0069:
        r6 = 1;
        goto L_0x006c;
    L_0x006b:
        r6 = 0;
    L_0x006c:
        com.google.android.exoplayer2.util.Assertions.checkState(r6);
        r6 = r0.data;
        r13.peekFully(r6, r5, r1);
        r0.setPosition(r5);
        r5 = r0.readLittleEndianUnsignedShort();
        r7 = r0.readLittleEndianUnsignedShort();
        r8 = r0.readLittleEndianUnsignedIntToInt();
        r9 = r0.readLittleEndianUnsignedIntToInt();
        r10 = r0.readLittleEndianUnsignedShort();
        r11 = r0.readLittleEndianUnsignedShort();
        r0 = r7 * r11;
        r0 = r0 / 8;
        if (r10 != r0) goto L_0x00de;
    L_0x0095:
        r12 = com.google.android.exoplayer2.util.Util.getPcmEncoding(r11);
        if (r12 != 0) goto L_0x00b2;
    L_0x009b:
        r13 = "WavHeaderReader";
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r1 = "Unsupported WAV bit depth: ";
        r0.append(r1);
        r0.append(r11);
        r0 = r0.toString();
        android.util.Log.e(r13, r0);
        return r4;
    L_0x00b2:
        if (r5 == r3) goto L_0x00d0;
    L_0x00b4:
        r0 = 65534; // 0xfffe float:9.1833E-41 double:3.2378E-319;
        if (r5 == r0) goto L_0x00d0;
    L_0x00b9:
        r13 = "WavHeaderReader";
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r1 = "Unsupported WAV format type: ";
        r0.append(r1);
        r0.append(r5);
        r0 = r0.toString();
        android.util.Log.e(r13, r0);
        return r4;
    L_0x00d0:
        r2 = r2.size;
        r0 = (int) r2;
        r0 = r0 - r1;
        r13.advancePeekPosition(r0);
        r13 = new com.google.android.exoplayer2.extractor.wav.WavHeader;
        r6 = r13;
        r6.<init>(r7, r8, r9, r10, r11, r12);
        return r13;
    L_0x00de:
        r13 = new com.google.android.exoplayer2.ParserException;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Expected block alignment: ";
        r1.append(r2);
        r1.append(r0);
        r0 = "; got: ";
        r1.append(r0);
        r1.append(r10);
        r0 = r1.toString();
        r13.<init>(r0);
        throw r13;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.wav.WavHeaderReader.peek(com.google.android.exoplayer2.extractor.ExtractorInput):com.google.android.exoplayer2.extractor.wav.WavHeader");
    }

    WavHeaderReader() {
    }

    public static void skipToData(ExtractorInput extractorInput, WavHeader wavHeader) throws IOException, InterruptedException {
        Assertions.checkNotNull(extractorInput);
        Assertions.checkNotNull(wavHeader);
        extractorInput.resetPeekPosition();
        ParsableByteArray parsableByteArray = new ParsableByteArray(8);
        ChunkHeader peek = ChunkHeader.peek(extractorInput, parsableByteArray);
        while (peek.id != Util.getIntegerCodeForString(DataBufferSafeParcelable.DATA_FIELD)) {
            String str = TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Ignoring unknown WAV chunk: ");
            stringBuilder.append(peek.id);
            Log.w(str, stringBuilder.toString());
            long j = peek.size + 8;
            if (peek.id == Util.getIntegerCodeForString("RIFF")) {
                j = 12;
            }
            if (j <= 2147483647L) {
                extractorInput.skipFully((int) j);
                peek = ChunkHeader.peek(extractorInput, parsableByteArray);
            } else {
                wavHeader = new StringBuilder();
                wavHeader.append("Chunk is too large (~2GB+) to skip; id: ");
                wavHeader.append(peek.id);
                throw new ParserException(wavHeader.toString());
            }
        }
        extractorInput.skipFully(8);
        wavHeader.setDataBounds(extractorInput.getPosition(), peek.size);
    }
}
