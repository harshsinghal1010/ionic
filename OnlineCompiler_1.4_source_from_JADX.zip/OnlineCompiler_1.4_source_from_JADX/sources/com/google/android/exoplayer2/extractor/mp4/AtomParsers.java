package com.google.android.exoplayer2.extractor.mp4;

import android.support.v4.internal.view.SupportMenu;
import android.util.Pair;
import com.google.android.exoplayer2.C0361C;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.ParserException;
import com.google.android.exoplayer2.audio.Ac3Util;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.extractor.ts.PsExtractor;
import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.Metadata.Entry;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.CodecSpecificDataUtil;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.exoplayer2.util.ParsableByteArray;
import com.google.android.exoplayer2.util.Util;
import com.google.android.exoplayer2.video.AvcConfig;
import com.google.android.exoplayer2.video.HevcConfig;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class AtomParsers {
    private static final String TAG = "AtomParsers";
    private static final int TYPE_cenc = Util.getIntegerCodeForString("cenc");
    private static final int TYPE_clcp = Util.getIntegerCodeForString("clcp");
    private static final int TYPE_meta = Util.getIntegerCodeForString("meta");
    private static final int TYPE_sbtl = Util.getIntegerCodeForString("sbtl");
    private static final int TYPE_soun = Util.getIntegerCodeForString("soun");
    private static final int TYPE_subt = Util.getIntegerCodeForString("subt");
    private static final int TYPE_text = Util.getIntegerCodeForString(MimeTypes.BASE_TYPE_TEXT);
    private static final int TYPE_vide = Util.getIntegerCodeForString("vide");

    private static final class ChunkIterator {
        private final ParsableByteArray chunkOffsets;
        private final boolean chunkOffsetsAreLongs;
        public int index;
        public final int length;
        private int nextSamplesPerChunkChangeIndex;
        public int numSamples;
        public long offset;
        private int remainingSamplesPerChunkChanges;
        private final ParsableByteArray stsc;

        public ChunkIterator(ParsableByteArray parsableByteArray, ParsableByteArray parsableByteArray2, boolean z) {
            this.stsc = parsableByteArray;
            this.chunkOffsets = parsableByteArray2;
            this.chunkOffsetsAreLongs = z;
            parsableByteArray2.setPosition(12);
            this.length = parsableByteArray2.readUnsignedIntToInt();
            parsableByteArray.setPosition(12);
            this.remainingSamplesPerChunkChanges = parsableByteArray.readUnsignedIntToInt();
            parsableByteArray2 = true;
            if (parsableByteArray.readInt() != 1) {
                parsableByteArray2 = null;
            }
            Assertions.checkState(parsableByteArray2, "first_chunk must be 1");
            this.index = -1;
        }

        public boolean moveNext() {
            int i = this.index + 1;
            this.index = i;
            if (i == this.length) {
                return false;
            }
            long readUnsignedLongToLong;
            if (this.chunkOffsetsAreLongs) {
                readUnsignedLongToLong = this.chunkOffsets.readUnsignedLongToLong();
            } else {
                readUnsignedLongToLong = this.chunkOffsets.readUnsignedInt();
            }
            this.offset = readUnsignedLongToLong;
            if (this.index == this.nextSamplesPerChunkChangeIndex) {
                this.numSamples = this.stsc.readUnsignedIntToInt();
                this.stsc.skipBytes(4);
                i = this.remainingSamplesPerChunkChanges - 1;
                this.remainingSamplesPerChunkChanges = i;
                this.nextSamplesPerChunkChangeIndex = i > 0 ? this.stsc.readUnsignedIntToInt() - 1 : -1;
            }
            return true;
        }
    }

    private interface SampleSizeBox {
        int getSampleCount();

        boolean isFixedSampleSize();

        int readNextSampleSize();
    }

    private static final class StsdData {
        public static final int STSD_HEADER_SIZE = 8;
        public Format format;
        public int nalUnitLengthFieldLength;
        public int requiredSampleTransformation = 0;
        public final TrackEncryptionBox[] trackEncryptionBoxes;

        public StsdData(int i) {
            this.trackEncryptionBoxes = new TrackEncryptionBox[i];
        }
    }

    private static final class TkhdData {
        private final long duration;
        private final int id;
        private final int rotationDegrees;

        public TkhdData(int i, long j, int i2) {
            this.id = i;
            this.duration = j;
            this.rotationDegrees = i2;
        }
    }

    static final class StszSampleSizeBox implements SampleSizeBox {
        private final ParsableByteArray data;
        private final int fixedSampleSize = this.data.readUnsignedIntToInt();
        private final int sampleCount = this.data.readUnsignedIntToInt();

        public StszSampleSizeBox(LeafAtom leafAtom) {
            this.data = leafAtom.data;
            this.data.setPosition(12);
        }

        public int getSampleCount() {
            return this.sampleCount;
        }

        public int readNextSampleSize() {
            int i = this.fixedSampleSize;
            return i == 0 ? this.data.readUnsignedIntToInt() : i;
        }

        public boolean isFixedSampleSize() {
            return this.fixedSampleSize != 0;
        }
    }

    static final class Stz2SampleSizeBox implements SampleSizeBox {
        private int currentByte;
        private final ParsableByteArray data;
        private final int fieldSize = (this.data.readUnsignedIntToInt() & 255);
        private final int sampleCount = this.data.readUnsignedIntToInt();
        private int sampleIndex;

        public boolean isFixedSampleSize() {
            return false;
        }

        public Stz2SampleSizeBox(LeafAtom leafAtom) {
            this.data = leafAtom.data;
            this.data.setPosition(12);
        }

        public int getSampleCount() {
            return this.sampleCount;
        }

        public int readNextSampleSize() {
            int i = this.fieldSize;
            if (i == 8) {
                return this.data.readUnsignedByte();
            }
            if (i == 16) {
                return this.data.readUnsignedShort();
            }
            i = this.sampleIndex;
            this.sampleIndex = i + 1;
            if (i % 2 != 0) {
                return this.currentByte & 15;
            }
            this.currentByte = this.data.readUnsignedByte();
            return (this.currentByte & PsExtractor.VIDEO_STREAM_MASK) >> 4;
        }
    }

    public static com.google.android.exoplayer2.extractor.mp4.TrackSampleTable parseStbl(com.google.android.exoplayer2.extractor.mp4.Track r43, com.google.android.exoplayer2.extractor.mp4.Atom.ContainerAtom r44, com.google.android.exoplayer2.extractor.GaplessInfoHolder r45) throws com.google.android.exoplayer2.ParserException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:210:0x0496 in {2, 5, 9, 12, 13, 16, 17, 20, 21, 24, 25, 30, 31, 32, 40, 41, 48, 53, 54, 55, 58, 59, 62, 63, 68, 69, 70, 74, 75, 76, 79, 80, 85, 86, 87, 92, 93, 94, 95, 99, 100, 105, 123, 129, 137, 139, 142, 143, 151, 152, 153, 154, 155, 158, 159, 162, 163, 165, 166, 168, 170, 171, 179, 180, 187, 188, 189, 190, 191, 198, 199, 200, 203, 205, 207, 209} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = r43;
        r1 = r44;
        r2 = r45;
        r3 = com.google.android.exoplayer2.extractor.mp4.Atom.TYPE_stsz;
        r3 = r1.getLeafAtomOfType(r3);
        if (r3 == 0) goto L_0x0014;
    L_0x000e:
        r4 = new com.google.android.exoplayer2.extractor.mp4.AtomParsers$StszSampleSizeBox;
        r4.<init>(r3);
        goto L_0x0021;
    L_0x0014:
        r3 = com.google.android.exoplayer2.extractor.mp4.Atom.TYPE_stz2;
        r3 = r1.getLeafAtomOfType(r3);
        if (r3 == 0) goto L_0x048e;
    L_0x001c:
        r4 = new com.google.android.exoplayer2.extractor.mp4.AtomParsers$Stz2SampleSizeBox;
        r4.<init>(r3);
    L_0x0021:
        r3 = r4.getSampleCount();
        r5 = 0;
        if (r3 != 0) goto L_0x0038;
    L_0x0028:
        r0 = new com.google.android.exoplayer2.extractor.mp4.TrackSampleTable;
        r7 = new long[r5];
        r8 = new int[r5];
        r9 = 0;
        r10 = new long[r5];
        r11 = new int[r5];
        r6 = r0;
        r6.<init>(r7, r8, r9, r10, r11);
        return r0;
    L_0x0038:
        r6 = com.google.android.exoplayer2.extractor.mp4.Atom.TYPE_stco;
        r6 = r1.getLeafAtomOfType(r6);
        r7 = 1;
        if (r6 != 0) goto L_0x0049;
    L_0x0041:
        r6 = com.google.android.exoplayer2.extractor.mp4.Atom.TYPE_co64;
        r6 = r1.getLeafAtomOfType(r6);
        r8 = 1;
        goto L_0x004a;
    L_0x0049:
        r8 = 0;
    L_0x004a:
        r6 = r6.data;
        r9 = com.google.android.exoplayer2.extractor.mp4.Atom.TYPE_stsc;
        r9 = r1.getLeafAtomOfType(r9);
        r9 = r9.data;
        r10 = com.google.android.exoplayer2.extractor.mp4.Atom.TYPE_stts;
        r10 = r1.getLeafAtomOfType(r10);
        r10 = r10.data;
        r11 = com.google.android.exoplayer2.extractor.mp4.Atom.TYPE_stss;
        r11 = r1.getLeafAtomOfType(r11);
        r12 = 0;
        if (r11 == 0) goto L_0x0068;
    L_0x0065:
        r11 = r11.data;
        goto L_0x0069;
    L_0x0068:
        r11 = r12;
    L_0x0069:
        r13 = com.google.android.exoplayer2.extractor.mp4.Atom.TYPE_ctts;
        r1 = r1.getLeafAtomOfType(r13);
        if (r1 == 0) goto L_0x0074;
    L_0x0071:
        r1 = r1.data;
        goto L_0x0075;
    L_0x0074:
        r1 = r12;
    L_0x0075:
        r13 = new com.google.android.exoplayer2.extractor.mp4.AtomParsers$ChunkIterator;
        r13.<init>(r9, r6, r8);
        r6 = 12;
        r10.setPosition(r6);
        r8 = r10.readUnsignedIntToInt();
        r8 = r8 - r7;
        r9 = r10.readUnsignedIntToInt();
        r14 = r10.readUnsignedIntToInt();
        if (r1 == 0) goto L_0x0096;
    L_0x008e:
        r1.setPosition(r6);
        r15 = r1.readUnsignedIntToInt();
        goto L_0x0097;
    L_0x0096:
        r15 = 0;
    L_0x0097:
        r16 = -1;
        if (r11 == 0) goto L_0x00ad;
    L_0x009b:
        r11.setPosition(r6);
        r6 = r11.readUnsignedIntToInt();
        if (r6 <= 0) goto L_0x00ab;
    L_0x00a4:
        r12 = r11.readUnsignedIntToInt();
        r16 = r12 + -1;
        goto L_0x00ae;
    L_0x00ab:
        r11 = r12;
        goto L_0x00ae;
    L_0x00ad:
        r6 = 0;
    L_0x00ae:
        r12 = r4.isFixedSampleSize();
        if (r12 == 0) goto L_0x00c8;
    L_0x00b4:
        r12 = "audio/raw";
        r5 = r0.format;
        r5 = r5.sampleMimeType;
        r5 = r12.equals(r5);
        if (r5 == 0) goto L_0x00c8;
    L_0x00c0:
        if (r8 != 0) goto L_0x00c8;
    L_0x00c2:
        if (r15 != 0) goto L_0x00c8;
    L_0x00c4:
        if (r6 != 0) goto L_0x00c8;
    L_0x00c6:
        r5 = 1;
        goto L_0x00c9;
    L_0x00c8:
        r5 = 0;
    L_0x00c9:
        r18 = 0;
        if (r5 != 0) goto L_0x0214;
    L_0x00cd:
        r5 = new long[r3];
        r12 = new int[r3];
        r7 = new long[r3];
        r44 = r6;
        r6 = new int[r3];
        r0 = r44;
        r27 = r10;
        r10 = r14;
        r25 = r15;
        r2 = r16;
        r21 = r18;
        r23 = r21;
        r44 = 0;
        r15 = 0;
        r16 = 0;
        r26 = 0;
        r14 = r9;
        r9 = r8;
        r8 = 0;
    L_0x00ee:
        if (r8 >= r3) goto L_0x01a4;
    L_0x00f0:
        r28 = r21;
        r21 = r44;
    L_0x00f4:
        if (r21 != 0) goto L_0x010e;
    L_0x00f6:
        r21 = r13.moveNext();
        com.google.android.exoplayer2.util.Assertions.checkState(r21);
        r22 = r9;
        r30 = r10;
        r9 = r13.offset;
        r28 = r9;
        r9 = r13.numSamples;
        r21 = r9;
        r9 = r22;
        r10 = r30;
        goto L_0x00f4;
    L_0x010e:
        r22 = r9;
        r30 = r10;
        if (r1 == 0) goto L_0x0128;
    L_0x0114:
        if (r26 != 0) goto L_0x0123;
    L_0x0116:
        if (r25 <= 0) goto L_0x0123;
    L_0x0118:
        r26 = r1.readUnsignedIntToInt();
        r16 = r1.readInt();
        r25 = r25 + -1;
        goto L_0x0114;
    L_0x0123:
        r26 = r26 + -1;
        r9 = r16;
        goto L_0x012a;
    L_0x0128:
        r9 = r16;
    L_0x012a:
        r5[r8] = r28;
        r10 = r4.readNextSampleSize();
        r12[r8] = r10;
        r10 = r12[r8];
        if (r10 <= r15) goto L_0x013d;
    L_0x0136:
        r10 = r12[r8];
        r16 = r3;
        r15 = r10;
        r10 = r4;
        goto L_0x0140;
    L_0x013d:
        r16 = r3;
        r10 = r4;
    L_0x0140:
        r3 = (long) r9;
        r3 = r23 + r3;
        r7[r8] = r3;
        if (r11 != 0) goto L_0x0149;
    L_0x0147:
        r3 = 1;
        goto L_0x014a;
    L_0x0149:
        r3 = 0;
    L_0x014a:
        r6[r8] = r3;
        if (r8 != r2) goto L_0x0166;
    L_0x014e:
        r3 = 1;
        r6[r8] = r3;
        r0 = r0 + -1;
        if (r0 <= 0) goto L_0x0160;
    L_0x0155:
        r2 = r11.readUnsignedIntToInt();
        r2 = r2 - r3;
        r4 = r0;
        r44 = r2;
        r0 = r30;
        goto L_0x016b;
    L_0x0160:
        r4 = r0;
        r44 = r2;
        r0 = r30;
        goto L_0x016b;
    L_0x0166:
        r4 = r0;
        r44 = r2;
        r0 = r30;
    L_0x016b:
        r2 = (long) r0;
        r23 = r23 + r2;
        r14 = r14 + -1;
        if (r14 != 0) goto L_0x0181;
    L_0x0172:
        if (r22 <= 0) goto L_0x0181;
    L_0x0174:
        r0 = r27.readUnsignedIntToInt();
        r2 = r27.readUnsignedIntToInt();
        r3 = r22 + -1;
        r14 = r0;
        r0 = r2;
        goto L_0x0183;
    L_0x0181:
        r3 = r22;
    L_0x0183:
        r2 = r12[r8];
        r22 = r3;
        r2 = (long) r2;
        r2 = r28 + r2;
        r21 = r21 + -1;
        r8 = r8 + 1;
        r40 = r2;
        r2 = r44;
        r3 = r16;
        r44 = r21;
        r16 = r9;
        r9 = r22;
        r21 = r40;
        r42 = r10;
        r10 = r0;
        r0 = r4;
        r4 = r42;
        goto L_0x00ee;
    L_0x01a4:
        r16 = r3;
        r22 = r9;
        if (r26 != 0) goto L_0x01ac;
    L_0x01aa:
        r2 = 1;
        goto L_0x01ad;
    L_0x01ac:
        r2 = 0;
    L_0x01ad:
        com.google.android.exoplayer2.util.Assertions.checkArgument(r2);
    L_0x01b0:
        if (r25 <= 0) goto L_0x01c4;
    L_0x01b2:
        r2 = r1.readUnsignedIntToInt();
        if (r2 != 0) goto L_0x01ba;
    L_0x01b8:
        r2 = 1;
        goto L_0x01bb;
    L_0x01ba:
        r2 = 0;
    L_0x01bb:
        com.google.android.exoplayer2.util.Assertions.checkArgument(r2);
        r1.readInt();
        r25 = r25 + -1;
        goto L_0x01b0;
    L_0x01c4:
        if (r0 != 0) goto L_0x01d0;
    L_0x01c6:
        if (r14 != 0) goto L_0x01d0;
    L_0x01c8:
        if (r44 != 0) goto L_0x01d0;
    L_0x01ca:
        if (r22 == 0) goto L_0x01cd;
    L_0x01cc:
        goto L_0x01d0;
    L_0x01cd:
        r0 = r43;
        goto L_0x020f;
    L_0x01d0:
        r1 = "AtomParsers";
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r3 = "Inconsistent stbl box for track ";
        r2.append(r3);
        r4 = r0;
        r0 = r43;
        r3 = r0.id;
        r2.append(r3);
        r3 = ": remainingSynchronizationSamples ";
        r2.append(r3);
        r2.append(r4);
        r3 = ", remainingSamplesAtTimestampDelta ";
        r2.append(r3);
        r2.append(r14);
        r3 = ", remainingSamplesInChunk ";
        r2.append(r3);
        r3 = r44;
        r2.append(r3);
        r3 = ", remainingTimestampDeltaChanges ";
        r2.append(r3);
        r8 = r22;
        r2.append(r8);
        r2 = r2.toString();
        android.util.Log.w(r1, r2);
    L_0x020f:
        r1 = r23;
        r24 = r15;
        goto L_0x0249;
    L_0x0214:
        r16 = r3;
        r10 = r4;
        r1 = r13.length;
        r1 = new long[r1];
        r2 = r13.length;
        r2 = new int[r2];
    L_0x021f:
        r3 = r13.moveNext();
        if (r3 == 0) goto L_0x0232;
    L_0x0225:
        r3 = r13.index;
        r4 = r13.offset;
        r1[r3] = r4;
        r3 = r13.index;
        r4 = r13.numSamples;
        r2[r3] = r4;
        goto L_0x021f;
    L_0x0232:
        r3 = r10.readNextSampleSize();
        r4 = (long) r14;
        r1 = com.google.android.exoplayer2.extractor.mp4.FixedSampleSizeRechunker.rechunk(r3, r1, r2, r4);
        r5 = r1.offsets;
        r12 = r1.sizes;
        r2 = r1.maximumSize;
        r7 = r1.timestamps;
        r6 = r1.flags;
        r24 = r2;
        r1 = r18;
    L_0x0249:
        r3 = r0.editListDurations;
        if (r3 == 0) goto L_0x0471;
    L_0x024d:
        r3 = r45.hasGaplessInfo();
        if (r3 == 0) goto L_0x0255;
    L_0x0253:
        goto L_0x0471;
    L_0x0255:
        r3 = r0.editListDurations;
        r3 = r3.length;
        r4 = 1;
        if (r3 != r4) goto L_0x02ea;
    L_0x025b:
        r3 = r0.type;
        if (r3 != r4) goto L_0x02ea;
    L_0x025f:
        r3 = r7.length;
        r4 = 2;
        if (r3 < r4) goto L_0x02ea;
    L_0x0263:
        r3 = r0.editListMediaTimes;
        r4 = 0;
        r10 = r3[r4];
        r3 = r0.editListDurations;
        r25 = r3[r4];
        r13 = r0.timescale;
        r8 = r0.movieTimescale;
        r27 = r13;
        r29 = r8;
        r8 = com.google.android.exoplayer2.util.Util.scaleLargeTimestamp(r25, r27, r29);
        r8 = r8 + r10;
        r13 = r7[r4];
        r3 = (r13 > r10 ? 1 : (r13 == r10 ? 0 : -1));
        if (r3 > 0) goto L_0x02ea;
    L_0x027f:
        r3 = 1;
        r13 = r7[r3];
        r4 = (r10 > r13 ? 1 : (r10 == r13 ? 0 : -1));
        if (r4 >= 0) goto L_0x02ea;
    L_0x0286:
        r4 = r7.length;
        r4 = r4 - r3;
        r3 = r7[r4];
        r13 = (r3 > r8 ? 1 : (r3 == r8 ? 0 : -1));
        if (r13 >= 0) goto L_0x02ea;
    L_0x028e:
        r3 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1));
        if (r3 > 0) goto L_0x02ea;
    L_0x0292:
        r25 = r1 - r8;
        r1 = 0;
        r2 = r7[r1];
        r27 = r10 - r2;
        r1 = r0.format;
        r1 = r1.sampleRate;
        r1 = (long) r1;
        r3 = r0.timescale;
        r29 = r1;
        r31 = r3;
        r1 = com.google.android.exoplayer2.util.Util.scaleLargeTimestamp(r27, r29, r31);
        r3 = r0.format;
        r3 = r3.sampleRate;
        r3 = (long) r3;
        r8 = r0.timescale;
        r27 = r3;
        r29 = r8;
        r3 = com.google.android.exoplayer2.util.Util.scaleLargeTimestamp(r25, r27, r29);
        r8 = (r1 > r18 ? 1 : (r1 == r18 ? 0 : -1));
        if (r8 != 0) goto L_0x02bf;
    L_0x02bb:
        r8 = (r3 > r18 ? 1 : (r3 == r18 ? 0 : -1));
        if (r8 == 0) goto L_0x02ea;
    L_0x02bf:
        r8 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        r10 = (r1 > r8 ? 1 : (r1 == r8 ? 0 : -1));
        if (r10 > 0) goto L_0x02ea;
    L_0x02c6:
        r10 = (r3 > r8 ? 1 : (r3 == r8 ? 0 : -1));
        if (r10 > 0) goto L_0x02ea;
    L_0x02ca:
        r1 = (int) r1;
        r2 = r45;
        r2.encoderDelay = r1;
        r1 = (int) r3;
        r2.encoderPadding = r1;
        r0 = r0.timescale;
        r2 = 1000000; // 0xf4240 float:1.401298E-39 double:4.940656E-318;
        com.google.android.exoplayer2.util.Util.scaleLargeTimestampsInPlace(r7, r2, r0);
        r0 = new com.google.android.exoplayer2.extractor.mp4.TrackSampleTable;
        r21 = r0;
        r22 = r5;
        r23 = r12;
        r25 = r7;
        r26 = r6;
        r21.<init>(r22, r23, r24, r25, r26);
        return r0;
    L_0x02ea:
        r1 = r0.editListDurations;
        r1 = r1.length;
        r2 = 1;
        if (r1 != r2) goto L_0x0328;
    L_0x02f0:
        r1 = r0.editListDurations;
        r17 = 0;
        r2 = r1[r17];
        r1 = (r2 > r18 ? 1 : (r2 == r18 ? 0 : -1));
        if (r1 != 0) goto L_0x0328;
    L_0x02fa:
        r1 = 0;
    L_0x02fb:
        r2 = r7.length;
        if (r1 >= r2) goto L_0x0318;
    L_0x02fe:
        r2 = r7[r1];
        r4 = r0.editListMediaTimes;
        r8 = r4[r17];
        r18 = r2 - r8;
        r20 = 1000000; // 0xf4240 float:1.401298E-39 double:4.940656E-318;
        r2 = r0.timescale;
        r22 = r2;
        r2 = com.google.android.exoplayer2.util.Util.scaleLargeTimestamp(r18, r20, r22);
        r7[r1] = r2;
        r1 = r1 + 1;
        r17 = 0;
        goto L_0x02fb;
    L_0x0318:
        r0 = new com.google.android.exoplayer2.extractor.mp4.TrackSampleTable;
        r21 = r0;
        r22 = r5;
        r23 = r12;
        r25 = r7;
        r26 = r6;
        r21.<init>(r22, r23, r24, r25, r26);
        return r0;
    L_0x0328:
        r1 = r0.type;
        r2 = 1;
        if (r1 != r2) goto L_0x032f;
    L_0x032d:
        r1 = 1;
        goto L_0x0330;
    L_0x032f:
        r1 = 0;
    L_0x0330:
        r2 = 0;
        r3 = 0;
        r4 = 0;
        r8 = 0;
    L_0x0334:
        r9 = r0.editListDurations;
        r9 = r9.length;
        r10 = -1;
        if (r2 >= r9) goto L_0x0372;
    L_0x033b:
        r9 = r0.editListMediaTimes;
        r13 = r9[r2];
        r9 = (r13 > r10 ? 1 : (r13 == r10 ? 0 : -1));
        if (r9 == 0) goto L_0x036b;
    L_0x0343:
        r9 = r0.editListDurations;
        r25 = r9[r2];
        r9 = r0.timescale;
        r44 = r12;
        r11 = r0.movieTimescale;
        r27 = r9;
        r29 = r11;
        r9 = com.google.android.exoplayer2.util.Util.scaleLargeTimestamp(r25, r27, r29);
        r11 = 1;
        r12 = com.google.android.exoplayer2.util.Util.binarySearchCeil(r7, r13, r11, r11);
        r13 = r13 + r9;
        r9 = 0;
        r10 = com.google.android.exoplayer2.util.Util.binarySearchCeil(r7, r13, r1, r9);
        r9 = r10 - r12;
        r4 = r4 + r9;
        if (r8 == r12) goto L_0x0367;
    L_0x0365:
        r8 = 1;
        goto L_0x0368;
    L_0x0367:
        r8 = 0;
    L_0x0368:
        r3 = r3 | r8;
        r8 = r10;
        goto L_0x036d;
    L_0x036b:
        r44 = r12;
    L_0x036d:
        r2 = r2 + 1;
        r12 = r44;
        goto L_0x0334;
    L_0x0372:
        r44 = r12;
        r2 = r16;
        if (r4 == r2) goto L_0x037a;
    L_0x0378:
        r2 = 1;
        goto L_0x037b;
    L_0x037a:
        r2 = 0;
    L_0x037b:
        r2 = r2 | r3;
        if (r2 == 0) goto L_0x0381;
    L_0x037e:
        r3 = new long[r4];
        goto L_0x0382;
    L_0x0381:
        r3 = r5;
    L_0x0382:
        if (r2 == 0) goto L_0x0387;
    L_0x0384:
        r12 = new int[r4];
        goto L_0x0389;
    L_0x0387:
        r12 = r44;
    L_0x0389:
        if (r2 == 0) goto L_0x038d;
    L_0x038b:
        r24 = 0;
    L_0x038d:
        if (r2 == 0) goto L_0x0392;
    L_0x038f:
        r8 = new int[r4];
        goto L_0x0393;
    L_0x0392:
        r8 = r6;
    L_0x0393:
        r4 = new long[r4];
        r28 = r24;
        r9 = 0;
        r13 = 0;
    L_0x0399:
        r14 = r0.editListDurations;
        r14 = r14.length;
        if (r9 >= r14) goto L_0x0442;
    L_0x039e:
        r14 = r0.editListMediaTimes;
        r10 = r14[r9];
        r14 = r0.editListDurations;
        r29 = r14[r9];
        r14 = -1;
        r16 = (r10 > r14 ? 1 : (r10 == r14 ? 0 : -1));
        if (r16 == 0) goto L_0x0426;
    L_0x03ac:
        r14 = r0.timescale;
        r16 = r8;
        r27 = r9;
        r8 = r0.movieTimescale;
        r21 = r29;
        r23 = r14;
        r25 = r8;
        r8 = com.google.android.exoplayer2.util.Util.scaleLargeTimestamp(r21, r23, r25);
        r8 = r8 + r10;
        r14 = 1;
        r15 = com.google.android.exoplayer2.util.Util.binarySearchCeil(r7, r10, r14, r14);
        r14 = 0;
        r8 = com.google.android.exoplayer2.util.Util.binarySearchCeil(r7, r8, r1, r14);
        if (r2 == 0) goto L_0x03dd;
    L_0x03cb:
        r9 = r8 - r15;
        java.lang.System.arraycopy(r5, r15, r3, r13, r9);
        r14 = r44;
        java.lang.System.arraycopy(r14, r15, r12, r13, r9);
        r44 = r1;
        r1 = r16;
        java.lang.System.arraycopy(r6, r15, r1, r13, r9);
        goto L_0x03e3;
    L_0x03dd:
        r14 = r44;
        r44 = r1;
        r1 = r16;
    L_0x03e3:
        r9 = r28;
    L_0x03e5:
        if (r15 >= r8) goto L_0x041f;
    L_0x03e7:
        r23 = 1000000; // 0xf4240 float:1.401298E-39 double:4.940656E-318;
        r16 = r5;
        r33 = r6;
        r5 = r0.movieTimescale;
        r21 = r18;
        r25 = r5;
        r5 = com.google.android.exoplayer2.util.Util.scaleLargeTimestamp(r21, r23, r25);
        r21 = r7[r15];
        r34 = r21 - r10;
        r36 = 1000000; // 0xf4240 float:1.401298E-39 double:4.940656E-318;
        r21 = r10;
        r10 = r0.timescale;
        r38 = r10;
        r10 = com.google.android.exoplayer2.util.Util.scaleLargeTimestamp(r34, r36, r38);
        r5 = r5 + r10;
        r4[r13] = r5;
        if (r2 == 0) goto L_0x0414;
    L_0x040e:
        r5 = r12[r13];
        if (r5 <= r9) goto L_0x0414;
    L_0x0412:
        r9 = r14[r15];
    L_0x0414:
        r13 = r13 + 1;
        r15 = r15 + 1;
        r5 = r16;
        r10 = r21;
        r6 = r33;
        goto L_0x03e5;
    L_0x041f:
        r16 = r5;
        r33 = r6;
        r28 = r9;
        goto L_0x0431;
    L_0x0426:
        r14 = r44;
        r44 = r1;
        r16 = r5;
        r33 = r6;
        r1 = r8;
        r27 = r9;
    L_0x0431:
        r18 = r18 + r29;
        r9 = r27 + 1;
        r8 = r1;
        r5 = r16;
        r6 = r33;
        r10 = -1;
        r1 = r44;
        r44 = r14;
        goto L_0x0399;
    L_0x0442:
        r1 = r8;
        r0 = 0;
        r2 = 0;
    L_0x0445:
        r5 = r1.length;
        if (r0 >= r5) goto L_0x0457;
    L_0x0448:
        if (r2 != 0) goto L_0x0457;
    L_0x044a:
        r5 = r1[r0];
        r6 = 1;
        r5 = r5 & r6;
        if (r5 == 0) goto L_0x0452;
    L_0x0450:
        r5 = 1;
        goto L_0x0453;
    L_0x0452:
        r5 = 0;
    L_0x0453:
        r2 = r2 | r5;
        r0 = r0 + 1;
        goto L_0x0445;
    L_0x0457:
        if (r2 == 0) goto L_0x0469;
    L_0x0459:
        r0 = new com.google.android.exoplayer2.extractor.mp4.TrackSampleTable;
        r25 = r0;
        r26 = r3;
        r27 = r12;
        r29 = r4;
        r30 = r1;
        r25.<init>(r26, r27, r28, r29, r30);
        return r0;
    L_0x0469:
        r0 = new com.google.android.exoplayer2.ParserException;
        r1 = "The edited sample sequence does not contain a sync sample.";
        r0.<init>(r1);
        throw r0;
    L_0x0471:
        r16 = r5;
        r33 = r6;
        r14 = r12;
        r0 = r0.timescale;
        r2 = 1000000; // 0xf4240 float:1.401298E-39 double:4.940656E-318;
        com.google.android.exoplayer2.util.Util.scaleLargeTimestampsInPlace(r7, r2, r0);
        r0 = new com.google.android.exoplayer2.extractor.mp4.TrackSampleTable;
        r21 = r0;
        r22 = r16;
        r23 = r14;
        r25 = r7;
        r26 = r33;
        r21.<init>(r22, r23, r24, r25, r26);
        return r0;
    L_0x048e:
        r0 = new com.google.android.exoplayer2.ParserException;
        r1 = "Track has no sample table size information";
        r0.<init>(r1);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.extractor.mp4.AtomParsers.parseStbl(com.google.android.exoplayer2.extractor.mp4.Track, com.google.android.exoplayer2.extractor.mp4.Atom$ContainerAtom, com.google.android.exoplayer2.extractor.GaplessInfoHolder):com.google.android.exoplayer2.extractor.mp4.TrackSampleTable");
    }

    public static Track parseTrak(ContainerAtom containerAtom, LeafAtom leafAtom, long j, DrmInitData drmInitData, boolean z) throws ParserException {
        ContainerAtom containerAtom2 = containerAtom;
        ContainerAtom containerAtomOfType = containerAtom2.getContainerAtomOfType(Atom.TYPE_mdia);
        int parseHdlr = parseHdlr(containerAtomOfType.getLeafAtomOfType(Atom.TYPE_hdlr).data);
        Track track = null;
        if (parseHdlr == -1) {
            return null;
        }
        long access$000;
        LeafAtom leafAtom2;
        TkhdData parseTkhd = parseTkhd(containerAtom2.getLeafAtomOfType(Atom.TYPE_tkhd).data);
        if (j == C0361C.TIME_UNSET) {
            access$000 = parseTkhd.duration;
            leafAtom2 = leafAtom;
        } else {
            leafAtom2 = leafAtom;
            access$000 = j;
        }
        long parseMvhd = parseMvhd(leafAtom2.data);
        long scaleLargeTimestamp = access$000 == C0361C.TIME_UNSET ? C0361C.TIME_UNSET : Util.scaleLargeTimestamp(access$000, C0361C.MICROS_PER_SECOND, parseMvhd);
        ContainerAtom containerAtomOfType2 = containerAtomOfType.getContainerAtomOfType(Atom.TYPE_minf).getContainerAtomOfType(Atom.TYPE_stbl);
        Pair parseMdhd = parseMdhd(containerAtomOfType.getLeafAtomOfType(Atom.TYPE_mdhd).data);
        StsdData parseStsd = parseStsd(containerAtomOfType2.getLeafAtomOfType(Atom.TYPE_stsd).data, parseTkhd.id, parseTkhd.rotationDegrees, (String) parseMdhd.second, drmInitData, z);
        Pair parseEdts = parseEdts(containerAtom2.getContainerAtomOfType(Atom.TYPE_edts));
        if (parseStsd.format != null) {
            Track track2 = new Track(parseTkhd.id, parseHdlr, ((Long) parseMdhd.first).longValue(), parseMvhd, scaleLargeTimestamp, parseStsd.format, parseStsd.requiredSampleTransformation, parseStsd.trackEncryptionBoxes, parseStsd.nalUnitLengthFieldLength, (long[]) parseEdts.first, (long[]) parseEdts.second);
        }
        return track;
    }

    public static Metadata parseUdta(LeafAtom leafAtom, boolean z) {
        if (z) {
            return null;
        }
        leafAtom = leafAtom.data;
        leafAtom.setPosition(8);
        while (leafAtom.bytesLeft() >= 8) {
            int position = leafAtom.getPosition();
            int readInt = leafAtom.readInt();
            if (leafAtom.readInt() == Atom.TYPE_meta) {
                leafAtom.setPosition(position);
                return parseMetaAtom(leafAtom, position + readInt);
            }
            leafAtom.skipBytes(readInt - 8);
        }
        return null;
    }

    private static Metadata parseMetaAtom(ParsableByteArray parsableByteArray, int i) {
        parsableByteArray.skipBytes(12);
        while (parsableByteArray.getPosition() < i) {
            int position = parsableByteArray.getPosition();
            int readInt = parsableByteArray.readInt();
            if (parsableByteArray.readInt() == Atom.TYPE_ilst) {
                parsableByteArray.setPosition(position);
                return parseIlst(parsableByteArray, position + readInt);
            }
            parsableByteArray.skipBytes(readInt - 8);
        }
        return null;
    }

    private static Metadata parseIlst(ParsableByteArray parsableByteArray, int i) {
        parsableByteArray.skipBytes(8);
        List arrayList = new ArrayList();
        while (parsableByteArray.getPosition() < i) {
            Entry parseIlstElement = MetadataUtil.parseIlstElement(parsableByteArray);
            if (parseIlstElement != null) {
                arrayList.add(parseIlstElement);
            }
        }
        return arrayList.isEmpty() != null ? null : new Metadata(arrayList);
    }

    private static long parseMvhd(ParsableByteArray parsableByteArray) {
        int i = 8;
        parsableByteArray.setPosition(8);
        if (Atom.parseFullAtomVersion(parsableByteArray.readInt()) != 0) {
            i = 16;
        }
        parsableByteArray.skipBytes(i);
        return parsableByteArray.readUnsignedInt();
    }

    private static TkhdData parseTkhd(ParsableByteArray parsableByteArray) {
        Object obj;
        int i = 8;
        parsableByteArray.setPosition(8);
        int parseFullAtomVersion = Atom.parseFullAtomVersion(parsableByteArray.readInt());
        parsableByteArray.skipBytes(parseFullAtomVersion == 0 ? 8 : 16);
        int readInt = parsableByteArray.readInt();
        parsableByteArray.skipBytes(4);
        int position = parsableByteArray.getPosition();
        if (parseFullAtomVersion == 0) {
            i = 4;
        }
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            if (parsableByteArray.data[position + i3] != (byte) -1) {
                obj = null;
                break;
            }
        }
        obj = 1;
        long j = C0361C.TIME_UNSET;
        if (obj != null) {
            parsableByteArray.skipBytes(i);
        } else {
            long readUnsignedInt = parseFullAtomVersion == 0 ? parsableByteArray.readUnsignedInt() : parsableByteArray.readUnsignedLongToLong();
            if (readUnsignedInt != 0) {
                j = readUnsignedInt;
            }
        }
        parsableByteArray.skipBytes(16);
        i = parsableByteArray.readInt();
        parseFullAtomVersion = parsableByteArray.readInt();
        parsableByteArray.skipBytes(4);
        int readInt2 = parsableByteArray.readInt();
        parsableByteArray = parsableByteArray.readInt();
        if (i == 0 && parseFullAtomVersion == 65536 && readInt2 == SupportMenu.CATEGORY_MASK && parsableByteArray == null) {
            i2 = 90;
        } else if (i == 0 && parseFullAtomVersion == SupportMenu.CATEGORY_MASK && readInt2 == 65536 && parsableByteArray == null) {
            i2 = 270;
        } else if (i == SupportMenu.CATEGORY_MASK && parseFullAtomVersion == 0 && readInt2 == 0 && parsableByteArray == -65536) {
            i2 = 180;
        }
        return new TkhdData(readInt, j, i2);
    }

    private static int parseHdlr(ParsableByteArray parsableByteArray) {
        parsableByteArray.setPosition(16);
        parsableByteArray = parsableByteArray.readInt();
        if (parsableByteArray == TYPE_soun) {
            return 1;
        }
        if (parsableByteArray == TYPE_vide) {
            return 2;
        }
        if (!(parsableByteArray == TYPE_text || parsableByteArray == TYPE_sbtl || parsableByteArray == TYPE_subt)) {
            if (parsableByteArray != TYPE_clcp) {
                return parsableByteArray == TYPE_meta ? 4 : -1;
            }
        }
        return 3;
    }

    private static Pair<Long, String> parseMdhd(ParsableByteArray parsableByteArray) {
        int i = 8;
        parsableByteArray.setPosition(8);
        int parseFullAtomVersion = Atom.parseFullAtomVersion(parsableByteArray.readInt());
        parsableByteArray.skipBytes(parseFullAtomVersion == 0 ? 8 : 16);
        long readUnsignedInt = parsableByteArray.readUnsignedInt();
        if (parseFullAtomVersion == 0) {
            i = 4;
        }
        parsableByteArray.skipBytes(i);
        parsableByteArray = parsableByteArray.readUnsignedShort();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append((char) (((parsableByteArray >> 10) & 31) + 96));
        stringBuilder.append((char) (((parsableByteArray >> 5) & 31) + 96));
        stringBuilder.append((char) ((parsableByteArray & 31) + 96));
        return Pair.create(Long.valueOf(readUnsignedInt), stringBuilder.toString());
    }

    private static StsdData parseStsd(ParsableByteArray parsableByteArray, int i, int i2, String str, DrmInitData drmInitData, boolean z) throws ParserException {
        ParsableByteArray parsableByteArray2 = parsableByteArray;
        parsableByteArray2.setPosition(12);
        int readInt = parsableByteArray.readInt();
        StsdData stsdData = new StsdData(readInt);
        for (int i3 = 0; i3 < readInt; i3++) {
            int position = parsableByteArray.getPosition();
            int readInt2 = parsableByteArray.readInt();
            Assertions.checkArgument(readInt2 > 0, "childAtomSize should be positive");
            int readInt3 = parsableByteArray.readInt();
            if (!(readInt3 == Atom.TYPE_avc1 || readInt3 == Atom.TYPE_avc3 || readInt3 == Atom.TYPE_encv || readInt3 == Atom.TYPE_mp4v || readInt3 == Atom.TYPE_hvc1 || readInt3 == Atom.TYPE_hev1 || readInt3 == Atom.TYPE_s263 || readInt3 == Atom.TYPE_vp08)) {
                if (readInt3 != Atom.TYPE_vp09) {
                    DrmInitData drmInitData2;
                    if (!(readInt3 == Atom.TYPE_mp4a || readInt3 == Atom.TYPE_enca || readInt3 == Atom.TYPE_ac_3 || readInt3 == Atom.TYPE_ec_3 || readInt3 == Atom.TYPE_dtsc || readInt3 == Atom.TYPE_dtse || readInt3 == Atom.TYPE_dtsh || readInt3 == Atom.TYPE_dtsl || readInt3 == Atom.TYPE_samr || readInt3 == Atom.TYPE_sawb || readInt3 == Atom.TYPE_lpcm || readInt3 == Atom.TYPE_sowt || readInt3 == Atom.TYPE__mp3)) {
                        if (readInt3 != Atom.TYPE_alac) {
                            if (!(readInt3 == Atom.TYPE_TTML || readInt3 == Atom.TYPE_tx3g || readInt3 == Atom.TYPE_wvtt || readInt3 == Atom.TYPE_stpp)) {
                                if (readInt3 != Atom.TYPE_c608) {
                                    if (readInt3 == Atom.TYPE_camm) {
                                        stsdData.format = Format.createSampleFormat(Integer.toString(i), MimeTypes.APPLICATION_CAMERA_MOTION, null, -1, drmInitData);
                                    } else {
                                        drmInitData2 = drmInitData;
                                    }
                                    parsableByteArray2.setPosition(position + readInt2);
                                }
                            }
                            drmInitData2 = drmInitData;
                            parseTextSampleEntry(parsableByteArray, readInt3, position, readInt2, i, str, drmInitData, stsdData);
                            parsableByteArray2.setPosition(position + readInt2);
                        }
                    }
                    drmInitData2 = drmInitData;
                    parseAudioSampleEntry(parsableByteArray, readInt3, position, readInt2, i, str, z, drmInitData, stsdData, i3);
                    parsableByteArray2.setPosition(position + readInt2);
                }
            }
            parseVideoSampleEntry(parsableByteArray, readInt3, position, readInt2, i, i2, drmInitData, stsdData, i3);
            parsableByteArray2.setPosition(position + readInt2);
        }
        return stsdData;
    }

    private static void parseTextSampleEntry(ParsableByteArray parsableByteArray, int i, int i2, int i3, int i4, String str, DrmInitData drmInitData, StsdData stsdData) throws ParserException {
        String str2;
        List list;
        long j;
        ParsableByteArray parsableByteArray2 = parsableByteArray;
        int i5 = i;
        StsdData stsdData2 = stsdData;
        parsableByteArray2.setPosition((i2 + 8) + 8);
        if (i5 == Atom.TYPE_TTML) {
            str2 = MimeTypes.APPLICATION_TTML;
            list = null;
            j = Long.MAX_VALUE;
        } else if (i5 == Atom.TYPE_tx3g) {
            String str3 = MimeTypes.APPLICATION_TX3G;
            int i6 = (i3 - 8) - 8;
            Object obj = new byte[i6];
            parsableByteArray2.readBytes(obj, 0, i6);
            str2 = str3;
            list = Collections.singletonList(obj);
            j = Long.MAX_VALUE;
        } else if (i5 == Atom.TYPE_wvtt) {
            str2 = MimeTypes.APPLICATION_MP4VTT;
            list = null;
            j = Long.MAX_VALUE;
        } else if (i5 == Atom.TYPE_stpp) {
            str2 = MimeTypes.APPLICATION_TTML;
            list = null;
            j = 0;
        } else if (i5 == Atom.TYPE_c608) {
            String str4 = MimeTypes.APPLICATION_MP4CEA608;
            stsdData2.requiredSampleTransformation = 1;
            str2 = str4;
            list = null;
            j = Long.MAX_VALUE;
        } else {
            throw new IllegalStateException();
        }
        stsdData2.format = Format.createTextSampleFormat(Integer.toString(i4), str2, null, -1, 0, str, -1, drmInitData, j, list);
    }

    private static void parseVideoSampleEntry(ParsableByteArray parsableByteArray, int i, int i2, int i3, int i4, int i5, DrmInitData drmInitData, StsdData stsdData, int i6) throws ParserException {
        int parseSampleEntryEncryptionData;
        ParsableByteArray parsableByteArray2 = parsableByteArray;
        int i7 = i2;
        int i8 = i3;
        StsdData stsdData2 = stsdData;
        parsableByteArray2.setPosition((i7 + 8) + 8);
        parsableByteArray2.skipBytes(16);
        int readUnsignedShort = parsableByteArray.readUnsignedShort();
        int readUnsignedShort2 = parsableByteArray.readUnsignedShort();
        parsableByteArray2.skipBytes(50);
        int position = parsableByteArray.getPosition();
        int i9 = i;
        if (i9 == Atom.TYPE_encv) {
            parseSampleEntryEncryptionData = parseSampleEntryEncryptionData(parsableByteArray2, i7, i8, stsdData2, i6);
            parsableByteArray2.setPosition(position);
        } else {
            parseSampleEntryEncryptionData = i9;
        }
        String str = null;
        List list = str;
        byte[] bArr = list;
        Object obj = null;
        float f = 1.0f;
        int i10 = -1;
        while (position - i7 < i8) {
            parsableByteArray2.setPosition(position);
            int position2 = parsableByteArray.getPosition();
            int readInt = parsableByteArray.readInt();
            if (readInt != 0 || parsableByteArray.getPosition() - i7 != i8) {
                Assertions.checkArgument(readInt > 0, "childAtomSize should be positive");
                int readInt2 = parsableByteArray.readInt();
                if (readInt2 == Atom.TYPE_avcC) {
                    Assertions.checkState(str == null);
                    str = MimeTypes.VIDEO_H264;
                    parsableByteArray2.setPosition(position2 + 8);
                    AvcConfig parse = AvcConfig.parse(parsableByteArray);
                    list = parse.initializationData;
                    stsdData2.nalUnitLengthFieldLength = parse.nalUnitLengthFieldLength;
                    if (obj == null) {
                        f = parse.pixelWidthAspectRatio;
                    }
                } else if (readInt2 == Atom.TYPE_hvcC) {
                    Assertions.checkState(str == null);
                    str = MimeTypes.VIDEO_H265;
                    parsableByteArray2.setPosition(position2 + 8);
                    HevcConfig parse2 = HevcConfig.parse(parsableByteArray);
                    list = parse2.initializationData;
                    stsdData2.nalUnitLengthFieldLength = parse2.nalUnitLengthFieldLength;
                } else if (readInt2 == Atom.TYPE_vpcC) {
                    Assertions.checkState(str == null);
                    str = parseSampleEntryEncryptionData == Atom.TYPE_vp08 ? MimeTypes.VIDEO_VP8 : MimeTypes.VIDEO_VP9;
                } else if (readInt2 == Atom.TYPE_d263) {
                    Assertions.checkState(str == null);
                    str = MimeTypes.VIDEO_H263;
                } else if (readInt2 == Atom.TYPE_esds) {
                    Assertions.checkState(str == null);
                    Pair parseEsdsFromParent = parseEsdsFromParent(parsableByteArray2, position2);
                    str = (String) parseEsdsFromParent.first;
                    list = Collections.singletonList(parseEsdsFromParent.second);
                } else if (readInt2 == Atom.TYPE_pasp) {
                    f = parsePaspFromParent(parsableByteArray2, position2);
                    obj = 1;
                } else if (readInt2 == Atom.TYPE_sv3d) {
                    bArr = parseProjFromParent(parsableByteArray2, position2, readInt);
                } else if (readInt2 == Atom.TYPE_st3d) {
                    readInt2 = parsableByteArray.readUnsignedByte();
                    parsableByteArray2.skipBytes(3);
                    if (readInt2 == 0) {
                        switch (parsableByteArray.readUnsignedByte()) {
                            case 0:
                                i10 = 0;
                                break;
                            case 1:
                                i10 = 1;
                                break;
                            case 2:
                                i10 = 2;
                                break;
                            case 3:
                                i10 = 3;
                                break;
                            default:
                                break;
                        }
                    }
                }
                position += readInt;
                i7 = i2;
            } else if (str == null) {
                stsdData2.format = Format.createVideoSampleFormat(Integer.toString(i4), str, null, -1, -1, readUnsignedShort, readUnsignedShort2, -1.0f, list, i5, f, bArr, i10, null, drmInitData);
            }
        }
        if (str == null) {
            stsdData2.format = Format.createVideoSampleFormat(Integer.toString(i4), str, null, -1, -1, readUnsignedShort, readUnsignedShort2, -1.0f, list, i5, f, bArr, i10, null, drmInitData);
        }
    }

    private static Pair<long[], long[]> parseEdts(ContainerAtom containerAtom) {
        if (containerAtom != null) {
            containerAtom = containerAtom.getLeafAtomOfType(Atom.TYPE_elst);
            if (containerAtom != null) {
                containerAtom = containerAtom.data;
                containerAtom.setPosition(8);
                int parseFullAtomVersion = Atom.parseFullAtomVersion(containerAtom.readInt());
                int readUnsignedIntToInt = containerAtom.readUnsignedIntToInt();
                Object obj = new long[readUnsignedIntToInt];
                Object obj2 = new long[readUnsignedIntToInt];
                int i = 0;
                while (i < readUnsignedIntToInt) {
                    obj[i] = parseFullAtomVersion == 1 ? containerAtom.readUnsignedLongToLong() : containerAtom.readUnsignedInt();
                    obj2[i] = parseFullAtomVersion == 1 ? containerAtom.readLong() : (long) containerAtom.readInt();
                    if (containerAtom.readShort() == (short) 1) {
                        containerAtom.skipBytes(2);
                        i++;
                    } else {
                        throw new IllegalArgumentException("Unsupported media rate.");
                    }
                }
                return Pair.create(obj, obj2);
            }
        }
        return Pair.create(null, null);
    }

    private static float parsePaspFromParent(ParsableByteArray parsableByteArray, int i) {
        parsableByteArray.setPosition(i + 8);
        return ((float) parsableByteArray.readUnsignedIntToInt()) / ((float) parsableByteArray.readUnsignedIntToInt());
    }

    private static void parseAudioSampleEntry(ParsableByteArray parsableByteArray, int i, int i2, int i3, int i4, String str, boolean z, DrmInitData drmInitData, StsdData stsdData, int i5) {
        int readUnsignedShort;
        int round;
        int i6;
        int i7;
        int parseSampleEntryEncryptionData;
        List list;
        String str2;
        int i8;
        int i9;
        String str3;
        int i10;
        Object obj;
        String str4;
        StsdData stsdData2;
        int i11;
        int i12;
        Pair parseEsdsFromParent;
        ParsableByteArray parsableByteArray2 = parsableByteArray;
        int i13 = i2;
        int i14 = i3;
        String str5 = str;
        DrmInitData drmInitData2 = drmInitData;
        StsdData stsdData3 = stsdData;
        parsableByteArray2.setPosition((i13 + 8) + 8);
        if (z) {
            readUnsignedShort = parsableByteArray.readUnsignedShort();
            parsableByteArray2.skipBytes(6);
        } else {
            parsableByteArray2.skipBytes(8);
            readUnsignedShort = 0;
        }
        if (readUnsignedShort != 0) {
            if (readUnsignedShort != 1) {
                if (readUnsignedShort == 2) {
                    parsableByteArray2.skipBytes(16);
                    round = (int) Math.round(parsableByteArray.readDouble());
                    readUnsignedShort = parsableByteArray.readUnsignedIntToInt();
                    parsableByteArray2.skipBytes(20);
                    i6 = readUnsignedShort;
                    readUnsignedShort = parsableByteArray.getPosition();
                    i7 = i;
                    if (i7 == Atom.TYPE_enca) {
                        parseSampleEntryEncryptionData = parseSampleEntryEncryptionData(parsableByteArray2, i13, i14, stsdData3, i5);
                        parsableByteArray2.setPosition(readUnsignedShort);
                        i7 = parseSampleEntryEncryptionData;
                    }
                    list = null;
                    if (i7 == Atom.TYPE_ac_3) {
                        str2 = MimeTypes.AUDIO_AC3;
                    } else if (i7 == Atom.TYPE_ec_3) {
                        str2 = MimeTypes.AUDIO_E_AC3;
                    } else if (i7 != Atom.TYPE_dtsc) {
                        str2 = MimeTypes.AUDIO_DTS;
                    } else {
                        if (i7 != Atom.TYPE_dtsh) {
                            if (i7 == Atom.TYPE_dtsl) {
                                if (i7 == Atom.TYPE_dtse) {
                                    str2 = MimeTypes.AUDIO_DTS_EXPRESS;
                                } else if (i7 == Atom.TYPE_samr) {
                                    str2 = MimeTypes.AUDIO_AMR_NB;
                                } else if (i7 != Atom.TYPE_sawb) {
                                    str2 = MimeTypes.AUDIO_AMR_WB;
                                } else {
                                    if (i7 != Atom.TYPE_lpcm) {
                                        if (i7 == Atom.TYPE_sowt) {
                                            str2 = i7 != Atom.TYPE__mp3 ? MimeTypes.AUDIO_MPEG : i7 != Atom.TYPE_alac ? MimeTypes.AUDIO_ALAC : null;
                                        }
                                    }
                                    str2 = MimeTypes.AUDIO_RAW;
                                }
                            }
                        }
                        str2 = MimeTypes.AUDIO_DTS_HD;
                    }
                    i8 = round;
                    i9 = readUnsignedShort;
                    str3 = str2;
                    i10 = i6;
                    obj = null;
                    while (i9 - i13 < i14) {
                        parsableByteArray2.setPosition(i9);
                        i7 = parsableByteArray.readInt();
                        Assertions.checkArgument(i7 <= 0, "childAtomSize should be positive");
                        round = parsableByteArray.readInt();
                        if (round != Atom.TYPE_esds) {
                            if (z || round != Atom.TYPE_wave) {
                                if (round == Atom.TYPE_dac3) {
                                    parsableByteArray2.setPosition(i9 + 8);
                                    stsdData3.format = Ac3Util.parseAc3AnnexFFormat(parsableByteArray2, Integer.toString(i4), str5, drmInitData2);
                                    parseSampleEntryEncryptionData = i7;
                                    str4 = str3;
                                    i6 = i9;
                                    stsdData2 = stsdData3;
                                } else if (round == Atom.TYPE_dec3) {
                                    parsableByteArray2.setPosition(i9 + 8);
                                    stsdData3.format = Ac3Util.parseEAc3AnnexFFormat(parsableByteArray2, Integer.toString(i4), str5, drmInitData2);
                                    parseSampleEntryEncryptionData = i7;
                                    str4 = str3;
                                    i6 = i9;
                                    stsdData2 = stsdData3;
                                } else if (round != Atom.TYPE_ddts) {
                                    i11 = i7;
                                    str4 = str3;
                                    i12 = i9;
                                    stsdData2 = stsdData3;
                                    stsdData2.format = Format.createAudioSampleFormat(Integer.toString(i4), str3, null, -1, -1, i10, i8, null, drmInitData, 0, str);
                                    parseSampleEntryEncryptionData = i11;
                                    i6 = i12;
                                } else {
                                    i11 = i7;
                                    str4 = str3;
                                    i12 = i9;
                                    stsdData2 = stsdData3;
                                    if (round != Atom.TYPE_alac) {
                                        parseSampleEntryEncryptionData = i11;
                                        Object obj2 = new byte[parseSampleEntryEncryptionData];
                                        i6 = i12;
                                        parsableByteArray2.setPosition(i6);
                                        parsableByteArray2.readBytes(obj2, 0, parseSampleEntryEncryptionData);
                                        obj = obj2;
                                        str3 = str4;
                                        i9 = i6 + parseSampleEntryEncryptionData;
                                        stsdData3 = stsdData2;
                                        i14 = i3;
                                    } else {
                                        parseSampleEntryEncryptionData = i11;
                                        i6 = i12;
                                    }
                                }
                                str3 = str4;
                                i9 = i6 + parseSampleEntryEncryptionData;
                                stsdData3 = stsdData2;
                                i14 = i3;
                            }
                        }
                        parseSampleEntryEncryptionData = i7;
                        str4 = str3;
                        i6 = i9;
                        stsdData2 = stsdData3;
                        if (round != Atom.TYPE_esds) {
                            i9 = i6;
                        } else {
                            i9 = findEsdsPosition(parsableByteArray2, i6, parseSampleEntryEncryptionData);
                        }
                        if (i9 == -1) {
                            parseEsdsFromParent = parseEsdsFromParent(parsableByteArray2, i9);
                            str3 = (String) parseEsdsFromParent.first;
                            obj = (byte[]) parseEsdsFromParent.second;
                            if (MimeTypes.AUDIO_AAC.equals(str3)) {
                                parseEsdsFromParent = CodecSpecificDataUtil.parseAacAudioSpecificConfig(obj);
                                i8 = ((Integer) parseEsdsFromParent.first).intValue();
                                i10 = ((Integer) parseEsdsFromParent.second).intValue();
                            }
                        } else {
                            str3 = str4;
                        }
                        i9 = i6 + parseSampleEntryEncryptionData;
                        stsdData3 = stsdData2;
                        i14 = i3;
                    }
                    str4 = str3;
                    stsdData2 = stsdData3;
                    if (stsdData2.format == null) {
                        str3 = str4;
                        if (str3 != null) {
                            i7 = MimeTypes.AUDIO_RAW.equals(str3) ? 2 : -1;
                            String num = Integer.toString(i4);
                            if (obj == null) {
                                list = Collections.singletonList(obj);
                            }
                            stsdData2.format = Format.createAudioSampleFormat(num, str3, null, -1, -1, i10, i8, i7, list, drmInitData, 0, str);
                        }
                    }
                }
                return;
            }
        }
        i6 = parsableByteArray.readUnsignedShort();
        parsableByteArray2.skipBytes(6);
        round = parsableByteArray.readUnsignedFixedPoint1616();
        if (readUnsignedShort == 1) {
            parsableByteArray2.skipBytes(16);
        }
        readUnsignedShort = parsableByteArray.getPosition();
        i7 = i;
        if (i7 == Atom.TYPE_enca) {
            parseSampleEntryEncryptionData = parseSampleEntryEncryptionData(parsableByteArray2, i13, i14, stsdData3, i5);
            parsableByteArray2.setPosition(readUnsignedShort);
            i7 = parseSampleEntryEncryptionData;
        }
        list = null;
        if (i7 == Atom.TYPE_ac_3) {
            str2 = MimeTypes.AUDIO_AC3;
        } else if (i7 == Atom.TYPE_ec_3) {
            str2 = MimeTypes.AUDIO_E_AC3;
        } else if (i7 != Atom.TYPE_dtsc) {
            if (i7 != Atom.TYPE_dtsh) {
                if (i7 == Atom.TYPE_dtsl) {
                    if (i7 == Atom.TYPE_dtse) {
                        str2 = MimeTypes.AUDIO_DTS_EXPRESS;
                    } else if (i7 == Atom.TYPE_samr) {
                        str2 = MimeTypes.AUDIO_AMR_NB;
                    } else if (i7 != Atom.TYPE_sawb) {
                        if (i7 != Atom.TYPE_lpcm) {
                            if (i7 == Atom.TYPE_sowt) {
                                if (i7 != Atom.TYPE__mp3) {
                                    if (i7 != Atom.TYPE_alac) {
                                    }
                                }
                            }
                        }
                        str2 = MimeTypes.AUDIO_RAW;
                    } else {
                        str2 = MimeTypes.AUDIO_AMR_WB;
                    }
                }
            }
            str2 = MimeTypes.AUDIO_DTS_HD;
        } else {
            str2 = MimeTypes.AUDIO_DTS;
        }
        i8 = round;
        i9 = readUnsignedShort;
        str3 = str2;
        i10 = i6;
        obj = null;
        while (i9 - i13 < i14) {
            parsableByteArray2.setPosition(i9);
            i7 = parsableByteArray.readInt();
            if (i7 <= 0) {
            }
            Assertions.checkArgument(i7 <= 0, "childAtomSize should be positive");
            round = parsableByteArray.readInt();
            if (round != Atom.TYPE_esds) {
                if (z) {
                }
                if (round == Atom.TYPE_dac3) {
                    parsableByteArray2.setPosition(i9 + 8);
                    stsdData3.format = Ac3Util.parseAc3AnnexFFormat(parsableByteArray2, Integer.toString(i4), str5, drmInitData2);
                    parseSampleEntryEncryptionData = i7;
                    str4 = str3;
                    i6 = i9;
                    stsdData2 = stsdData3;
                } else if (round == Atom.TYPE_dec3) {
                    parsableByteArray2.setPosition(i9 + 8);
                    stsdData3.format = Ac3Util.parseEAc3AnnexFFormat(parsableByteArray2, Integer.toString(i4), str5, drmInitData2);
                    parseSampleEntryEncryptionData = i7;
                    str4 = str3;
                    i6 = i9;
                    stsdData2 = stsdData3;
                } else if (round != Atom.TYPE_ddts) {
                    i11 = i7;
                    str4 = str3;
                    i12 = i9;
                    stsdData2 = stsdData3;
                    if (round != Atom.TYPE_alac) {
                        parseSampleEntryEncryptionData = i11;
                        i6 = i12;
                    } else {
                        parseSampleEntryEncryptionData = i11;
                        Object obj22 = new byte[parseSampleEntryEncryptionData];
                        i6 = i12;
                        parsableByteArray2.setPosition(i6);
                        parsableByteArray2.readBytes(obj22, 0, parseSampleEntryEncryptionData);
                        obj = obj22;
                        str3 = str4;
                        i9 = i6 + parseSampleEntryEncryptionData;
                        stsdData3 = stsdData2;
                        i14 = i3;
                    }
                } else {
                    i11 = i7;
                    str4 = str3;
                    i12 = i9;
                    stsdData2 = stsdData3;
                    stsdData2.format = Format.createAudioSampleFormat(Integer.toString(i4), str3, null, -1, -1, i10, i8, null, drmInitData, 0, str);
                    parseSampleEntryEncryptionData = i11;
                    i6 = i12;
                }
                str3 = str4;
                i9 = i6 + parseSampleEntryEncryptionData;
                stsdData3 = stsdData2;
                i14 = i3;
            }
            parseSampleEntryEncryptionData = i7;
            str4 = str3;
            i6 = i9;
            stsdData2 = stsdData3;
            if (round != Atom.TYPE_esds) {
                i9 = findEsdsPosition(parsableByteArray2, i6, parseSampleEntryEncryptionData);
            } else {
                i9 = i6;
            }
            if (i9 == -1) {
                str3 = str4;
            } else {
                parseEsdsFromParent = parseEsdsFromParent(parsableByteArray2, i9);
                str3 = (String) parseEsdsFromParent.first;
                obj = (byte[]) parseEsdsFromParent.second;
                if (MimeTypes.AUDIO_AAC.equals(str3)) {
                    parseEsdsFromParent = CodecSpecificDataUtil.parseAacAudioSpecificConfig(obj);
                    i8 = ((Integer) parseEsdsFromParent.first).intValue();
                    i10 = ((Integer) parseEsdsFromParent.second).intValue();
                }
            }
            i9 = i6 + parseSampleEntryEncryptionData;
            stsdData3 = stsdData2;
            i14 = i3;
        }
        str4 = str3;
        stsdData2 = stsdData3;
        if (stsdData2.format == null) {
            str3 = str4;
            if (str3 != null) {
                if (MimeTypes.AUDIO_RAW.equals(str3)) {
                }
                String num2 = Integer.toString(i4);
                if (obj == null) {
                    list = Collections.singletonList(obj);
                }
                stsdData2.format = Format.createAudioSampleFormat(num2, str3, null, -1, -1, i10, i8, i7, list, drmInitData, 0, str);
            }
        }
    }

    private static int findEsdsPosition(ParsableByteArray parsableByteArray, int i, int i2) {
        int position = parsableByteArray.getPosition();
        while (position - i < i2) {
            parsableByteArray.setPosition(position);
            int readInt = parsableByteArray.readInt();
            Assertions.checkArgument(readInt > 0, "childAtomSize should be positive");
            if (parsableByteArray.readInt() == Atom.TYPE_esds) {
                return position;
            }
            position += readInt;
        }
        return -1;
    }

    private static Pair<String, byte[]> parseEsdsFromParent(ParsableByteArray parsableByteArray, int i) {
        parsableByteArray.setPosition((i + 8) + 4);
        parsableByteArray.skipBytes(1);
        parseExpandableClassSize(parsableByteArray);
        parsableByteArray.skipBytes(2);
        int readUnsignedByte = parsableByteArray.readUnsignedByte();
        if ((readUnsignedByte & 128) != 0) {
            parsableByteArray.skipBytes(2);
        }
        if ((readUnsignedByte & 64) != 0) {
            parsableByteArray.skipBytes(parsableByteArray.readUnsignedShort());
        }
        if ((readUnsignedByte & 32) != 0) {
            parsableByteArray.skipBytes(2);
        }
        parsableByteArray.skipBytes(1);
        parseExpandableClassSize(parsableByteArray);
        Object obj = null;
        switch (parsableByteArray.readUnsignedByte()) {
            case 32:
                obj = MimeTypes.VIDEO_MP4V;
                break;
            case 33:
                obj = MimeTypes.VIDEO_H264;
                break;
            case 35:
                obj = MimeTypes.VIDEO_H265;
                break;
            case 64:
            case 102:
            case 103:
            case 104:
                obj = MimeTypes.AUDIO_AAC;
                break;
            case 107:
                return Pair.create(MimeTypes.AUDIO_MPEG, null);
            case 165:
                obj = MimeTypes.AUDIO_AC3;
                break;
            case 166:
                obj = MimeTypes.AUDIO_E_AC3;
                break;
            case 169:
            case 172:
                return Pair.create(MimeTypes.AUDIO_DTS, null);
            case 170:
            case 171:
                return Pair.create(MimeTypes.AUDIO_DTS_HD, null);
            default:
                break;
        }
        parsableByteArray.skipBytes(12);
        parsableByteArray.skipBytes(1);
        i = parseExpandableClassSize(parsableByteArray);
        Object obj2 = new byte[i];
        parsableByteArray.readBytes(obj2, 0, i);
        return Pair.create(obj, obj2);
    }

    private static int parseSampleEntryEncryptionData(ParsableByteArray parsableByteArray, int i, int i2, StsdData stsdData, int i3) {
        int position = parsableByteArray.getPosition();
        while (true) {
            boolean z = false;
            if (position - i >= i2) {
                return 0;
            }
            parsableByteArray.setPosition(position);
            int readInt = parsableByteArray.readInt();
            if (readInt > 0) {
                z = true;
            }
            Assertions.checkArgument(z, "childAtomSize should be positive");
            if (parsableByteArray.readInt() == Atom.TYPE_sinf) {
                Pair parseSinfFromParent = parseSinfFromParent(parsableByteArray, position, readInt);
                if (parseSinfFromParent != null) {
                    stsdData.trackEncryptionBoxes[i3] = (TrackEncryptionBox) parseSinfFromParent.second;
                    return ((Integer) parseSinfFromParent.first).intValue();
                }
            }
            position += readInt;
        }
    }

    private static Pair<Integer, TrackEncryptionBox> parseSinfFromParent(ParsableByteArray parsableByteArray, int i, int i2) {
        int i3 = i + 8;
        boolean z = false;
        Object obj = null;
        Object obj2 = obj;
        Object obj3 = null;
        while (true) {
            Object obj4 = 1;
            if (i3 - i >= i2) {
                break;
            }
            parsableByteArray.setPosition(i3);
            int readInt = parsableByteArray.readInt();
            int readInt2 = parsableByteArray.readInt();
            if (readInt2 == Atom.TYPE_frma) {
                obj = Integer.valueOf(parsableByteArray.readInt());
            } else if (readInt2 == Atom.TYPE_schm) {
                parsableByteArray.skipBytes(4);
                if (parsableByteArray.readInt() != TYPE_cenc) {
                    obj4 = null;
                }
                obj3 = obj4;
            } else if (readInt2 == Atom.TYPE_schi) {
                obj2 = parseSchiFromParent(parsableByteArray, i3, readInt);
            }
            i3 += readInt;
        }
        if (obj3 == null) {
            return null;
        }
        Assertions.checkArgument(obj != null ? true : null, "frma atom is mandatory");
        if (obj2 != null) {
            z = true;
        }
        Assertions.checkArgument(z, "schi->tenc atom is mandatory");
        return Pair.create(obj, obj2);
    }

    private static TrackEncryptionBox parseSchiFromParent(ParsableByteArray parsableByteArray, int i, int i2) {
        int i3 = i + 8;
        while (i3 - i < i2) {
            parsableByteArray.setPosition(i3);
            int readInt = parsableByteArray.readInt();
            if (parsableByteArray.readInt() == Atom.TYPE_tenc) {
                parsableByteArray.skipBytes(6);
                boolean z = true;
                if (parsableByteArray.readUnsignedByte() != 1) {
                    z = false;
                }
                i = parsableByteArray.readUnsignedByte();
                byte[] bArr = new byte[16];
                parsableByteArray.readBytes(bArr, 0, bArr.length);
                return new TrackEncryptionBox(z, i, bArr);
            }
            i3 += readInt;
        }
        return null;
    }

    private static byte[] parseProjFromParent(ParsableByteArray parsableByteArray, int i, int i2) {
        int i3 = i + 8;
        while (i3 - i < i2) {
            parsableByteArray.setPosition(i3);
            int readInt = parsableByteArray.readInt();
            if (parsableByteArray.readInt() == Atom.TYPE_proj) {
                return Arrays.copyOfRange(parsableByteArray.data, i3, readInt + i3);
            }
            i3 += readInt;
        }
        return null;
    }

    private static int parseExpandableClassSize(ParsableByteArray parsableByteArray) {
        int readUnsignedByte = parsableByteArray.readUnsignedByte();
        int i = readUnsignedByte & 127;
        while ((readUnsignedByte & 128) == 128) {
            readUnsignedByte = parsableByteArray.readUnsignedByte();
            i = (i << 7) | (readUnsignedByte & 127);
        }
        return i;
    }

    private AtomParsers() {
    }
}
