package com.google.android.exoplayer2.extractor.mp3;

import com.google.android.exoplayer2.C0361C;
import com.google.android.exoplayer2.extractor.MpegAudioHeader;
import com.google.android.exoplayer2.util.ParsableByteArray;
import com.google.android.exoplayer2.util.Util;

final class XingSeeker implements Seeker {
    private final long durationUs;
    private final long firstFramePosition;
    private final int headerSize;
    private final long inputLength;
    private final long sizeBytes;
    private final long[] tableOfContents;

    public static XingSeeker create(MpegAudioHeader mpegAudioHeader, ParsableByteArray parsableByteArray, long j, long j2) {
        MpegAudioHeader mpegAudioHeader2 = mpegAudioHeader;
        int i = mpegAudioHeader2.samplesPerFrame;
        int i2 = mpegAudioHeader2.sampleRate;
        long j3 = j + ((long) mpegAudioHeader2.frameSize);
        int readInt = parsableByteArray.readInt();
        if ((readInt & 1) == 1) {
            int readUnsignedIntToInt = parsableByteArray.readUnsignedIntToInt();
            if (readUnsignedIntToInt != 0) {
                long scaleLargeTimestamp = Util.scaleLargeTimestamp((long) readUnsignedIntToInt, ((long) i) * C0361C.MICROS_PER_SECOND, (long) i2);
                if ((readInt & 6) != 6) {
                    return new XingSeeker(j3, scaleLargeTimestamp, j2);
                }
                long readUnsignedIntToInt2 = (long) parsableByteArray.readUnsignedIntToInt();
                parsableByteArray.skipBytes(1);
                long[] jArr = new long[99];
                for (readInt = 0; readInt < 99; readInt++) {
                    jArr[readInt] = (long) parsableByteArray.readUnsignedByte();
                }
                return new XingSeeker(j3, scaleLargeTimestamp, j2, jArr, readUnsignedIntToInt2, mpegAudioHeader2.frameSize);
            }
        }
        return null;
    }

    private XingSeeker(long j, long j2, long j3) {
        this(j, j2, j3, null, 0, 0);
    }

    private XingSeeker(long j, long j2, long j3, long[] jArr, long j4, int i) {
        this.firstFramePosition = j;
        this.durationUs = j2;
        this.inputLength = j3;
        this.tableOfContents = jArr;
        this.sizeBytes = j4;
        this.headerSize = i;
    }

    public boolean isSeekable() {
        return this.tableOfContents != null;
    }

    public long getPosition(long j) {
        if (!isSeekable()) {
            return this.firstFramePosition;
        }
        j = (((float) j) * 1120403456) / ((float) this.durationUs);
        float f = 256.0f;
        float f2 = 0.0f;
        if (j <= 0) {
            f = 0.0f;
        } else if (j < 1120403456) {
            int i = (int) j;
            if (i != 0) {
                f2 = (float) this.tableOfContents[i - 1];
            }
            if (i < 99) {
                f = (float) this.tableOfContents[i];
            }
            f = ((f - f2) * (j - ((float) i))) + f2;
        }
        double d = (double) f;
        Double.isNaN(d);
        d *= 4571153621781053440L;
        j = (double) this.sizeBytes;
        Double.isNaN(j);
        j = Math.round(d * j);
        long j2 = this.firstFramePosition;
        j += j2;
        long j3 = this.inputLength;
        return Math.min(j, j3 != -1 ? j3 - 1 : ((j2 - ((long) this.headerSize)) + this.sizeBytes) - 1);
    }

    public long getTimeUs(long j) {
        long j2 = 0;
        if (isSeekable()) {
            long j3 = this.firstFramePosition;
            if (j >= j3) {
                long j4;
                long j5;
                j = (double) (j - j3);
                Double.isNaN(j);
                j *= 4643211215818981376L;
                double d = (double) this.sizeBytes;
                Double.isNaN(d);
                j /= d;
                int binarySearchFloor = Util.binarySearchFloor(this.tableOfContents, (long) j, true, false) + 1;
                j3 = getTimeUsForTocPosition(binarySearchFloor);
                if (binarySearchFloor == 0) {
                    j4 = 0;
                } else {
                    j4 = this.tableOfContents[binarySearchFloor - 1];
                }
                if (binarySearchFloor == 99) {
                    j5 = 256;
                } else {
                    j5 = this.tableOfContents[binarySearchFloor];
                }
                long timeUsForTocPosition = getTimeUsForTocPosition(binarySearchFloor + 1);
                if (j5 != j4) {
                    double d2 = (double) (timeUsForTocPosition - j3);
                    double d3 = (double) j4;
                    Double.isNaN(d3);
                    j -= d3;
                    Double.isNaN(d2);
                    d2 *= j;
                    j = (double) (j5 - j4);
                    Double.isNaN(j);
                    j2 = (long) (d2 / j);
                }
                return j3 + j2;
            }
        }
        return 0;
    }

    public long getDurationUs() {
        return this.durationUs;
    }

    private long getTimeUsForTocPosition(int i) {
        return (this.durationUs * ((long) i)) / 100;
    }
}
