package com.google.android.exoplayer2.extractor.mp4;

import android.util.Log;
import android.util.Pair;
import com.google.android.exoplayer2.util.ParsableByteArray;
import java.nio.ByteBuffer;
import java.util.UUID;

public final class PsshAtomUtil {
    private static final String TAG = "PsshAtomUtil";

    private PsshAtomUtil() {
    }

    public static byte[] buildPsshAtom(UUID uuid, byte[] bArr) {
        int length = bArr.length + 32;
        ByteBuffer allocate = ByteBuffer.allocate(length);
        allocate.putInt(length);
        allocate.putInt(Atom.TYPE_pssh);
        allocate.putInt(0);
        allocate.putLong(uuid.getMostSignificantBits());
        allocate.putLong(uuid.getLeastSignificantBits());
        allocate.putInt(bArr.length);
        allocate.put(bArr);
        return allocate.array();
    }

    public static UUID parseUuid(byte[] bArr) {
        bArr = parsePsshAtom(bArr);
        if (bArr == null) {
            return null;
        }
        return (UUID) bArr.first;
    }

    public static byte[] parseSchemeSpecificData(byte[] bArr, UUID uuid) {
        bArr = parsePsshAtom(bArr);
        if (bArr == null) {
            return null;
        }
        if (uuid == null || uuid.equals(bArr.first)) {
            return bArr.second;
        }
        String str = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("UUID mismatch. Expected: ");
        stringBuilder.append(uuid);
        stringBuilder.append(", got: ");
        stringBuilder.append(bArr.first);
        stringBuilder.append(".");
        Log.w(str, stringBuilder.toString());
        return null;
    }

    private static Pair<UUID, byte[]> parsePsshAtom(byte[] bArr) {
        ParsableByteArray parsableByteArray = new ParsableByteArray(bArr);
        if (parsableByteArray.limit() < 32) {
            return null;
        }
        parsableByteArray.setPosition(0);
        if (parsableByteArray.readInt() != parsableByteArray.bytesLeft() + 4 || parsableByteArray.readInt() != Atom.TYPE_pssh) {
            return null;
        }
        int parseFullAtomVersion = Atom.parseFullAtomVersion(parsableByteArray.readInt());
        if (parseFullAtomVersion > 1) {
            bArr = TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unsupported pssh version: ");
            stringBuilder.append(parseFullAtomVersion);
            Log.w(bArr, stringBuilder.toString());
            return null;
        }
        UUID uuid = new UUID(parsableByteArray.readLong(), parsableByteArray.readLong());
        if (parseFullAtomVersion == 1) {
            parsableByteArray.skipBytes(parsableByteArray.readUnsignedIntToInt() * 16);
        }
        parseFullAtomVersion = parsableByteArray.readUnsignedIntToInt();
        if (parseFullAtomVersion != parsableByteArray.bytesLeft()) {
            return null;
        }
        Object obj = new byte[parseFullAtomVersion];
        parsableByteArray.readBytes(obj, 0, parseFullAtomVersion);
        return Pair.create(uuid, obj);
    }
}
