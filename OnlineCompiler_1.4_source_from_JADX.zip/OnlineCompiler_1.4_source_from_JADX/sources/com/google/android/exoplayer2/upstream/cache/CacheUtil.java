package com.google.android.exoplayer2.upstream.cache;

import android.net.Uri;
import com.google.android.exoplayer2.upstream.DataSpec;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.PriorityTaskManager;
import java.io.IOException;

public final class CacheUtil {

    public static class CachingCounters {
        public long alreadyCachedBytes;
        public long downloadedBytes;
    }

    public static String generateKey(Uri uri) {
        return uri.toString();
    }

    public static String getKey(DataSpec dataSpec) {
        return dataSpec.key != null ? dataSpec.key : generateKey(dataSpec.uri);
    }

    public static CachingCounters getCached(DataSpec dataSpec, Cache cache, CachingCounters cachingCounters) {
        try {
            return internalCache(dataSpec, cache, null, null, null, 0, cachingCounters);
        } catch (DataSpec dataSpec2) {
            throw new IllegalStateException(dataSpec2);
        }
    }

    public static CachingCounters cache(DataSpec dataSpec, Cache cache, CacheDataSource cacheDataSource, byte[] bArr, PriorityTaskManager priorityTaskManager, int i, CachingCounters cachingCounters) throws IOException, InterruptedException {
        Assertions.checkNotNull(cacheDataSource);
        Assertions.checkNotNull(bArr);
        return internalCache(dataSpec, cache, cacheDataSource, bArr, priorityTaskManager, i, cachingCounters);
    }

    private static CachingCounters internalCache(DataSpec dataSpec, Cache cache, CacheDataSource cacheDataSource, byte[] bArr, PriorityTaskManager priorityTaskManager, int i, CachingCounters cachingCounters) throws IOException, InterruptedException {
        DataSpec dataSpec2 = dataSpec;
        CacheDataSource cacheDataSource2 = cacheDataSource;
        byte[] bArr2 = bArr;
        CachingCounters cachingCounters2 = cachingCounters;
        long j = dataSpec2.position;
        long j2 = dataSpec2.length;
        String key = getKey(dataSpec);
        if (j2 == -1) {
            j2 = cache.getContentLength(key);
            if (j2 == -1) {
                j2 = Long.MAX_VALUE;
            }
        } else {
            Cache cache2 = cache;
        }
        long j3 = 0;
        if (cachingCounters2 == null) {
            cachingCounters2 = new CachingCounters();
        } else {
            cachingCounters2.alreadyCachedBytes = 0;
            cachingCounters2.downloadedBytes = 0;
        }
        while (j2 > j3) {
            long j4;
            long j5;
            long j6 = j3;
            long cachedBytes = cache.getCachedBytes(key, j, j2);
            PriorityTaskManager priorityTaskManager2;
            int i2;
            if (cachedBytes > j6) {
                cachingCounters2.alreadyCachedBytes += cachedBytes;
                j4 = cachedBytes;
                j3 = -1;
                priorityTaskManager2 = priorityTaskManager;
                i2 = i;
            } else {
                j5 = -cachedBytes;
                if (cacheDataSource2 == null || bArr2 == null) {
                    priorityTaskManager2 = priorityTaskManager;
                    i2 = i;
                    j4 = j5;
                    if (j4 == Long.MAX_VALUE) {
                        cachingCounters2.downloadedBytes = -1;
                        break;
                    }
                    j3 = -1;
                    cachingCounters2.downloadedBytes += j4;
                } else {
                    Uri uri = dataSpec2.uri;
                    dataSpec2 = r8;
                    j4 = j5;
                    DataSpec dataSpec3 = new DataSpec(uri, j, j5 == Long.MAX_VALUE ? -1 : j5, key);
                    j3 = readAndDiscard(dataSpec2, cacheDataSource2, bArr2, priorityTaskManager, i);
                    cachingCounters2.downloadedBytes += j3;
                    if (j3 < j4) {
                        break;
                    }
                    j3 = -1;
                }
            }
            j += j4;
            if (j2 != Long.MAX_VALUE) {
                j2 -= j4;
            }
            cache2 = cache;
            j5 = j3;
            j3 = j6;
            dataSpec2 = dataSpec;
        }
        return cachingCounters2;
    }

    private static long readAndDiscard(com.google.android.exoplayer2.upstream.DataSpec r4, com.google.android.exoplayer2.upstream.DataSource r5, byte[] r6, com.google.android.exoplayer2.util.PriorityTaskManager r7, int r8) throws java.io.IOException, java.lang.InterruptedException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
    L_0x0000:
        if (r7 == 0) goto L_0x0005;
    L_0x0002:
        r7.proceed(r8);
    L_0x0005:
        r5.open(r4);	 Catch:{ PriorityTooLowException -> 0x002b, all -> 0x0026 }
        r0 = 0;	 Catch:{ PriorityTooLowException -> 0x002b, all -> 0x0026 }
    L_0x000a:
        r2 = java.lang.Thread.interrupted();	 Catch:{ PriorityTooLowException -> 0x002b, all -> 0x0026 }
        if (r2 != 0) goto L_0x0020;	 Catch:{ PriorityTooLowException -> 0x002b, all -> 0x0026 }
    L_0x0010:
        r2 = 0;	 Catch:{ PriorityTooLowException -> 0x002b, all -> 0x0026 }
        r3 = r6.length;	 Catch:{ PriorityTooLowException -> 0x002b, all -> 0x0026 }
        r2 = r5.read(r6, r2, r3);	 Catch:{ PriorityTooLowException -> 0x002b, all -> 0x0026 }
        r3 = -1;
        if (r2 != r3) goto L_0x001d;
    L_0x0019:
        com.google.android.exoplayer2.util.Util.closeQuietly(r5);
        return r0;
    L_0x001d:
        r2 = (long) r2;
        r0 = r0 + r2;
        goto L_0x000a;
    L_0x0020:
        r0 = new java.lang.InterruptedException;	 Catch:{ PriorityTooLowException -> 0x002b, all -> 0x0026 }
        r0.<init>();	 Catch:{ PriorityTooLowException -> 0x002b, all -> 0x0026 }
        throw r0;	 Catch:{ PriorityTooLowException -> 0x002b, all -> 0x0026 }
    L_0x0026:
        r4 = move-exception;
        com.google.android.exoplayer2.util.Util.closeQuietly(r5);
        throw r4;
    L_0x002b:
        com.google.android.exoplayer2.util.Util.closeQuietly(r5);
        goto L_0x0000;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.cache.CacheUtil.readAndDiscard(com.google.android.exoplayer2.upstream.DataSpec, com.google.android.exoplayer2.upstream.DataSource, byte[], com.google.android.exoplayer2.util.PriorityTaskManager, int):long");
    }

    public static void remove(com.google.android.exoplayer2.upstream.cache.Cache r1, java.lang.String r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r2 = r1.getCachedSpans(r2);
        if (r2 != 0) goto L_0x0007;
    L_0x0006:
        return;
    L_0x0007:
        r2 = r2.iterator();
    L_0x000b:
        r0 = r2.hasNext();
        if (r0 == 0) goto L_0x001b;
    L_0x0011:
        r0 = r2.next();
        r0 = (com.google.android.exoplayer2.upstream.cache.CacheSpan) r0;
        r1.removeSpan(r0);	 Catch:{ CacheException -> 0x000b }
        goto L_0x000b;
    L_0x001b:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.cache.CacheUtil.remove(com.google.android.exoplayer2.upstream.cache.Cache, java.lang.String):void");
    }

    private CacheUtil() {
    }
}
