package com.google.android.exoplayer2.upstream.cache;

import android.util.SparseArray;
import com.google.android.exoplayer2.upstream.cache.Cache.CacheException;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.AtomicFile;
import com.google.android.exoplayer2.util.ReusableBufferedOutputStream;
import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

final class CachedContentIndex {
    public static final String FILE_NAME = "cached_content_index.exi";
    private static final int FLAG_ENCRYPTED_INDEX = 1;
    private static final String TAG = "CachedContentIndex";
    private static final int VERSION = 1;
    private final AtomicFile atomicFile;
    private ReusableBufferedOutputStream bufferedOutputStream;
    private boolean changed;
    private final Cipher cipher;
    private final SparseArray<String> idToKey;
    private final HashMap<String, CachedContent> keyToContent;
    private final SecretKeySpec secretKeySpec;

    private void writeFile() throws com.google.android.exoplayer2.upstream.cache.Cache.CacheException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:42:0x00b1 in {4, 5, 11, 12, 19, 22, 26, 29, 31, 33, 35, 38, 39, 41} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r8 = this;
        r0 = 0;
        r1 = r8.atomicFile;	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
        r1 = r1.startWrite();	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
        r2 = r8.bufferedOutputStream;	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
        if (r2 != 0) goto L_0x0013;	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
    L_0x000b:
        r2 = new com.google.android.exoplayer2.util.ReusableBufferedOutputStream;	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
        r2.<init>(r1);	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
        r8.bufferedOutputStream = r2;	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
        goto L_0x0018;	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
    L_0x0013:
        r2 = r8.bufferedOutputStream;	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
        r2.reset(r1);	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
    L_0x0018:
        r1 = new java.io.DataOutputStream;	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
        r2 = r8.bufferedOutputStream;	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
        r1.<init>(r2);	 Catch:{ IOException -> 0x00a2, all -> 0x009d }
        r2 = 1;
        r1.writeInt(r2);	 Catch:{ IOException -> 0x009b }
        r3 = r8.cipher;	 Catch:{ IOException -> 0x009b }
        r4 = 0;	 Catch:{ IOException -> 0x009b }
        if (r3 == 0) goto L_0x002a;	 Catch:{ IOException -> 0x009b }
    L_0x0028:
        r3 = 1;	 Catch:{ IOException -> 0x009b }
        goto L_0x002b;	 Catch:{ IOException -> 0x009b }
    L_0x002a:
        r3 = 0;	 Catch:{ IOException -> 0x009b }
    L_0x002b:
        r1.writeInt(r3);	 Catch:{ IOException -> 0x009b }
        r3 = r8.cipher;	 Catch:{ IOException -> 0x009b }
        if (r3 == 0) goto L_0x0067;	 Catch:{ IOException -> 0x009b }
    L_0x0032:
        r3 = 16;	 Catch:{ IOException -> 0x009b }
        r3 = new byte[r3];	 Catch:{ IOException -> 0x009b }
        r5 = new java.util.Random;	 Catch:{ IOException -> 0x009b }
        r5.<init>();	 Catch:{ IOException -> 0x009b }
        r5.nextBytes(r3);	 Catch:{ IOException -> 0x009b }
        r1.write(r3);	 Catch:{ IOException -> 0x009b }
        r5 = new javax.crypto.spec.IvParameterSpec;	 Catch:{ IOException -> 0x009b }
        r5.<init>(r3);	 Catch:{ IOException -> 0x009b }
        r3 = r8.cipher;	 Catch:{ InvalidKeyException -> 0x0060, InvalidKeyException -> 0x0060 }
        r6 = r8.secretKeySpec;	 Catch:{ InvalidKeyException -> 0x0060, InvalidKeyException -> 0x0060 }
        r3.init(r2, r6, r5);	 Catch:{ InvalidKeyException -> 0x0060, InvalidKeyException -> 0x0060 }
        r1.flush();	 Catch:{ IOException -> 0x009b }
        r2 = new java.io.DataOutputStream;	 Catch:{ IOException -> 0x009b }
        r3 = new javax.crypto.CipherOutputStream;	 Catch:{ IOException -> 0x009b }
        r5 = r8.bufferedOutputStream;	 Catch:{ IOException -> 0x009b }
        r6 = r8.cipher;	 Catch:{ IOException -> 0x009b }
        r3.<init>(r5, r6);	 Catch:{ IOException -> 0x009b }
        r2.<init>(r3);	 Catch:{ IOException -> 0x009b }
        r1 = r2;	 Catch:{ IOException -> 0x009b }
        goto L_0x0067;	 Catch:{ IOException -> 0x009b }
    L_0x0060:
        r0 = move-exception;	 Catch:{ IOException -> 0x009b }
        r2 = new java.lang.IllegalStateException;	 Catch:{ IOException -> 0x009b }
        r2.<init>(r0);	 Catch:{ IOException -> 0x009b }
        throw r2;	 Catch:{ IOException -> 0x009b }
    L_0x0067:
        r2 = r8.keyToContent;	 Catch:{ IOException -> 0x009b }
        r2 = r2.size();	 Catch:{ IOException -> 0x009b }
        r1.writeInt(r2);	 Catch:{ IOException -> 0x009b }
        r2 = r8.keyToContent;	 Catch:{ IOException -> 0x009b }
        r2 = r2.values();	 Catch:{ IOException -> 0x009b }
        r2 = r2.iterator();	 Catch:{ IOException -> 0x009b }
    L_0x007a:
        r3 = r2.hasNext();	 Catch:{ IOException -> 0x009b }
        if (r3 == 0) goto L_0x008f;	 Catch:{ IOException -> 0x009b }
    L_0x0080:
        r3 = r2.next();	 Catch:{ IOException -> 0x009b }
        r3 = (com.google.android.exoplayer2.upstream.cache.CachedContent) r3;	 Catch:{ IOException -> 0x009b }
        r3.writeToStream(r1);	 Catch:{ IOException -> 0x009b }
        r3 = r3.headerHashCode();	 Catch:{ IOException -> 0x009b }
        r4 = r4 + r3;	 Catch:{ IOException -> 0x009b }
        goto L_0x007a;	 Catch:{ IOException -> 0x009b }
    L_0x008f:
        r1.writeInt(r4);	 Catch:{ IOException -> 0x009b }
        r2 = r8.atomicFile;	 Catch:{ IOException -> 0x009b }
        r2.endWrite(r1);	 Catch:{ IOException -> 0x009b }
        com.google.android.exoplayer2.util.Util.closeQuietly(r0);
        return;
    L_0x009b:
        r0 = move-exception;
        goto L_0x00a6;
    L_0x009d:
        r1 = move-exception;
        r7 = r1;
        r1 = r0;
        r0 = r7;
        goto L_0x00ad;
    L_0x00a2:
        r1 = move-exception;
        r7 = r1;
        r1 = r0;
        r0 = r7;
    L_0x00a6:
        r2 = new com.google.android.exoplayer2.upstream.cache.Cache$CacheException;	 Catch:{ all -> 0x00ac }
        r2.<init>(r0);	 Catch:{ all -> 0x00ac }
        throw r2;	 Catch:{ all -> 0x00ac }
    L_0x00ac:
        r0 = move-exception;
    L_0x00ad:
        com.google.android.exoplayer2.util.Util.closeQuietly(r1);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.cache.CachedContentIndex.writeFile():void");
    }

    public CachedContentIndex(File file) {
        this(file, null);
    }

    public CachedContentIndex(File file, byte[] bArr) {
        if (bArr != null) {
            Assertions.checkArgument(bArr.length == 16);
            try {
                this.cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
                this.secretKeySpec = new SecretKeySpec(bArr, "AES");
            } catch (File file2) {
                throw new IllegalStateException(file2);
            }
        }
        this.cipher = null;
        this.secretKeySpec = null;
        this.keyToContent = new HashMap();
        this.idToKey = new SparseArray();
        this.atomicFile = new AtomicFile(new File(file2, FILE_NAME));
    }

    public void load() {
        Assertions.checkState(this.changed ^ 1);
        if (!readFile()) {
            this.atomicFile.delete();
            this.keyToContent.clear();
            this.idToKey.clear();
        }
    }

    public void store() throws CacheException {
        if (this.changed) {
            writeFile();
            this.changed = false;
        }
    }

    public CachedContent add(String str) {
        CachedContent cachedContent = (CachedContent) this.keyToContent.get(str);
        return cachedContent == null ? addNew(str, -1) : cachedContent;
    }

    public CachedContent get(String str) {
        return (CachedContent) this.keyToContent.get(str);
    }

    public Collection<CachedContent> getAll() {
        return this.keyToContent.values();
    }

    public int assignIdForKey(String str) {
        return add(str).id;
    }

    public String getKeyForId(int i) {
        return (String) this.idToKey.get(i);
    }

    public void removeEmpty(String str) {
        CachedContent cachedContent = (CachedContent) this.keyToContent.remove(str);
        if (cachedContent != null) {
            Assertions.checkState(cachedContent.isEmpty());
            this.idToKey.remove(cachedContent.id);
            this.changed = true;
        }
    }

    public void removeEmpty() {
        LinkedList linkedList = new LinkedList();
        for (CachedContent cachedContent : this.keyToContent.values()) {
            if (cachedContent.isEmpty()) {
                linkedList.add(cachedContent.key);
            }
        }
        Iterator it = linkedList.iterator();
        while (it.hasNext()) {
            removeEmpty((String) it.next());
        }
    }

    public Set<String> getKeys() {
        return this.keyToContent.keySet();
    }

    public void setContentLength(String str, long j) {
        CachedContent cachedContent = get(str);
        if (cachedContent == null) {
            addNew(str, j);
        } else if (cachedContent.getLength() != j) {
            cachedContent.setLength(j);
            this.changed = true;
        }
    }

    public long getContentLength(String str) {
        str = get(str);
        if (str == null) {
            return -1;
        }
        return str.getLength();
    }

    private boolean readFile() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r8 = this;
        r0 = 0;
        r1 = 0;
        r2 = new java.io.BufferedInputStream;	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r3 = r8.atomicFile;	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r3 = r3.openRead();	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r2.<init>(r3);	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r3 = new java.io.DataInputStream;	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r3.<init>(r2);	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r1 = r3.readInt();	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r4 = 1;
        if (r1 == r4) goto L_0x001d;
    L_0x0019:
        com.google.android.exoplayer2.util.Util.closeQuietly(r3);
        return r0;
    L_0x001d:
        r1 = r3.readInt();	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r1 = r1 & r4;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        if (r1 == 0) goto L_0x0054;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
    L_0x0024:
        r1 = r8.cipher;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        if (r1 != 0) goto L_0x002c;
    L_0x0028:
        com.google.android.exoplayer2.util.Util.closeQuietly(r3);
        return r0;
    L_0x002c:
        r1 = 16;
        r1 = new byte[r1];	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r3.readFully(r1);	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r5 = new javax.crypto.spec.IvParameterSpec;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r5.<init>(r1);	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r1 = r8.cipher;	 Catch:{ InvalidKeyException -> 0x004d, InvalidKeyException -> 0x004d }
        r6 = 2;	 Catch:{ InvalidKeyException -> 0x004d, InvalidKeyException -> 0x004d }
        r7 = r8.secretKeySpec;	 Catch:{ InvalidKeyException -> 0x004d, InvalidKeyException -> 0x004d }
        r1.init(r6, r7, r5);	 Catch:{ InvalidKeyException -> 0x004d, InvalidKeyException -> 0x004d }
        r1 = new java.io.DataInputStream;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r5 = new javax.crypto.CipherInputStream;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r6 = r8.cipher;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r5.<init>(r2, r6);	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r1.<init>(r5);	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        goto L_0x005b;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
    L_0x004d:
        r1 = move-exception;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r2 = new java.lang.IllegalStateException;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        r2.<init>(r1);	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        throw r2;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
    L_0x0054:
        r1 = r8.cipher;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
        if (r1 == 0) goto L_0x005a;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
    L_0x0058:
        r8.changed = r4;	 Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x0081 }
    L_0x005a:
        r1 = r3;
    L_0x005b:
        r2 = r1.readInt();	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r3 = 0;	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r5 = 0;	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
    L_0x0061:
        if (r3 >= r2) goto L_0x0073;	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
    L_0x0063:
        r6 = new com.google.android.exoplayer2.upstream.cache.CachedContent;	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r6.<init>(r1);	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r8.add(r6);	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r6 = r6.headerHashCode();	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r5 = r5 + r6;	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        r3 = r3 + 1;	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        goto L_0x0061;	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
    L_0x0073:
        r2 = r1.readInt();	 Catch:{ FileNotFoundException -> 0x009f, IOException -> 0x0088, all -> 0x0085 }
        if (r2 == r5) goto L_0x007d;
    L_0x0079:
        com.google.android.exoplayer2.util.Util.closeQuietly(r1);
        return r0;
    L_0x007d:
        com.google.android.exoplayer2.util.Util.closeQuietly(r1);
        return r4;
    L_0x0081:
        r1 = move-exception;
        goto L_0x008b;
        goto L_0x00a0;
    L_0x0085:
        r0 = move-exception;
        r3 = r1;
        goto L_0x0099;
    L_0x0088:
        r2 = move-exception;
        r3 = r1;
        r1 = r2;
    L_0x008b:
        r2 = "CachedContentIndex";	 Catch:{ all -> 0x0098 }
        r4 = "Error reading cache content index file.";	 Catch:{ all -> 0x0098 }
        android.util.Log.e(r2, r4, r1);	 Catch:{ all -> 0x0098 }
        if (r3 == 0) goto L_0x0097;
    L_0x0094:
        com.google.android.exoplayer2.util.Util.closeQuietly(r3);
    L_0x0097:
        return r0;
    L_0x0098:
        r0 = move-exception;
    L_0x0099:
        if (r3 == 0) goto L_0x009e;
    L_0x009b:
        com.google.android.exoplayer2.util.Util.closeQuietly(r3);
    L_0x009e:
        throw r0;
    L_0x009f:
        r3 = r1;
    L_0x00a0:
        if (r3 == 0) goto L_0x00a5;
    L_0x00a2:
        com.google.android.exoplayer2.util.Util.closeQuietly(r3);
    L_0x00a5:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.cache.CachedContentIndex.readFile():boolean");
    }

    private void add(CachedContent cachedContent) {
        this.keyToContent.put(cachedContent.key, cachedContent);
        this.idToKey.put(cachedContent.id, cachedContent.key);
    }

    void addNew(CachedContent cachedContent) {
        add(cachedContent);
        this.changed = true;
    }

    private CachedContent addNew(String str, long j) {
        CachedContent cachedContent = new CachedContent(getNewId(this.idToKey), str, j);
        addNew(cachedContent);
        return cachedContent;
    }

    public static int getNewId(SparseArray<String> sparseArray) {
        int i;
        int size = sparseArray.size();
        if (size == 0) {
            i = 0;
        } else {
            i = sparseArray.keyAt(size - 1) + 1;
        }
        if (i < 0) {
            i = 0;
            while (i < size) {
                if (i != sparseArray.keyAt(i)) {
                    break;
                }
                i++;
            }
        }
        return i;
    }
}
