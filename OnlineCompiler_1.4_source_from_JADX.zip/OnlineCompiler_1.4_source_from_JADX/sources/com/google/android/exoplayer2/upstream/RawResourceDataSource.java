package com.google.android.exoplayer2.upstream;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.net.Uri;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public final class RawResourceDataSource implements DataSource {
    private static final String RAW_RESOURCE_SCHEME = "rawresource";
    private AssetFileDescriptor assetFileDescriptor;
    private long bytesRemaining;
    private InputStream inputStream;
    private final TransferListener<? super RawResourceDataSource> listener;
    private boolean opened;
    private final Resources resources;
    private Uri uri;

    public static class RawResourceDataSourceException extends IOException {
        public RawResourceDataSourceException(String str) {
            super(str);
        }

        public RawResourceDataSourceException(IOException iOException) {
            super(iOException);
        }
    }

    public static Uri buildRawResourceUri(int i) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("rawresource:///");
        stringBuilder.append(i);
        return Uri.parse(stringBuilder.toString());
    }

    public RawResourceDataSource(Context context) {
        this(context, null);
    }

    public RawResourceDataSource(Context context, TransferListener<? super RawResourceDataSource> transferListener) {
        this.resources = context.getResources();
        this.listener = transferListener;
    }

    public long open(com.google.android.exoplayer2.upstream.DataSpec r6) throws com.google.android.exoplayer2.upstream.RawResourceDataSource.RawResourceDataSourceException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = r6.uri;	 Catch:{ IOException -> 0x008b }
        r5.uri = r0;	 Catch:{ IOException -> 0x008b }
        r0 = "rawresource";	 Catch:{ IOException -> 0x008b }
        r1 = r5.uri;	 Catch:{ IOException -> 0x008b }
        r1 = r1.getScheme();	 Catch:{ IOException -> 0x008b }
        r0 = android.text.TextUtils.equals(r0, r1);	 Catch:{ IOException -> 0x008b }
        if (r0 == 0) goto L_0x0083;
    L_0x0012:
        r0 = r5.uri;	 Catch:{ NumberFormatException -> 0x007b }
        r0 = r0.getLastPathSegment();	 Catch:{ NumberFormatException -> 0x007b }
        r0 = java.lang.Integer.parseInt(r0);	 Catch:{ NumberFormatException -> 0x007b }
        r1 = r5.resources;	 Catch:{ IOException -> 0x008b }
        r0 = r1.openRawResourceFd(r0);	 Catch:{ IOException -> 0x008b }
        r5.assetFileDescriptor = r0;	 Catch:{ IOException -> 0x008b }
        r0 = new java.io.FileInputStream;	 Catch:{ IOException -> 0x008b }
        r1 = r5.assetFileDescriptor;	 Catch:{ IOException -> 0x008b }
        r1 = r1.getFileDescriptor();	 Catch:{ IOException -> 0x008b }
        r0.<init>(r1);	 Catch:{ IOException -> 0x008b }
        r5.inputStream = r0;	 Catch:{ IOException -> 0x008b }
        r0 = r5.inputStream;	 Catch:{ IOException -> 0x008b }
        r1 = r5.assetFileDescriptor;	 Catch:{ IOException -> 0x008b }
        r1 = r1.getStartOffset();	 Catch:{ IOException -> 0x008b }
        r0.skip(r1);	 Catch:{ IOException -> 0x008b }
        r0 = r5.inputStream;	 Catch:{ IOException -> 0x008b }
        r1 = r6.position;	 Catch:{ IOException -> 0x008b }
        r0 = r0.skip(r1);	 Catch:{ IOException -> 0x008b }
        r2 = r6.position;	 Catch:{ IOException -> 0x008b }
        r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));	 Catch:{ IOException -> 0x008b }
        if (r4 < 0) goto L_0x0075;	 Catch:{ IOException -> 0x008b }
    L_0x004a:
        r0 = r6.length;	 Catch:{ IOException -> 0x008b }
        r2 = -1;	 Catch:{ IOException -> 0x008b }
        r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));	 Catch:{ IOException -> 0x008b }
        if (r4 == 0) goto L_0x0057;	 Catch:{ IOException -> 0x008b }
    L_0x0052:
        r0 = r6.length;	 Catch:{ IOException -> 0x008b }
        r5.bytesRemaining = r0;	 Catch:{ IOException -> 0x008b }
        goto L_0x0068;	 Catch:{ IOException -> 0x008b }
    L_0x0057:
        r0 = r5.assetFileDescriptor;	 Catch:{ IOException -> 0x008b }
        r0 = r0.getLength();	 Catch:{ IOException -> 0x008b }
        r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));	 Catch:{ IOException -> 0x008b }
        if (r4 != 0) goto L_0x0062;	 Catch:{ IOException -> 0x008b }
    L_0x0061:
        goto L_0x0066;	 Catch:{ IOException -> 0x008b }
    L_0x0062:
        r2 = r6.position;	 Catch:{ IOException -> 0x008b }
        r2 = r0 - r2;	 Catch:{ IOException -> 0x008b }
    L_0x0066:
        r5.bytesRemaining = r2;	 Catch:{ IOException -> 0x008b }
    L_0x0068:
        r0 = 1;
        r5.opened = r0;
        r0 = r5.listener;
        if (r0 == 0) goto L_0x0072;
    L_0x006f:
        r0.onTransferStart(r5, r6);
    L_0x0072:
        r0 = r5.bytesRemaining;
        return r0;
    L_0x0075:
        r6 = new java.io.EOFException;	 Catch:{ IOException -> 0x008b }
        r6.<init>();	 Catch:{ IOException -> 0x008b }
        throw r6;	 Catch:{ IOException -> 0x008b }
    L_0x007b:
        r6 = new com.google.android.exoplayer2.upstream.RawResourceDataSource$RawResourceDataSourceException;	 Catch:{ IOException -> 0x008b }
        r0 = "Resource identifier must be an integer.";	 Catch:{ IOException -> 0x008b }
        r6.<init>(r0);	 Catch:{ IOException -> 0x008b }
        throw r6;	 Catch:{ IOException -> 0x008b }
    L_0x0083:
        r6 = new com.google.android.exoplayer2.upstream.RawResourceDataSource$RawResourceDataSourceException;	 Catch:{ IOException -> 0x008b }
        r0 = "URI must use scheme rawresource";	 Catch:{ IOException -> 0x008b }
        r6.<init>(r0);	 Catch:{ IOException -> 0x008b }
        throw r6;	 Catch:{ IOException -> 0x008b }
    L_0x008b:
        r6 = move-exception;
        r0 = new com.google.android.exoplayer2.upstream.RawResourceDataSource$RawResourceDataSourceException;
        r0.<init>(r6);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.RawResourceDataSource.open(com.google.android.exoplayer2.upstream.DataSpec):long");
    }

    public int read(byte[] bArr, int i, int i2) throws RawResourceDataSourceException {
        if (i2 == 0) {
            return null;
        }
        long j = this.bytesRemaining;
        if (j == 0) {
            return -1;
        }
        if (j != -1) {
            try {
                i2 = (int) Math.min(j, (long) i2);
            } catch (IOException e) {
                throw new RawResourceDataSourceException(e);
            }
        }
        bArr = this.inputStream.read(bArr, i, i2);
        if (bArr != -1) {
            i = this.bytesRemaining;
            if (i != -1) {
                this.bytesRemaining = i - ((long) bArr);
            }
            i = this.listener;
            if (i != 0) {
                i.onBytesTransferred(this, bArr);
            }
            return bArr;
        } else if (this.bytesRemaining == -1) {
            return -1;
        } else {
            throw new RawResourceDataSourceException(new EOFException());
        }
    }

    public Uri getUri() {
        return this.uri;
    }

    public void close() throws RawResourceDataSourceException {
        this.uri = null;
        TransferListener transferListener;
        try {
            if (this.inputStream != null) {
                this.inputStream.close();
            }
            this.inputStream = null;
            try {
                if (this.assetFileDescriptor != null) {
                    this.assetFileDescriptor.close();
                }
                this.assetFileDescriptor = null;
                if (this.opened) {
                    this.opened = false;
                    transferListener = this.listener;
                    if (transferListener != null) {
                        transferListener.onTransferEnd(this);
                    }
                }
            } catch (IOException e) {
                throw new RawResourceDataSourceException(e);
            } catch (Throwable th) {
                this.assetFileDescriptor = null;
                if (this.opened) {
                    this.opened = false;
                    transferListener = this.listener;
                    if (transferListener != null) {
                        transferListener.onTransferEnd(this);
                    }
                }
            }
        } catch (IOException e2) {
            throw new RawResourceDataSourceException(e2);
        } catch (Throwable th2) {
            this.inputStream = null;
            try {
                if (this.assetFileDescriptor != null) {
                    this.assetFileDescriptor.close();
                }
                this.assetFileDescriptor = null;
                if (this.opened) {
                    this.opened = false;
                    transferListener = this.listener;
                    if (transferListener != null) {
                        transferListener.onTransferEnd(this);
                    }
                }
            } catch (IOException e22) {
                throw new RawResourceDataSourceException(e22);
            } catch (Throwable th3) {
                this.assetFileDescriptor = null;
                if (this.opened) {
                    this.opened = false;
                    transferListener = this.listener;
                    if (transferListener != null) {
                        transferListener.onTransferEnd(this);
                    }
                }
            }
        }
    }
}
