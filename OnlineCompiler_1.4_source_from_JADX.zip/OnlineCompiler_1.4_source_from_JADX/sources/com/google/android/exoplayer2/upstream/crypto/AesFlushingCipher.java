package com.google.android.exoplayer2.upstream.crypto;

import com.google.android.exoplayer2.util.Assertions;
import java.nio.ByteBuffer;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public final class AesFlushingCipher {
    private final int blockSize;
    private final Cipher cipher;
    private final byte[] flushedBlock;
    private int pendingXorBytes;
    private final byte[] zerosBlock;

    public AesFlushingCipher(int i, byte[] bArr, long j, long j2) {
        try {
            this.cipher = Cipher.getInstance("AES/CTR/NoPadding");
            this.blockSize = this.cipher.getBlockSize();
            this.zerosBlock = new byte[this.blockSize];
            this.flushedBlock = new byte[this.blockSize];
            long j3 = j2 / ((long) this.blockSize);
            j2 = (int) (j2 % ((long) this.blockSize));
            this.cipher.init(i, new SecretKeySpec(bArr, this.cipher.getAlgorithm().split("/")[0]), new IvParameterSpec(getInitializationVector(j, j3)));
            if (j2 != null) {
                updateInPlace(new byte[j2], 0, j2);
            }
        } catch (int i2) {
            throw new RuntimeException(i2);
        }
    }

    public void updateInPlace(byte[] bArr, int i, int i2) {
        update(bArr, i, i2, bArr, i);
    }

    public void update(byte[] bArr, int i, int i2, byte[] bArr2, int i3) {
        int i4 = i;
        do {
            i = this.pendingXorBytes;
            if (i > 0) {
                bArr2[i3] = (byte) (bArr[i4] ^ this.flushedBlock[this.blockSize - i]);
                i3++;
                i4++;
                this.pendingXorBytes = i - 1;
                i2--;
            } else {
                bArr = nonFlushingUpdate(bArr, i4, i2, bArr2, i3);
                if (i2 != bArr) {
                    i2 -= bArr;
                    int i5 = 0;
                    boolean z = true;
                    Assertions.checkState(i2 < this.blockSize ? 1 : 0);
                    i3 += bArr;
                    this.pendingXorBytes = this.blockSize - i2;
                    if (nonFlushingUpdate(this.zerosBlock, 0, this.pendingXorBytes, this.flushedBlock, 0) != this.blockSize) {
                        z = false;
                    }
                    Assertions.checkState(z);
                    while (i5 < i2) {
                        bArr = i3 + 1;
                        bArr2[i3] = this.flushedBlock[i5];
                        i5++;
                        i3 = bArr;
                    }
                    return;
                }
                return;
            }
        } while (i2 != 0);
    }

    private int nonFlushingUpdate(byte[] bArr, int i, int i2, byte[] bArr2, int i3) {
        try {
            return this.cipher.update(bArr, i, i2, bArr2, i3);
        } catch (byte[] bArr3) {
            throw new RuntimeException(bArr3);
        }
    }

    private byte[] getInitializationVector(long j, long j2) {
        return ByteBuffer.allocate(16).putLong(j).putLong(j2).array();
    }
}
