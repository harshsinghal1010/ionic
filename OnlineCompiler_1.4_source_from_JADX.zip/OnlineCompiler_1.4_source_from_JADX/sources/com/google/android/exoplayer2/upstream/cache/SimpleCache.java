package com.google.android.exoplayer2.upstream.cache;

import android.os.ConditionVariable;
import com.google.android.exoplayer2.upstream.cache.Cache.CacheException;
import com.google.android.exoplayer2.upstream.cache.Cache.Listener;
import com.google.android.exoplayer2.util.Assertions;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

public final class SimpleCache implements Cache {
    private final File cacheDir;
    private final CacheEvictor evictor;
    private final CachedContentIndex index;
    private CacheException initializationException;
    private final HashMap<String, ArrayList<Listener>> listeners;
    private final HashMap<String, CacheSpan> lockedSpans;
    private long totalSpace;

    public synchronized com.google.android.exoplayer2.upstream.cache.SimpleCacheSpan startReadWrite(java.lang.String r2, long r3) throws java.lang.InterruptedException, com.google.android.exoplayer2.upstream.cache.Cache.CacheException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:12:0x0010 in {5, 8, 11} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r1 = this;
        monitor-enter(r1);
    L_0x0001:
        r0 = r1.startReadWriteNonBlocking(r2, r3);	 Catch:{ all -> 0x000d }
        if (r0 == 0) goto L_0x0009;
    L_0x0007:
        monitor-exit(r1);
        return r0;
    L_0x0009:
        r1.wait();	 Catch:{ all -> 0x000d }
        goto L_0x0001;
    L_0x000d:
        r2 = move-exception;
        monitor-exit(r1);
        throw r2;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.cache.SimpleCache.startReadWrite(java.lang.String, long):com.google.android.exoplayer2.upstream.cache.SimpleCacheSpan");
    }

    public SimpleCache(File file, CacheEvictor cacheEvictor) {
        this(file, cacheEvictor, null);
    }

    public SimpleCache(File file, CacheEvictor cacheEvictor, byte[] bArr) {
        this.totalSpace = 0;
        this.cacheDir = file;
        this.evictor = cacheEvictor;
        this.lockedSpans = new HashMap();
        this.index = new CachedContentIndex(file, bArr);
        this.listeners = new HashMap();
        file = new ConditionVariable();
        new Thread("SimpleCache.initialize()") {
            public void run() {
                synchronized (SimpleCache.this) {
                    file.open();
                    try {
                        SimpleCache.this.initialize();
                    } catch (CacheException e) {
                        SimpleCache.this.initializationException = e;
                    }
                    SimpleCache.this.evictor.onCacheInitialized();
                }
            }
        }.start();
        file.block();
    }

    public synchronized NavigableSet<CacheSpan> addListener(String str, Listener listener) {
        ArrayList arrayList = (ArrayList) this.listeners.get(str);
        if (arrayList == null) {
            arrayList = new ArrayList();
            this.listeners.put(str, arrayList);
        }
        arrayList.add(listener);
        return getCachedSpans(str);
    }

    public synchronized void removeListener(String str, Listener listener) {
        ArrayList arrayList = (ArrayList) this.listeners.get(str);
        if (arrayList != null) {
            arrayList.remove(listener);
            if (arrayList.isEmpty() != null) {
                this.listeners.remove(str);
            }
        }
    }

    public synchronized NavigableSet<CacheSpan> getCachedSpans(String str) {
        str = this.index.get(str);
        if (str == null) {
            str = null;
        } else {
            str = new TreeSet(str.getSpans());
        }
        return str;
    }

    public synchronized Set<String> getKeys() {
        return new HashSet(this.index.getKeys());
    }

    public synchronized long getCacheSpace() {
        return this.totalSpace;
    }

    public synchronized SimpleCacheSpan startReadWriteNonBlocking(String str, long j) throws CacheException {
        if (this.initializationException == null) {
            j = getSpan(str, j);
            if (j.isCached) {
                str = this.index.get(str).touch(j);
                notifySpanTouched(j, str);
                return str;
            } else if (this.lockedSpans.containsKey(str)) {
                return null;
            } else {
                this.lockedSpans.put(str, j);
                return j;
            }
        }
        throw this.initializationException;
    }

    public synchronized File startFile(String str, long j, long j2) throws CacheException {
        Assertions.checkState(this.lockedSpans.containsKey(str));
        if (!this.cacheDir.exists()) {
            removeStaleSpansAndCachedContents();
            this.cacheDir.mkdirs();
        }
        this.evictor.onStartFile(this, str, j, j2);
        return SimpleCacheSpan.getCacheFile(this.cacheDir, this.index.assignIdForKey(str), j, System.currentTimeMillis());
    }

    public synchronized void commitFile(File file) throws CacheException {
        SimpleCacheSpan createCacheEntry = SimpleCacheSpan.createCacheEntry(file, this.index);
        boolean z = true;
        Assertions.checkState(createCacheEntry != null);
        Assertions.checkState(this.lockedSpans.containsKey(createCacheEntry.key));
        if (!file.exists()) {
            return;
        }
        if (file.length() == 0) {
            file.delete();
            return;
        }
        file = Long.valueOf(getContentLength(createCacheEntry.key));
        if (file.longValue() != -1) {
            if (createCacheEntry.position + createCacheEntry.length > file.longValue()) {
                z = false;
            }
            Assertions.checkState(z);
        }
        addSpan(createCacheEntry);
        this.index.store();
        notifyAll();
    }

    public synchronized void releaseHoleSpan(CacheSpan cacheSpan) {
        Assertions.checkState(cacheSpan == this.lockedSpans.remove(cacheSpan.key) ? true : null);
        notifyAll();
    }

    private SimpleCacheSpan getSpan(String str, long j) throws CacheException {
        CachedContent cachedContent = this.index.get(str);
        if (cachedContent == null) {
            return SimpleCacheSpan.createOpenHole(str, j);
        }
        while (true) {
            str = cachedContent.getSpan(j);
            if (!str.isCached || str.file.exists()) {
                return str;
            }
            removeStaleSpansAndCachedContents();
        }
        return str;
    }

    private void initialize() throws CacheException {
        if (this.cacheDir.exists()) {
            this.index.load();
            File[] listFiles = this.cacheDir.listFiles();
            if (listFiles != null) {
                for (File file : listFiles) {
                    if (!file.getName().equals(CachedContentIndex.FILE_NAME)) {
                        SimpleCacheSpan createCacheEntry = file.length() > 0 ? SimpleCacheSpan.createCacheEntry(file, this.index) : null;
                        if (createCacheEntry != null) {
                            addSpan(createCacheEntry);
                        } else {
                            file.delete();
                        }
                    }
                }
                this.index.removeEmpty();
                this.index.store();
                return;
            }
            return;
        }
        this.cacheDir.mkdirs();
    }

    private void addSpan(SimpleCacheSpan simpleCacheSpan) {
        this.index.add(simpleCacheSpan.key).addSpan(simpleCacheSpan);
        this.totalSpace += simpleCacheSpan.length;
        notifySpanAdded(simpleCacheSpan);
    }

    private void removeSpan(CacheSpan cacheSpan, boolean z) throws CacheException {
        CachedContent cachedContent = this.index.get(cacheSpan.key);
        if (cachedContent != null) {
            if (cachedContent.removeSpan(cacheSpan)) {
                this.totalSpace -= cacheSpan.length;
                if (z && cachedContent.isEmpty()) {
                    this.index.removeEmpty(cachedContent.key);
                    this.index.store();
                }
                notifySpanRemoved(cacheSpan);
            }
        }
    }

    public synchronized void removeSpan(CacheSpan cacheSpan) throws CacheException {
        removeSpan(cacheSpan, true);
    }

    private void removeStaleSpansAndCachedContents() throws CacheException {
        LinkedList linkedList = new LinkedList();
        for (CachedContent spans : this.index.getAll()) {
            Iterator it = spans.getSpans().iterator();
            while (it.hasNext()) {
                CacheSpan cacheSpan = (CacheSpan) it.next();
                if (!cacheSpan.file.exists()) {
                    linkedList.add(cacheSpan);
                }
            }
        }
        Iterator it2 = linkedList.iterator();
        while (it2.hasNext()) {
            removeSpan((CacheSpan) it2.next(), false);
        }
        this.index.removeEmpty();
        this.index.store();
    }

    private void notifySpanRemoved(CacheSpan cacheSpan) {
        ArrayList arrayList = (ArrayList) this.listeners.get(cacheSpan.key);
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((Listener) arrayList.get(size)).onSpanRemoved(this, cacheSpan);
            }
        }
        this.evictor.onSpanRemoved(this, cacheSpan);
    }

    private void notifySpanAdded(SimpleCacheSpan simpleCacheSpan) {
        ArrayList arrayList = (ArrayList) this.listeners.get(simpleCacheSpan.key);
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((Listener) arrayList.get(size)).onSpanAdded(this, simpleCacheSpan);
            }
        }
        this.evictor.onSpanAdded(this, simpleCacheSpan);
    }

    private void notifySpanTouched(SimpleCacheSpan simpleCacheSpan, CacheSpan cacheSpan) {
        ArrayList arrayList = (ArrayList) this.listeners.get(simpleCacheSpan.key);
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((Listener) arrayList.get(size)).onSpanTouched(this, simpleCacheSpan, cacheSpan);
            }
        }
        this.evictor.onSpanTouched(this, simpleCacheSpan, cacheSpan);
    }

    public synchronized boolean isCached(String str, long j, long j2) {
        str = this.index.get(str);
        str = (str == null || str.getCachedBytes(j, j2) < j2) ? null : true;
        return str;
    }

    public synchronized long getCachedBytes(String str, long j, long j2) {
        str = this.index.get(str);
        return str != null ? str.getCachedBytes(j, j2) : -j2;
    }

    public synchronized void setContentLength(String str, long j) throws CacheException {
        this.index.setContentLength(str, j);
        this.index.store();
    }

    public synchronized long getContentLength(String str) {
        return this.index.getContentLength(str);
    }
}
