package com.google.android.exoplayer2.upstream;

import com.google.android.exoplayer2.util.Assertions;

public final class DefaultAllocator implements Allocator {
    private static final int AVAILABLE_EXTRA_CAPACITY = 100;
    private int allocatedCount;
    private Allocation[] availableAllocations;
    private int availableCount;
    private final int individualAllocationSize;
    private final byte[] initialAllocationBlock;
    private final Allocation[] singleAllocationReleaseHolder;
    private int targetBufferSize;
    private final boolean trimOnReset;

    public synchronized void release(com.google.android.exoplayer2.upstream.Allocation[] r8) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:21:0x0057 in {4, 11, 12, 13, 14, 17, 20} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r7 = this;
        monitor-enter(r7);
        r0 = r7.availableCount;	 Catch:{ all -> 0x0054 }
        r1 = r8.length;	 Catch:{ all -> 0x0054 }
        r0 = r0 + r1;	 Catch:{ all -> 0x0054 }
        r1 = r7.availableAllocations;	 Catch:{ all -> 0x0054 }
        r1 = r1.length;	 Catch:{ all -> 0x0054 }
        if (r0 < r1) goto L_0x0021;	 Catch:{ all -> 0x0054 }
    L_0x000a:
        r0 = r7.availableAllocations;	 Catch:{ all -> 0x0054 }
        r1 = r7.availableAllocations;	 Catch:{ all -> 0x0054 }
        r1 = r1.length;	 Catch:{ all -> 0x0054 }
        r1 = r1 * 2;	 Catch:{ all -> 0x0054 }
        r2 = r7.availableCount;	 Catch:{ all -> 0x0054 }
        r3 = r8.length;	 Catch:{ all -> 0x0054 }
        r2 = r2 + r3;	 Catch:{ all -> 0x0054 }
        r1 = java.lang.Math.max(r1, r2);	 Catch:{ all -> 0x0054 }
        r0 = java.util.Arrays.copyOf(r0, r1);	 Catch:{ all -> 0x0054 }
        r0 = (com.google.android.exoplayer2.upstream.Allocation[]) r0;	 Catch:{ all -> 0x0054 }
        r7.availableAllocations = r0;	 Catch:{ all -> 0x0054 }
    L_0x0021:
        r0 = r8.length;	 Catch:{ all -> 0x0054 }
        r1 = 0;	 Catch:{ all -> 0x0054 }
        r2 = 0;	 Catch:{ all -> 0x0054 }
    L_0x0024:
        if (r2 >= r0) goto L_0x0049;	 Catch:{ all -> 0x0054 }
    L_0x0026:
        r3 = r8[r2];	 Catch:{ all -> 0x0054 }
        r4 = r3.data;	 Catch:{ all -> 0x0054 }
        r5 = r7.initialAllocationBlock;	 Catch:{ all -> 0x0054 }
        if (r4 == r5) goto L_0x0038;	 Catch:{ all -> 0x0054 }
    L_0x002e:
        r4 = r3.data;	 Catch:{ all -> 0x0054 }
        r4 = r4.length;	 Catch:{ all -> 0x0054 }
        r5 = r7.individualAllocationSize;	 Catch:{ all -> 0x0054 }
        if (r4 != r5) goto L_0x0036;	 Catch:{ all -> 0x0054 }
    L_0x0035:
        goto L_0x0038;	 Catch:{ all -> 0x0054 }
    L_0x0036:
        r4 = 0;	 Catch:{ all -> 0x0054 }
        goto L_0x0039;	 Catch:{ all -> 0x0054 }
    L_0x0038:
        r4 = 1;	 Catch:{ all -> 0x0054 }
    L_0x0039:
        com.google.android.exoplayer2.util.Assertions.checkArgument(r4);	 Catch:{ all -> 0x0054 }
        r4 = r7.availableAllocations;	 Catch:{ all -> 0x0054 }
        r5 = r7.availableCount;	 Catch:{ all -> 0x0054 }
        r6 = r5 + 1;	 Catch:{ all -> 0x0054 }
        r7.availableCount = r6;	 Catch:{ all -> 0x0054 }
        r4[r5] = r3;	 Catch:{ all -> 0x0054 }
        r2 = r2 + 1;	 Catch:{ all -> 0x0054 }
        goto L_0x0024;	 Catch:{ all -> 0x0054 }
    L_0x0049:
        r0 = r7.allocatedCount;	 Catch:{ all -> 0x0054 }
        r8 = r8.length;	 Catch:{ all -> 0x0054 }
        r0 = r0 - r8;	 Catch:{ all -> 0x0054 }
        r7.allocatedCount = r0;	 Catch:{ all -> 0x0054 }
        r7.notifyAll();	 Catch:{ all -> 0x0054 }
        monitor-exit(r7);
        return;
    L_0x0054:
        r8 = move-exception;
        monitor-exit(r7);
        throw r8;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.DefaultAllocator.release(com.google.android.exoplayer2.upstream.Allocation[]):void");
    }

    public synchronized void trim() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:29:0x0063 in {5, 13, 16, 17, 21, 25, 28} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r7 = this;
        monitor-enter(r7);
        r0 = r7.targetBufferSize;	 Catch:{ all -> 0x0060 }
        r1 = r7.individualAllocationSize;	 Catch:{ all -> 0x0060 }
        r0 = com.google.android.exoplayer2.util.Util.ceilDivide(r0, r1);	 Catch:{ all -> 0x0060 }
        r1 = r7.allocatedCount;	 Catch:{ all -> 0x0060 }
        r0 = r0 - r1;	 Catch:{ all -> 0x0060 }
        r1 = 0;	 Catch:{ all -> 0x0060 }
        r0 = java.lang.Math.max(r1, r0);	 Catch:{ all -> 0x0060 }
        r2 = r7.availableCount;	 Catch:{ all -> 0x0060 }
        if (r0 < r2) goto L_0x0017;
    L_0x0015:
        monitor-exit(r7);
        return;
    L_0x0017:
        r2 = r7.initialAllocationBlock;	 Catch:{ all -> 0x0060 }
        if (r2 == 0) goto L_0x0054;	 Catch:{ all -> 0x0060 }
    L_0x001b:
        r2 = r7.availableCount;	 Catch:{ all -> 0x0060 }
        r2 = r2 + -1;	 Catch:{ all -> 0x0060 }
    L_0x001f:
        if (r1 > r2) goto L_0x004a;	 Catch:{ all -> 0x0060 }
    L_0x0021:
        r3 = r7.availableAllocations;	 Catch:{ all -> 0x0060 }
        r3 = r3[r1];	 Catch:{ all -> 0x0060 }
        r4 = r3.data;	 Catch:{ all -> 0x0060 }
        r5 = r7.initialAllocationBlock;	 Catch:{ all -> 0x0060 }
        if (r4 != r5) goto L_0x002e;	 Catch:{ all -> 0x0060 }
    L_0x002b:
        r1 = r1 + 1;	 Catch:{ all -> 0x0060 }
        goto L_0x001f;	 Catch:{ all -> 0x0060 }
    L_0x002e:
        r4 = r7.availableAllocations;	 Catch:{ all -> 0x0060 }
        r4 = r4[r2];	 Catch:{ all -> 0x0060 }
        r5 = r4.data;	 Catch:{ all -> 0x0060 }
        r6 = r7.initialAllocationBlock;	 Catch:{ all -> 0x0060 }
        if (r5 == r6) goto L_0x003b;	 Catch:{ all -> 0x0060 }
    L_0x0038:
        r2 = r2 + -1;	 Catch:{ all -> 0x0060 }
        goto L_0x001f;	 Catch:{ all -> 0x0060 }
    L_0x003b:
        r5 = r7.availableAllocations;	 Catch:{ all -> 0x0060 }
        r6 = r1 + 1;	 Catch:{ all -> 0x0060 }
        r5[r1] = r4;	 Catch:{ all -> 0x0060 }
        r1 = r7.availableAllocations;	 Catch:{ all -> 0x0060 }
        r4 = r2 + -1;	 Catch:{ all -> 0x0060 }
        r1[r2] = r3;	 Catch:{ all -> 0x0060 }
        r2 = r4;	 Catch:{ all -> 0x0060 }
        r1 = r6;	 Catch:{ all -> 0x0060 }
        goto L_0x001f;	 Catch:{ all -> 0x0060 }
    L_0x004a:
        r0 = java.lang.Math.max(r0, r1);	 Catch:{ all -> 0x0060 }
        r1 = r7.availableCount;	 Catch:{ all -> 0x0060 }
        if (r0 < r1) goto L_0x0054;
    L_0x0052:
        monitor-exit(r7);
        return;
    L_0x0054:
        r1 = r7.availableAllocations;	 Catch:{ all -> 0x0060 }
        r2 = r7.availableCount;	 Catch:{ all -> 0x0060 }
        r3 = 0;	 Catch:{ all -> 0x0060 }
        java.util.Arrays.fill(r1, r0, r2, r3);	 Catch:{ all -> 0x0060 }
        r7.availableCount = r0;	 Catch:{ all -> 0x0060 }
        monitor-exit(r7);
        return;
    L_0x0060:
        r0 = move-exception;
        monitor-exit(r7);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.DefaultAllocator.trim():void");
    }

    public DefaultAllocator(boolean z, int i) {
        this(z, i, 0);
    }

    public DefaultAllocator(boolean z, int i, int i2) {
        Assertions.checkArgument(i > 0);
        Assertions.checkArgument(i2 >= 0);
        this.trimOnReset = z;
        this.individualAllocationSize = i;
        this.availableCount = i2;
        this.availableAllocations = new Allocation[(i2 + 100)];
        if (i2 > 0) {
            this.initialAllocationBlock = new byte[(i2 * i)];
            for (int i3 = 0; i3 < i2; i3++) {
                this.availableAllocations[i3] = new Allocation(this.initialAllocationBlock, i3 * i);
            }
        } else {
            this.initialAllocationBlock = false;
        }
        this.singleAllocationReleaseHolder = new Allocation[1];
    }

    public synchronized void reset() {
        if (this.trimOnReset) {
            setTargetBufferSize(0);
        }
    }

    public synchronized void setTargetBufferSize(int i) {
        Object obj = i < this.targetBufferSize ? 1 : null;
        this.targetBufferSize = i;
        if (obj != null) {
            trim();
        }
    }

    public synchronized Allocation allocate() {
        Allocation allocation;
        this.allocatedCount++;
        if (this.availableCount > 0) {
            Allocation[] allocationArr = this.availableAllocations;
            int i = this.availableCount - 1;
            this.availableCount = i;
            allocation = allocationArr[i];
            this.availableAllocations[this.availableCount] = null;
        } else {
            allocation = new Allocation(new byte[this.individualAllocationSize], 0);
        }
        return allocation;
    }

    public synchronized void release(Allocation allocation) {
        this.singleAllocationReleaseHolder[0] = allocation;
        release(this.singleAllocationReleaseHolder);
    }

    public synchronized int getTotalBytesAllocated() {
        return this.allocatedCount * this.individualAllocationSize;
    }

    public int getIndividualAllocationLength() {
        return this.individualAllocationSize;
    }
}
