package com.google.android.exoplayer2.upstream;

import android.net.Uri;
import android.util.Log;
import com.google.android.exoplayer2.upstream.HttpDataSource.HttpDataSourceException;
import com.google.android.exoplayer2.upstream.HttpDataSource.InvalidContentTypeException;
import com.google.android.exoplayer2.upstream.HttpDataSource.InvalidResponseCodeException;
import com.google.android.exoplayer2.upstream.HttpDataSource.RequestProperties;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.Predicate;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;

public class DefaultHttpDataSource implements HttpDataSource {
    private static final Pattern CONTENT_RANGE_HEADER = Pattern.compile("^bytes (\\d+)-(\\d+)/(\\d+)$");
    public static final int DEFAULT_CONNECT_TIMEOUT_MILLIS = 8000;
    public static final int DEFAULT_READ_TIMEOUT_MILLIS = 8000;
    private static final long MAX_BYTES_TO_DRAIN = 2048;
    private static final int MAX_REDIRECTS = 20;
    private static final String TAG = "DefaultHttpDataSource";
    private static final AtomicReference<byte[]> skipBufferReference = new AtomicReference();
    private final boolean allowCrossProtocolRedirects;
    private long bytesRead;
    private long bytesSkipped;
    private long bytesToRead;
    private long bytesToSkip;
    private final int connectTimeoutMillis;
    private HttpURLConnection connection;
    private final Predicate<String> contentTypePredicate;
    private DataSpec dataSpec;
    private final RequestProperties defaultRequestProperties;
    private InputStream inputStream;
    private final TransferListener<? super DefaultHttpDataSource> listener;
    private boolean opened;
    private final int readTimeoutMillis;
    private final RequestProperties requestProperties;
    private final String userAgent;

    private java.net.HttpURLConnection makeConnection(com.google.android.exoplayer2.upstream.DataSpec r20) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:25:0x008e in {3, 20, 21, 22, 24} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r19 = this;
        r0 = r20;
        r1 = new java.net.URL;
        r2 = r0.uri;
        r2 = r2.toString();
        r1.<init>(r2);
        r2 = r0.postBody;
        r12 = r0.position;
        r14 = r0.length;
        r3 = 1;
        r16 = r0.isFlagSet(r3);
        r11 = r19;
        r0 = r11.allowCrossProtocolRedirects;
        if (r0 != 0) goto L_0x002a;
    L_0x001e:
        r8 = 1;
        r0 = r19;
        r3 = r12;
        r5 = r14;
        r7 = r16;
        r0 = r0.makeConnection(r1, r2, r3, r5, r7, r8);
        return r0;
    L_0x002a:
        r0 = 0;
    L_0x002b:
        r10 = r0 + 1;
        r3 = 20;
        if (r0 > r3) goto L_0x0076;
    L_0x0031:
        r0 = 0;
        r3 = r19;
        r4 = r1;
        r5 = r2;
        r6 = r12;
        r8 = r14;
        r17 = r12;
        r12 = r10;
        r10 = r16;
        r11 = r0;
        r0 = r3.makeConnection(r4, r5, r6, r8, r10, r11);
        r3 = r0.getResponseCode();
        r4 = 300; // 0x12c float:4.2E-43 double:1.48E-321;
        if (r3 == r4) goto L_0x0062;
    L_0x004a:
        r4 = 301; // 0x12d float:4.22E-43 double:1.487E-321;
        if (r3 == r4) goto L_0x0062;
    L_0x004e:
        r4 = 302; // 0x12e float:4.23E-43 double:1.49E-321;
        if (r3 == r4) goto L_0x0062;
    L_0x0052:
        r4 = 303; // 0x12f float:4.25E-43 double:1.497E-321;
        if (r3 == r4) goto L_0x0062;
    L_0x0056:
        if (r2 != 0) goto L_0x0061;
    L_0x0058:
        r2 = 307; // 0x133 float:4.3E-43 double:1.517E-321;
        if (r3 == r2) goto L_0x0062;
    L_0x005c:
        r2 = 308; // 0x134 float:4.32E-43 double:1.52E-321;
        if (r3 != r2) goto L_0x0061;
    L_0x0060:
        goto L_0x0062;
    L_0x0061:
        return r0;
    L_0x0062:
        r2 = 0;
        r3 = "Location";
        r3 = r0.getHeaderField(r3);
        r0.disconnect();
        r1 = handleRedirect(r1, r3);
        r11 = r19;
        r0 = r12;
        r12 = r17;
        goto L_0x002b;
    L_0x0076:
        r12 = r10;
        r0 = new java.net.NoRouteToHostException;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Too many redirects: ";
        r1.append(r2);
        r1.append(r12);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.DefaultHttpDataSource.makeConnection(com.google.android.exoplayer2.upstream.DataSpec):java.net.HttpURLConnection");
    }

    public DefaultHttpDataSource(String str, Predicate<String> predicate) {
        this(str, predicate, null);
    }

    public DefaultHttpDataSource(String str, Predicate<String> predicate, TransferListener<? super DefaultHttpDataSource> transferListener) {
        this(str, predicate, transferListener, 8000, 8000);
    }

    public DefaultHttpDataSource(String str, Predicate<String> predicate, TransferListener<? super DefaultHttpDataSource> transferListener, int i, int i2) {
        this(str, predicate, transferListener, i, i2, false, null);
    }

    public DefaultHttpDataSource(String str, Predicate<String> predicate, TransferListener<? super DefaultHttpDataSource> transferListener, int i, int i2, boolean z, RequestProperties requestProperties) {
        this.userAgent = Assertions.checkNotEmpty(str);
        this.contentTypePredicate = predicate;
        this.listener = transferListener;
        this.requestProperties = new RequestProperties();
        this.connectTimeoutMillis = i;
        this.readTimeoutMillis = i2;
        this.allowCrossProtocolRedirects = z;
        this.defaultRequestProperties = requestProperties;
    }

    public Uri getUri() {
        HttpURLConnection httpURLConnection = this.connection;
        return httpURLConnection == null ? null : Uri.parse(httpURLConnection.getURL().toString());
    }

    public Map<String, List<String>> getResponseHeaders() {
        HttpURLConnection httpURLConnection = this.connection;
        return httpURLConnection == null ? null : httpURLConnection.getHeaderFields();
    }

    public void setRequestProperty(String str, String str2) {
        Assertions.checkNotNull(str);
        Assertions.checkNotNull(str2);
        this.requestProperties.set(str, str2);
    }

    public void clearRequestProperty(String str) {
        Assertions.checkNotNull(str);
        this.requestProperties.remove(str);
    }

    public void clearAllRequestProperties() {
        this.requestProperties.clear();
    }

    public long open(DataSpec dataSpec) throws HttpDataSourceException {
        StringBuilder stringBuilder;
        this.dataSpec = dataSpec;
        long j = 0;
        this.bytesRead = 0;
        this.bytesSkipped = 0;
        try {
            this.connection = makeConnection(dataSpec);
            try {
                int responseCode = this.connection.getResponseCode();
                if (responseCode >= 200) {
                    if (responseCode <= 299) {
                        String contentType = this.connection.getContentType();
                        Predicate predicate = this.contentTypePredicate;
                        if (predicate != null) {
                            if (!predicate.evaluate(contentType)) {
                                closeConnectionQuietly();
                                throw new InvalidContentTypeException(contentType, dataSpec);
                            }
                        }
                        if (responseCode == 200 && dataSpec.position != 0) {
                            j = dataSpec.position;
                        }
                        this.bytesToSkip = j;
                        if (dataSpec.isFlagSet(1)) {
                            this.bytesToRead = dataSpec.length;
                        } else {
                            long j2 = -1;
                            if (dataSpec.length != -1) {
                                this.bytesToRead = dataSpec.length;
                            } else {
                                j = getContentLength(this.connection);
                                if (j != -1) {
                                    j2 = j - this.bytesToSkip;
                                }
                                this.bytesToRead = j2;
                            }
                        }
                        try {
                            this.inputStream = this.connection.getInputStream();
                            this.opened = true;
                            TransferListener transferListener = this.listener;
                            if (transferListener != null) {
                                transferListener.onTransferStart(this, dataSpec);
                            }
                            return this.bytesToRead;
                        } catch (IOException e) {
                            closeConnectionQuietly();
                            throw new HttpDataSourceException(e, dataSpec, 1);
                        }
                    }
                }
                Map headerFields = this.connection.getHeaderFields();
                closeConnectionQuietly();
                InvalidResponseCodeException invalidResponseCodeException = new InvalidResponseCodeException(responseCode, headerFields, dataSpec);
                if (responseCode == 416) {
                    invalidResponseCodeException.initCause(new DataSourceException(0));
                }
                throw invalidResponseCodeException;
            } catch (IOException e2) {
                closeConnectionQuietly();
                stringBuilder = new StringBuilder();
                stringBuilder.append("Unable to connect to ");
                stringBuilder.append(dataSpec.uri.toString());
                throw new HttpDataSourceException(stringBuilder.toString(), e2, dataSpec, 1);
            }
        } catch (IOException e22) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to connect to ");
            stringBuilder.append(dataSpec.uri.toString());
            throw new HttpDataSourceException(stringBuilder.toString(), e22, dataSpec, 1);
        }
    }

    public int read(byte[] bArr, int i, int i2) throws HttpDataSourceException {
        try {
            skipInternal();
            return readInternal(bArr, i, i2);
        } catch (IOException e) {
            throw new HttpDataSourceException(e, this.dataSpec, 2);
        }
    }

    public void close() throws HttpDataSourceException {
        TransferListener transferListener;
        try {
            if (this.inputStream != null) {
                maybeTerminateInputStream(this.connection, bytesRemaining());
                this.inputStream.close();
            }
            this.inputStream = null;
            closeConnectionQuietly();
            if (this.opened) {
                this.opened = false;
                transferListener = this.listener;
                if (transferListener != null) {
                    transferListener.onTransferEnd(this);
                }
            }
        } catch (IOException e) {
            throw new HttpDataSourceException(e, this.dataSpec, 3);
        } catch (Throwable th) {
            this.inputStream = null;
            closeConnectionQuietly();
            if (this.opened) {
                this.opened = false;
                transferListener = this.listener;
                if (transferListener != null) {
                    transferListener.onTransferEnd(this);
                }
            }
        }
    }

    protected final HttpURLConnection getConnection() {
        return this.connection;
    }

    protected final long bytesSkipped() {
        return this.bytesSkipped;
    }

    protected final long bytesRead() {
        return this.bytesRead;
    }

    protected final long bytesRemaining() {
        long j = this.bytesToRead;
        return j == -1 ? j : j - this.bytesRead;
    }

    private HttpURLConnection makeConnection(URL url, byte[] bArr, long j, long j2, boolean z, boolean z2) throws IOException {
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        httpURLConnection.setConnectTimeout(this.connectTimeoutMillis);
        httpURLConnection.setReadTimeout(this.readTimeoutMillis);
        RequestProperties requestProperties = this.defaultRequestProperties;
        if (requestProperties != null) {
            for (Entry entry : requestProperties.getSnapshot().entrySet()) {
                httpURLConnection.setRequestProperty((String) entry.getKey(), (String) entry.getValue());
            }
        }
        for (Entry entry2 : this.requestProperties.getSnapshot().entrySet()) {
            httpURLConnection.setRequestProperty((String) entry2.getKey(), (String) entry2.getValue());
        }
        if (!(j == 0 && j2 == -1)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("bytes=");
            stringBuilder.append(j);
            stringBuilder.append("-");
            String stringBuilder2 = stringBuilder.toString();
            if (j2 != -1) {
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append(stringBuilder2);
                stringBuilder3.append((j + j2) - 1);
                stringBuilder2 = stringBuilder3.toString();
            }
            httpURLConnection.setRequestProperty("Range", stringBuilder2);
        }
        httpURLConnection.setRequestProperty("User-Agent", this.userAgent);
        if (!z) {
            httpURLConnection.setRequestProperty("Accept-Encoding", "identity");
        }
        httpURLConnection.setInstanceFollowRedirects(z2);
        httpURLConnection.setDoOutput(bArr != null ? 1 : null);
        if (bArr != null) {
            httpURLConnection.setRequestMethod("POST");
            if (bArr.length == null) {
                httpURLConnection.connect();
            } else {
                httpURLConnection.setFixedLengthStreamingMode(bArr.length);
                httpURLConnection.connect();
                j = httpURLConnection.getOutputStream();
                j.write(bArr);
                j.close();
            }
        } else {
            httpURLConnection.connect();
        }
        return httpURLConnection;
    }

    private static URL handleRedirect(URL url, String str) throws IOException {
        if (str != null) {
            URL url2 = new URL(url, str);
            url = url2.getProtocol();
            if ("https".equals(url) == null) {
                if ("http".equals(url) == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Unsupported protocol redirect: ");
                    stringBuilder.append(url);
                    throw new ProtocolException(stringBuilder.toString());
                }
            }
            return url2;
        }
        throw new ProtocolException("Null location redirect");
    }

    private static long getContentLength(java.net.HttpURLConnection r8) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = "Content-Length";
        r0 = r8.getHeaderField(r0);
        r1 = android.text.TextUtils.isEmpty(r0);
        if (r1 != 0) goto L_0x002c;
    L_0x000c:
        r1 = java.lang.Long.parseLong(r0);	 Catch:{ NumberFormatException -> 0x0011 }
        goto L_0x002e;
    L_0x0011:
        r1 = "DefaultHttpDataSource";
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r3 = "Unexpected Content-Length [";
        r2.append(r3);
        r2.append(r0);
        r3 = "]";
        r2.append(r3);
        r2 = r2.toString();
        android.util.Log.e(r1, r2);
    L_0x002c:
        r1 = -1;
    L_0x002e:
        r3 = "Content-Range";
        r8 = r8.getHeaderField(r3);
        r3 = android.text.TextUtils.isEmpty(r8);
        if (r3 != 0) goto L_0x00ac;
    L_0x003a:
        r3 = CONTENT_RANGE_HEADER;
        r3 = r3.matcher(r8);
        r4 = r3.find();
        if (r4 == 0) goto L_0x00ac;
    L_0x0046:
        r4 = 2;
        r4 = r3.group(r4);	 Catch:{ NumberFormatException -> 0x0091 }
        r4 = java.lang.Long.parseLong(r4);	 Catch:{ NumberFormatException -> 0x0091 }
        r6 = 1;	 Catch:{ NumberFormatException -> 0x0091 }
        r3 = r3.group(r6);	 Catch:{ NumberFormatException -> 0x0091 }
        r6 = java.lang.Long.parseLong(r3);	 Catch:{ NumberFormatException -> 0x0091 }
        r4 = r4 - r6;	 Catch:{ NumberFormatException -> 0x0091 }
        r6 = 1;	 Catch:{ NumberFormatException -> 0x0091 }
        r4 = r4 + r6;	 Catch:{ NumberFormatException -> 0x0091 }
        r6 = 0;	 Catch:{ NumberFormatException -> 0x0091 }
        r3 = (r1 > r6 ? 1 : (r1 == r6 ? 0 : -1));	 Catch:{ NumberFormatException -> 0x0091 }
        if (r3 >= 0) goto L_0x0064;	 Catch:{ NumberFormatException -> 0x0091 }
    L_0x0062:
        r1 = r4;	 Catch:{ NumberFormatException -> 0x0091 }
        goto L_0x00ac;	 Catch:{ NumberFormatException -> 0x0091 }
    L_0x0064:
        r3 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1));	 Catch:{ NumberFormatException -> 0x0091 }
        if (r3 == 0) goto L_0x00ac;	 Catch:{ NumberFormatException -> 0x0091 }
    L_0x0068:
        r3 = "DefaultHttpDataSource";	 Catch:{ NumberFormatException -> 0x0091 }
        r6 = new java.lang.StringBuilder;	 Catch:{ NumberFormatException -> 0x0091 }
        r6.<init>();	 Catch:{ NumberFormatException -> 0x0091 }
        r7 = "Inconsistent headers [";	 Catch:{ NumberFormatException -> 0x0091 }
        r6.append(r7);	 Catch:{ NumberFormatException -> 0x0091 }
        r6.append(r0);	 Catch:{ NumberFormatException -> 0x0091 }
        r0 = "] [";	 Catch:{ NumberFormatException -> 0x0091 }
        r6.append(r0);	 Catch:{ NumberFormatException -> 0x0091 }
        r6.append(r8);	 Catch:{ NumberFormatException -> 0x0091 }
        r0 = "]";	 Catch:{ NumberFormatException -> 0x0091 }
        r6.append(r0);	 Catch:{ NumberFormatException -> 0x0091 }
        r0 = r6.toString();	 Catch:{ NumberFormatException -> 0x0091 }
        android.util.Log.w(r3, r0);	 Catch:{ NumberFormatException -> 0x0091 }
        r0 = java.lang.Math.max(r1, r4);	 Catch:{ NumberFormatException -> 0x0091 }
        r1 = r0;
        goto L_0x00ac;
    L_0x0091:
        r0 = "DefaultHttpDataSource";
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r4 = "Unexpected Content-Range [";
        r3.append(r4);
        r3.append(r8);
        r8 = "]";
        r3.append(r8);
        r8 = r3.toString();
        android.util.Log.e(r0, r8);
    L_0x00ac:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.DefaultHttpDataSource.getContentLength(java.net.HttpURLConnection):long");
    }

    private void skipInternal() throws IOException {
        if (this.bytesSkipped != this.bytesToSkip) {
            Object obj = (byte[]) skipBufferReference.getAndSet(null);
            if (obj == null) {
                obj = new byte[4096];
            }
            while (true) {
                long j = this.bytesSkipped;
                long j2 = this.bytesToSkip;
                if (j != j2) {
                    int read = this.inputStream.read(obj, 0, (int) Math.min(j2 - j, (long) obj.length));
                    if (Thread.interrupted()) {
                        throw new InterruptedIOException();
                    } else if (read != -1) {
                        this.bytesSkipped += (long) read;
                        TransferListener transferListener = this.listener;
                        if (transferListener != null) {
                            transferListener.onBytesTransferred(this, read);
                        }
                    } else {
                        throw new EOFException();
                    }
                }
                skipBufferReference.set(obj);
                return;
            }
        }
    }

    private int readInternal(byte[] bArr, int i, int i2) throws IOException {
        if (i2 == 0) {
            return null;
        }
        long j = this.bytesToRead;
        if (j != -1) {
            j -= this.bytesRead;
            if (j == 0) {
                return -1;
            }
            i2 = (int) Math.min((long) i2, j);
        }
        bArr = this.inputStream.read(bArr, i, i2);
        if (bArr != -1) {
            this.bytesRead += (long) bArr;
            i = this.listener;
            if (i != 0) {
                i.onBytesTransferred(this, bArr);
            }
            return bArr;
        } else if (this.bytesToRead == -1) {
            return -1;
        } else {
            throw new EOFException();
        }
    }

    private static void maybeTerminateInputStream(java.net.HttpURLConnection r3, long r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = com.google.android.exoplayer2.util.Util.SDK_INT;
        r1 = 19;
        if (r0 == r1) goto L_0x000d;
    L_0x0006:
        r0 = com.google.android.exoplayer2.util.Util.SDK_INT;
        r1 = 20;
        if (r0 == r1) goto L_0x000d;
    L_0x000c:
        return;
    L_0x000d:
        r3 = r3.getInputStream();	 Catch:{ Exception -> 0x0058 }
        r0 = -1;	 Catch:{ Exception -> 0x0058 }
        r2 = (r4 > r0 ? 1 : (r4 == r0 ? 0 : -1));	 Catch:{ Exception -> 0x0058 }
        if (r2 != 0) goto L_0x001f;	 Catch:{ Exception -> 0x0058 }
    L_0x0017:
        r4 = r3.read();	 Catch:{ Exception -> 0x0058 }
        r5 = -1;	 Catch:{ Exception -> 0x0058 }
        if (r4 != r5) goto L_0x0026;	 Catch:{ Exception -> 0x0058 }
    L_0x001e:
        return;	 Catch:{ Exception -> 0x0058 }
    L_0x001f:
        r0 = 2048; // 0x800 float:2.87E-42 double:1.0118E-320;	 Catch:{ Exception -> 0x0058 }
        r2 = (r4 > r0 ? 1 : (r4 == r0 ? 0 : -1));	 Catch:{ Exception -> 0x0058 }
        if (r2 > 0) goto L_0x0026;	 Catch:{ Exception -> 0x0058 }
    L_0x0025:
        return;	 Catch:{ Exception -> 0x0058 }
    L_0x0026:
        r4 = r3.getClass();	 Catch:{ Exception -> 0x0058 }
        r4 = r4.getName();	 Catch:{ Exception -> 0x0058 }
        r5 = "com.android.okhttp.internal.http.HttpTransport$ChunkedInputStream";	 Catch:{ Exception -> 0x0058 }
        r5 = r4.equals(r5);	 Catch:{ Exception -> 0x0058 }
        if (r5 != 0) goto L_0x003e;	 Catch:{ Exception -> 0x0058 }
    L_0x0036:
        r5 = "com.android.okhttp.internal.http.HttpTransport$FixedLengthInputStream";	 Catch:{ Exception -> 0x0058 }
        r4 = r4.equals(r5);	 Catch:{ Exception -> 0x0058 }
        if (r4 == 0) goto L_0x0058;	 Catch:{ Exception -> 0x0058 }
    L_0x003e:
        r4 = r3.getClass();	 Catch:{ Exception -> 0x0058 }
        r4 = r4.getSuperclass();	 Catch:{ Exception -> 0x0058 }
        r5 = "unexpectedEndOfInput";	 Catch:{ Exception -> 0x0058 }
        r0 = 0;	 Catch:{ Exception -> 0x0058 }
        r1 = new java.lang.Class[r0];	 Catch:{ Exception -> 0x0058 }
        r4 = r4.getDeclaredMethod(r5, r1);	 Catch:{ Exception -> 0x0058 }
        r5 = 1;	 Catch:{ Exception -> 0x0058 }
        r4.setAccessible(r5);	 Catch:{ Exception -> 0x0058 }
        r5 = new java.lang.Object[r0];	 Catch:{ Exception -> 0x0058 }
        r4.invoke(r3, r5);	 Catch:{ Exception -> 0x0058 }
    L_0x0058:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.DefaultHttpDataSource.maybeTerminateInputStream(java.net.HttpURLConnection, long):void");
    }

    private void closeConnectionQuietly() {
        HttpURLConnection httpURLConnection = this.connection;
        if (httpURLConnection != null) {
            try {
                httpURLConnection.disconnect();
            } catch (Throwable e) {
                Log.e(TAG, "Unexpected error while disconnecting", e);
            }
            this.connection = null;
        }
    }
}
