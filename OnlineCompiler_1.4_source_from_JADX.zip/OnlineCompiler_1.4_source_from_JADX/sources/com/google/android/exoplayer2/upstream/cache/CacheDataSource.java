package com.google.android.exoplayer2.upstream.cache;

import android.net.Uri;
import android.support.annotation.Nullable;
import com.google.android.exoplayer2.upstream.DataSink;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DataSourceException;
import com.google.android.exoplayer2.upstream.DataSpec;
import com.google.android.exoplayer2.upstream.FileDataSource;
import com.google.android.exoplayer2.upstream.TeeDataSource;
import com.google.android.exoplayer2.upstream.cache.Cache.CacheException;
import java.io.IOException;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class CacheDataSource implements DataSource {
    public static final long DEFAULT_MAX_CACHE_FILE_SIZE = 2097152;
    public static final int FLAG_BLOCK_ON_CACHE = 1;
    public static final int FLAG_IGNORE_CACHE_FOR_UNSET_LENGTH_REQUESTS = 4;
    public static final int FLAG_IGNORE_CACHE_ON_ERROR = 2;
    private final boolean blockOnCache;
    private long bytesRemaining;
    private final Cache cache;
    private final DataSource cacheReadDataSource;
    private final DataSource cacheWriteDataSource;
    private DataSource currentDataSource;
    private boolean currentRequestIgnoresCache;
    private boolean currentRequestUnbounded;
    @Nullable
    private final EventListener eventListener;
    private int flags;
    private final boolean ignoreCacheForUnsetLengthRequests;
    private final boolean ignoreCacheOnError;
    private String key;
    private CacheSpan lockedSpan;
    private long readPosition;
    private boolean seenCacheError;
    private long totalCachedBytesRead;
    private final DataSource upstreamDataSource;
    private Uri uri;

    public interface EventListener {
        void onCachedBytesRead(long j, long j2);
    }

    @Retention(RetentionPolicy.SOURCE)
    public @interface Flags {
    }

    private boolean openNextSource(boolean r17) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:61:0x00f6 in {2, 7, 9, 10, 13, 18, 19, 20, 23, 26, 27, 30, 31, 34, 35, 39, 50, 51, 53, 58, 59, 60} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r16 = this;
        r1 = r16;
        r0 = r1.currentRequestIgnoresCache;
        r2 = 0;
        if (r0 == 0) goto L_0x0009;
    L_0x0007:
        r0 = r2;
        goto L_0x0028;
    L_0x0009:
        r0 = r1.blockOnCache;
        if (r0 == 0) goto L_0x001e;
    L_0x000d:
        r0 = r1.cache;	 Catch:{ InterruptedException -> 0x0018 }
        r3 = r1.key;	 Catch:{ InterruptedException -> 0x0018 }
        r4 = r1.readPosition;	 Catch:{ InterruptedException -> 0x0018 }
        r0 = r0.startReadWrite(r3, r4);	 Catch:{ InterruptedException -> 0x0018 }
        goto L_0x0028;
    L_0x0018:
        r0 = new java.io.InterruptedIOException;
        r0.<init>();
        throw r0;
    L_0x001e:
        r0 = r1.cache;
        r3 = r1.key;
        r4 = r1.readPosition;
        r0 = r0.startReadWriteNonBlocking(r3, r4);
    L_0x0028:
        r3 = -1;
        if (r0 != 0) goto L_0x0042;
    L_0x002c:
        r0 = r1.upstreamDataSource;
        r1.currentDataSource = r0;
        r0 = new com.google.android.exoplayer2.upstream.DataSpec;
        r6 = r1.uri;
        r7 = r1.readPosition;
        r9 = r1.bytesRemaining;
        r11 = r1.key;
        r12 = r1.flags;
        r5 = r0;
        r5.<init>(r6, r7, r9, r11, r12);
        goto L_0x00ad;
    L_0x0042:
        r5 = r0.isCached;
        if (r5 == 0) goto L_0x0074;
    L_0x0046:
        r5 = r0.file;
        r7 = android.net.Uri.fromFile(r5);
        r5 = r1.readPosition;
        r8 = r0.position;
        r10 = r5 - r8;
        r5 = r0.length;
        r5 = r5 - r10;
        r8 = r1.bytesRemaining;
        r0 = (r8 > r3 ? 1 : (r8 == r3 ? 0 : -1));
        if (r0 == 0) goto L_0x0061;
    L_0x005b:
        r5 = java.lang.Math.min(r5, r8);
        r12 = r5;
        goto L_0x0062;
    L_0x0061:
        r12 = r5;
    L_0x0062:
        r0 = new com.google.android.exoplayer2.upstream.DataSpec;
        r8 = r1.readPosition;
        r14 = r1.key;
        r15 = r1.flags;
        r6 = r0;
        r6.<init>(r7, r8, r10, r12, r14, r15);
        r5 = r1.cacheReadDataSource;
        r1.currentDataSource = r5;
        r5 = r0;
        goto L_0x00ad;
    L_0x0074:
        r5 = r0.isOpenEnded();
        if (r5 == 0) goto L_0x007e;
    L_0x007a:
        r5 = r1.bytesRemaining;
        r11 = r5;
        goto L_0x008d;
    L_0x007e:
        r5 = r0.length;
        r7 = r1.bytesRemaining;
        r9 = (r7 > r3 ? 1 : (r7 == r3 ? 0 : -1));
        if (r9 == 0) goto L_0x008c;
    L_0x0086:
        r5 = java.lang.Math.min(r5, r7);
        r11 = r5;
        goto L_0x008d;
    L_0x008c:
        r11 = r5;
    L_0x008d:
        r5 = new com.google.android.exoplayer2.upstream.DataSpec;
        r8 = r1.uri;
        r9 = r1.readPosition;
        r13 = r1.key;
        r14 = r1.flags;
        r7 = r5;
        r7.<init>(r8, r9, r11, r13, r14);
        r6 = r1.cacheWriteDataSource;
        if (r6 == 0) goto L_0x00a4;
    L_0x009f:
        r1.currentDataSource = r6;
        r1.lockedSpan = r0;
        goto L_0x00ad;
    L_0x00a4:
        r6 = r1.upstreamDataSource;
        r1.currentDataSource = r6;
        r6 = r1.cache;
        r6.releaseHoleSpan(r0);
    L_0x00ad:
        r6 = r5.length;
        r0 = 1;
        r8 = 0;
        r9 = (r6 > r3 ? 1 : (r6 == r3 ? 0 : -1));
        if (r9 != 0) goto L_0x00b7;
    L_0x00b5:
        r6 = 1;
        goto L_0x00b8;
    L_0x00b7:
        r6 = 0;
    L_0x00b8:
        r1.currentRequestUnbounded = r6;
        r6 = 0;
        r9 = r1.currentDataSource;	 Catch:{ IOException -> 0x00c3 }
        r6 = r9.open(r5);	 Catch:{ IOException -> 0x00c3 }
        goto L_0x00e2;
    L_0x00c3:
        r0 = move-exception;
        if (r17 != 0) goto L_0x00df;
    L_0x00c6:
        r9 = r1.currentRequestUnbounded;
        if (r9 == 0) goto L_0x00df;
    L_0x00ca:
        r9 = r0;
    L_0x00cb:
        if (r9 == 0) goto L_0x00df;
    L_0x00cd:
        r10 = r9 instanceof com.google.android.exoplayer2.upstream.DataSourceException;
        if (r10 == 0) goto L_0x00da;
    L_0x00d1:
        r10 = r9;
        r10 = (com.google.android.exoplayer2.upstream.DataSourceException) r10;
        r10 = r10.reason;
        if (r10 != 0) goto L_0x00da;
    L_0x00d8:
        r0 = r2;
        goto L_0x00df;
    L_0x00da:
        r9 = r9.getCause();
        goto L_0x00cb;
    L_0x00df:
        if (r0 != 0) goto L_0x00f5;
    L_0x00e1:
        r0 = 0;
    L_0x00e2:
        r2 = r1.currentRequestUnbounded;
        if (r2 == 0) goto L_0x00f4;
    L_0x00e6:
        r2 = (r6 > r3 ? 1 : (r6 == r3 ? 0 : -1));
        if (r2 == 0) goto L_0x00f4;
    L_0x00ea:
        r1.bytesRemaining = r6;
        r2 = r5.position;
        r4 = r1.bytesRemaining;
        r2 = r2 + r4;
        r1.setContentLength(r2);
    L_0x00f4:
        return r0;
    L_0x00f5:
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.upstream.cache.CacheDataSource.openNextSource(boolean):boolean");
    }

    public CacheDataSource(Cache cache, DataSource dataSource) {
        this(cache, dataSource, 0, 2097152);
    }

    public CacheDataSource(Cache cache, DataSource dataSource, int i) {
        this(cache, dataSource, i, 2097152);
    }

    public CacheDataSource(Cache cache, DataSource dataSource, int i, long j) {
        this(cache, dataSource, new FileDataSource(), new CacheDataSink(cache, j), i, null);
    }

    public CacheDataSource(Cache cache, DataSource dataSource, DataSource dataSource2, DataSink dataSink, int i, @Nullable EventListener eventListener) {
        this.cache = cache;
        this.cacheReadDataSource = dataSource2;
        dataSource2 = null;
        this.blockOnCache = (i & 1) != null ? true : null;
        this.ignoreCacheOnError = (i & 2) != null ? true : null;
        if ((i & 4) != null) {
            dataSource2 = true;
        }
        this.ignoreCacheForUnsetLengthRequests = dataSource2;
        this.upstreamDataSource = dataSource;
        if (dataSink != null) {
            this.cacheWriteDataSource = new TeeDataSource(dataSource, dataSink);
        } else {
            this.cacheWriteDataSource = null;
        }
        this.eventListener = eventListener;
    }

    public long open(DataSpec dataSpec) throws IOException {
        try {
            this.uri = dataSpec.uri;
            this.flags = dataSpec.flags;
            this.key = CacheUtil.getKey(dataSpec);
            this.readPosition = dataSpec.position;
            boolean z = (this.ignoreCacheOnError && this.seenCacheError) || (dataSpec.length == -1 && this.ignoreCacheForUnsetLengthRequests);
            this.currentRequestIgnoresCache = z;
            if (dataSpec.length == -1) {
                if (!this.currentRequestIgnoresCache) {
                    this.bytesRemaining = this.cache.getContentLength(this.key);
                    if (this.bytesRemaining != -1) {
                        this.bytesRemaining -= dataSpec.position;
                        if (this.bytesRemaining <= 0) {
                            throw new DataSourceException(0);
                        }
                    }
                    openNextSource(true);
                    return this.bytesRemaining;
                }
            }
            this.bytesRemaining = dataSpec.length;
            openNextSource(true);
            return this.bytesRemaining;
        } catch (DataSpec dataSpec2) {
            handleBeforeThrow(dataSpec2);
            throw dataSpec2;
        }
    }

    public int read(byte[] bArr, int i, int i2) throws IOException {
        if (i2 == 0) {
            return 0;
        }
        if (this.bytesRemaining == 0) {
            return -1;
        }
        try {
            int read = this.currentDataSource.read(bArr, i, i2);
            if (read >= 0) {
                if (this.currentDataSource == this.cacheReadDataSource) {
                    this.totalCachedBytesRead += (long) read;
                }
                long j = (long) read;
                this.readPosition += j;
                if (this.bytesRemaining != -1) {
                    this.bytesRemaining -= j;
                }
            } else {
                if (this.currentRequestUnbounded) {
                    setContentLength(this.readPosition);
                    this.bytesRemaining = 0;
                }
                closeCurrentSource();
                if ((this.bytesRemaining > 0 || this.bytesRemaining == -1) && openNextSource(false)) {
                    return read(bArr, i, i2);
                }
            }
            return read;
        } catch (byte[] bArr2) {
            handleBeforeThrow(bArr2);
            throw bArr2;
        }
    }

    public Uri getUri() {
        DataSource dataSource = this.currentDataSource;
        return dataSource == this.upstreamDataSource ? dataSource.getUri() : this.uri;
    }

    public void close() throws IOException {
        this.uri = null;
        notifyBytesRead();
        try {
            closeCurrentSource();
        } catch (IOException e) {
            handleBeforeThrow(e);
            throw e;
        }
    }

    private void setContentLength(long j) throws IOException {
        if (this.currentDataSource == this.cacheWriteDataSource) {
            this.cache.setContentLength(this.key, j);
        }
    }

    private void closeCurrentSource() throws IOException {
        DataSource dataSource = this.currentDataSource;
        if (dataSource != null) {
            try {
                dataSource.close();
                this.currentDataSource = null;
                this.currentRequestUnbounded = false;
            } finally {
                CacheSpan cacheSpan = this.lockedSpan;
                if (cacheSpan != null) {
                    this.cache.releaseHoleSpan(cacheSpan);
                    this.lockedSpan = null;
                }
            }
        }
    }

    private void handleBeforeThrow(IOException iOException) {
        if (this.currentDataSource == this.cacheReadDataSource || (iOException instanceof CacheException) != null) {
            this.seenCacheError = true;
        }
    }

    private void notifyBytesRead() {
        EventListener eventListener = this.eventListener;
        if (eventListener != null && this.totalCachedBytesRead > 0) {
            eventListener.onCachedBytesRead(this.cache.getCacheSpace(), this.totalCachedBytesRead);
            this.totalCachedBytesRead = 0;
        }
    }
}
