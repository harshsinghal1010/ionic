package com.google.android.exoplayer2;

public final class FormatHolder {
    public Format format;
}
