package com.google.android.exoplayer2.video;

import android.annotation.TargetApi;
import android.graphics.SurfaceTexture;
import android.graphics.SurfaceTexture.OnFrameAvailableListener;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.view.Surface;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.Util;

@TargetApi(17)
public final class DummySurface extends Surface {
    private static final int EGL_PROTECTED_CONTENT_EXT = 12992;
    public static final boolean SECURE_SUPPORTED;
    private static final String TAG = "DummySurface";
    public final boolean secure;
    private final DummySurfaceThread thread;
    private boolean threadReleased;

    private static class DummySurfaceThread extends HandlerThread implements OnFrameAvailableListener, Callback {
        private static final int MSG_INIT = 1;
        private static final int MSG_RELEASE = 3;
        private static final int MSG_UPDATE_TEXTURE = 2;
        private Handler handler;
        private Error initError;
        private RuntimeException initException;
        private DummySurface surface;
        private SurfaceTexture surfaceTexture;
        private final int[] textureIdHolder = new int[1];

        public boolean handleMessage(android.os.Message r4) {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:64:0x0068 in {2, 4, 11, 12, 14, 16, 20, 21, 27, 30, 40, 43, 50, 51, 54, 59, 63} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
            /*
            r3 = this;
            r0 = r4.what;
            r1 = 1;
            switch(r0) {
                case 1: goto L_0x0024;
                case 2: goto L_0x001e;
                case 3: goto L_0x0007;
                default: goto L_0x0006;
            };
        L_0x0006:
            return r1;
        L_0x0007:
            r3.releaseInternal();	 Catch:{ Throwable -> 0x0010 }
        L_0x000a:
            r3.quit();
            goto L_0x0019;
        L_0x000e:
            r4 = move-exception;
            goto L_0x001a;
        L_0x0010:
            r4 = move-exception;
            r0 = "DummySurface";	 Catch:{ all -> 0x000e }
            r2 = "Failed to release dummy surface";	 Catch:{ all -> 0x000e }
            android.util.Log.e(r0, r2, r4);	 Catch:{ all -> 0x000e }
            goto L_0x000a;
        L_0x0019:
            return r1;
        L_0x001a:
            r3.quit();
            throw r4;
        L_0x001e:
            r4 = r3.surfaceTexture;
            r4.updateTexImage();
            return r1;
        L_0x0024:
            r4 = r4.arg1;	 Catch:{ RuntimeException -> 0x004c, Error -> 0x0039 }
            if (r4 == 0) goto L_0x002a;	 Catch:{ RuntimeException -> 0x004c, Error -> 0x0039 }
        L_0x0028:
            r4 = 1;	 Catch:{ RuntimeException -> 0x004c, Error -> 0x0039 }
            goto L_0x002b;	 Catch:{ RuntimeException -> 0x004c, Error -> 0x0039 }
        L_0x002a:
            r4 = 0;	 Catch:{ RuntimeException -> 0x004c, Error -> 0x0039 }
        L_0x002b:
            r3.initInternal(r4);	 Catch:{ RuntimeException -> 0x004c, Error -> 0x0039 }
            monitor-enter(r3);
            r3.notify();	 Catch:{ all -> 0x0034 }
            monitor-exit(r3);	 Catch:{ all -> 0x0034 }
            goto L_0x005b;	 Catch:{ all -> 0x0034 }
        L_0x0034:
            r4 = move-exception;	 Catch:{ all -> 0x0034 }
            monitor-exit(r3);	 Catch:{ all -> 0x0034 }
            throw r4;
        L_0x0037:
            r4 = move-exception;
            goto L_0x005f;
        L_0x0039:
            r4 = move-exception;
            r0 = "DummySurface";	 Catch:{ all -> 0x0037 }
            r2 = "Failed to initialize dummy surface";	 Catch:{ all -> 0x0037 }
            android.util.Log.e(r0, r2, r4);	 Catch:{ all -> 0x0037 }
            r3.initError = r4;	 Catch:{ all -> 0x0037 }
            monitor-enter(r3);
            r3.notify();	 Catch:{ all -> 0x0049 }
            monitor-exit(r3);	 Catch:{ all -> 0x0049 }
            goto L_0x005b;	 Catch:{ all -> 0x0049 }
        L_0x0049:
            r4 = move-exception;	 Catch:{ all -> 0x0049 }
            monitor-exit(r3);	 Catch:{ all -> 0x0049 }
            throw r4;
        L_0x004c:
            r4 = move-exception;
            r0 = "DummySurface";	 Catch:{ all -> 0x0037 }
            r2 = "Failed to initialize dummy surface";	 Catch:{ all -> 0x0037 }
            android.util.Log.e(r0, r2, r4);	 Catch:{ all -> 0x0037 }
            r3.initException = r4;	 Catch:{ all -> 0x0037 }
            monitor-enter(r3);
            r3.notify();	 Catch:{ all -> 0x005c }
            monitor-exit(r3);	 Catch:{ all -> 0x005c }
        L_0x005b:
            return r1;	 Catch:{ all -> 0x005c }
        L_0x005c:
            r4 = move-exception;	 Catch:{ all -> 0x005c }
            monitor-exit(r3);	 Catch:{ all -> 0x005c }
            throw r4;
        L_0x005f:
            monitor-enter(r3);
            r3.notify();	 Catch:{ all -> 0x0065 }
            monitor-exit(r3);	 Catch:{ all -> 0x0065 }
            throw r4;
        L_0x0065:
            r4 = move-exception;
            monitor-exit(r3);	 Catch:{ all -> 0x0065 }
            throw r4;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.video.DummySurface.DummySurfaceThread.handleMessage(android.os.Message):boolean");
        }

        public com.google.android.exoplayer2.video.DummySurface init(boolean r4) {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:34:0x004b in {5, 6, 16, 17, 21, 27, 28, 29, 33} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
            /*
            r3 = this;
            r3.start();
            r0 = new android.os.Handler;
            r1 = r3.getLooper();
            r0.<init>(r1, r3);
            r3.handler = r0;
            monitor-enter(r3);
            r0 = r3.handler;	 Catch:{ all -> 0x0048 }
            r1 = 1;	 Catch:{ all -> 0x0048 }
            r2 = 0;	 Catch:{ all -> 0x0048 }
            if (r4 == 0) goto L_0x0017;	 Catch:{ all -> 0x0048 }
        L_0x0015:
            r4 = 1;	 Catch:{ all -> 0x0048 }
            goto L_0x0018;	 Catch:{ all -> 0x0048 }
        L_0x0017:
            r4 = 0;	 Catch:{ all -> 0x0048 }
        L_0x0018:
            r4 = r0.obtainMessage(r1, r4, r2);	 Catch:{ all -> 0x0048 }
            r4.sendToTarget();	 Catch:{ all -> 0x0048 }
        L_0x001f:
            r4 = r3.surface;	 Catch:{ all -> 0x0048 }
            if (r4 != 0) goto L_0x0031;	 Catch:{ all -> 0x0048 }
        L_0x0023:
            r4 = r3.initException;	 Catch:{ all -> 0x0048 }
            if (r4 != 0) goto L_0x0031;	 Catch:{ all -> 0x0048 }
        L_0x0027:
            r4 = r3.initError;	 Catch:{ all -> 0x0048 }
            if (r4 != 0) goto L_0x0031;
        L_0x002b:
            r3.wait();	 Catch:{ InterruptedException -> 0x002f }
            goto L_0x001f;
        L_0x002f:
            r2 = 1;
            goto L_0x001f;
        L_0x0031:
            monitor-exit(r3);	 Catch:{ all -> 0x0048 }
            if (r2 == 0) goto L_0x003b;
        L_0x0034:
            r4 = java.lang.Thread.currentThread();
            r4.interrupt();
        L_0x003b:
            r4 = r3.initException;
            if (r4 != 0) goto L_0x0047;
        L_0x003f:
            r4 = r3.initError;
            if (r4 != 0) goto L_0x0046;
        L_0x0043:
            r4 = r3.surface;
            return r4;
        L_0x0046:
            throw r4;
        L_0x0047:
            throw r4;
        L_0x0048:
            r4 = move-exception;
            monitor-exit(r3);	 Catch:{ all -> 0x0048 }
            throw r4;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.video.DummySurface.DummySurfaceThread.init(boolean):com.google.android.exoplayer2.video.DummySurface");
        }

        public DummySurfaceThread() {
            super("dummySurface");
        }

        public void release() {
            this.handler.sendEmptyMessage(3);
        }

        public void onFrameAvailable(SurfaceTexture surfaceTexture) {
            this.handler.sendEmptyMessage(2);
        }

        private void initInternal(boolean z) {
            int[] iArr;
            int[] iArr2;
            EGLDisplay eglGetDisplay = EGL14.eglGetDisplay(0);
            Assertions.checkState(eglGetDisplay != null, "eglGetDisplay failed");
            int[] iArr3 = new int[2];
            Assertions.checkState(EGL14.eglInitialize(eglGetDisplay, iArr3, 0, iArr3, 1), "eglInitialize failed");
            EGLConfig[] eGLConfigArr = new EGLConfig[1];
            int[] iArr4 = new int[1];
            boolean z2 = EGL14.eglChooseConfig(eglGetDisplay, new int[]{12352, 4, 12324, 8, 12323, 8, 12322, 8, 12321, 8, 12325, 0, 12327, 12344, 12339, 4, 12344}, 0, eGLConfigArr, 0, 1, iArr4, 0) && iArr4[0] > 0 && eGLConfigArr[0] != null;
            Assertions.checkState(z2, "eglChooseConfig failed");
            EGLConfig eGLConfig = eGLConfigArr[0];
            if (z) {
                iArr = new int[]{12440, 2, DummySurface.EGL_PROTECTED_CONTENT_EXT, 1, 12344};
            } else {
                iArr = new int[]{12440, 2, 12344};
            }
            EGLContext eglCreateContext = EGL14.eglCreateContext(eglGetDisplay, eGLConfig, EGL14.EGL_NO_CONTEXT, iArr, 0);
            Assertions.checkState(eglCreateContext != null, "eglCreateContext failed");
            if (z) {
                iArr2 = new int[]{12375, 1, 12374, 1, DummySurface.EGL_PROTECTED_CONTENT_EXT, 1, 12344};
            } else {
                iArr2 = new int[]{12375, 1, 12374, 1, 12344};
            }
            EGLSurface eglCreatePbufferSurface = EGL14.eglCreatePbufferSurface(eglGetDisplay, eGLConfig, iArr2, 0);
            Assertions.checkState(eglCreatePbufferSurface != null, "eglCreatePbufferSurface failed");
            Assertions.checkState(EGL14.eglMakeCurrent(eglGetDisplay, eglCreatePbufferSurface, eglCreatePbufferSurface, eglCreateContext), "eglMakeCurrent failed");
            GLES20.glGenTextures(1, this.textureIdHolder, 0);
            this.surfaceTexture = new SurfaceTexture(this.textureIdHolder[0]);
            this.surfaceTexture.setOnFrameAvailableListener(this);
            this.surface = new DummySurface(this, this.surfaceTexture, z);
        }

        private void releaseInternal() {
            try {
                this.surfaceTexture.release();
            } finally {
                this.surface = null;
                this.surfaceTexture = null;
                GLES20.glDeleteTextures(1, this.textureIdHolder, 0);
            }
        }
    }

    static {
        boolean z = false;
        if (Util.SDK_INT >= 17) {
            String eglQueryString = EGL14.eglQueryString(EGL14.eglGetDisplay(0), 12373);
            if (eglQueryString != null && eglQueryString.contains("EGL_EXT_protected_content")) {
                z = true;
            }
            SECURE_SUPPORTED = z;
            return;
        }
        SECURE_SUPPORTED = false;
    }

    public static DummySurface newInstanceV17(boolean z) {
        boolean z2;
        assertApiLevel17OrHigher();
        if (z) {
            if (!SECURE_SUPPORTED) {
                z2 = false;
                Assertions.checkState(z2);
                return new DummySurfaceThread().init(z);
            }
        }
        z2 = true;
        Assertions.checkState(z2);
        return new DummySurfaceThread().init(z);
    }

    private DummySurface(DummySurfaceThread dummySurfaceThread, SurfaceTexture surfaceTexture, boolean z) {
        super(surfaceTexture);
        this.thread = dummySurfaceThread;
        this.secure = z;
    }

    public void release() {
        super.release();
        synchronized (this.thread) {
            if (!this.threadReleased) {
                this.thread.release();
                this.threadReleased = true;
            }
        }
    }

    private static void assertApiLevel17OrHigher() {
        if (Util.SDK_INT < 17) {
            throw new UnsupportedOperationException("Unsupported prior to API level 17");
        }
    }
}
