package com.google.android.exoplayer2.audio;

import android.annotation.TargetApi;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Handler;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.audio.AudioRendererEventListener.EventDispatcher;
import com.google.android.exoplayer2.audio.AudioTrack.Listener;
import com.google.android.exoplayer2.drm.DrmSessionManager;
import com.google.android.exoplayer2.drm.FrameworkMediaCrypto;
import com.google.android.exoplayer2.mediacodec.MediaCodecInfo;
import com.google.android.exoplayer2.mediacodec.MediaCodecRenderer;
import com.google.android.exoplayer2.mediacodec.MediaCodecSelector;
import com.google.android.exoplayer2.mediacodec.MediaCodecUtil.DecoderQueryException;
import com.google.android.exoplayer2.util.MediaClock;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.exoplayer2.util.Util;
import java.nio.ByteBuffer;

@TargetApi(16)
public class MediaCodecAudioRenderer extends MediaCodecRenderer implements MediaClock {
    private boolean allowPositionDiscontinuity;
    private final AudioTrack audioTrack;
    private int channelCount;
    private boolean codecNeedsDiscardChannelsWorkaround;
    private long currentPositionUs;
    private final EventDispatcher eventDispatcher;
    private boolean passthroughEnabled;
    private MediaFormat passthroughMediaFormat;
    private int pcmEncoding;

    private final class AudioTrackListener implements Listener {
        private AudioTrackListener() {
        }

        public void onAudioSessionId(int i) {
            MediaCodecAudioRenderer.this.eventDispatcher.audioSessionId(i);
            MediaCodecAudioRenderer.this.onAudioSessionId(i);
        }

        public void onPositionDiscontinuity() {
            MediaCodecAudioRenderer.this.onAudioTrackPositionDiscontinuity();
            MediaCodecAudioRenderer.this.allowPositionDiscontinuity = true;
        }

        public void onUnderrun(int i, long j, long j2) {
            MediaCodecAudioRenderer.this.eventDispatcher.audioTrackUnderrun(i, j, j2);
            MediaCodecAudioRenderer.this.onAudioTrackUnderrun(i, j, j2);
        }
    }

    public MediaClock getMediaClock() {
        return this;
    }

    protected void onAudioSessionId(int i) {
    }

    protected void onAudioTrackPositionDiscontinuity() {
    }

    protected void onAudioTrackUnderrun(int i, long j, long j2) {
    }

    protected void onOutputFormatChanged(android.media.MediaCodec r10, android.media.MediaFormat r11) throws com.google.android.exoplayer2.ExoPlaybackException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:28:0x0053 in {2, 3, 5, 6, 9, 19, 20, 21, 24, 27} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r9 = this;
        r10 = r9.passthroughMediaFormat;
        r0 = 0;
        if (r10 == 0) goto L_0x0007;
    L_0x0005:
        r10 = 1;
        goto L_0x0008;
    L_0x0007:
        r10 = 0;
    L_0x0008:
        if (r10 == 0) goto L_0x0013;
    L_0x000a:
        r1 = r9.passthroughMediaFormat;
        r2 = "mime";
        r1 = r1.getString(r2);
        goto L_0x0015;
    L_0x0013:
        r1 = "audio/raw";
    L_0x0015:
        r3 = r1;
        if (r10 == 0) goto L_0x001a;
    L_0x0018:
        r11 = r9.passthroughMediaFormat;
    L_0x001a:
        r10 = "channel-count";
        r4 = r11.getInteger(r10);
        r10 = "sample-rate";
        r5 = r11.getInteger(r10);
        r10 = r9.codecNeedsDiscardChannelsWorkaround;
        if (r10 == 0) goto L_0x003e;
    L_0x002a:
        r10 = 6;
        if (r4 != r10) goto L_0x003e;
    L_0x002d:
        r11 = r9.channelCount;
        if (r11 >= r10) goto L_0x003e;
    L_0x0031:
        r10 = new int[r11];
    L_0x0033:
        r11 = r9.channelCount;
        if (r0 >= r11) goto L_0x003c;
    L_0x0037:
        r10[r0] = r0;
        r0 = r0 + 1;
        goto L_0x0033;
    L_0x003c:
        r8 = r10;
        goto L_0x0040;
    L_0x003e:
        r10 = 0;
        r8 = r10;
    L_0x0040:
        r2 = r9.audioTrack;	 Catch:{ ConfigurationException -> 0x0049 }
        r6 = r9.pcmEncoding;	 Catch:{ ConfigurationException -> 0x0049 }
        r7 = 0;	 Catch:{ ConfigurationException -> 0x0049 }
        r2.configure(r3, r4, r5, r6, r7, r8);	 Catch:{ ConfigurationException -> 0x0049 }
        return;
    L_0x0049:
        r10 = move-exception;
        r11 = r9.getIndex();
        r10 = com.google.android.exoplayer2.ExoPlaybackException.createForRenderer(r10, r11);
        throw r10;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.audio.MediaCodecAudioRenderer.onOutputFormatChanged(android.media.MediaCodec, android.media.MediaFormat):void");
    }

    public MediaCodecAudioRenderer(MediaCodecSelector mediaCodecSelector) {
        this(mediaCodecSelector, null, true);
    }

    public MediaCodecAudioRenderer(MediaCodecSelector mediaCodecSelector, DrmSessionManager<FrameworkMediaCrypto> drmSessionManager, boolean z) {
        this(mediaCodecSelector, drmSessionManager, z, null, null);
    }

    public MediaCodecAudioRenderer(MediaCodecSelector mediaCodecSelector, Handler handler, AudioRendererEventListener audioRendererEventListener) {
        this(mediaCodecSelector, null, true, handler, audioRendererEventListener);
    }

    public MediaCodecAudioRenderer(MediaCodecSelector mediaCodecSelector, DrmSessionManager<FrameworkMediaCrypto> drmSessionManager, boolean z, Handler handler, AudioRendererEventListener audioRendererEventListener) {
        this(mediaCodecSelector, drmSessionManager, z, handler, audioRendererEventListener, null, new AudioProcessor[0]);
    }

    public MediaCodecAudioRenderer(MediaCodecSelector mediaCodecSelector, DrmSessionManager<FrameworkMediaCrypto> drmSessionManager, boolean z, Handler handler, AudioRendererEventListener audioRendererEventListener, AudioCapabilities audioCapabilities, AudioProcessor... audioProcessorArr) {
        super(1, mediaCodecSelector, drmSessionManager, z);
        this.audioTrack = new AudioTrack(audioCapabilities, audioProcessorArr, new AudioTrackListener());
        this.eventDispatcher = new EventDispatcher(handler, audioRendererEventListener);
    }

    protected int supportsFormat(MediaCodecSelector mediaCodecSelector, Format format) throws DecoderQueryException {
        String str = format.sampleMimeType;
        if (!MimeTypes.isAudio(str)) {
            return 0;
        }
        int i = Util.SDK_INT >= 21 ? 16 : 0;
        int i2 = 3;
        if (allowPassthrough(str) && mediaCodecSelector.getPassthroughDecoderInfo() != null) {
            return (i | 4) | 3;
        }
        mediaCodecSelector = mediaCodecSelector.getDecoderInfo(str, false);
        int i3 = 1;
        if (mediaCodecSelector == null) {
            return 1;
        }
        if (Util.SDK_INT >= 21) {
            if (format.sampleRate == -1 || mediaCodecSelector.isAudioSampleRateSupportedV21(format.sampleRate)) {
                if (format.channelCount != -1) {
                    if (mediaCodecSelector.isAudioChannelCountSupportedV21(format.channelCount) != null) {
                    }
                }
            }
            i3 = 0;
        }
        if (i3 == 0) {
            i2 = 2;
        }
        return (i | 4) | i2;
    }

    protected MediaCodecInfo getDecoderInfo(MediaCodecSelector mediaCodecSelector, Format format, boolean z) throws DecoderQueryException {
        if (allowPassthrough(format.sampleMimeType)) {
            MediaCodecInfo passthroughDecoderInfo = mediaCodecSelector.getPassthroughDecoderInfo();
            if (passthroughDecoderInfo != null) {
                this.passthroughEnabled = true;
                return passthroughDecoderInfo;
            }
        }
        this.passthroughEnabled = false;
        return super.getDecoderInfo(mediaCodecSelector, format, z);
    }

    protected boolean allowPassthrough(String str) {
        return this.audioTrack.isPassthroughSupported(str);
    }

    protected void configureCodec(MediaCodecInfo mediaCodecInfo, MediaCodec mediaCodec, Format format, MediaCrypto mediaCrypto) {
        this.codecNeedsDiscardChannelsWorkaround = codecNeedsDiscardChannelsWorkaround(mediaCodecInfo.name);
        if (this.passthroughEnabled != null) {
            this.passthroughMediaFormat = format.getFrameworkMediaFormatV16();
            this.passthroughMediaFormat.setString("mime", MimeTypes.AUDIO_RAW);
            mediaCodec.configure(this.passthroughMediaFormat, null, mediaCrypto, 0);
            this.passthroughMediaFormat.setString("mime", format.sampleMimeType);
            return;
        }
        mediaCodec.configure(format.getFrameworkMediaFormatV16(), null, mediaCrypto, 0);
        this.passthroughMediaFormat = null;
    }

    protected void onCodecInitialized(String str, long j, long j2) {
        this.eventDispatcher.decoderInitialized(str, j, j2);
    }

    protected void onInputFormatChanged(Format format) throws ExoPlaybackException {
        super.onInputFormatChanged(format);
        this.eventDispatcher.inputFormatChanged(format);
        this.pcmEncoding = MimeTypes.AUDIO_RAW.equals(format.sampleMimeType) ? format.pcmEncoding : 2;
        this.channelCount = format.channelCount;
    }

    protected void onEnabled(boolean z) throws ExoPlaybackException {
        super.onEnabled(z);
        this.eventDispatcher.enabled(this.decoderCounters);
        z = getConfiguration().tunnelingAudioSessionId;
        if (z) {
            this.audioTrack.enableTunnelingV21(z);
        } else {
            this.audioTrack.disableTunneling();
        }
    }

    protected void onPositionReset(long j, boolean z) throws ExoPlaybackException {
        super.onPositionReset(j, z);
        this.audioTrack.reset();
        this.currentPositionUs = j;
        this.allowPositionDiscontinuity = 1;
    }

    protected void onStarted() {
        super.onStarted();
        this.audioTrack.play();
    }

    protected void onStopped() {
        this.audioTrack.pause();
        super.onStopped();
    }

    protected void onDisabled() {
        try {
            this.audioTrack.release();
            try {
                super.onDisabled();
            } finally {
                this.decoderCounters.ensureUpdated();
                this.eventDispatcher.disabled(this.decoderCounters);
            }
        } catch (Throwable th) {
            super.onDisabled();
        } finally {
            this.decoderCounters.ensureUpdated();
            this.eventDispatcher.disabled(this.decoderCounters);
        }
    }

    public boolean isEnded() {
        return super.isEnded() && this.audioTrack.isEnded();
    }

    public boolean isReady() {
        if (!this.audioTrack.hasPendingData()) {
            if (!super.isReady()) {
                return false;
            }
        }
        return true;
    }

    public long getPositionUs() {
        long currentPositionUs = this.audioTrack.getCurrentPositionUs(isEnded());
        if (currentPositionUs != Long.MIN_VALUE) {
            if (!this.allowPositionDiscontinuity) {
                currentPositionUs = Math.max(this.currentPositionUs, currentPositionUs);
            }
            this.currentPositionUs = currentPositionUs;
            this.allowPositionDiscontinuity = false;
        }
        return this.currentPositionUs;
    }

    public PlaybackParameters setPlaybackParameters(PlaybackParameters playbackParameters) {
        return this.audioTrack.setPlaybackParameters(playbackParameters);
    }

    public PlaybackParameters getPlaybackParameters() {
        return this.audioTrack.getPlaybackParameters();
    }

    protected boolean processOutputBuffer(long j, long j2, MediaCodec mediaCodec, ByteBuffer byteBuffer, int i, int i2, long j3, boolean z) throws ExoPlaybackException {
        if (this.passthroughEnabled != null && (i2 & 2) != null) {
            mediaCodec.releaseOutputBuffer(i, false);
            return true;
        } else if (z) {
            mediaCodec.releaseOutputBuffer(i, false);
            j = this.decoderCounters;
            j.skippedOutputBufferCount++;
            this.audioTrack.handleDiscontinuity();
            return true;
        } else {
            try {
                if (this.audioTrack.handleBuffer(byteBuffer, j3) == null) {
                    return false;
                }
                mediaCodec.releaseOutputBuffer(i, false);
                j = this.decoderCounters;
                j.renderedOutputBufferCount++;
                return true;
            } catch (long j4) {
                throw ExoPlaybackException.createForRenderer(j4, getIndex());
            }
        }
    }

    protected void renderToEndOfStream() throws ExoPlaybackException {
        try {
            this.audioTrack.playToEndOfStream();
        } catch (Exception e) {
            throw ExoPlaybackException.createForRenderer(e, getIndex());
        }
    }

    public void handleMessage(int i, Object obj) throws ExoPlaybackException {
        switch (i) {
            case 2:
                this.audioTrack.setVolume(((Float) obj).floatValue());
                return;
            case 3:
                this.audioTrack.setStreamType(((Integer) obj).intValue());
                return;
            default:
                super.handleMessage(i, obj);
                return;
        }
    }

    private static boolean codecNeedsDiscardChannelsWorkaround(String str) {
        return (Util.SDK_INT >= 24 || "OMX.SEC.aac.dec".equals(str) == null || "samsung".equals(Util.MANUFACTURER) == null || (Util.DEVICE.startsWith("zeroflte") == null && Util.DEVICE.startsWith("herolte") == null && Util.DEVICE.startsWith("heroqlte") == null)) ? null : true;
    }
}
