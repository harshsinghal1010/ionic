package com.google.android.exoplayer2.audio;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.media.AudioAttributes.Builder;
import android.media.AudioFormat;
import android.media.AudioTimestamp;
import android.os.ConditionVariable;
import android.os.SystemClock;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import com.google.android.exoplayer2.C0361C;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.upstream.cache.CacheDataSink;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.exoplayer2.util.Util;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.LinkedList;

public final class AudioTrack {
    private static final int BUFFER_MULTIPLICATION_FACTOR = 4;
    public static final long CURRENT_POSITION_NOT_SET = Long.MIN_VALUE;
    private static final int ERROR_BAD_VALUE = -2;
    private static final long MAX_AUDIO_TIMESTAMP_OFFSET_US = 5000000;
    private static final long MAX_BUFFER_DURATION_US = 750000;
    private static final long MAX_LATENCY_US = 5000000;
    private static final int MAX_PLAYHEAD_OFFSET_COUNT = 10;
    private static final long MIN_BUFFER_DURATION_US = 250000;
    private static final int MIN_PLAYHEAD_OFFSET_SAMPLE_INTERVAL_US = 30000;
    private static final int MIN_TIMESTAMP_SAMPLE_INTERVAL_US = 500000;
    private static final int MODE_STATIC = 0;
    private static final int MODE_STREAM = 1;
    private static final long PASSTHROUGH_BUFFER_DURATION_US = 250000;
    private static final int PLAYSTATE_PAUSED = 2;
    private static final int PLAYSTATE_PLAYING = 3;
    private static final int PLAYSTATE_STOPPED = 1;
    private static final int SONIC_MIN_BYTES_FOR_SPEEDUP = 1024;
    private static final int START_IN_SYNC = 1;
    private static final int START_NEED_SYNC = 2;
    private static final int START_NOT_SET = 0;
    private static final int STATE_INITIALIZED = 1;
    private static final String TAG = "AudioTrack";
    @SuppressLint({"InlinedApi"})
    private static final int WRITE_NON_BLOCKING = 1;
    public static boolean enablePreV21AudioSessionWorkaround = false;
    public static boolean failOnSpuriousAudioTimestamp = false;
    private final AudioCapabilities audioCapabilities;
    private AudioProcessor[] audioProcessors;
    private int audioSessionId;
    private boolean audioTimestampSet;
    private android.media.AudioTrack audioTrack;
    private final AudioTrackUtil audioTrackUtil;
    private ByteBuffer avSyncHeader;
    private final AudioProcessor[] availableAudioProcessors;
    private int bufferSize;
    private long bufferSizeUs;
    private int bytesUntilNextAvSync;
    private int channelConfig;
    private final ChannelMappingAudioProcessor channelMappingAudioProcessor;
    private int drainingAudioProcessorIndex;
    private PlaybackParameters drainingPlaybackParameters;
    private int encoding;
    private int framesPerEncodedSample;
    private Method getLatencyMethod;
    private boolean handledEndOfStream;
    private boolean hasData;
    private ByteBuffer inputBuffer;
    private android.media.AudioTrack keepSessionIdAudioTrack;
    private long lastFeedElapsedRealtimeMs;
    private long lastPlayheadSampleTimeUs;
    private long lastTimestampSampleTimeUs;
    private long latencyUs;
    private final Listener listener;
    private int nextPlayheadOffsetIndex;
    private ByteBuffer outputBuffer;
    private ByteBuffer[] outputBuffers;
    private int outputEncoding;
    private int outputPcmFrameSize;
    private boolean passthrough;
    private int pcmFrameSize;
    private PlaybackParameters playbackParameters;
    private final LinkedList<PlaybackParametersCheckpoint> playbackParametersCheckpoints;
    private long playbackParametersOffsetUs;
    private long playbackParametersPositionUs;
    private int playheadOffsetCount;
    private final long[] playheadOffsets;
    private boolean playing;
    private byte[] preV21OutputBuffer;
    private int preV21OutputBufferOffset;
    private final ConditionVariable releasingConditionVariable = new ConditionVariable(true);
    private long resumeSystemTimeUs;
    private int sampleRate;
    private long smoothedPlayheadOffsetUs;
    private final SonicAudioProcessor sonicAudioProcessor;
    private int startMediaTimeState;
    private long startMediaTimeUs;
    private int streamType;
    private long submittedEncodedFrames;
    private long submittedPcmBytes;
    private boolean tunneling;
    private float volume;
    private long writtenEncodedFrames;
    private long writtenPcmBytes;

    private static class AudioTrackUtil {
        protected android.media.AudioTrack audioTrack;
        private long endPlaybackHeadPosition;
        private long lastRawPlaybackHeadPosition;
        private boolean needsPassthroughWorkaround;
        private long passthroughWorkaroundPauseOffset;
        private long rawPlaybackHeadWrapCount;
        private int sampleRate;
        private long stopPlaybackHeadPosition;
        private long stopTimestampUs;

        public boolean updateTimestamp() {
            return false;
        }

        private AudioTrackUtil() {
        }

        public void reconfigure(android.media.AudioTrack audioTrack, boolean z) {
            this.audioTrack = audioTrack;
            this.needsPassthroughWorkaround = z;
            this.stopTimestampUs = C0361C.TIME_UNSET;
            this.lastRawPlaybackHeadPosition = 0;
            this.rawPlaybackHeadWrapCount = 0;
            this.passthroughWorkaroundPauseOffset = 0;
            if (audioTrack != null) {
                this.sampleRate = audioTrack.getSampleRate();
            }
        }

        public void handleEndOfStream(long j) {
            this.stopPlaybackHeadPosition = getPlaybackHeadPosition();
            this.stopTimestampUs = SystemClock.elapsedRealtime() * 1000;
            this.endPlaybackHeadPosition = j;
            this.audioTrack.stop();
        }

        public void pause() {
            if (this.stopTimestampUs == C0361C.TIME_UNSET) {
                this.audioTrack.pause();
            }
        }

        public long getPlaybackHeadPosition() {
            if (this.stopTimestampUs != C0361C.TIME_UNSET) {
                return Math.min(this.endPlaybackHeadPosition, this.stopPlaybackHeadPosition + ((((SystemClock.elapsedRealtime() * 1000) - this.stopTimestampUs) * ((long) this.sampleRate)) / C0361C.MICROS_PER_SECOND));
            }
            int playState = this.audioTrack.getPlayState();
            if (playState == 1) {
                return 0;
            }
            long playbackHeadPosition = 4294967295L & ((long) this.audioTrack.getPlaybackHeadPosition());
            if (this.needsPassthroughWorkaround) {
                if (playState == 2 && playbackHeadPosition == 0) {
                    this.passthroughWorkaroundPauseOffset = this.lastRawPlaybackHeadPosition;
                }
                playbackHeadPosition += this.passthroughWorkaroundPauseOffset;
            }
            if (this.lastRawPlaybackHeadPosition > playbackHeadPosition) {
                this.rawPlaybackHeadWrapCount++;
            }
            this.lastRawPlaybackHeadPosition = playbackHeadPosition;
            return playbackHeadPosition + (this.rawPlaybackHeadWrapCount << 32);
        }

        public long getPositionUs() {
            return (getPlaybackHeadPosition() * C0361C.MICROS_PER_SECOND) / ((long) this.sampleRate);
        }

        public long getTimestampNanoTime() {
            throw new UnsupportedOperationException();
        }

        public long getTimestampFramePosition() {
            throw new UnsupportedOperationException();
        }
    }

    public static final class ConfigurationException extends Exception {
        public ConfigurationException(Throwable th) {
            super(th);
        }

        public ConfigurationException(String str) {
            super(str);
        }
    }

    public static final class InitializationException extends Exception {
        public final int audioTrackState;

        public InitializationException(int i, int i2, int i3, int i4) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("AudioTrack init failed: ");
            stringBuilder.append(i);
            stringBuilder.append(", Config(");
            stringBuilder.append(i2);
            stringBuilder.append(", ");
            stringBuilder.append(i3);
            stringBuilder.append(", ");
            stringBuilder.append(i4);
            stringBuilder.append(")");
            super(stringBuilder.toString());
            this.audioTrackState = i;
        }
    }

    public static final class InvalidAudioTrackTimestampException extends RuntimeException {
        public InvalidAudioTrackTimestampException(String str) {
            super(str);
        }
    }

    public interface Listener {
        void onAudioSessionId(int i);

        void onPositionDiscontinuity();

        void onUnderrun(int i, long j, long j2);
    }

    private static final class PlaybackParametersCheckpoint {
        private final long mediaTimeUs;
        private final PlaybackParameters playbackParameters;
        private final long positionUs;

        private PlaybackParametersCheckpoint(PlaybackParameters playbackParameters, long j, long j2) {
            this.playbackParameters = playbackParameters;
            this.mediaTimeUs = j;
            this.positionUs = j2;
        }
    }

    public static final class WriteException extends Exception {
        public final int errorCode;

        public WriteException(int i) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("AudioTrack write failed: ");
            stringBuilder.append(i);
            super(stringBuilder.toString());
            this.errorCode = i;
        }
    }

    @TargetApi(19)
    private static class AudioTrackUtilV19 extends AudioTrackUtil {
        private final AudioTimestamp audioTimestamp = new AudioTimestamp();
        private long lastRawTimestampFramePosition;
        private long lastTimestampFramePosition;
        private long rawTimestampFramePositionWrapCount;

        public AudioTrackUtilV19() {
            super();
        }

        public void reconfigure(android.media.AudioTrack audioTrack, boolean z) {
            super.reconfigure(audioTrack, z);
            this.rawTimestampFramePositionWrapCount = 0;
            this.lastRawTimestampFramePosition = 0;
            this.lastTimestampFramePosition = 0;
        }

        public boolean updateTimestamp() {
            boolean timestamp = this.audioTrack.getTimestamp(this.audioTimestamp);
            if (timestamp) {
                long j = this.audioTimestamp.framePosition;
                if (this.lastRawTimestampFramePosition > j) {
                    this.rawTimestampFramePositionWrapCount++;
                }
                this.lastRawTimestampFramePosition = j;
                this.lastTimestampFramePosition = j + (this.rawTimestampFramePositionWrapCount << 32);
            }
            return timestamp;
        }

        public long getTimestampNanoTime() {
            return this.audioTimestamp.nanoTime;
        }

        public long getTimestampFramePosition() {
            return this.lastTimestampFramePosition;
        }
    }

    public AudioTrack(com.google.android.exoplayer2.audio.AudioCapabilities r4, com.google.android.exoplayer2.audio.AudioProcessor[] r5, com.google.android.exoplayer2.audio.AudioTrack.Listener r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r3 = this;
        r3.<init>();
        r3.audioCapabilities = r4;
        r3.listener = r6;
        r4 = new android.os.ConditionVariable;
        r6 = 1;
        r4.<init>(r6);
        r3.releasingConditionVariable = r4;
        r4 = com.google.android.exoplayer2.util.Util.SDK_INT;
        r0 = 0;
        r1 = 18;
        if (r4 < r1) goto L_0x0025;
    L_0x0016:
        r4 = android.media.AudioTrack.class;	 Catch:{ NoSuchMethodException -> 0x0024 }
        r1 = "getLatency";	 Catch:{ NoSuchMethodException -> 0x0024 }
        r2 = r0;	 Catch:{ NoSuchMethodException -> 0x0024 }
        r2 = (java.lang.Class[]) r2;	 Catch:{ NoSuchMethodException -> 0x0024 }
        r4 = r4.getMethod(r1, r2);	 Catch:{ NoSuchMethodException -> 0x0024 }
        r3.getLatencyMethod = r4;	 Catch:{ NoSuchMethodException -> 0x0024 }
        goto L_0x0025;
    L_0x0025:
        r4 = com.google.android.exoplayer2.util.Util.SDK_INT;
        r1 = 19;
        if (r4 < r1) goto L_0x0033;
    L_0x002b:
        r4 = new com.google.android.exoplayer2.audio.AudioTrack$AudioTrackUtilV19;
        r4.<init>();
        r3.audioTrackUtil = r4;
        goto L_0x003a;
    L_0x0033:
        r4 = new com.google.android.exoplayer2.audio.AudioTrack$AudioTrackUtil;
        r4.<init>();
        r3.audioTrackUtil = r4;
    L_0x003a:
        r4 = new com.google.android.exoplayer2.audio.ChannelMappingAudioProcessor;
        r4.<init>();
        r3.channelMappingAudioProcessor = r4;
        r4 = new com.google.android.exoplayer2.audio.SonicAudioProcessor;
        r4.<init>();
        r3.sonicAudioProcessor = r4;
        r4 = r5.length;
        r0 = 3;
        r4 = r4 + r0;
        r4 = new com.google.android.exoplayer2.audio.AudioProcessor[r4];
        r3.availableAudioProcessors = r4;
        r4 = r3.availableAudioProcessors;
        r1 = new com.google.android.exoplayer2.audio.ResamplingAudioProcessor;
        r1.<init>();
        r2 = 0;
        r4[r2] = r1;
        r4 = r3.availableAudioProcessors;
        r1 = r3.channelMappingAudioProcessor;
        r4[r6] = r1;
        r6 = r5.length;
        r1 = 2;
        java.lang.System.arraycopy(r5, r2, r4, r1, r6);
        r4 = r3.availableAudioProcessors;
        r5 = r5.length;
        r5 = r5 + r1;
        r6 = r3.sonicAudioProcessor;
        r4[r5] = r6;
        r4 = 10;
        r4 = new long[r4];
        r3.playheadOffsets = r4;
        r4 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r3.volume = r4;
        r3.startMediaTimeState = r2;
        r3.streamType = r0;
        r3.audioSessionId = r2;
        r4 = com.google.android.exoplayer2.PlaybackParameters.DEFAULT;
        r3.playbackParameters = r4;
        r4 = -1;
        r3.drainingAudioProcessorIndex = r4;
        r4 = new com.google.android.exoplayer2.audio.AudioProcessor[r2];
        r3.audioProcessors = r4;
        r4 = new java.nio.ByteBuffer[r2];
        r3.outputBuffers = r4;
        r4 = new java.util.LinkedList;
        r4.<init>();
        r3.playbackParametersCheckpoints = r4;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.audio.AudioTrack.<init>(com.google.android.exoplayer2.audio.AudioCapabilities, com.google.android.exoplayer2.audio.AudioProcessor[], com.google.android.exoplayer2.audio.AudioTrack$Listener):void");
    }

    public boolean isPassthroughSupported(String str) {
        AudioCapabilities audioCapabilities = this.audioCapabilities;
        return (audioCapabilities == null || audioCapabilities.supportsEncoding(getEncodingForMimeType(str)) == null) ? null : true;
    }

    public long getCurrentPositionUs(boolean z) {
        if (!hasCurrentPositionUs()) {
            return Long.MIN_VALUE;
        }
        if (this.audioTrack.getPlayState() == 3) {
            maybeSampleSyncParams();
        }
        long nanoTime = System.nanoTime() / 1000;
        if (this.audioTimestampSet) {
            nanoTime = framesToDurationUs(this.audioTrackUtil.getTimestampFramePosition() + durationUsToFrames(nanoTime - (this.audioTrackUtil.getTimestampNanoTime() / 1000)));
        } else {
            if (this.playheadOffsetCount == 0) {
                nanoTime = this.audioTrackUtil.getPositionUs();
            } else {
                nanoTime += this.smoothedPlayheadOffsetUs;
            }
            if (!z) {
                nanoTime -= this.latencyUs;
            }
        }
        return this.startMediaTimeUs + applySpeedup(nanoTime);
    }

    public void configure(String str, int i, int i2, int i3, int i4) throws ConfigurationException {
        configure(str, i, i2, i3, i4, null);
    }

    public void configure(String str, int i, int i2, int i3, int i4, int[] iArr) throws ConfigurationException {
        int i5;
        boolean z = true;
        boolean equals = MimeTypes.AUDIO_RAW.equals(str) ^ true;
        str = equals ? getEncodingForMimeType(str) : i3;
        if (equals) {
            i3 = 0;
        } else {
            this.pcmFrameSize = Util.getPcmFrameSize(i3, i);
            this.channelMappingAudioProcessor.setChannelMap(iArr);
            i3 = this.availableAudioProcessors;
            iArr = i3.length;
            i5 = str;
            int i6 = i;
            str = null;
            i = 0;
            while (str < iArr) {
                AudioProcessor audioProcessor = i3[str];
                try {
                    i |= audioProcessor.configure(i2, i6, i5);
                    if (audioProcessor.isActive()) {
                        i6 = audioProcessor.getOutputChannelCount();
                        i5 = audioProcessor.getOutputEncoding();
                    }
                    str++;
                } catch (Throwable e) {
                    throw new ConfigurationException(e);
                }
            }
            if (i != 0) {
                resetAudioProcessors();
            }
            i3 = i;
            i = i6;
            str = i5;
        }
        iArr = 252;
        switch (i) {
            case 1:
                i5 = 4;
                break;
            case 2:
                i5 = 12;
                break;
            case 3:
                i5 = 28;
                break;
            case 4:
                i5 = 204;
                break;
            case 5:
                i5 = 220;
                break;
            case 6:
                i5 = 252;
                break;
            case 7:
                i5 = 1276;
                break;
            case 8:
                i5 = C0361C.CHANNEL_OUT_7POINT1_SURROUND;
                break;
            default:
                i2 = new StringBuilder();
                i2.append("Unsupported channel count: ");
                i2.append(i);
                throw new ConfigurationException(i2.toString());
        }
        if (Util.SDK_INT <= 23 && "foster".equals(Util.DEVICE) && "NVIDIA".equals(Util.MANUFACTURER)) {
            if (!(i == 3 || i == 5)) {
                if (i == 7) {
                    iArr = C0361C.CHANNEL_OUT_7POINT1_SURROUND;
                }
            }
            if (Util.SDK_INT <= 25 && "fugu".equals(Util.DEVICE) && equals && i == 1) {
                iArr = 12;
            }
            if (i3 == 0 || isInitialized() == 0 || this.encoding != str || this.sampleRate != i2 || this.channelConfig != iArr) {
                reset();
                this.encoding = str;
                this.passthrough = equals;
                this.sampleRate = i2;
                this.channelConfig = iArr;
                if (equals) {
                    str = 2;
                }
                this.outputEncoding = str;
                this.outputPcmFrameSize = Util.getPcmFrameSize(2, i);
                if (i4 != 0) {
                    this.bufferSize = i4;
                } else if (equals) {
                    str = android.media.AudioTrack.getMinBufferSize(i2, iArr, this.outputEncoding);
                    if (str != -2) {
                        z = false;
                    }
                    Assertions.checkState(z);
                    i = str * 4;
                    i2 = ((int) durationUsToFrames(250000)) * this.outputPcmFrameSize;
                    str = (int) Math.max((long) str, durationUsToFrames(MAX_BUFFER_DURATION_US) * ((long) this.outputPcmFrameSize));
                    if (i < i2) {
                        str = i2;
                    } else if (i > str) {
                        str = i;
                    }
                    this.bufferSize = str;
                } else {
                    str = this.outputEncoding;
                    if (str != 5) {
                        if (str == 6) {
                            this.bufferSize = 49152;
                        }
                    }
                    this.bufferSize = CacheDataSink.DEFAULT_BUFFER_SIZE;
                }
                if (equals) {
                    str = framesToDurationUs((long) (this.bufferSize / this.outputPcmFrameSize));
                } else {
                    str = 1;
                }
                this.bufferSizeUs = str;
                setPlaybackParameters(this.playbackParameters);
            }
            return;
        }
        iArr = i5;
        iArr = 12;
        if (i3 == 0) {
        }
        reset();
        this.encoding = str;
        this.passthrough = equals;
        this.sampleRate = i2;
        this.channelConfig = iArr;
        if (equals) {
            str = 2;
        }
        this.outputEncoding = str;
        this.outputPcmFrameSize = Util.getPcmFrameSize(2, i);
        if (i4 != 0) {
            this.bufferSize = i4;
        } else if (equals) {
            str = android.media.AudioTrack.getMinBufferSize(i2, iArr, this.outputEncoding);
            if (str != -2) {
                z = false;
            }
            Assertions.checkState(z);
            i = str * 4;
            i2 = ((int) durationUsToFrames(250000)) * this.outputPcmFrameSize;
            str = (int) Math.max((long) str, durationUsToFrames(MAX_BUFFER_DURATION_US) * ((long) this.outputPcmFrameSize));
            if (i < i2) {
                str = i2;
            } else if (i > str) {
                str = i;
            }
            this.bufferSize = str;
        } else {
            str = this.outputEncoding;
            if (str != 5) {
                if (str == 6) {
                    this.bufferSize = 49152;
                }
            }
            this.bufferSize = CacheDataSink.DEFAULT_BUFFER_SIZE;
        }
        if (equals) {
            str = framesToDurationUs((long) (this.bufferSize / this.outputPcmFrameSize));
        } else {
            str = 1;
        }
        this.bufferSizeUs = str;
        setPlaybackParameters(this.playbackParameters);
    }

    private void resetAudioProcessors() {
        ArrayList arrayList = new ArrayList();
        for (AudioProcessor audioProcessor : this.availableAudioProcessors) {
            if (audioProcessor.isActive()) {
                arrayList.add(audioProcessor);
            } else {
                audioProcessor.flush();
            }
        }
        int size = arrayList.size();
        this.audioProcessors = (AudioProcessor[]) arrayList.toArray(new AudioProcessor[size]);
        this.outputBuffers = new ByteBuffer[size];
        for (int i = 0; i < size; i++) {
            AudioProcessor audioProcessor2 = this.audioProcessors[i];
            audioProcessor2.flush();
            this.outputBuffers[i] = audioProcessor2.getOutput();
        }
    }

    private void initialize() throws InitializationException {
        this.releasingConditionVariable.block();
        if (this.tunneling) {
            this.audioTrack = createHwAvSyncAudioTrackV21(this.sampleRate, this.channelConfig, this.outputEncoding, this.bufferSize, this.audioSessionId);
        } else {
            int i = this.audioSessionId;
            if (i == 0) {
                this.audioTrack = new android.media.AudioTrack(this.streamType, this.sampleRate, this.channelConfig, this.outputEncoding, this.bufferSize, 1);
            } else {
                this.audioTrack = new android.media.AudioTrack(this.streamType, this.sampleRate, this.channelConfig, this.outputEncoding, this.bufferSize, 1, i);
            }
        }
        checkAudioTrackInitialized();
        int audioSessionId = this.audioTrack.getAudioSessionId();
        if (enablePreV21AudioSessionWorkaround && Util.SDK_INT < 21) {
            android.media.AudioTrack audioTrack = this.keepSessionIdAudioTrack;
            if (!(audioTrack == null || audioSessionId == audioTrack.getAudioSessionId())) {
                releaseKeepSessionIdAudioTrack();
            }
            if (this.keepSessionIdAudioTrack == null) {
                this.keepSessionIdAudioTrack = new android.media.AudioTrack(this.streamType, 4000, 4, 2, 2, 0, audioSessionId);
            }
        }
        if (this.audioSessionId != audioSessionId) {
            this.audioSessionId = audioSessionId;
            this.listener.onAudioSessionId(audioSessionId);
        }
        this.audioTrackUtil.reconfigure(this.audioTrack, needsPassthroughWorkarounds());
        setVolumeInternal();
        this.hasData = false;
    }

    public void play() {
        this.playing = true;
        if (isInitialized()) {
            this.resumeSystemTimeUs = System.nanoTime() / 1000;
            this.audioTrack.play();
        }
    }

    public void handleDiscontinuity() {
        if (this.startMediaTimeState == 1) {
            this.startMediaTimeState = 2;
        }
    }

    public boolean handleBuffer(ByteBuffer byteBuffer, long j) throws InitializationException, WriteException {
        boolean z;
        long framesToDurationUs;
        int i;
        ByteBuffer byteBuffer2 = byteBuffer;
        long j2 = j;
        ByteBuffer byteBuffer3 = this.inputBuffer;
        if (byteBuffer3 != null) {
            if (byteBuffer2 != byteBuffer3) {
                z = false;
                Assertions.checkArgument(z);
                if (!isInitialized()) {
                    initialize();
                    if (r0.playing) {
                        play();
                    }
                }
                if (needsPassthroughWorkarounds()) {
                    if (r0.audioTrack.getPlayState() != 2) {
                        r0.hasData = false;
                        return false;
                    } else if (r0.audioTrack.getPlayState() == 1 && r0.audioTrackUtil.getPlaybackHeadPosition() != 0) {
                        return false;
                    }
                }
                z = r0.hasData;
                r0.hasData = hasPendingData();
                if (!(!z || r0.hasData || r0.audioTrack.getPlayState() == 1)) {
                    r0.listener.onUnderrun(r0.bufferSize, C0361C.usToMs(r0.bufferSizeUs), SystemClock.elapsedRealtime() - r0.lastFeedElapsedRealtimeMs);
                }
                if (r0.inputBuffer == null) {
                    if (!byteBuffer.hasRemaining()) {
                        return true;
                    }
                    if (r0.passthrough && r0.framesPerEncodedSample == 0) {
                        r0.framesPerEncodedSample = getFramesPerEncodedSample(r0.outputEncoding, byteBuffer2);
                    }
                    if (r0.drainingPlaybackParameters != null) {
                        if (!drainAudioProcessorsToEndOfStream()) {
                            return false;
                        }
                        LinkedList linkedList = r0.playbackParametersCheckpoints;
                        PlaybackParametersCheckpoint playbackParametersCheckpoint = r11;
                        PlaybackParametersCheckpoint playbackParametersCheckpoint2 = new PlaybackParametersCheckpoint(r0.drainingPlaybackParameters, Math.max(0, j2), framesToDurationUs(getWrittenFrames()));
                        linkedList.add(playbackParametersCheckpoint);
                        r0.drainingPlaybackParameters = null;
                        resetAudioProcessors();
                    }
                    if (r0.startMediaTimeState != 0) {
                        r0.startMediaTimeUs = Math.max(0, j2);
                        r0.startMediaTimeState = 1;
                    } else {
                        framesToDurationUs = r0.startMediaTimeUs + framesToDurationUs(getSubmittedFrames());
                        if (r0.startMediaTimeState == 1) {
                            i = 2;
                        } else if (Math.abs(framesToDurationUs - j2) <= 200000) {
                            String str = TAG;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Discontinuity detected [expected ");
                            stringBuilder.append(framesToDurationUs);
                            stringBuilder.append(", got ");
                            stringBuilder.append(j2);
                            stringBuilder.append("]");
                            Log.e(str, stringBuilder.toString());
                            i = 2;
                            r0.startMediaTimeState = 2;
                        } else {
                            i = 2;
                        }
                        if (r0.startMediaTimeState == i) {
                            r0.startMediaTimeUs += j2 - framesToDurationUs;
                            r0.startMediaTimeState = 1;
                            r0.listener.onPositionDiscontinuity();
                        }
                    }
                    if (r0.passthrough) {
                        r0.submittedPcmBytes += (long) byteBuffer.remaining();
                    } else {
                        r0.submittedEncodedFrames += (long) r0.framesPerEncodedSample;
                    }
                    r0.inputBuffer = byteBuffer2;
                }
                if (r0.passthrough) {
                    processBuffers(j2);
                } else {
                    writeBuffer(r0.inputBuffer, j2);
                }
                if (!r0.inputBuffer.hasRemaining()) {
                    return false;
                }
                r0.inputBuffer = null;
                return true;
            }
        }
        z = true;
        Assertions.checkArgument(z);
        if (isInitialized()) {
            initialize();
            if (r0.playing) {
                play();
            }
        }
        if (needsPassthroughWorkarounds()) {
            if (r0.audioTrack.getPlayState() != 2) {
                return false;
            }
            r0.hasData = false;
            return false;
        }
        z = r0.hasData;
        r0.hasData = hasPendingData();
        r0.listener.onUnderrun(r0.bufferSize, C0361C.usToMs(r0.bufferSizeUs), SystemClock.elapsedRealtime() - r0.lastFeedElapsedRealtimeMs);
        if (r0.inputBuffer == null) {
            if (!byteBuffer.hasRemaining()) {
                return true;
            }
            r0.framesPerEncodedSample = getFramesPerEncodedSample(r0.outputEncoding, byteBuffer2);
            if (r0.drainingPlaybackParameters != null) {
                if (!drainAudioProcessorsToEndOfStream()) {
                    return false;
                }
                LinkedList linkedList2 = r0.playbackParametersCheckpoints;
                PlaybackParametersCheckpoint playbackParametersCheckpoint3 = playbackParametersCheckpoint2;
                PlaybackParametersCheckpoint playbackParametersCheckpoint22 = new PlaybackParametersCheckpoint(r0.drainingPlaybackParameters, Math.max(0, j2), framesToDurationUs(getWrittenFrames()));
                linkedList2.add(playbackParametersCheckpoint3);
                r0.drainingPlaybackParameters = null;
                resetAudioProcessors();
            }
            if (r0.startMediaTimeState != 0) {
                framesToDurationUs = r0.startMediaTimeUs + framesToDurationUs(getSubmittedFrames());
                if (r0.startMediaTimeState == 1) {
                    i = 2;
                } else if (Math.abs(framesToDurationUs - j2) <= 200000) {
                    i = 2;
                } else {
                    String str2 = TAG;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("Discontinuity detected [expected ");
                    stringBuilder2.append(framesToDurationUs);
                    stringBuilder2.append(", got ");
                    stringBuilder2.append(j2);
                    stringBuilder2.append("]");
                    Log.e(str2, stringBuilder2.toString());
                    i = 2;
                    r0.startMediaTimeState = 2;
                }
                if (r0.startMediaTimeState == i) {
                    r0.startMediaTimeUs += j2 - framesToDurationUs;
                    r0.startMediaTimeState = 1;
                    r0.listener.onPositionDiscontinuity();
                }
            } else {
                r0.startMediaTimeUs = Math.max(0, j2);
                r0.startMediaTimeState = 1;
            }
            if (r0.passthrough) {
                r0.submittedPcmBytes += (long) byteBuffer.remaining();
            } else {
                r0.submittedEncodedFrames += (long) r0.framesPerEncodedSample;
            }
            r0.inputBuffer = byteBuffer2;
        }
        if (r0.passthrough) {
            processBuffers(j2);
        } else {
            writeBuffer(r0.inputBuffer, j2);
        }
        if (!r0.inputBuffer.hasRemaining()) {
            return false;
        }
        r0.inputBuffer = null;
        return true;
    }

    private void processBuffers(long j) throws WriteException {
        int length = this.audioProcessors.length;
        int i = length;
        while (i >= 0) {
            ByteBuffer byteBuffer;
            if (i > 0) {
                byteBuffer = this.outputBuffers[i - 1];
            } else {
                byteBuffer = this.inputBuffer;
                if (byteBuffer == null) {
                    byteBuffer = AudioProcessor.EMPTY_BUFFER;
                }
            }
            if (i == length) {
                writeBuffer(byteBuffer, j);
            } else {
                AudioProcessor audioProcessor = this.audioProcessors[i];
                audioProcessor.queueInput(byteBuffer);
                ByteBuffer output = audioProcessor.getOutput();
                this.outputBuffers[i] = output;
                if (output.hasRemaining()) {
                    i++;
                }
            }
            if (!byteBuffer.hasRemaining()) {
                i--;
            } else {
                return;
            }
        }
    }

    private boolean writeBuffer(ByteBuffer byteBuffer, long j) throws WriteException {
        if (!byteBuffer.hasRemaining()) {
            return true;
        }
        int remaining;
        ByteBuffer byteBuffer2 = this.outputBuffer;
        if (byteBuffer2 != null) {
            Assertions.checkArgument(byteBuffer2 == byteBuffer);
        } else {
            this.outputBuffer = byteBuffer;
            if (Util.SDK_INT < 21) {
                remaining = byteBuffer.remaining();
                byte[] bArr = this.preV21OutputBuffer;
                if (bArr == null || bArr.length < remaining) {
                    this.preV21OutputBuffer = new byte[remaining];
                }
                int position = byteBuffer.position();
                byteBuffer.get(this.preV21OutputBuffer, 0, remaining);
                byteBuffer.position(position);
                this.preV21OutputBufferOffset = 0;
            }
        }
        remaining = byteBuffer.remaining();
        if (Util.SDK_INT < 21) {
            int playbackHeadPosition = this.bufferSize - ((int) (this.writtenPcmBytes - (this.audioTrackUtil.getPlaybackHeadPosition() * ((long) this.outputPcmFrameSize))));
            if (playbackHeadPosition > 0) {
                j = this.audioTrack.write(this.preV21OutputBuffer, this.preV21OutputBufferOffset, Math.min(remaining, playbackHeadPosition));
                if (j > null) {
                    this.preV21OutputBufferOffset += j;
                    byteBuffer.position(byteBuffer.position() + j);
                }
            } else {
                j = null;
            }
        } else if (this.tunneling) {
            Assertions.checkState(j != C0361C.TIME_UNSET);
            j = writeNonBlockingWithAvSyncV21(this.audioTrack, byteBuffer, remaining, j);
        } else {
            j = writeNonBlockingV21(this.audioTrack, byteBuffer, remaining);
        }
        this.lastFeedElapsedRealtimeMs = SystemClock.elapsedRealtime();
        if (j >= null) {
            if (this.passthrough == null) {
                this.writtenPcmBytes += (long) j;
            }
            if (j != remaining) {
                return false;
            }
            if (this.passthrough != null) {
                this.writtenEncodedFrames += (long) this.framesPerEncodedSample;
            }
            this.outputBuffer = null;
            return true;
        }
        throw new WriteException(j);
    }

    public void playToEndOfStream() throws WriteException {
        if (!this.handledEndOfStream) {
            if (isInitialized()) {
                if (drainAudioProcessorsToEndOfStream()) {
                    this.audioTrackUtil.handleEndOfStream(getWrittenFrames());
                    this.bytesUntilNextAvSync = 0;
                    this.handledEndOfStream = true;
                }
            }
        }
    }

    private boolean drainAudioProcessorsToEndOfStream() throws WriteException {
        Object obj;
        if (this.drainingAudioProcessorIndex == -1) {
            this.drainingAudioProcessorIndex = this.passthrough ? this.audioProcessors.length : 0;
            obj = 1;
        } else {
            obj = null;
        }
        while (true) {
            int i = this.drainingAudioProcessorIndex;
            AudioProcessor[] audioProcessorArr = this.audioProcessors;
            if (i >= audioProcessorArr.length) {
                break;
            }
            AudioProcessor audioProcessor = audioProcessorArr[i];
            if (obj != null) {
                audioProcessor.queueEndOfStream();
            }
            processBuffers(C0361C.TIME_UNSET);
            if (!audioProcessor.isEnded()) {
                return false;
            }
            this.drainingAudioProcessorIndex++;
            obj = 1;
        }
        ByteBuffer byteBuffer = this.outputBuffer;
        if (byteBuffer != null) {
            writeBuffer(byteBuffer, C0361C.TIME_UNSET);
            if (this.outputBuffer != null) {
                return false;
            }
        }
        this.drainingAudioProcessorIndex = -1;
        return true;
    }

    public boolean isEnded() {
        if (isInitialized()) {
            if (!this.handledEndOfStream || hasPendingData()) {
                return false;
            }
        }
        return true;
    }

    public boolean hasPendingData() {
        return isInitialized() && (getWrittenFrames() > this.audioTrackUtil.getPlaybackHeadPosition() || overrideHasPendingData());
    }

    public PlaybackParameters setPlaybackParameters(PlaybackParameters playbackParameters) {
        if (this.passthrough) {
            this.playbackParameters = PlaybackParameters.DEFAULT;
            return this.playbackParameters;
        }
        PlaybackParameters playbackParameters2 = new PlaybackParameters(this.sonicAudioProcessor.setSpeed(playbackParameters.speed), this.sonicAudioProcessor.setPitch(playbackParameters.pitch));
        playbackParameters = this.drainingPlaybackParameters;
        if (playbackParameters == null) {
            playbackParameters = this.playbackParametersCheckpoints.isEmpty() == null ? ((PlaybackParametersCheckpoint) this.playbackParametersCheckpoints.getLast()).playbackParameters : this.playbackParameters;
        }
        if (playbackParameters2.equals(playbackParameters) == null) {
            if (isInitialized() != null) {
                this.drainingPlaybackParameters = playbackParameters2;
            } else {
                this.playbackParameters = playbackParameters2;
            }
        }
        return this.playbackParameters;
    }

    public PlaybackParameters getPlaybackParameters() {
        return this.playbackParameters;
    }

    public void setStreamType(int i) {
        if (this.streamType != i) {
            this.streamType = i;
            if (this.tunneling == 0) {
                reset();
                this.audioSessionId = 0;
            }
        }
    }

    public void setAudioSessionId(int i) {
        if (this.audioSessionId != i) {
            this.audioSessionId = i;
            reset();
        }
    }

    public void enableTunnelingV21(int i) {
        Assertions.checkState(Util.SDK_INT >= 21);
        if (!this.tunneling || this.audioSessionId != i) {
            this.tunneling = true;
            this.audioSessionId = i;
            reset();
        }
    }

    public void disableTunneling() {
        if (this.tunneling) {
            this.tunneling = false;
            this.audioSessionId = 0;
            reset();
        }
    }

    public void setVolume(float f) {
        if (this.volume != f) {
            this.volume = f;
            setVolumeInternal();
        }
    }

    private void setVolumeInternal() {
        if (!isInitialized()) {
            return;
        }
        if (Util.SDK_INT >= 21) {
            setVolumeInternalV21(this.audioTrack, this.volume);
        } else {
            setVolumeInternalV3(this.audioTrack, this.volume);
        }
    }

    public void pause() {
        this.playing = false;
        if (isInitialized()) {
            resetSyncParams();
            this.audioTrackUtil.pause();
        }
    }

    public void reset() {
        if (isInitialized()) {
            this.submittedPcmBytes = 0;
            this.submittedEncodedFrames = 0;
            this.writtenPcmBytes = 0;
            this.writtenEncodedFrames = 0;
            this.framesPerEncodedSample = 0;
            PlaybackParameters playbackParameters = this.drainingPlaybackParameters;
            if (playbackParameters != null) {
                this.playbackParameters = playbackParameters;
                this.drainingPlaybackParameters = null;
            } else if (!this.playbackParametersCheckpoints.isEmpty()) {
                this.playbackParameters = ((PlaybackParametersCheckpoint) this.playbackParametersCheckpoints.getLast()).playbackParameters;
            }
            this.playbackParametersCheckpoints.clear();
            this.playbackParametersOffsetUs = 0;
            this.playbackParametersPositionUs = 0;
            this.inputBuffer = null;
            this.outputBuffer = null;
            int i = 0;
            while (true) {
                AudioProcessor[] audioProcessorArr = this.audioProcessors;
                if (i >= audioProcessorArr.length) {
                    break;
                }
                AudioProcessor audioProcessor = audioProcessorArr[i];
                audioProcessor.flush();
                this.outputBuffers[i] = audioProcessor.getOutput();
                i++;
            }
            this.handledEndOfStream = false;
            this.drainingAudioProcessorIndex = -1;
            this.avSyncHeader = null;
            this.bytesUntilNextAvSync = 0;
            this.startMediaTimeState = 0;
            this.latencyUs = 0;
            resetSyncParams();
            if (this.audioTrack.getPlayState() == 3) {
                this.audioTrack.pause();
            }
            final android.media.AudioTrack audioTrack = this.audioTrack;
            this.audioTrack = null;
            this.audioTrackUtil.reconfigure(null, false);
            this.releasingConditionVariable.close();
            new Thread() {
                public void run() {
                    try {
                        audioTrack.flush();
                        audioTrack.release();
                    } finally {
                        AudioTrack.this.releasingConditionVariable.open();
                    }
                }
            }.start();
        }
    }

    public void release() {
        reset();
        releaseKeepSessionIdAudioTrack();
        for (AudioProcessor reset : this.availableAudioProcessors) {
            reset.reset();
        }
        this.audioSessionId = 0;
        this.playing = false;
    }

    private void releaseKeepSessionIdAudioTrack() {
        final android.media.AudioTrack audioTrack = this.keepSessionIdAudioTrack;
        if (audioTrack != null) {
            this.keepSessionIdAudioTrack = null;
            new Thread() {
                public void run() {
                    audioTrack.release();
                }
            }.start();
        }
    }

    private boolean hasCurrentPositionUs() {
        return isInitialized() && this.startMediaTimeState != 0;
    }

    private long applySpeedup(long j) {
        while (!this.playbackParametersCheckpoints.isEmpty() && j >= ((PlaybackParametersCheckpoint) this.playbackParametersCheckpoints.getFirst()).positionUs) {
            PlaybackParametersCheckpoint playbackParametersCheckpoint = (PlaybackParametersCheckpoint) this.playbackParametersCheckpoints.remove();
            this.playbackParameters = playbackParametersCheckpoint.playbackParameters;
            this.playbackParametersPositionUs = playbackParametersCheckpoint.positionUs;
            this.playbackParametersOffsetUs = playbackParametersCheckpoint.mediaTimeUs - this.startMediaTimeUs;
        }
        if (this.playbackParameters.speed == 1.0f) {
            return (j + this.playbackParametersOffsetUs) - this.playbackParametersPositionUs;
        }
        if (this.playbackParametersCheckpoints.isEmpty() && this.sonicAudioProcessor.getOutputByteCount() >= PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID) {
            return this.playbackParametersOffsetUs + Util.scaleLargeTimestamp(j - this.playbackParametersPositionUs, this.sonicAudioProcessor.getInputByteCount(), this.sonicAudioProcessor.getOutputByteCount());
        }
        long j2 = this.playbackParametersOffsetUs;
        double d = (double) this.playbackParameters.speed;
        j = (double) (j - this.playbackParametersPositionUs);
        Double.isNaN(d);
        Double.isNaN(j);
        return j2 + ((long) (d * j));
    }

    private void maybeSampleSyncParams() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r17 = this;
        r0 = r17;
        r1 = r0.audioTrackUtil;
        r1 = r1.getPositionUs();
        r3 = 0;
        r5 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1));
        if (r5 != 0) goto L_0x000f;
    L_0x000e:
        return;
    L_0x000f:
        r5 = java.lang.System.nanoTime();
        r7 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
        r5 = r5 / r7;
        r9 = r0.lastPlayheadSampleTimeUs;
        r9 = r5 - r9;
        r11 = 30000; // 0x7530 float:4.2039E-41 double:1.4822E-319;
        r13 = 0;
        r14 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1));
        if (r14 < 0) goto L_0x0051;
    L_0x0021:
        r9 = r0.playheadOffsets;
        r10 = r0.nextPlayheadOffsetIndex;
        r11 = r1 - r5;
        r9[r10] = r11;
        r10 = r10 + 1;
        r9 = 10;
        r10 = r10 % r9;
        r0.nextPlayheadOffsetIndex = r10;
        r10 = r0.playheadOffsetCount;
        if (r10 >= r9) goto L_0x0038;
    L_0x0034:
        r10 = r10 + 1;
        r0.playheadOffsetCount = r10;
    L_0x0038:
        r0.lastPlayheadSampleTimeUs = r5;
        r0.smoothedPlayheadOffsetUs = r3;
        r9 = 0;
    L_0x003d:
        r10 = r0.playheadOffsetCount;
        if (r9 >= r10) goto L_0x0051;
    L_0x0041:
        r11 = r0.smoothedPlayheadOffsetUs;
        r14 = r0.playheadOffsets;
        r15 = r14[r9];
        r3 = (long) r10;
        r15 = r15 / r3;
        r11 = r11 + r15;
        r0.smoothedPlayheadOffsetUs = r11;
        r9 = r9 + 1;
        r3 = 0;
        goto L_0x003d;
    L_0x0051:
        r3 = r17.needsPassthroughWorkarounds();
        if (r3 == 0) goto L_0x0058;
    L_0x0057:
        return;
    L_0x0058:
        r3 = r0.lastTimestampSampleTimeUs;
        r3 = r5 - r3;
        r9 = 500000; // 0x7a120 float:7.00649E-40 double:2.47033E-318;
        r11 = (r3 > r9 ? 1 : (r3 == r9 ? 0 : -1));
        if (r11 < 0) goto L_0x0197;
    L_0x0063:
        r3 = r0.audioTrackUtil;
        r3 = r3.updateTimestamp();
        r0.audioTimestampSet = r3;
        r3 = r0.audioTimestampSet;
        r9 = 5000000; // 0x4c4b40 float:7.006492E-39 double:2.470328E-317;
        if (r3 == 0) goto L_0x0146;
    L_0x0072:
        r3 = r0.audioTrackUtil;
        r3 = r3.getTimestampNanoTime();
        r3 = r3 / r7;
        r11 = r0.audioTrackUtil;
        r11 = r11.getTimestampFramePosition();
        r14 = r0.resumeSystemTimeUs;
        r16 = (r3 > r14 ? 1 : (r3 == r14 ? 0 : -1));
        if (r16 >= 0) goto L_0x0089;
    L_0x0085:
        r0.audioTimestampSet = r13;
        goto L_0x0146;
    L_0x0089:
        r14 = r3 - r5;
        r14 = java.lang.Math.abs(r14);
        r16 = (r14 > r9 ? 1 : (r14 == r9 ? 0 : -1));
        if (r16 <= 0) goto L_0x00e6;
    L_0x0093:
        r14 = new java.lang.StringBuilder;
        r14.<init>();
        r15 = "Spurious audio timestamp (system clock mismatch): ";
        r14.append(r15);
        r14.append(r11);
        r11 = ", ";
        r14.append(r11);
        r14.append(r3);
        r3 = ", ";
        r14.append(r3);
        r14.append(r5);
        r3 = ", ";
        r14.append(r3);
        r14.append(r1);
        r1 = ", ";
        r14.append(r1);
        r1 = r17.getSubmittedFrames();
        r14.append(r1);
        r1 = ", ";
        r14.append(r1);
        r1 = r17.getWrittenFrames();
        r14.append(r1);
        r1 = r14.toString();
        r2 = failOnSpuriousAudioTimestamp;
        if (r2 != 0) goto L_0x00e0;
    L_0x00d8:
        r2 = "AudioTrack";
        android.util.Log.w(r2, r1);
        r0.audioTimestampSet = r13;
        goto L_0x0146;
    L_0x00e0:
        r2 = new com.google.android.exoplayer2.audio.AudioTrack$InvalidAudioTrackTimestampException;
        r2.<init>(r1);
        throw r2;
    L_0x00e6:
        r14 = r0.framesToDurationUs(r11);
        r14 = r14 - r1;
        r14 = java.lang.Math.abs(r14);
        r16 = (r14 > r9 ? 1 : (r14 == r9 ? 0 : -1));
        if (r16 <= 0) goto L_0x0146;
    L_0x00f3:
        r14 = new java.lang.StringBuilder;
        r14.<init>();
        r15 = "Spurious audio timestamp (frame position mismatch): ";
        r14.append(r15);
        r14.append(r11);
        r11 = ", ";
        r14.append(r11);
        r14.append(r3);
        r3 = ", ";
        r14.append(r3);
        r14.append(r5);
        r3 = ", ";
        r14.append(r3);
        r14.append(r1);
        r1 = ", ";
        r14.append(r1);
        r1 = r17.getSubmittedFrames();
        r14.append(r1);
        r1 = ", ";
        r14.append(r1);
        r1 = r17.getWrittenFrames();
        r14.append(r1);
        r1 = r14.toString();
        r2 = failOnSpuriousAudioTimestamp;
        if (r2 != 0) goto L_0x0140;
    L_0x0138:
        r2 = "AudioTrack";
        android.util.Log.w(r2, r1);
        r0.audioTimestampSet = r13;
        goto L_0x0146;
    L_0x0140:
        r2 = new com.google.android.exoplayer2.audio.AudioTrack$InvalidAudioTrackTimestampException;
        r2.<init>(r1);
        throw r2;
    L_0x0146:
        r1 = r0.getLatencyMethod;
        if (r1 == 0) goto L_0x0195;
    L_0x014a:
        r2 = r0.passthrough;
        if (r2 != 0) goto L_0x0195;
    L_0x014e:
        r2 = 0;
        r3 = r0.audioTrack;	 Catch:{ Exception -> 0x0193 }
        r4 = r2;	 Catch:{ Exception -> 0x0193 }
        r4 = (java.lang.Object[]) r4;	 Catch:{ Exception -> 0x0193 }
        r1 = r1.invoke(r3, r4);	 Catch:{ Exception -> 0x0193 }
        r1 = (java.lang.Integer) r1;	 Catch:{ Exception -> 0x0193 }
        r1 = r1.intValue();	 Catch:{ Exception -> 0x0193 }
        r3 = (long) r1;	 Catch:{ Exception -> 0x0193 }
        r3 = r3 * r7;	 Catch:{ Exception -> 0x0193 }
        r7 = r0.bufferSizeUs;	 Catch:{ Exception -> 0x0193 }
        r3 = r3 - r7;	 Catch:{ Exception -> 0x0193 }
        r0.latencyUs = r3;	 Catch:{ Exception -> 0x0193 }
        r3 = r0.latencyUs;	 Catch:{ Exception -> 0x0193 }
        r7 = 0;	 Catch:{ Exception -> 0x0193 }
        r3 = java.lang.Math.max(r3, r7);	 Catch:{ Exception -> 0x0193 }
        r0.latencyUs = r3;	 Catch:{ Exception -> 0x0193 }
        r3 = r0.latencyUs;	 Catch:{ Exception -> 0x0193 }
        r1 = (r3 > r9 ? 1 : (r3 == r9 ? 0 : -1));	 Catch:{ Exception -> 0x0193 }
        if (r1 <= 0) goto L_0x0195;	 Catch:{ Exception -> 0x0193 }
    L_0x0176:
        r1 = "AudioTrack";	 Catch:{ Exception -> 0x0193 }
        r3 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0193 }
        r3.<init>();	 Catch:{ Exception -> 0x0193 }
        r4 = "Ignoring impossibly large audio latency: ";	 Catch:{ Exception -> 0x0193 }
        r3.append(r4);	 Catch:{ Exception -> 0x0193 }
        r7 = r0.latencyUs;	 Catch:{ Exception -> 0x0193 }
        r3.append(r7);	 Catch:{ Exception -> 0x0193 }
        r3 = r3.toString();	 Catch:{ Exception -> 0x0193 }
        android.util.Log.w(r1, r3);	 Catch:{ Exception -> 0x0193 }
        r3 = 0;	 Catch:{ Exception -> 0x0193 }
        r0.latencyUs = r3;	 Catch:{ Exception -> 0x0193 }
        goto L_0x0195;
    L_0x0193:
        r0.getLatencyMethod = r2;
    L_0x0195:
        r0.lastTimestampSampleTimeUs = r5;
    L_0x0197:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.audio.AudioTrack.maybeSampleSyncParams():void");
    }

    private void checkAudioTrackInitialized() throws com.google.android.exoplayer2.audio.AudioTrack.InitializationException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = r5.audioTrack;
        r0 = r0.getState();
        r1 = 1;
        if (r0 != r1) goto L_0x000a;
    L_0x0009:
        return;
    L_0x000a:
        r1 = 0;
        r2 = r5.audioTrack;	 Catch:{ Exception -> 0x0015, all -> 0x0011 }
        r2.release();	 Catch:{ Exception -> 0x0015, all -> 0x0011 }
        goto L_0x0015;
    L_0x0011:
        r0 = move-exception;
        r5.audioTrack = r1;
        throw r0;
    L_0x0015:
        r5.audioTrack = r1;
        r1 = new com.google.android.exoplayer2.audio.AudioTrack$InitializationException;
        r2 = r5.sampleRate;
        r3 = r5.channelConfig;
        r4 = r5.bufferSize;
        r1.<init>(r0, r2, r3, r4);
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.exoplayer2.audio.AudioTrack.checkAudioTrackInitialized():void");
    }

    private boolean isInitialized() {
        return this.audioTrack != null;
    }

    private long framesToDurationUs(long j) {
        return (j * C0361C.MICROS_PER_SECOND) / ((long) this.sampleRate);
    }

    private long durationUsToFrames(long j) {
        return (j * ((long) this.sampleRate)) / C0361C.MICROS_PER_SECOND;
    }

    private long getSubmittedFrames() {
        return this.passthrough ? this.submittedEncodedFrames : this.submittedPcmBytes / ((long) this.pcmFrameSize);
    }

    private long getWrittenFrames() {
        return this.passthrough ? this.writtenEncodedFrames : this.writtenPcmBytes / ((long) this.outputPcmFrameSize);
    }

    private void resetSyncParams() {
        this.smoothedPlayheadOffsetUs = 0;
        this.playheadOffsetCount = 0;
        this.nextPlayheadOffsetIndex = 0;
        this.lastPlayheadSampleTimeUs = 0;
        this.audioTimestampSet = false;
        this.lastTimestampSampleTimeUs = 0;
    }

    private boolean needsPassthroughWorkarounds() {
        if (Util.SDK_INT < 23) {
            int i = this.outputEncoding;
            if (i == 5 || i == 6) {
                return true;
            }
        }
        return false;
    }

    private boolean overrideHasPendingData() {
        return needsPassthroughWorkarounds() && this.audioTrack.getPlayState() == 2 && this.audioTrack.getPlaybackHeadPosition() == 0;
    }

    @TargetApi(21)
    private static android.media.AudioTrack createHwAvSyncAudioTrackV21(int i, int i2, int i3, int i4, int i5) {
        return new android.media.AudioTrack(new Builder().setUsage(1).setContentType(3).setFlags(16).build(), new AudioFormat.Builder().setChannelMask(i2).setEncoding(i3).setSampleRate(i).build(), i4, 1, i5);
    }

    private static int getEncodingForMimeType(String str) {
        int hashCode = str.hashCode();
        if (hashCode != -1095064472) {
            if (hashCode != 187078296) {
                if (hashCode != 1504578661) {
                    if (hashCode == 1505942594) {
                        if (str.equals(MimeTypes.AUDIO_DTS_HD) != null) {
                            str = 3;
                            switch (str) {
                                case null:
                                    return 5;
                                case 1:
                                    return 6;
                                case 2:
                                    return 7;
                                case 3:
                                    return 8;
                                default:
                                    return 0;
                            }
                        }
                    }
                } else if (str.equals(MimeTypes.AUDIO_E_AC3) != null) {
                    str = true;
                    switch (str) {
                        case null:
                            return 5;
                        case 1:
                            return 6;
                        case 2:
                            return 7;
                        case 3:
                            return 8;
                        default:
                            return 0;
                    }
                }
            } else if (str.equals(MimeTypes.AUDIO_AC3) != null) {
                str = null;
                switch (str) {
                    case null:
                        return 5;
                    case 1:
                        return 6;
                    case 2:
                        return 7;
                    case 3:
                        return 8;
                    default:
                        return 0;
                }
            }
        } else if (str.equals(MimeTypes.AUDIO_DTS) != null) {
            str = 2;
            switch (str) {
                case null:
                    return 5;
                case 1:
                    return 6;
                case 2:
                    return 7;
                case 3:
                    return 8;
                default:
                    return 0;
            }
        }
        str = -1;
        switch (str) {
            case null:
                return 5;
            case 1:
                return 6;
            case 2:
                return 7;
            case 3:
                return 8;
            default:
                return 0;
        }
    }

    private static int getFramesPerEncodedSample(int i, ByteBuffer byteBuffer) {
        if (i != 7) {
            if (i != 8) {
                if (i == 5) {
                    return Ac3Util.getAc3SyncframeAudioSampleCount();
                }
                if (i == 6) {
                    return Ac3Util.parseEAc3SyncframeAudioSampleCount(byteBuffer);
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unexpected audio encoding: ");
                stringBuilder.append(i);
                throw new IllegalStateException(stringBuilder.toString());
            }
        }
        return DtsUtil.parseDtsAudioSampleCount(byteBuffer);
    }

    @TargetApi(21)
    private static int writeNonBlockingV21(android.media.AudioTrack audioTrack, ByteBuffer byteBuffer, int i) {
        return audioTrack.write(byteBuffer, i, 1);
    }

    @TargetApi(21)
    private int writeNonBlockingWithAvSyncV21(android.media.AudioTrack audioTrack, ByteBuffer byteBuffer, int i, long j) {
        if (this.avSyncHeader == null) {
            this.avSyncHeader = ByteBuffer.allocate(16);
            this.avSyncHeader.order(ByteOrder.BIG_ENDIAN);
            this.avSyncHeader.putInt(1431633921);
        }
        if (this.bytesUntilNextAvSync == 0) {
            this.avSyncHeader.putInt(4, i);
            this.avSyncHeader.putLong(8, j * 1000);
            this.avSyncHeader.position(0);
            this.bytesUntilNextAvSync = i;
        }
        j = this.avSyncHeader.remaining();
        if (j > null) {
            int write = audioTrack.write(this.avSyncHeader, j, 1);
            if (write < 0) {
                this.bytesUntilNextAvSync = 0;
                return write;
            } else if (write < j) {
                return 0;
            }
        }
        audioTrack = writeNonBlockingV21(audioTrack, byteBuffer, i);
        if (audioTrack < null) {
            this.bytesUntilNextAvSync = 0;
            return audioTrack;
        }
        this.bytesUntilNextAvSync -= audioTrack;
        return audioTrack;
    }

    @TargetApi(21)
    private static void setVolumeInternalV21(android.media.AudioTrack audioTrack, float f) {
        audioTrack.setVolume(f);
    }

    private static void setVolumeInternalV3(android.media.AudioTrack audioTrack, float f) {
        audioTrack.setStereoVolume(f, f);
    }
}
