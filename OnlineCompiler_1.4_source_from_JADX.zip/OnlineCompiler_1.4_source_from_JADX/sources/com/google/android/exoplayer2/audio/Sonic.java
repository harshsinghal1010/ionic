package com.google.android.exoplayer2.audio;

import com.google.android.exoplayer2.util.Assertions;
import java.nio.ShortBuffer;
import java.util.Arrays;

final class Sonic {
    private static final int AMDF_FREQUENCY = 4000;
    private static final int MAXIMUM_PITCH = 400;
    private static final int MINIMUM_PITCH = 65;
    private static final boolean USE_CHORD_PITCH = false;
    private final short[] downSampleBuffer;
    private short[] inputBuffer;
    private int inputBufferSize;
    private int maxDiff;
    private final int maxPeriod;
    private final int maxRequired = (this.maxPeriod * 2);
    private int minDiff;
    private final int minPeriod;
    private int newRatePosition;
    private final int numChannels;
    private int numInputSamples;
    private int numOutputSamples;
    private int numPitchSamples;
    private int oldRatePosition;
    private short[] outputBuffer;
    private int outputBufferSize;
    private float pitch;
    private short[] pitchBuffer;
    private int pitchBufferSize;
    private int prevMinDiff;
    private int prevPeriod;
    private int remainingInputToCopy;
    private final int sampleRate;
    private float speed;

    public Sonic(int i, int i2) {
        this.sampleRate = i;
        this.numChannels = i2;
        this.minPeriod = i / MAXIMUM_PITCH;
        this.maxPeriod = i / 65;
        i = this.maxRequired;
        this.downSampleBuffer = new short[i];
        this.inputBufferSize = i;
        this.inputBuffer = new short[(i * i2)];
        this.outputBufferSize = i;
        this.outputBuffer = new short[(i * i2)];
        this.pitchBufferSize = i;
        this.pitchBuffer = new short[(i * i2)];
        this.oldRatePosition = 0;
        this.newRatePosition = 0;
        this.prevPeriod = 0;
        this.speed = 1.0f;
        this.pitch = 1.0f;
    }

    public void setSpeed(float f) {
        this.speed = f;
    }

    public float getSpeed() {
        return this.speed;
    }

    public void setPitch(float f) {
        this.pitch = f;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void queueInput(ShortBuffer shortBuffer) {
        int remaining = shortBuffer.remaining();
        int i = this.numChannels;
        remaining /= i;
        i = (i * remaining) * 2;
        enlargeInputBufferIfNeeded(remaining);
        shortBuffer.get(this.inputBuffer, this.numInputSamples * this.numChannels, i / 2);
        this.numInputSamples += remaining;
        processStreamInput();
    }

    public void getOutput(ShortBuffer shortBuffer) {
        int min = Math.min(shortBuffer.remaining() / this.numChannels, this.numOutputSamples);
        shortBuffer.put(this.outputBuffer, 0, this.numChannels * min);
        this.numOutputSamples -= min;
        shortBuffer = this.outputBuffer;
        int i = this.numChannels;
        System.arraycopy(shortBuffer, min * i, shortBuffer, 0, this.numOutputSamples * i);
    }

    public void queueEndOfStream() {
        int i;
        int i2 = this.numInputSamples;
        float f = this.speed;
        float f2 = this.pitch;
        int i3 = this.numOutputSamples + ((int) ((((((float) i2) / (f / f2)) + ((float) this.numPitchSamples)) / f2) + 0.5f));
        enlargeInputBufferIfNeeded((this.maxRequired * 2) + i2);
        int i4 = 0;
        while (true) {
            i = this.maxRequired;
            int i5 = i * 2;
            int i6 = this.numChannels;
            if (i4 >= i5 * i6) {
                break;
            }
            this.inputBuffer[(i6 * i2) + i4] = (short) 0;
            i4++;
        }
        this.numInputSamples += i * 2;
        processStreamInput();
        if (this.numOutputSamples > i3) {
            this.numOutputSamples = i3;
        }
        this.numInputSamples = 0;
        this.remainingInputToCopy = 0;
        this.numPitchSamples = 0;
    }

    public int getSamplesAvailable() {
        return this.numOutputSamples;
    }

    private void enlargeOutputBufferIfNeeded(int i) {
        int i2 = this.numOutputSamples + i;
        int i3 = this.outputBufferSize;
        if (i2 > i3) {
            this.outputBufferSize = i3 + ((i3 / 2) + i);
            this.outputBuffer = Arrays.copyOf(this.outputBuffer, this.outputBufferSize * this.numChannels);
        }
    }

    private void enlargeInputBufferIfNeeded(int i) {
        int i2 = this.numInputSamples + i;
        int i3 = this.inputBufferSize;
        if (i2 > i3) {
            this.inputBufferSize = i3 + ((i3 / 2) + i);
            this.inputBuffer = Arrays.copyOf(this.inputBuffer, this.inputBufferSize * this.numChannels);
        }
    }

    private void removeProcessedInputSamples(int i) {
        int i2 = this.numInputSamples - i;
        Object obj = this.inputBuffer;
        int i3 = this.numChannels;
        System.arraycopy(obj, i * i3, obj, 0, i3 * i2);
        this.numInputSamples = i2;
    }

    private void copyToOutput(short[] sArr, int i, int i2) {
        enlargeOutputBufferIfNeeded(i2);
        int i3 = this.numChannels;
        System.arraycopy(sArr, i * i3, this.outputBuffer, this.numOutputSamples * i3, i3 * i2);
        this.numOutputSamples += i2;
    }

    private int copyInputToOutput(int i) {
        int min = Math.min(this.maxRequired, this.remainingInputToCopy);
        copyToOutput(this.inputBuffer, i, min);
        this.remainingInputToCopy -= min;
        return min;
    }

    private void downSampleInput(short[] sArr, int i, int i2) {
        int i3 = this.maxRequired / i2;
        int i4 = this.numChannels;
        i2 *= i4;
        i *= i4;
        for (int i5 = 0; i5 < i3; i5++) {
            int i6 = 0;
            for (int i7 = 0; i7 < i2; i7++) {
                i6 += sArr[((i5 * i2) + i) + i7];
            }
            this.downSampleBuffer[i5] = (short) (i6 / i2);
        }
    }

    private int findPitchPeriodInRange(short[] sArr, int i, int i2, int i3) {
        i *= this.numChannels;
        int i4 = 1;
        int i5 = 0;
        int i6 = 0;
        int i7 = 255;
        while (i2 <= i3) {
            int i8 = 0;
            for (int i9 = 0; i9 < i2; i9++) {
                short s = sArr[i + i9];
                short s2 = sArr[(i + i2) + i9];
                i8 += s >= s2 ? s - s2 : s2 - s;
            }
            if (i8 * i5 < i4 * i2) {
                i5 = i2;
                i4 = i8;
            }
            if (i8 * i7 > i6 * i2) {
                i7 = i2;
                i6 = i8;
            }
            i2++;
        }
        this.minDiff = i4 / i5;
        this.maxDiff = i6 / i7;
        return i5;
    }

    private boolean previousPeriodBetter(int i, int i2, boolean z) {
        if (i != 0) {
            if (this.prevPeriod != 0) {
                if (z) {
                    if (i2 > i * 3 || i * 2 <= this.prevMinDiff * 3) {
                        return false;
                    }
                } else if (i <= this.prevMinDiff) {
                    return false;
                }
                return true;
            }
        }
        return false;
    }

    private int findPitchPeriod(short[] sArr, int i, boolean z) {
        int i2 = this.sampleRate;
        i2 = i2 > AMDF_FREQUENCY ? i2 / AMDF_FREQUENCY : 1;
        if (this.numChannels == 1 && i2 == 1) {
            sArr = findPitchPeriodInRange(sArr, i, this.minPeriod, this.maxPeriod);
        } else {
            downSampleInput(sArr, i, i2);
            int findPitchPeriodInRange = findPitchPeriodInRange(this.downSampleBuffer, 0, this.minPeriod / i2, this.maxPeriod / i2);
            if (i2 != 1) {
                findPitchPeriodInRange *= i2;
                i2 *= 4;
                int i3 = findPitchPeriodInRange - i2;
                findPitchPeriodInRange += i2;
                i2 = this.minPeriod;
                if (i3 >= i2) {
                    i2 = i3;
                }
                i3 = this.maxPeriod;
                if (findPitchPeriodInRange > i3) {
                    findPitchPeriodInRange = i3;
                }
                if (this.numChannels == 1) {
                    sArr = findPitchPeriodInRange(sArr, i, i2, findPitchPeriodInRange);
                } else {
                    downSampleInput(sArr, i, 1);
                    sArr = findPitchPeriodInRange(this.downSampleBuffer, 0, i2, findPitchPeriodInRange);
                }
            } else {
                sArr = findPitchPeriodInRange;
            }
        }
        i = previousPeriodBetter(this.minDiff, this.maxDiff, z) != 0 ? this.prevPeriod : sArr;
        this.prevMinDiff = this.minDiff;
        this.prevPeriod = sArr;
        return i;
    }

    private void moveNewSamplesToPitchBuffer(int i) {
        int i2 = this.numOutputSamples - i;
        int i3 = this.numPitchSamples + i2;
        int i4 = this.pitchBufferSize;
        if (i3 > i4) {
            this.pitchBufferSize = i4 + ((i4 / 2) + i2);
            this.pitchBuffer = Arrays.copyOf(this.pitchBuffer, this.pitchBufferSize * this.numChannels);
        }
        Object obj = this.outputBuffer;
        i4 = this.numChannels;
        System.arraycopy(obj, i * i4, this.pitchBuffer, this.numPitchSamples * i4, i4 * i2);
        this.numOutputSamples = i;
        this.numPitchSamples += i2;
    }

    private void removePitchSamples(int i) {
        if (i != 0) {
            Object obj = this.pitchBuffer;
            int i2 = this.numChannels;
            System.arraycopy(obj, i * i2, obj, 0, (this.numPitchSamples - i) * i2);
            this.numPitchSamples -= i;
        }
    }

    private void adjustPitch(int i) {
        if (this.numOutputSamples != i) {
            moveNewSamplesToPitchBuffer(i);
            int i2 = 0;
            while (this.numPitchSamples - i2 >= this.maxRequired) {
                int findPitchPeriod = findPitchPeriod(this.pitchBuffer, i2, 0);
                int i3 = (int) (((float) findPitchPeriod) / this.pitch);
                enlargeOutputBufferIfNeeded(i3);
                int i4;
                if (this.pitch >= 1.0f) {
                    i4 = this.numChannels;
                    short[] sArr = this.outputBuffer;
                    int i5 = this.numOutputSamples;
                    short[] sArr2 = this.pitchBuffer;
                    overlapAdd(i3, i4, sArr, i5, sArr2, i2, sArr2, (i2 + findPitchPeriod) - i3);
                } else {
                    int i6 = i3 - findPitchPeriod;
                    i4 = this.numChannels;
                    short[] sArr3 = this.outputBuffer;
                    int i7 = this.numOutputSamples;
                    short[] sArr4 = this.pitchBuffer;
                    overlapAddWithSeparation(findPitchPeriod, i4, i6, sArr3, i7, sArr4, i2, sArr4, i2);
                }
                this.numOutputSamples += i3;
                i2 += findPitchPeriod;
            }
            removePitchSamples(i2);
        }
    }

    private short interpolate(short[] sArr, int i, int i2, int i3) {
        short s = sArr[i];
        sArr = sArr[i + this.numChannels];
        i = this.newRatePosition * i2;
        i2 = this.oldRatePosition;
        int i4 = i2 * i3;
        i2 = (i2 + 1) * i3;
        i = i2 - i;
        i2 -= i4;
        return (short) (((s * i) + ((i2 - i) * sArr)) / i2);
    }

    private void adjustRate(float f, int i) {
        if (this.numOutputSamples != i) {
            int i2 = this.sampleRate;
            int i3 = (int) (((float) i2) / f);
            while (true) {
                if (i3 <= 16384) {
                    if (i2 <= 16384) {
                        break;
                    }
                }
                i3 /= 2;
                i2 /= 2;
            }
            moveNewSamplesToPitchBuffer(i);
            int i4 = 0;
            while (true) {
                int i5 = this.numPitchSamples;
                boolean z = true;
                if (i4 < i5 - 1) {
                    int i6;
                    while (true) {
                        i5 = this.oldRatePosition;
                        int i7 = (i5 + 1) * i3;
                        i6 = this.newRatePosition;
                        if (i7 <= i6 * i2) {
                            break;
                        }
                        enlargeOutputBufferIfNeeded(1);
                        i5 = 0;
                        while (true) {
                            i7 = this.numChannels;
                            if (i5 >= i7) {
                                break;
                            }
                            this.outputBuffer[(this.numOutputSamples * i7) + i5] = interpolate(this.pitchBuffer, (i7 * i4) + i5, i2, i3);
                            i5++;
                        }
                        this.newRatePosition++;
                        this.numOutputSamples++;
                    }
                    this.oldRatePosition = i5 + 1;
                    if (this.oldRatePosition == i2) {
                        this.oldRatePosition = 0;
                        if (i6 != i3) {
                            z = false;
                        }
                        Assertions.checkState(z);
                        this.newRatePosition = 0;
                    }
                    i4++;
                } else {
                    removePitchSamples(i5 - 1);
                    return;
                }
            }
        }
    }

    private int skipPitchPeriod(short[] sArr, int i, float f, int i2) {
        int i3;
        if (f >= 2.0f) {
            i3 = (int) (((float) i2) / (f - 1.0f));
        } else {
            this.remainingInputToCopy = (int) ((((float) i2) * (2.0f - f)) / (f - 1.0f));
            i3 = i2;
        }
        enlargeOutputBufferIfNeeded(i3);
        overlapAdd(i3, this.numChannels, this.outputBuffer, this.numOutputSamples, sArr, i, sArr, i + i2);
        this.numOutputSamples += i3;
        return i3;
    }

    private int insertPitchPeriod(short[] sArr, int i, float f, int i2) {
        int i3;
        if (f < 0.5f) {
            i3 = (int) ((((float) i2) * f) / (1.0f - f));
        } else {
            this.remainingInputToCopy = (int) ((((float) i2) * ((2.0f * f) - 1.0f)) / (1.0f - f));
            i3 = i2;
        }
        int i4 = i2 + i3;
        enlargeOutputBufferIfNeeded(i4);
        int i5 = this.numChannels;
        System.arraycopy(sArr, i * i5, this.outputBuffer, this.numOutputSamples * i5, i5 * i2);
        overlapAdd(i3, this.numChannels, this.outputBuffer, this.numOutputSamples + i2, sArr, i + i2, sArr, i);
        this.numOutputSamples += i4;
        return i3;
    }

    private void changeSpeed(float f) {
        int i = this.numInputSamples;
        if (i >= this.maxRequired) {
            int i2 = 0;
            do {
                if (this.remainingInputToCopy > 0) {
                    i2 += copyInputToOutput(i2);
                } else {
                    int findPitchPeriod = findPitchPeriod(this.inputBuffer, i2, true);
                    if (((double) f) > 1.0d) {
                        i2 += findPitchPeriod + skipPitchPeriod(this.inputBuffer, i2, f, findPitchPeriod);
                    } else {
                        i2 += insertPitchPeriod(this.inputBuffer, i2, f, findPitchPeriod);
                    }
                }
            } while (this.maxRequired + i2 <= i);
            removeProcessedInputSamples(i2);
        }
    }

    private void processStreamInput() {
        int i = this.numOutputSamples;
        float f = this.speed / this.pitch;
        double d = (double) f;
        if (d <= 1.00001d) {
            if (d >= 0.99999d) {
                copyToOutput(this.inputBuffer, 0, this.numInputSamples);
                this.numInputSamples = 0;
                f = this.pitch;
                if (f != 1.0f) {
                    adjustRate(f, i);
                }
            }
        }
        changeSpeed(f);
        f = this.pitch;
        if (f != 1.0f) {
            adjustRate(f, i);
        }
    }

    private static void overlapAdd(int i, int i2, short[] sArr, int i3, short[] sArr2, int i4, short[] sArr3, int i5) {
        for (int i6 = 0; i6 < i2; i6++) {
            int i7 = (i4 * i2) + i6;
            int i8 = (i5 * i2) + i6;
            int i9 = (i3 * i2) + i6;
            for (int i10 = 0; i10 < i; i10++) {
                sArr[i9] = (short) (((sArr2[i7] * (i - i10)) + (sArr3[i8] * i10)) / i);
                i9 += i2;
                i7 += i2;
                i8 += i2;
            }
        }
    }

    private static void overlapAddWithSeparation(int i, int i2, int i3, short[] sArr, int i4, short[] sArr2, int i5, short[] sArr3, int i6) {
        int i7 = i;
        int i8 = i2;
        int i9 = i3;
        for (int i10 = 0; i10 < i8; i10++) {
            int i11 = (i5 * i8) + i10;
            int i12 = (i6 * i8) + i10;
            int i13 = (i4 * i8) + i10;
            for (int i14 = 0; i14 < i7 + i9; i14++) {
                if (i14 < i9) {
                    sArr[i13] = (short) ((sArr2[i11] * (i7 - i14)) / i7);
                    i11 += i8;
                } else if (i14 < i7) {
                    sArr[i13] = (short) (((sArr2[i11] * (i7 - i14)) + (sArr3[i12] * (i14 - i9))) / i7);
                    i11 += i8;
                    i12 += i8;
                } else {
                    sArr[i13] = (short) ((sArr3[i12] * (i14 - i9)) / i7);
                    i12 += i8;
                }
                i13 += i8;
            }
        }
    }
}
