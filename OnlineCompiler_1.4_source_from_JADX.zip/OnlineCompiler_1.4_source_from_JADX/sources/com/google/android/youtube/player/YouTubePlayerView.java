package com.google.android.youtube.player;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver.OnGlobalFocusChangeListener;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.internal.C0484n;
import com.google.android.youtube.player.internal.C0494t.C0492a;
import com.google.android.youtube.player.internal.C0494t.C0493b;
import com.google.android.youtube.player.internal.C0499y;
import com.google.android.youtube.player.internal.C0880b;
import com.google.android.youtube.player.internal.C0903s;
import com.google.android.youtube.player.internal.aa;
import com.google.android.youtube.player.internal.ab;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public final class YouTubePlayerView extends ViewGroup implements Provider {
    /* renamed from: a */
    private final C0471a f67a;
    /* renamed from: b */
    private final Set<View> f68b;
    /* renamed from: c */
    private final C0472b f69c;
    /* renamed from: d */
    private C0880b f70d;
    /* renamed from: e */
    private C0903s f71e;
    /* renamed from: f */
    private View f72f;
    /* renamed from: g */
    private C0484n f73g;
    /* renamed from: h */
    private Provider f74h;
    /* renamed from: i */
    private Bundle f75i;
    /* renamed from: j */
    private OnInitializedListener f76j;
    /* renamed from: k */
    private boolean f77k;
    /* renamed from: l */
    private boolean f78l;

    /* renamed from: com.google.android.youtube.player.YouTubePlayerView$a */
    private final class C0471a implements OnGlobalFocusChangeListener {
        /* renamed from: a */
        final /* synthetic */ YouTubePlayerView f19a;

        private C0471a(YouTubePlayerView youTubePlayerView) {
            this.f19a = youTubePlayerView;
        }

        public final void onGlobalFocusChanged(View view, View view2) {
            if (this.f19a.f71e != null && this.f19a.f68b.contains(view2) && !this.f19a.f68b.contains(view)) {
                this.f19a.f71e.m331g();
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.YouTubePlayerView$b */
    interface C0472b {
        /* renamed from: a */
        void mo3424a(YouTubePlayerView youTubePlayerView);

        /* renamed from: a */
        void mo3425a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener);
    }

    /* renamed from: com.google.android.youtube.player.YouTubePlayerView$2 */
    class C08772 implements C0493b {
        /* renamed from: a */
        final /* synthetic */ YouTubePlayerView f66a;

        C08772(YouTubePlayerView youTubePlayerView) {
            this.f66a = youTubePlayerView;
        }

        /* renamed from: a */
        public final void mo3429a(YouTubeInitializationResult youTubeInitializationResult) {
            this.f66a.m178a(youTubeInitializationResult);
            this.f66a.f70d = null;
        }
    }

    public YouTubePlayerView(Context context) {
        this(context, null);
    }

    public YouTubePlayerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public YouTubePlayerView(Context context, AttributeSet attributeSet, int i) {
        if (context instanceof YouTubeBaseActivity) {
            this(context, attributeSet, i, ((YouTubeBaseActivity) context).m35a());
            return;
        }
        throw new IllegalStateException("A YouTubePlayerView can only be created with an Activity  which extends YouTubeBaseActivity as its context.");
    }

    YouTubePlayerView(Context context, AttributeSet attributeSet, int i, C0472b c0472b) {
        super((Context) ab.m55a((Object) context, (Object) "context cannot be null"), attributeSet, i);
        this.f69c = (C0472b) ab.m55a((Object) c0472b, (Object) "listener cannot be null");
        if (getBackground() == null) {
            setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        }
        setClipToPadding(false);
        this.f73g = new C0484n(context);
        requestTransparentRegion(this.f73g);
        addView(this.f73g);
        this.f68b = new HashSet();
        this.f67a = new C0471a();
    }

    /* renamed from: a */
    private void m177a(View view) {
        Object obj;
        if (view != this.f73g) {
            if (this.f71e == null || view != this.f72f) {
                obj = null;
                if (obj != null) {
                    throw new UnsupportedOperationException("No views can be added on top of the player");
                }
            }
        }
        obj = 1;
        if (obj != null) {
            throw new UnsupportedOperationException("No views can be added on top of the player");
        }
    }

    /* renamed from: a */
    private void m178a(YouTubeInitializationResult youTubeInitializationResult) {
        this.f71e = null;
        this.f73g.m131c();
        OnInitializedListener onInitializedListener = this.f76j;
        if (onInitializedListener != null) {
            onInitializedListener.onInitializationFailure(this.f74h, youTubeInitializationResult);
            this.f76j = null;
        }
    }

    /* renamed from: a */
    static /* synthetic */ void m179a(YouTubePlayerView youTubePlayerView, Activity activity) {
        try {
            youTubePlayerView.f71e = new C0903s(youTubePlayerView.f70d, aa.m49a().mo3442a(activity, youTubePlayerView.f70d, youTubePlayerView.f77k));
            youTubePlayerView.f72f = youTubePlayerView.f71e.m319a();
            youTubePlayerView.addView(youTubePlayerView.f72f);
            youTubePlayerView.removeView(youTubePlayerView.f73g);
            youTubePlayerView.f69c.mo3424a(youTubePlayerView);
            if (youTubePlayerView.f76j != null) {
                boolean z = false;
                Bundle bundle = youTubePlayerView.f75i;
                if (bundle != null) {
                    z = youTubePlayerView.f71e.m323a(bundle);
                    youTubePlayerView.f75i = null;
                }
                youTubePlayerView.f76j.onInitializationSuccess(youTubePlayerView.f74h, youTubePlayerView.f71e, z);
                youTubePlayerView.f76j = null;
            }
        } catch (Throwable e) {
            C0499y.m145a("Error creating YouTubePlayerView", e);
            youTubePlayerView.m178a(YouTubeInitializationResult.INTERNAL_ERROR);
        }
    }

    /* renamed from: a */
    final void m189a() {
        C0903s c0903s = this.f71e;
        if (c0903s != null) {
            c0903s.m324b();
        }
    }

    /* renamed from: a */
    final void m190a(final Activity activity, Provider provider, String str, OnInitializedListener onInitializedListener, Bundle bundle) {
        if (this.f71e != null) {
            return;
        }
        if (this.f76j == null) {
            ab.m55a((Object) activity, (Object) "activity cannot be null");
            this.f74h = (Provider) ab.m55a((Object) provider, (Object) "provider cannot be null");
            this.f76j = (OnInitializedListener) ab.m55a((Object) onInitializedListener, (Object) "listener cannot be null");
            this.f75i = bundle;
            this.f73g.m130b();
            this.f70d = aa.m49a().mo3441a(getContext(), str, new C0492a(this) {
                /* renamed from: b */
                final /* synthetic */ YouTubePlayerView f65b;

                /* renamed from: a */
                public final void mo3427a() {
                    if (this.f65b.f70d != null) {
                        YouTubePlayerView.m179a(this.f65b, activity);
                    }
                    this.f65b.f70d = null;
                }

                /* renamed from: b */
                public final void mo3428b() {
                    if (!(this.f65b.f78l || this.f65b.f71e == null)) {
                        this.f65b.f71e.m330f();
                    }
                    this.f65b.f73g.m129a();
                    YouTubePlayerView youTubePlayerView = this.f65b;
                    if (youTubePlayerView.indexOfChild(youTubePlayerView.f73g) < 0) {
                        youTubePlayerView = this.f65b;
                        youTubePlayerView.addView(youTubePlayerView.f73g);
                        youTubePlayerView = this.f65b;
                        youTubePlayerView.removeView(youTubePlayerView.f72f);
                    }
                    this.f65b.f72f = null;
                    this.f65b.f71e = null;
                    this.f65b.f70d = null;
                }
            }, new C08772(this));
            this.f70d.mo3516e();
        }
    }

    /* renamed from: a */
    final void m191a(boolean z) {
        if (!z || VERSION.SDK_INT >= 14) {
            this.f77k = z;
            return;
        }
        C0499y.m146a("Could not enable TextureView because API level is lower than 14", new Object[0]);
        this.f77k = false;
    }

    public final void addFocusables(ArrayList<View> arrayList, int i) {
        Collection arrayList2 = new ArrayList();
        super.addFocusables(arrayList2, i);
        arrayList.addAll(arrayList2);
        this.f68b.clear();
        this.f68b.addAll(arrayList2);
    }

    public final void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        Collection arrayList2 = new ArrayList();
        super.addFocusables(arrayList2, i, i2);
        arrayList.addAll(arrayList2);
        this.f68b.clear();
        this.f68b.addAll(arrayList2);
    }

    public final void addView(View view) {
        m177a(view);
        super.addView(view);
    }

    public final void addView(View view, int i) {
        m177a(view);
        super.addView(view, i);
    }

    public final void addView(View view, int i, int i2) {
        m177a(view);
        super.addView(view, i, i2);
    }

    public final void addView(View view, int i, LayoutParams layoutParams) {
        m177a(view);
        super.addView(view, i, layoutParams);
    }

    public final void addView(View view, LayoutParams layoutParams) {
        m177a(view);
        super.addView(view, layoutParams);
    }

    /* renamed from: b */
    final void m192b() {
        C0903s c0903s = this.f71e;
        if (c0903s != null) {
            c0903s.m327c();
        }
    }

    /* renamed from: b */
    final void m193b(boolean z) {
        C0903s c0903s = this.f71e;
        if (c0903s != null) {
            c0903s.m325b(z);
            m195c(z);
        }
    }

    /* renamed from: c */
    final void m194c() {
        C0903s c0903s = this.f71e;
        if (c0903s != null) {
            c0903s.m328d();
        }
    }

    /* renamed from: c */
    final void m195c(boolean z) {
        this.f78l = true;
        C0903s c0903s = this.f71e;
        if (c0903s != null) {
            c0903s.m321a(z);
        }
    }

    public final void clearChildFocus(View view) {
        if (hasFocusable()) {
            requestFocus();
        } else {
            super.clearChildFocus(view);
        }
    }

    /* renamed from: d */
    final void m196d() {
        C0903s c0903s = this.f71e;
        if (c0903s != null) {
            c0903s.m329e();
        }
    }

    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (this.f71e != null) {
            if (keyEvent.getAction() == 0) {
                if (!this.f71e.m322a(keyEvent.getKeyCode(), keyEvent)) {
                    if (!super.dispatchKeyEvent(keyEvent)) {
                        return false;
                    }
                }
                return true;
            } else if (keyEvent.getAction() == 1) {
                if (!this.f71e.m326b(keyEvent.getKeyCode(), keyEvent)) {
                    if (!super.dispatchKeyEvent(keyEvent)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    /* renamed from: e */
    final Bundle m197e() {
        C0903s c0903s = this.f71e;
        return c0903s == null ? this.f75i : c0903s.m332h();
    }

    public final void focusableViewAvailable(View view) {
        super.focusableViewAvailable(view);
        this.f68b.add(view);
    }

    public final void initialize(String str, OnInitializedListener onInitializedListener) {
        ab.m56a(str, (Object) "Developer key cannot be null or empty");
        this.f69c.mo3425a(this, str, onInitializedListener);
    }

    protected final void onAttachedToWindow() {
        super.onAttachedToWindow();
        getViewTreeObserver().addOnGlobalFocusChangeListener(this.f67a);
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0903s c0903s = this.f71e;
        if (c0903s != null) {
            c0903s.m320a(configuration);
        }
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getViewTreeObserver().removeOnGlobalFocusChangeListener(this.f67a);
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (getChildCount() > 0) {
            getChildAt(0).layout(0, 0, i3 - i, i4 - i2);
        }
    }

    protected final void onMeasure(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            childAt.measure(i, i2);
            setMeasuredDimension(childAt.getMeasuredWidth(), childAt.getMeasuredHeight());
            return;
        }
        setMeasuredDimension(0, 0);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public final void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        this.f68b.add(view2);
    }

    public final void setClipToPadding(boolean z) {
    }

    public final void setPadding(int i, int i2, int i3, int i4) {
    }
}
