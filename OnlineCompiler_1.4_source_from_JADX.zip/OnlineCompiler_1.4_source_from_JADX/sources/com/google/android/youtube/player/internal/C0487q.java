package com.google.android.youtube.player.internal;

import android.os.RemoteException;

/* renamed from: com.google.android.youtube.player.internal.q */
public final class C0487q extends RuntimeException {
    public C0487q(RemoteException remoteException) {
        super(remoteException);
    }
}
