package com.google.android.youtube.player.internal;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.KeyEvent;
import android.view.View;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayer.OnFullscreenListener;
import com.google.android.youtube.player.YouTubePlayer.PlaybackEventListener;
import com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener;
import com.google.android.youtube.player.YouTubePlayer.PlayerStyle;
import com.google.android.youtube.player.YouTubePlayer.PlaylistEventListener;
import com.google.android.youtube.player.internal.C0475e.C0886a;
import com.google.android.youtube.player.internal.C0476f.C0888a;
import com.google.android.youtube.player.internal.C0477g.C0890a;
import com.google.android.youtube.player.internal.C0478h.C0892a;
import java.util.List;

/* renamed from: com.google.android.youtube.player.internal.s */
public final class C0903s implements YouTubePlayer {
    /* renamed from: a */
    private C0880b f109a;
    /* renamed from: b */
    private C0474d f110b;

    public C0903s(C0880b c0880b, C0474d c0474d) {
        this.f109a = (C0880b) ab.m55a((Object) c0880b, (Object) "connectionClient cannot be null");
        this.f110b = (C0474d) ab.m55a((Object) c0474d, (Object) "embeddedPlayer cannot be null");
    }

    /* renamed from: a */
    public final View m319a() {
        try {
            return (View) C1092v.m376a(this.f110b.mo3486s());
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: a */
    public final void m320a(Configuration configuration) {
        try {
            this.f110b.mo3446a(configuration);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: a */
    public final void m321a(boolean z) {
        try {
            this.f110b.mo3455a(z);
            this.f109a.mo4729a(z);
            this.f109a.mo3515d();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: a */
    public final boolean m322a(int i, KeyEvent keyEvent) {
        try {
            return this.f110b.mo3456a(i, keyEvent);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: a */
    public final boolean m323a(Bundle bundle) {
        try {
            return this.f110b.mo3457a(bundle);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void addFullscreenControlFlag(int i) {
        try {
            this.f110b.mo3468d(i);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: b */
    public final void m324b() {
        try {
            this.f110b.mo3480m();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: b */
    public final void m325b(boolean z) {
        try {
            this.f110b.mo3471e(z);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: b */
    public final boolean m326b(int i, KeyEvent keyEvent) {
        try {
            return this.f110b.mo3464b(i, keyEvent);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: c */
    public final void m327c() {
        try {
            this.f110b.mo3481n();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void cuePlaylist(String str) {
        cuePlaylist(str, 0, 0);
    }

    public final void cuePlaylist(String str, int i, int i2) {
        try {
            this.f110b.mo3453a(str, i, i2);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void cueVideo(String str) {
        cueVideo(str, 0);
    }

    public final void cueVideo(String str, int i) {
        try {
            this.f110b.mo3452a(str, i);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void cueVideos(List<String> list) {
        cueVideos(list, 0, 0);
    }

    public final void cueVideos(List<String> list, int i, int i2) {
        try {
            this.f110b.mo3454a((List) list, i, i2);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: d */
    public final void m328d() {
        try {
            this.f110b.mo3482o();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: e */
    public final void m329e() {
        try {
            this.f110b.mo3483p();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: f */
    public final void m330f() {
        try {
            this.f110b.mo3484q();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: g */
    public final void m331g() {
        try {
            this.f110b.mo3479l();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final int getCurrentTimeMillis() {
        try {
            return this.f110b.mo3475h();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final int getDurationMillis() {
        try {
            return this.f110b.mo3476i();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final int getFullscreenControlFlags() {
        try {
            return this.f110b.mo3477j();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    /* renamed from: h */
    public final Bundle m332h() {
        try {
            return this.f110b.mo3485r();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final boolean hasNext() {
        try {
            return this.f110b.mo3470d();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final boolean hasPrevious() {
        try {
            return this.f110b.mo3472e();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final boolean isPlaying() {
        try {
            return this.f110b.mo3467c();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void loadPlaylist(String str) {
        loadPlaylist(str, 0, 0);
    }

    public final void loadPlaylist(String str, int i, int i2) {
        try {
            this.f110b.mo3461b(str, i, i2);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void loadVideo(String str) {
        loadVideo(str, 0);
    }

    public final void loadVideo(String str, int i) {
        try {
            this.f110b.mo3460b(str, i);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void loadVideos(List<String> list) {
        loadVideos(list, 0, 0);
    }

    public final void loadVideos(List<String> list, int i, int i2) {
        try {
            this.f110b.mo3462b((List) list, i, i2);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void next() {
        try {
            this.f110b.mo3473f();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void pause() {
        try {
            this.f110b.mo3458b();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void play() {
        try {
            this.f110b.mo3444a();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void previous() {
        try {
            this.f110b.mo3474g();
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void release() {
        m321a(true);
    }

    public final void seekRelativeMillis(int i) {
        try {
            this.f110b.mo3459b(i);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void seekToMillis(int i) {
        try {
            this.f110b.mo3445a(i);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void setFullscreen(boolean z) {
        try {
            this.f110b.mo3463b(z);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void setFullscreenControlFlags(int i) {
        try {
            this.f110b.mo3465c(i);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void setManageAudioFocus(boolean z) {
        try {
            this.f110b.mo3469d(z);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void setOnFullscreenListener(final OnFullscreenListener onFullscreenListener) {
        try {
            this.f110b.mo3447a(new C0886a(this) {
                /* renamed from: b */
                final /* synthetic */ C0903s f130b;

                /* renamed from: a */
                public final void mo3487a(boolean z) {
                    onFullscreenListener.onFullscreen(z);
                }
            });
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void setPlaybackEventListener(final PlaybackEventListener playbackEventListener) {
        try {
            this.f110b.mo3448a(new C0888a(this) {
                /* renamed from: b */
                final /* synthetic */ C0903s f136b;

                /* renamed from: a */
                public final void mo3488a() {
                    playbackEventListener.onPlaying();
                }

                /* renamed from: a */
                public final void mo3489a(int i) {
                    playbackEventListener.onSeekTo(i);
                }

                /* renamed from: a */
                public final void mo3490a(boolean z) {
                    playbackEventListener.onBuffering(z);
                }

                /* renamed from: b */
                public final void mo3491b() {
                    playbackEventListener.onPaused();
                }

                /* renamed from: c */
                public final void mo3492c() {
                    playbackEventListener.onStopped();
                }
            });
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void setPlayerStateChangeListener(final PlayerStateChangeListener playerStateChangeListener) {
        try {
            this.f110b.mo3449a(new C0890a(this) {
                /* renamed from: b */
                final /* synthetic */ C0903s f134b;

                /* renamed from: a */
                public final void mo3493a() {
                    playerStateChangeListener.onLoading();
                }

                /* renamed from: a */
                public final void mo3494a(String str) {
                    playerStateChangeListener.onLoaded(str);
                }

                /* renamed from: b */
                public final void mo3495b() {
                    playerStateChangeListener.onAdStarted();
                }

                /* renamed from: b */
                public final void mo3496b(java.lang.String r2) {
                    /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
                    /*
                    r1 = this;
                    r2 = com.google.android.youtube.player.YouTubePlayer.ErrorReason.valueOf(r2);	 Catch:{ IllegalArgumentException -> 0x0005, IllegalArgumentException -> 0x0005 }
                    goto L_0x0007;
                L_0x0005:
                    r2 = com.google.android.youtube.player.YouTubePlayer.ErrorReason.UNKNOWN;
                L_0x0007:
                    r0 = r3;
                    r0.onError(r2);
                    return;
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.s.3.b(java.lang.String):void");
                }

                /* renamed from: c */
                public final void mo3497c() {
                    playerStateChangeListener.onVideoStarted();
                }

                /* renamed from: d */
                public final void mo3498d() {
                    playerStateChangeListener.onVideoEnded();
                }
            });
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void setPlayerStyle(PlayerStyle playerStyle) {
        try {
            this.f110b.mo3451a(playerStyle.name());
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void setPlaylistEventListener(final PlaylistEventListener playlistEventListener) {
        try {
            this.f110b.mo3450a(new C0892a(this) {
                /* renamed from: b */
                final /* synthetic */ C0903s f132b;

                /* renamed from: a */
                public final void mo3499a() {
                    playlistEventListener.onPrevious();
                }

                /* renamed from: b */
                public final void mo3500b() {
                    playlistEventListener.onNext();
                }

                /* renamed from: c */
                public final void mo3501c() {
                    playlistEventListener.onPlaylistEnded();
                }
            });
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }

    public final void setShowFullscreenButton(boolean z) {
        try {
            this.f110b.mo3466c(z);
        } catch (RemoteException e) {
            throw new C0487q(e);
        }
    }
}
