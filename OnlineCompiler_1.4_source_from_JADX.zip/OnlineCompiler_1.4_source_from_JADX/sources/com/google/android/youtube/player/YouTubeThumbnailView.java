package com.google.android.youtube.player;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import com.google.android.youtube.player.internal.C0494t.C0492a;
import com.google.android.youtube.player.internal.C0494t.C0493b;
import com.google.android.youtube.player.internal.C0879a;
import com.google.android.youtube.player.internal.C0880b;
import com.google.android.youtube.player.internal.aa;
import com.google.android.youtube.player.internal.ab;

public final class YouTubeThumbnailView extends ImageView {
    /* renamed from: a */
    private C0880b f21a;
    /* renamed from: b */
    private C0879a f22b;

    public interface OnInitializedListener {
        void onInitializationFailure(YouTubeThumbnailView youTubeThumbnailView, YouTubeInitializationResult youTubeInitializationResult);

        void onInitializationSuccess(YouTubeThumbnailView youTubeThumbnailView, YouTubeThumbnailLoader youTubeThumbnailLoader);
    }

    /* renamed from: com.google.android.youtube.player.YouTubeThumbnailView$a */
    private static final class C0878a implements C0492a, C0493b {
        /* renamed from: a */
        private YouTubeThumbnailView f79a;
        /* renamed from: b */
        private OnInitializedListener f80b;

        public C0878a(YouTubeThumbnailView youTubeThumbnailView, OnInitializedListener onInitializedListener) {
            this.f79a = (YouTubeThumbnailView) ab.m55a((Object) youTubeThumbnailView, (Object) "thumbnailView cannot be null");
            this.f80b = (OnInitializedListener) ab.m55a((Object) onInitializedListener, (Object) "onInitializedlistener cannot be null");
        }

        /* renamed from: c */
        private void m198c() {
            YouTubeThumbnailView youTubeThumbnailView = this.f79a;
            if (youTubeThumbnailView != null) {
                youTubeThumbnailView.f21a = null;
                this.f79a = null;
                this.f80b = null;
            }
        }

        /* renamed from: a */
        public final void mo3427a() {
            YouTubeThumbnailView youTubeThumbnailView = this.f79a;
            if (youTubeThumbnailView != null && youTubeThumbnailView.f21a != null) {
                this.f79a.f22b = aa.m49a().mo3440a(this.f79a.f21a, this.f79a);
                OnInitializedListener onInitializedListener = this.f80b;
                YouTubeThumbnailView youTubeThumbnailView2 = this.f79a;
                onInitializedListener.onInitializationSuccess(youTubeThumbnailView2, youTubeThumbnailView2.f22b);
                m198c();
            }
        }

        /* renamed from: a */
        public final void mo3429a(YouTubeInitializationResult youTubeInitializationResult) {
            this.f80b.onInitializationFailure(this.f79a, youTubeInitializationResult);
            m198c();
        }

        /* renamed from: b */
        public final void mo3428b() {
            m198c();
        }
    }

    public YouTubeThumbnailView(Context context) {
        this(context, null);
    }

    public YouTubeThumbnailView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public YouTubeThumbnailView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    protected final void finalize() throws Throwable {
        C0879a c0879a = this.f22b;
        if (c0879a != null) {
            c0879a.m207b();
            this.f22b = null;
        }
        super.finalize();
    }

    public final void initialize(String str, OnInitializedListener onInitializedListener) {
        Object c0878a = new C0878a(this, onInitializedListener);
        this.f21a = aa.m49a().mo3441a(getContext(), str, c0878a, c0878a);
        this.f21a.mo3516e();
    }
}
