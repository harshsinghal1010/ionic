package com.google.android.youtube.player.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.youtube.player.YouTubeApiServiceUtil;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.internal.C0473c.C0882a;
import com.google.android.youtube.player.internal.C0494t.C0492a;
import com.google.android.youtube.player.internal.C0494t.C0493b;
import java.util.ArrayList;

/* renamed from: com.google.android.youtube.player.internal.r */
public abstract class C0902r<T extends IInterface> implements C0494t {
    /* renamed from: a */
    final Handler f98a;
    /* renamed from: b */
    private final Context f99b;
    /* renamed from: c */
    private T f100c;
    /* renamed from: d */
    private ArrayList<C0492a> f101d;
    /* renamed from: e */
    private final ArrayList<C0492a> f102e = new ArrayList();
    /* renamed from: f */
    private boolean f103f = false;
    /* renamed from: g */
    private ArrayList<C0493b> f104g;
    /* renamed from: h */
    private boolean f105h = false;
    /* renamed from: i */
    private final ArrayList<C0490b<?>> f106i = new ArrayList();
    /* renamed from: j */
    private ServiceConnection f107j;
    /* renamed from: k */
    private boolean f108k = false;

    /* renamed from: com.google.android.youtube.player.internal.r$1 */
    static /* synthetic */ class C04881 {
        /* renamed from: a */
        static final /* synthetic */ int[] f45a = new int[YouTubeInitializationResult.values().length];

        static {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
            /*
            r0 = com.google.android.youtube.player.YouTubeInitializationResult.values();
            r0 = r0.length;
            r0 = new int[r0];
            f45a = r0;
            r0 = f45a;	 Catch:{ NoSuchFieldError -> 0x0014 }
            r1 = com.google.android.youtube.player.YouTubeInitializationResult.SUCCESS;	 Catch:{ NoSuchFieldError -> 0x0014 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0014 }
            r2 = 1;	 Catch:{ NoSuchFieldError -> 0x0014 }
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0014 }
        L_0x0014:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.1.<clinit>():void");
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r$a */
    final class C0489a extends Handler {
        /* renamed from: a */
        final /* synthetic */ C0902r f46a;

        C0489a(C0902r c0902r) {
            this.f46a = c0902r;
        }

        public final void handleMessage(Message message) {
            if (message.what == 3) {
                this.f46a.m307a((YouTubeInitializationResult) message.obj);
            } else if (message.what == 4) {
                synchronized (this.f46a.f101d) {
                    if (this.f46a.f108k && this.f46a.m314f() && this.f46a.f101d.contains(message.obj)) {
                        ((C0492a) message.obj).mo3427a();
                    }
                }
            } else if (message.what != 2 || this.f46a.m314f()) {
                if (message.what != 2) {
                    if (message.what != 1) {
                        return;
                    }
                }
                ((C0490b) message.obj).m132a();
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r$b */
    protected abstract class C0490b<TListener> {
        /* renamed from: a */
        final /* synthetic */ C0902r f47a;
        /* renamed from: b */
        private TListener f48b;

        public C0490b(C0902r c0902r, TListener tListener) {
            this.f47a = c0902r;
            this.f48b = tListener;
            synchronized (c0902r.f106i) {
                c0902r.f106i.add(this);
            }
        }

        /* renamed from: a */
        public final void m132a() {
            Object obj;
            synchronized (this) {
                obj = this.f48b;
            }
            mo3514a(obj);
        }

        /* renamed from: a */
        protected abstract void mo3514a(TListener tListener);

        /* renamed from: b */
        public final void m134b() {
            synchronized (this) {
                this.f48b = null;
            }
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r$e */
    final class C0491e implements ServiceConnection {
        /* renamed from: a */
        final /* synthetic */ C0902r f49a;

        C0491e(C0902r c0902r) {
            this.f49a = c0902r;
        }

        public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            this.f49a.m310b(iBinder);
        }

        public final void onServiceDisconnected(ComponentName componentName) {
            this.f49a.f100c = null;
            this.f49a.m316h();
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r$c */
    protected final class C0901c extends C0490b<Boolean> {
        /* renamed from: b */
        public final YouTubeInitializationResult f95b;
        /* renamed from: c */
        public final IBinder f96c;
        /* renamed from: d */
        final /* synthetic */ C0902r f97d;

        public C0901c(C0902r c0902r, String str, IBinder iBinder) {
            this.f97d = c0902r;
            super(c0902r, Boolean.valueOf(true));
            this.f95b = C0902r.m301b(str);
            this.f96c = iBinder;
        }

        /* renamed from: a */
        protected final /* synthetic */ void mo3514a(java.lang.Object r3) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
            /*
            r2 = this;
            r3 = (java.lang.Boolean) r3;
            if (r3 == 0) goto L_0x0052;
        L_0x0004:
            r3 = com.google.android.youtube.player.internal.C0902r.C04881.f45a;
            r0 = r2.f95b;
            r0 = r0.ordinal();
            r3 = r3[r0];
            r0 = 1;
            if (r3 == r0) goto L_0x0019;
        L_0x0011:
            r3 = r2.f97d;
            r0 = r2.f95b;
            r3.m307a(r0);
            goto L_0x0052;
        L_0x0019:
            r3 = r2.f96c;	 Catch:{ RemoteException -> 0x0046 }
            r3 = r3.getInterfaceDescriptor();	 Catch:{ RemoteException -> 0x0046 }
            r0 = r2.f97d;	 Catch:{ RemoteException -> 0x0046 }
            r0 = r0.mo4730b();	 Catch:{ RemoteException -> 0x0046 }
            r3 = r0.equals(r3);	 Catch:{ RemoteException -> 0x0046 }
            if (r3 == 0) goto L_0x0046;	 Catch:{ RemoteException -> 0x0046 }
        L_0x002b:
            r3 = r2.f97d;	 Catch:{ RemoteException -> 0x0046 }
            r0 = r2.f97d;	 Catch:{ RemoteException -> 0x0046 }
            r1 = r2.f96c;	 Catch:{ RemoteException -> 0x0046 }
            r0 = r0.mo4726a(r1);	 Catch:{ RemoteException -> 0x0046 }
            r3.f100c = r0;	 Catch:{ RemoteException -> 0x0046 }
            r3 = r2.f97d;	 Catch:{ RemoteException -> 0x0046 }
            r3 = r3.f100c;	 Catch:{ RemoteException -> 0x0046 }
            if (r3 == 0) goto L_0x0046;	 Catch:{ RemoteException -> 0x0046 }
        L_0x0040:
            r3 = r2.f97d;	 Catch:{ RemoteException -> 0x0046 }
            r3.m315g();	 Catch:{ RemoteException -> 0x0046 }
            return;
        L_0x0046:
            r3 = r2.f97d;
            r3.mo4725a();
            r3 = r2.f97d;
            r0 = com.google.android.youtube.player.YouTubeInitializationResult.INTERNAL_ERROR;
            r3.m307a(r0);
        L_0x0052:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.c.a(java.lang.Object):void");
        }
    }

    /* renamed from: com.google.android.youtube.player.internal.r$d */
    protected final class C1087d extends C0882a {
        /* renamed from: a */
        final /* synthetic */ C0902r f128a;

        protected C1087d(C0902r c0902r) {
            this.f128a = c0902r;
        }

        /* renamed from: a */
        public final void mo3443a(String str, IBinder iBinder) {
            this.f128a.f98a.sendMessage(this.f128a.f98a.obtainMessage(1, new C0901c(this.f128a, str, iBinder)));
        }
    }

    protected C0902r(Context context, C0492a c0492a, C0493b c0493b) {
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            this.f99b = (Context) ab.m54a((Object) context);
            this.f101d = new ArrayList();
            this.f101d.add(ab.m54a((Object) c0492a));
            this.f104g = new ArrayList();
            this.f104g.add(ab.m54a((Object) c0493b));
            this.f98a = new C0489a(this);
            return;
        }
        throw new IllegalStateException("Clients must be created on the UI thread.");
    }

    /* renamed from: a */
    private void mo4725a() {
        ServiceConnection serviceConnection = this.f107j;
        if (serviceConnection != null) {
            try {
                this.f99b.unbindService(serviceConnection);
            } catch (Throwable e) {
                Log.w("YouTubeClient", "Unexpected error from unbindService()", e);
            }
        }
        this.f100c = null;
        this.f107j = null;
    }

    /* renamed from: b */
    private static com.google.android.youtube.player.YouTubeInitializationResult m301b(java.lang.String r0) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = com.google.android.youtube.player.YouTubeInitializationResult.valueOf(r0);	 Catch:{ IllegalArgumentException -> 0x0008, NullPointerException -> 0x0005 }
        return r0;
    L_0x0005:
        r0 = com.google.android.youtube.player.YouTubeInitializationResult.UNKNOWN_ERROR;
        return r0;
    L_0x0008:
        r0 = com.google.android.youtube.player.YouTubeInitializationResult.UNKNOWN_ERROR;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.b(java.lang.String):com.google.android.youtube.player.YouTubeInitializationResult");
    }

    /* renamed from: a */
    protected abstract T mo4726a(IBinder iBinder);

    /* renamed from: a */
    protected final void m307a(com.google.android.youtube.player.YouTubeInitializationResult r8) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:20:0x003b in {9, 12, 13, 16, 19} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r7 = this;
        r0 = r7.f98a;
        r1 = 4;
        r0.removeMessages(r1);
        r0 = r7.f104g;
        monitor-enter(r0);
        r1 = 1;
        r7.f105h = r1;	 Catch:{ all -> 0x0038 }
        r1 = r7.f104g;	 Catch:{ all -> 0x0038 }
        r2 = r1.size();	 Catch:{ all -> 0x0038 }
        r3 = 0;	 Catch:{ all -> 0x0038 }
        r4 = 0;	 Catch:{ all -> 0x0038 }
    L_0x0014:
        if (r4 >= r2) goto L_0x0034;	 Catch:{ all -> 0x0038 }
    L_0x0016:
        r5 = r7.f108k;	 Catch:{ all -> 0x0038 }
        if (r5 != 0) goto L_0x001c;	 Catch:{ all -> 0x0038 }
    L_0x001a:
        monitor-exit(r0);	 Catch:{ all -> 0x0038 }
        return;	 Catch:{ all -> 0x0038 }
    L_0x001c:
        r5 = r7.f104g;	 Catch:{ all -> 0x0038 }
        r6 = r1.get(r4);	 Catch:{ all -> 0x0038 }
        r5 = r5.contains(r6);	 Catch:{ all -> 0x0038 }
        if (r5 == 0) goto L_0x0031;	 Catch:{ all -> 0x0038 }
    L_0x0028:
        r5 = r1.get(r4);	 Catch:{ all -> 0x0038 }
        r5 = (com.google.android.youtube.player.internal.C0494t.C0493b) r5;	 Catch:{ all -> 0x0038 }
        r5.mo3429a(r8);	 Catch:{ all -> 0x0038 }
    L_0x0031:
        r4 = r4 + 1;	 Catch:{ all -> 0x0038 }
        goto L_0x0014;	 Catch:{ all -> 0x0038 }
    L_0x0034:
        r7.f105h = r3;	 Catch:{ all -> 0x0038 }
        monitor-exit(r0);	 Catch:{ all -> 0x0038 }
        return;	 Catch:{ all -> 0x0038 }
    L_0x0038:
        r8 = move-exception;	 Catch:{ all -> 0x0038 }
        monitor-exit(r0);	 Catch:{ all -> 0x0038 }
        throw r8;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.a(com.google.android.youtube.player.YouTubeInitializationResult):void");
    }

    /* renamed from: a */
    protected abstract void mo4728a(C0479i c0479i, C1087d c1087d) throws RemoteException;

    /* renamed from: b */
    protected abstract String mo4730b();

    /* renamed from: b */
    protected final void m310b(android.os.IBinder r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r1 = this;
        r2 = com.google.android.youtube.player.internal.C0479i.C0894a.m282a(r2);	 Catch:{ RemoteException -> 0x000d }
        r0 = new com.google.android.youtube.player.internal.r$d;	 Catch:{ RemoteException -> 0x000d }
        r0.<init>(r1);	 Catch:{ RemoteException -> 0x000d }
        r1.mo4728a(r2, r0);	 Catch:{ RemoteException -> 0x000d }
        return;
    L_0x000d:
        r2 = "YouTubeClient";
        r0 = "service died";
        android.util.Log.w(r2, r0);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.b(android.os.IBinder):void");
    }

    /* renamed from: c */
    protected abstract String mo4731c();

    /* renamed from: d */
    public void mo3515d() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:14:0x002c in {5, 9, 13} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r4 = this;
        r4.m316h();
        r0 = 0;
        r4.f108k = r0;
        r1 = r4.f106i;
        monitor-enter(r1);
        r2 = r4.f106i;	 Catch:{ all -> 0x0029 }
        r2 = r2.size();	 Catch:{ all -> 0x0029 }
    L_0x000f:
        if (r0 >= r2) goto L_0x001f;	 Catch:{ all -> 0x0029 }
    L_0x0011:
        r3 = r4.f106i;	 Catch:{ all -> 0x0029 }
        r3 = r3.get(r0);	 Catch:{ all -> 0x0029 }
        r3 = (com.google.android.youtube.player.internal.C0902r.C0490b) r3;	 Catch:{ all -> 0x0029 }
        r3.m134b();	 Catch:{ all -> 0x0029 }
        r0 = r0 + 1;	 Catch:{ all -> 0x0029 }
        goto L_0x000f;	 Catch:{ all -> 0x0029 }
    L_0x001f:
        r0 = r4.f106i;	 Catch:{ all -> 0x0029 }
        r0.clear();	 Catch:{ all -> 0x0029 }
        monitor-exit(r1);	 Catch:{ all -> 0x0029 }
        r4.mo4725a();
        return;
    L_0x0029:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0029 }
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.d():void");
    }

    /* renamed from: e */
    public final void mo3516e() {
        this.f108k = true;
        YouTubeInitializationResult isYouTubeApiServiceAvailable = YouTubeApiServiceUtil.isYouTubeApiServiceAvailable(this.f99b);
        if (isYouTubeApiServiceAvailable != YouTubeInitializationResult.SUCCESS) {
            Handler handler = this.f98a;
            handler.sendMessage(handler.obtainMessage(3, isYouTubeApiServiceAvailable));
            return;
        }
        Intent intent = new Intent(mo4731c()).setPackage(C0500z.m149a(this.f99b));
        if (this.f107j != null) {
            Log.e("YouTubeClient", "Calling connect() while still connected, missing disconnect().");
            mo4725a();
        }
        this.f107j = new C0491e(this);
        if (!this.f99b.bindService(intent, this.f107j, 129)) {
            Handler handler2 = this.f98a;
            handler2.sendMessage(handler2.obtainMessage(3, YouTubeInitializationResult.ERROR_CONNECTING_TO_SERVICE));
        }
    }

    /* renamed from: f */
    public final boolean m314f() {
        return this.f100c != null;
    }

    /* renamed from: g */
    protected final void m315g() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:27:0x005b in {5, 6, 9, 10, 19, 20, 23, 26} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r7 = this;
        r0 = r7.f101d;
        monitor-enter(r0);
        r1 = r7.f103f;	 Catch:{ all -> 0x0058 }
        r2 = 1;	 Catch:{ all -> 0x0058 }
        r3 = 0;	 Catch:{ all -> 0x0058 }
        if (r1 != 0) goto L_0x000b;	 Catch:{ all -> 0x0058 }
    L_0x0009:
        r1 = 1;	 Catch:{ all -> 0x0058 }
        goto L_0x000c;	 Catch:{ all -> 0x0058 }
    L_0x000b:
        r1 = 0;	 Catch:{ all -> 0x0058 }
    L_0x000c:
        com.google.android.youtube.player.internal.ab.m57a(r1);	 Catch:{ all -> 0x0058 }
        r1 = r7.f98a;	 Catch:{ all -> 0x0058 }
        r4 = 4;	 Catch:{ all -> 0x0058 }
        r1.removeMessages(r4);	 Catch:{ all -> 0x0058 }
        r7.f103f = r2;	 Catch:{ all -> 0x0058 }
        r1 = r7.f102e;	 Catch:{ all -> 0x0058 }
        r1 = r1.size();	 Catch:{ all -> 0x0058 }
        if (r1 != 0) goto L_0x0020;	 Catch:{ all -> 0x0058 }
    L_0x001f:
        goto L_0x0021;	 Catch:{ all -> 0x0058 }
    L_0x0020:
        r2 = 0;	 Catch:{ all -> 0x0058 }
    L_0x0021:
        com.google.android.youtube.player.internal.ab.m57a(r2);	 Catch:{ all -> 0x0058 }
        r1 = r7.f101d;	 Catch:{ all -> 0x0058 }
        r2 = r1.size();	 Catch:{ all -> 0x0058 }
        r4 = 0;	 Catch:{ all -> 0x0058 }
    L_0x002b:
        if (r4 >= r2) goto L_0x004f;	 Catch:{ all -> 0x0058 }
    L_0x002d:
        r5 = r7.f108k;	 Catch:{ all -> 0x0058 }
        if (r5 == 0) goto L_0x004f;	 Catch:{ all -> 0x0058 }
    L_0x0031:
        r5 = r7.m314f();	 Catch:{ all -> 0x0058 }
        if (r5 == 0) goto L_0x004f;	 Catch:{ all -> 0x0058 }
    L_0x0037:
        r5 = r7.f102e;	 Catch:{ all -> 0x0058 }
        r6 = r1.get(r4);	 Catch:{ all -> 0x0058 }
        r5 = r5.contains(r6);	 Catch:{ all -> 0x0058 }
        if (r5 != 0) goto L_0x004c;	 Catch:{ all -> 0x0058 }
    L_0x0043:
        r5 = r1.get(r4);	 Catch:{ all -> 0x0058 }
        r5 = (com.google.android.youtube.player.internal.C0494t.C0492a) r5;	 Catch:{ all -> 0x0058 }
        r5.mo3427a();	 Catch:{ all -> 0x0058 }
    L_0x004c:
        r4 = r4 + 1;	 Catch:{ all -> 0x0058 }
        goto L_0x002b;	 Catch:{ all -> 0x0058 }
    L_0x004f:
        r1 = r7.f102e;	 Catch:{ all -> 0x0058 }
        r1.clear();	 Catch:{ all -> 0x0058 }
        r7.f103f = r3;	 Catch:{ all -> 0x0058 }
        monitor-exit(r0);	 Catch:{ all -> 0x0058 }
        return;	 Catch:{ all -> 0x0058 }
    L_0x0058:
        r1 = move-exception;	 Catch:{ all -> 0x0058 }
        monitor-exit(r0);	 Catch:{ all -> 0x0058 }
        throw r1;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.g():void");
    }

    /* renamed from: h */
    protected final void m316h() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:18:0x0039 in {10, 11, 14, 17} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r7 = this;
        r0 = r7.f98a;
        r1 = 4;
        r0.removeMessages(r1);
        r0 = r7.f101d;
        monitor-enter(r0);
        r1 = 1;
        r7.f103f = r1;	 Catch:{ all -> 0x0036 }
        r1 = r7.f101d;	 Catch:{ all -> 0x0036 }
        r2 = r1.size();	 Catch:{ all -> 0x0036 }
        r3 = 0;	 Catch:{ all -> 0x0036 }
        r4 = 0;	 Catch:{ all -> 0x0036 }
    L_0x0014:
        if (r4 >= r2) goto L_0x0032;	 Catch:{ all -> 0x0036 }
    L_0x0016:
        r5 = r7.f108k;	 Catch:{ all -> 0x0036 }
        if (r5 == 0) goto L_0x0032;	 Catch:{ all -> 0x0036 }
    L_0x001a:
        r5 = r7.f101d;	 Catch:{ all -> 0x0036 }
        r6 = r1.get(r4);	 Catch:{ all -> 0x0036 }
        r5 = r5.contains(r6);	 Catch:{ all -> 0x0036 }
        if (r5 == 0) goto L_0x002f;	 Catch:{ all -> 0x0036 }
    L_0x0026:
        r5 = r1.get(r4);	 Catch:{ all -> 0x0036 }
        r5 = (com.google.android.youtube.player.internal.C0494t.C0492a) r5;	 Catch:{ all -> 0x0036 }
        r5.mo3428b();	 Catch:{ all -> 0x0036 }
    L_0x002f:
        r4 = r4 + 1;	 Catch:{ all -> 0x0036 }
        goto L_0x0014;	 Catch:{ all -> 0x0036 }
    L_0x0032:
        r7.f103f = r3;	 Catch:{ all -> 0x0036 }
        monitor-exit(r0);	 Catch:{ all -> 0x0036 }
        return;	 Catch:{ all -> 0x0036 }
    L_0x0036:
        r1 = move-exception;	 Catch:{ all -> 0x0036 }
        monitor-exit(r0);	 Catch:{ all -> 0x0036 }
        throw r1;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.r.h():void");
    }

    /* renamed from: i */
    protected final void m317i() {
        if (!m314f()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    /* renamed from: j */
    protected final T m318j() {
        m317i();
        return this.f100c;
    }
}
