package com.google.android.youtube.player.internal;

import android.util.Log;

/* renamed from: com.google.android.youtube.player.internal.y */
public final class C0499y {
    /* renamed from: a */
    public static void m145a(String str, Throwable th) {
        Log.e("YouTubeAndroidPlayerAPI", str, th);
    }

    /* renamed from: a */
    public static void m146a(String str, Object... objArr) {
        Log.w("YouTubeAndroidPlayerAPI", String.format(str, objArr));
    }
}
