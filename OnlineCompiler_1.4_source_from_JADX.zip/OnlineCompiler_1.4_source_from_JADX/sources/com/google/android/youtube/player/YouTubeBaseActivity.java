package com.google.android.youtube.player;

import android.app.Activity;
import android.os.Bundle;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayerView.C0472b;

public class YouTubeBaseActivity extends Activity {
    /* renamed from: a */
    private C0873a f8a;
    /* renamed from: b */
    private YouTubePlayerView f9b;
    /* renamed from: c */
    private int f10c;
    /* renamed from: d */
    private Bundle f11d;

    /* renamed from: com.google.android.youtube.player.YouTubeBaseActivity$a */
    private final class C0873a implements C0472b {
        /* renamed from: a */
        final /* synthetic */ YouTubeBaseActivity f55a;

        private C0873a(YouTubeBaseActivity youTubeBaseActivity) {
            this.f55a = youTubeBaseActivity;
        }

        /* renamed from: a */
        public final void mo3424a(YouTubePlayerView youTubePlayerView) {
            if (!(this.f55a.f9b == null || this.f55a.f9b == youTubePlayerView)) {
                this.f55a.f9b.m195c(true);
            }
            this.f55a.f9b = youTubePlayerView;
            if (this.f55a.f10c > 0) {
                youTubePlayerView.m189a();
            }
            if (this.f55a.f10c >= 2) {
                youTubePlayerView.m192b();
            }
        }

        /* renamed from: a */
        public final void mo3425a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            Activity activity = this.f55a;
            youTubePlayerView.m190a(activity, youTubePlayerView, str, onInitializedListener, activity.f11d);
            this.f55a.f11d = null;
        }
    }

    /* renamed from: a */
    final C0472b m35a() {
        return this.f8a;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f8a = new C0873a();
        this.f11d = bundle != null ? bundle.getBundle("YouTubeBaseActivity.KEY_PLAYER_VIEW_STATE") : null;
    }

    protected void onDestroy() {
        YouTubePlayerView youTubePlayerView = this.f9b;
        if (youTubePlayerView != null) {
            youTubePlayerView.m193b(isFinishing());
        }
        super.onDestroy();
    }

    protected void onPause() {
        this.f10c = 1;
        YouTubePlayerView youTubePlayerView = this.f9b;
        if (youTubePlayerView != null) {
            youTubePlayerView.m194c();
        }
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
        this.f10c = 2;
        YouTubePlayerView youTubePlayerView = this.f9b;
        if (youTubePlayerView != null) {
            youTubePlayerView.m192b();
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        YouTubePlayerView youTubePlayerView = this.f9b;
        bundle.putBundle("YouTubeBaseActivity.KEY_PLAYER_VIEW_STATE", youTubePlayerView != null ? youTubePlayerView.m197e() : this.f11d);
    }

    protected void onStart() {
        super.onStart();
        this.f10c = 1;
        YouTubePlayerView youTubePlayerView = this.f9b;
        if (youTubePlayerView != null) {
            youTubePlayerView.m189a();
        }
    }

    protected void onStop() {
        this.f10c = 0;
        YouTubePlayerView youTubePlayerView = this.f9b;
        if (youTubePlayerView != null) {
            youTubePlayerView.m196d();
        }
        super.onStop();
    }
}
