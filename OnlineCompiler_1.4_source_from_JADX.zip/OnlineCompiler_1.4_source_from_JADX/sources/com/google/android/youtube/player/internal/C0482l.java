package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.youtube.player.internal.C0480j.C0896a.C0895a;
import com.google.android.youtube.player.internal.C0481k.C0898a;

/* renamed from: com.google.android.youtube.player.internal.l */
public interface C0482l extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.l$a */
    public static abstract class C0900a extends Binder implements C0482l {

        /* renamed from: com.google.android.youtube.player.internal.l$a$a */
        private static class C0899a implements C0482l {
            /* renamed from: a */
            private IBinder f94a;

            C0899a(IBinder iBinder) {
                this.f94a = iBinder;
            }

            /* renamed from: a */
            public final IBinder mo3511a() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IYouTubeService");
                    this.f94a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    IBinder readStrongBinder = obtain2.readStrongBinder();
                    return readStrongBinder;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final C0481k mo3512a(C0480j c0480j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IYouTubeService");
                    obtain.writeStrongBinder(c0480j != null ? c0480j.asBinder() : null);
                    this.f94a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                    C0481k a = C0898a.m291a(obtain2.readStrongBinder());
                    return a;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public final void mo3513a(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IYouTubeService");
                    obtain.writeInt(z ? 1 : 0);
                    this.f94a.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final IBinder asBinder() {
                return this.f94a;
            }
        }

        /* renamed from: a */
        public static C0482l m295a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.youtube.player.internal.IYouTubeService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0482l)) ? new C0899a(iBinder) : (C0482l) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i != 1598968902) {
                IBinder a;
                switch (i) {
                    case 1:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IYouTubeService");
                        a = mo3511a();
                        parcel2.writeNoException();
                        parcel2.writeStrongBinder(a);
                        return true;
                    case 2:
                        C0480j c0480j;
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IYouTubeService");
                        a = parcel.readStrongBinder();
                        IBinder iBinder = null;
                        if (a == null) {
                            c0480j = null;
                        } else {
                            IInterface queryLocalInterface = a.queryLocalInterface("com.google.android.youtube.player.internal.IThumbnailLoaderClient");
                            c0480j = (queryLocalInterface == null || !(queryLocalInterface instanceof C0480j)) ? new C0895a(a) : (C0480j) queryLocalInterface;
                        }
                        C0481k a2 = mo3512a(c0480j);
                        parcel2.writeNoException();
                        if (a2 != null) {
                            iBinder = a2.asBinder();
                        }
                        parcel2.writeStrongBinder(iBinder);
                        return true;
                    case 3:
                        parcel.enforceInterface("com.google.android.youtube.player.internal.IYouTubeService");
                        mo3513a(parcel.readInt() != 0);
                        parcel2.writeNoException();
                        return true;
                    default:
                        return super.onTransact(i, parcel, parcel2, i2);
                }
            }
            parcel2.writeString("com.google.android.youtube.player.internal.IYouTubeService");
            return true;
        }
    }

    /* renamed from: a */
    IBinder mo3511a() throws RemoteException;

    /* renamed from: a */
    C0481k mo3512a(C0480j c0480j) throws RemoteException;

    /* renamed from: a */
    void mo3513a(boolean z) throws RemoteException;
}
