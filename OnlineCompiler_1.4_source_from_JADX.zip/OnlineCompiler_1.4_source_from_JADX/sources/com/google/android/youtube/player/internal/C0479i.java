package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.youtube.player.internal.C0473c.C0882a.C0881a;

/* renamed from: com.google.android.youtube.player.internal.i */
public interface C0479i extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.i$a */
    public static abstract class C0894a extends Binder implements C0479i {

        /* renamed from: com.google.android.youtube.player.internal.i$a$a */
        private static class C0893a implements C0479i {
            /* renamed from: a */
            private IBinder f91a;

            C0893a(IBinder iBinder) {
                this.f91a = iBinder;
            }

            /* renamed from: a */
            public final void mo3502a(C0473c c0473c, int i, String str, String str2, String str3, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.youtube.player.internal.IServiceBroker");
                    obtain.writeStrongBinder(c0473c != null ? c0473c.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f91a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final IBinder asBinder() {
                return this.f91a;
            }
        }

        /* renamed from: a */
        public static C0479i m282a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.youtube.player.internal.IServiceBroker");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0479i)) ? new C0893a(iBinder) : (C0479i) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i == 1) {
                C0473c c0473c;
                parcel.enforceInterface("com.google.android.youtube.player.internal.IServiceBroker");
                IBinder readStrongBinder = parcel.readStrongBinder();
                Bundle bundle = null;
                if (readStrongBinder == null) {
                    c0473c = null;
                } else {
                    IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.youtube.player.internal.IConnectionCallbacks");
                    c0473c = (queryLocalInterface == null || !(queryLocalInterface instanceof C0473c)) ? new C0881a(readStrongBinder) : (C0473c) queryLocalInterface;
                }
                int readInt = parcel.readInt();
                String readString = parcel.readString();
                String readString2 = parcel.readString();
                String readString3 = parcel.readString();
                if (parcel.readInt() != 0) {
                    bundle = (Bundle) Bundle.CREATOR.createFromParcel(parcel);
                }
                mo3502a(c0473c, readInt, readString, readString2, readString3, bundle);
                parcel2.writeNoException();
                return true;
            } else if (i != 1598968902) {
                return super.onTransact(i, parcel, parcel2, i2);
            } else {
                parcel2.writeString("com.google.android.youtube.player.internal.IServiceBroker");
                return true;
            }
        }
    }

    /* renamed from: a */
    void mo3502a(C0473c c0473c, int i, String str, String str2, String str3, Bundle bundle) throws RemoteException;
}
