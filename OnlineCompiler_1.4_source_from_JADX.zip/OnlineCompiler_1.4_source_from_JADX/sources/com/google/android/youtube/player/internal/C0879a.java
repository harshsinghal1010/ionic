package com.google.android.youtube.player.internal;

import android.graphics.Bitmap;
import com.google.android.youtube.player.YouTubeThumbnailLoader;
import com.google.android.youtube.player.YouTubeThumbnailLoader.OnThumbnailLoadedListener;
import com.google.android.youtube.player.YouTubeThumbnailView;
import java.lang.ref.WeakReference;
import java.util.NoSuchElementException;

/* renamed from: com.google.android.youtube.player.internal.a */
public abstract class C0879a implements YouTubeThumbnailLoader {
    /* renamed from: a */
    private final WeakReference<YouTubeThumbnailView> f81a;
    /* renamed from: b */
    private OnThumbnailLoadedListener f82b;
    /* renamed from: c */
    private boolean f83c;
    /* renamed from: d */
    private boolean f84d;

    public C0879a(YouTubeThumbnailView youTubeThumbnailView) {
        this.f81a = new WeakReference(ab.m54a((Object) youTubeThumbnailView));
    }

    /* renamed from: i */
    private void m202i() {
        if (!mo4734a()) {
            throw new IllegalStateException("This YouTubeThumbnailLoader has been released");
        }
    }

    /* renamed from: a */
    public final void m203a(Bitmap bitmap, String str) {
        YouTubeThumbnailView youTubeThumbnailView = (YouTubeThumbnailView) this.f81a.get();
        if (mo4734a() && youTubeThumbnailView != null) {
            youTubeThumbnailView.setImageBitmap(bitmap);
            OnThumbnailLoadedListener onThumbnailLoadedListener = this.f82b;
            if (onThumbnailLoadedListener != null) {
                onThumbnailLoadedListener.onThumbnailLoaded(youTubeThumbnailView, str);
            }
        }
    }

    /* renamed from: a */
    public abstract void mo4732a(String str);

    /* renamed from: a */
    public abstract void mo4733a(String str, int i);

    /* renamed from: a */
    protected boolean mo4734a() {
        return !this.f84d;
    }

    /* renamed from: b */
    public final void m207b() {
        if (mo4734a()) {
            C0499y.m146a("The finalize() method for a YouTubeThumbnailLoader has work to do. You should have called release().", new Object[0]);
            release();
        }
    }

    /* renamed from: b */
    public final void m208b(java.lang.String r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = r2.f81a;
        r0 = r0.get();
        r0 = (com.google.android.youtube.player.YouTubeThumbnailView) r0;
        r1 = r2.mo4734a();
        if (r1 == 0) goto L_0x0020;
    L_0x000e:
        r1 = r2.f82b;
        if (r1 == 0) goto L_0x0020;
    L_0x0012:
        if (r0 == 0) goto L_0x0020;
    L_0x0014:
        r3 = com.google.android.youtube.player.YouTubeThumbnailLoader.ErrorReason.valueOf(r3);	 Catch:{ IllegalArgumentException -> 0x0019, IllegalArgumentException -> 0x0019 }
        goto L_0x001b;
    L_0x0019:
        r3 = com.google.android.youtube.player.YouTubeThumbnailLoader.ErrorReason.UNKNOWN;
    L_0x001b:
        r1 = r2.f82b;
        r1.onThumbnailError(r0, r3);
    L_0x0020:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.a.b(java.lang.String):void");
    }

    /* renamed from: c */
    public abstract void mo4735c();

    /* renamed from: d */
    public abstract void mo4736d();

    /* renamed from: e */
    public abstract void mo4737e();

    /* renamed from: f */
    public abstract boolean mo4738f();

    public final void first() {
        m202i();
        if (this.f83c) {
            mo4737e();
            return;
        }
        throw new IllegalStateException("Must call setPlaylist first");
    }

    /* renamed from: g */
    public abstract boolean mo4739g();

    /* renamed from: h */
    public abstract void mo4740h();

    public final boolean hasNext() {
        m202i();
        return mo4738f();
    }

    public final boolean hasPrevious() {
        m202i();
        return mo4739g();
    }

    public final void next() {
        m202i();
        if (!this.f83c) {
            throw new IllegalStateException("Must call setPlaylist first");
        } else if (mo4738f()) {
            mo4735c();
        } else {
            throw new NoSuchElementException("Called next at end of playlist");
        }
    }

    public final void previous() {
        m202i();
        if (!this.f83c) {
            throw new IllegalStateException("Must call setPlaylist first");
        } else if (mo4739g()) {
            mo4736d();
        } else {
            throw new NoSuchElementException("Called previous at start of playlist");
        }
    }

    public final void release() {
        if (mo4734a()) {
            this.f84d = true;
            this.f82b = null;
            mo4740h();
        }
    }

    public final void setOnThumbnailLoadedListener(OnThumbnailLoadedListener onThumbnailLoadedListener) {
        m202i();
        this.f82b = onThumbnailLoadedListener;
    }

    public final void setPlaylist(String str) {
        setPlaylist(str, 0);
    }

    public final void setPlaylist(String str, int i) {
        m202i();
        this.f83c = true;
        mo4733a(str, i);
    }

    public final void setVideo(String str) {
        m202i();
        this.f83c = false;
        mo4732a(str);
    }
}
