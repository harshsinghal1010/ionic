package com.google.android.youtube.player.internal;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C0480j.C0896a;

/* renamed from: com.google.android.youtube.player.internal.p */
public final class C1086p extends C0879a {
    /* renamed from: a */
    private final Handler f123a = new Handler(Looper.getMainLooper());
    /* renamed from: b */
    private C0880b f124b;
    /* renamed from: c */
    private C0481k f125c;
    /* renamed from: d */
    private boolean f126d;
    /* renamed from: e */
    private boolean f127e;

    /* renamed from: com.google.android.youtube.player.internal.p$a */
    private final class C1085a extends C0896a {
        /* renamed from: a */
        final /* synthetic */ C1086p f122a;

        private C1085a(C1086p c1086p) {
            this.f122a = c1086p;
        }

        /* renamed from: a */
        public final void mo3503a(Bitmap bitmap, String str, boolean z, boolean z2) {
            final boolean z3 = z;
            final boolean z4 = z2;
            final Bitmap bitmap2 = bitmap;
            final String str2 = str;
            this.f122a.f123a.post(new Runnable(this) {
                /* renamed from: e */
                final /* synthetic */ C1085a f40e;

                public final void run() {
                    this.f40e.f122a.f126d = z3;
                    this.f40e.f122a.f127e = z4;
                    this.f40e.f122a.m203a(bitmap2, str2);
                }
            });
        }

        /* renamed from: a */
        public final void mo3504a(final String str, final boolean z, final boolean z2) {
            this.f122a.f123a.post(new Runnable(this) {
                /* renamed from: d */
                final /* synthetic */ C1085a f44d;

                public final void run() {
                    this.f44d.f122a.f126d = z;
                    this.f44d.f122a.f127e = z2;
                    this.f44d.f122a.m208b(str);
                }
            });
        }
    }

    public C1086p(C0880b c0880b, YouTubeThumbnailView youTubeThumbnailView) {
        super(youTubeThumbnailView);
        this.f124b = (C0880b) ab.m55a((Object) c0880b, (Object) "connectionClient cannot be null");
        this.f125c = c0880b.mo4727a(new C1085a());
    }

    /* renamed from: a */
    public final void mo4732a(String str) {
        try {
            this.f125c.mo3506a(str);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: a */
    public final void mo4733a(String str, int i) {
        try {
            this.f125c.mo3507a(str, i);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: a */
    protected final boolean mo4734a() {
        return super.mo4734a() && this.f125c != null;
    }

    /* renamed from: c */
    public final void mo4735c() {
        try {
            this.f125c.mo3505a();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: d */
    public final void mo4736d() {
        try {
            this.f125c.mo3508b();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: e */
    public final void mo4737e() {
        try {
            this.f125c.mo3509c();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: f */
    public final boolean mo4738f() {
        return this.f127e;
    }

    /* renamed from: g */
    public final boolean mo4739g() {
        return this.f126d;
    }

    /* renamed from: h */
    public final void mo4740h() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r1 = this;
        r0 = r1.f125c;	 Catch:{ RemoteException -> 0x0005 }
        r0.mo3510d();	 Catch:{ RemoteException -> 0x0005 }
    L_0x0005:
        r0 = r1.f124b;
        r0.mo3515d();
        r0 = 0;
        r1.f125c = r0;
        r1.f124b = r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.p.h():void");
    }
}
