package com.google.android.youtube.player.internal;

import android.content.Context;
import android.content.res.Resources;
import java.util.Locale;
import java.util.Map;

/* renamed from: com.google.android.youtube.player.internal.m */
public final class C0483m {
    /* renamed from: a */
    public final String f24a;
    /* renamed from: b */
    public final String f25b;
    /* renamed from: c */
    public final String f26c;
    /* renamed from: d */
    public final String f27d;
    /* renamed from: e */
    public final String f28e;
    /* renamed from: f */
    public final String f29f;
    /* renamed from: g */
    public final String f30g;
    /* renamed from: h */
    public final String f31h;
    /* renamed from: i */
    public final String f32i;
    /* renamed from: j */
    public final String f33j;

    public C0483m(Context context) {
        Resources resources = context.getResources();
        Locale locale = (resources == null || resources.getConfiguration() == null || resources.getConfiguration().locale == null) ? Locale.getDefault() : resources.getConfiguration().locale;
        Map a = C0498x.m143a(locale);
        this.f24a = (String) a.get("error_initializing_player");
        this.f25b = (String) a.get("get_youtube_app_title");
        this.f26c = (String) a.get("get_youtube_app_text");
        this.f27d = (String) a.get("get_youtube_app_action");
        this.f28e = (String) a.get("enable_youtube_app_title");
        this.f29f = (String) a.get("enable_youtube_app_text");
        this.f30g = (String) a.get("enable_youtube_app_action");
        this.f31h = (String) a.get("update_youtube_app_title");
        this.f32i = (String) a.get("update_youtube_app_text");
        this.f33j = (String) a.get("update_youtube_app_action");
    }
}
