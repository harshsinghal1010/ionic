package com.google.android.youtube.player.internal;

import android.os.IBinder;

/* renamed from: com.google.android.youtube.player.internal.b */
public interface C0880b extends C0494t {
    /* renamed from: a */
    IBinder mo4725a();

    /* renamed from: a */
    C0481k mo4727a(C0480j c0480j);

    /* renamed from: a */
    void mo4729a(boolean z);
}
