package com.google.android.youtube.player;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerView.C0472b;
import com.google.android.youtube.player.internal.ab;

public class YouTubePlayerSupportFragment extends Fragment implements Provider {
    /* renamed from: a */
    private final C0875a f112a = new C0875a();
    /* renamed from: b */
    private Bundle f113b;
    /* renamed from: c */
    private YouTubePlayerView f114c;
    /* renamed from: d */
    private String f115d;
    /* renamed from: e */
    private OnInitializedListener f116e;
    /* renamed from: f */
    private boolean f117f;

    /* renamed from: com.google.android.youtube.player.YouTubePlayerSupportFragment$a */
    private final class C0875a implements C0472b {
        /* renamed from: a */
        final /* synthetic */ YouTubePlayerSupportFragment f63a;

        private C0875a(YouTubePlayerSupportFragment youTubePlayerSupportFragment) {
            this.f63a = youTubePlayerSupportFragment;
        }

        /* renamed from: a */
        public final void mo3424a(YouTubePlayerView youTubePlayerView) {
        }

        /* renamed from: a */
        public final void mo3425a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            YouTubePlayerSupportFragment youTubePlayerSupportFragment = this.f63a;
            youTubePlayerSupportFragment.initialize(str, youTubePlayerSupportFragment.f116e);
        }
    }

    /* renamed from: a */
    private void m335a() {
        YouTubePlayerView youTubePlayerView = this.f114c;
        if (youTubePlayerView != null && this.f116e != null) {
            youTubePlayerView.m191a(this.f117f);
            this.f114c.m190a(getActivity(), this, this.f115d, this.f116e, this.f113b);
            this.f113b = null;
            this.f116e = null;
        }
    }

    public static YouTubePlayerSupportFragment newInstance() {
        return new YouTubePlayerSupportFragment();
    }

    public void initialize(String str, OnInitializedListener onInitializedListener) {
        this.f115d = ab.m56a(str, (Object) "Developer key cannot be null or empty");
        this.f116e = onInitializedListener;
        m335a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f113b = bundle != null ? bundle.getBundle("YouTubePlayerSupportFragment.KEY_PLAYER_VIEW_STATE") : null;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f114c = new YouTubePlayerView(getActivity(), null, 0, this.f112a);
        m335a();
        return this.f114c;
    }

    public void onDestroy() {
        if (this.f114c != null) {
            boolean z;
            Activity activity = getActivity();
            YouTubePlayerView youTubePlayerView = this.f114c;
            if (activity != null) {
                if (!activity.isFinishing()) {
                    z = false;
                    youTubePlayerView.m193b(z);
                }
            }
            z = true;
            youTubePlayerView.m193b(z);
        }
        super.onDestroy();
    }

    public void onDestroyView() {
        this.f114c.m195c(getActivity().isFinishing());
        this.f114c = null;
        super.onDestroyView();
    }

    public void onPause() {
        this.f114c.m194c();
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.f114c.m192b();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        YouTubePlayerView youTubePlayerView = this.f114c;
        bundle.putBundle("YouTubePlayerSupportFragment.KEY_PLAYER_VIEW_STATE", youTubePlayerView != null ? youTubePlayerView.m197e() : this.f113b);
    }

    public void onStart() {
        super.onStart();
        this.f114c.m189a();
    }

    public void onStop() {
        this.f114c.m196d();
        super.onStop();
    }
}
