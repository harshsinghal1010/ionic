package com.google.android.youtube.player.internal;

import android.app.Activity;
import android.content.Context;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C0494t.C0492a;
import com.google.android.youtube.player.internal.C0494t.C0493b;
import com.google.android.youtube.player.internal.C0497w.C0496a;

public final class ac extends aa {
    /* renamed from: a */
    public final C0879a mo3440a(C0880b c0880b, YouTubeThumbnailView youTubeThumbnailView) {
        return new C1086p(c0880b, youTubeThumbnailView);
    }

    /* renamed from: a */
    public final C0880b mo3441a(Context context, String str, C0492a c0492a, C0493b c0493b) {
        return new C1084o(context, str, context.getPackageName(), C0500z.m156d(context), c0492a, c0493b);
    }

    /* renamed from: a */
    public final C0474d mo3442a(Activity activity, C0880b c0880b, boolean z) throws C0496a {
        return C0497w.m142a(activity, c0880b.mo4725a(), z);
    }
}
