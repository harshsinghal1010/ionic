package com.google.android.youtube.player.internal;

import android.app.Activity;
import android.content.Context;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.google.android.youtube.player.internal.C0494t.C0492a;
import com.google.android.youtube.player.internal.C0494t.C0493b;
import com.google.android.youtube.player.internal.C0497w.C0496a;

public abstract class aa {
    /* renamed from: a */
    private static final aa f23a = m50b();

    /* renamed from: a */
    public static aa m49a() {
        return f23a;
    }

    /* renamed from: b */
    private static com.google.android.youtube.player.internal.aa m50b() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = "com.google.android.youtube.api.locallylinked.LocallyLinkedFactory";	 Catch:{ ClassNotFoundException -> 0x0021 }
        r0 = java.lang.Class.forName(r0);	 Catch:{ ClassNotFoundException -> 0x0021 }
        r1 = com.google.android.youtube.player.internal.aa.class;	 Catch:{ ClassNotFoundException -> 0x0021 }
        r0 = r0.asSubclass(r1);	 Catch:{ ClassNotFoundException -> 0x0021 }
        r0 = r0.newInstance();	 Catch:{ InstantiationException -> 0x001a, IllegalAccessException -> 0x0013 }
        r0 = (com.google.android.youtube.player.internal.aa) r0;	 Catch:{ InstantiationException -> 0x001a, IllegalAccessException -> 0x0013 }
        return r0;
    L_0x0013:
        r0 = move-exception;
        r1 = new java.lang.IllegalStateException;	 Catch:{ ClassNotFoundException -> 0x0021 }
        r1.<init>(r0);	 Catch:{ ClassNotFoundException -> 0x0021 }
        throw r1;	 Catch:{ ClassNotFoundException -> 0x0021 }
    L_0x001a:
        r0 = move-exception;	 Catch:{ ClassNotFoundException -> 0x0021 }
        r1 = new java.lang.IllegalStateException;	 Catch:{ ClassNotFoundException -> 0x0021 }
        r1.<init>(r0);	 Catch:{ ClassNotFoundException -> 0x0021 }
        throw r1;	 Catch:{ ClassNotFoundException -> 0x0021 }
    L_0x0021:
        r0 = new com.google.android.youtube.player.internal.ac;
        r0.<init>();
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.aa.b():com.google.android.youtube.player.internal.aa");
    }

    /* renamed from: a */
    public abstract C0879a mo3440a(C0880b c0880b, YouTubeThumbnailView youTubeThumbnailView);

    /* renamed from: a */
    public abstract C0880b mo3441a(Context context, String str, C0492a c0492a, C0493b c0493b);

    /* renamed from: a */
    public abstract C0474d mo3442a(Activity activity, C0880b c0880b, boolean z) throws C0496a;
}
