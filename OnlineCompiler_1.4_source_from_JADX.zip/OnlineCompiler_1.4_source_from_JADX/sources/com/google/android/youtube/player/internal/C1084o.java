package com.google.android.youtube.player.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.youtube.player.internal.C0482l.C0900a;
import com.google.android.youtube.player.internal.C0494t.C0492a;
import com.google.android.youtube.player.internal.C0494t.C0493b;
import com.google.android.youtube.player.internal.C0902r.C1087d;

/* renamed from: com.google.android.youtube.player.internal.o */
public final class C1084o extends C0902r<C0482l> implements C0880b {
    /* renamed from: b */
    private final String f118b;
    /* renamed from: c */
    private final String f119c;
    /* renamed from: d */
    private final String f120d;
    /* renamed from: e */
    private boolean f121e;

    public C1084o(Context context, String str, String str2, String str3, C0492a c0492a, C0493b c0493b) {
        super(context, c0492a, c0493b);
        this.f118b = (String) ab.m54a((Object) str);
        this.f119c = ab.m56a(str2, (Object) "callingPackage cannot be null or empty");
        this.f120d = ab.m56a(str3, (Object) "callingAppVersion cannot be null or empty");
    }

    /* renamed from: k */
    private final void m336k() {
        m317i();
        if (this.f121e) {
            throw new IllegalStateException("Connection client has been released");
        }
    }

    /* renamed from: a */
    public final IBinder mo4725a() {
        m336k();
        try {
            return ((C0482l) m318j()).mo3511a();
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: a */
    protected final /* synthetic */ IInterface mo4726a(IBinder iBinder) {
        return C0900a.m295a(iBinder);
    }

    /* renamed from: a */
    public final C0481k mo4727a(C0480j c0480j) {
        m336k();
        try {
            return ((C0482l) m318j()).mo3512a(c0480j);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: a */
    protected final void mo4728a(C0479i c0479i, C1087d c1087d) throws RemoteException {
        c0479i.mo3502a(c1087d, 1202, this.f119c, this.f120d, this.f118b, null);
    }

    /* renamed from: a */
    public final void mo4729a(boolean r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r1 = this;
        r0 = r1.m314f();
        if (r0 == 0) goto L_0x0012;
    L_0x0006:
        r0 = r1.m318j();	 Catch:{ RemoteException -> 0x000f }
        r0 = (com.google.android.youtube.player.internal.C0482l) r0;	 Catch:{ RemoteException -> 0x000f }
        r0.mo3513a(r2);	 Catch:{ RemoteException -> 0x000f }
    L_0x000f:
        r2 = 1;
        r1.f121e = r2;
    L_0x0012:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.internal.o.a(boolean):void");
    }

    /* renamed from: b */
    protected final String mo4730b() {
        return "com.google.android.youtube.player.internal.IYouTubeService";
    }

    /* renamed from: c */
    protected final String mo4731c() {
        return "com.google.android.youtube.api.service.START";
    }

    /* renamed from: d */
    public final void mo3515d() {
        if (!this.f121e) {
            mo4729a(true);
        }
        super.mo3515d();
    }
}
