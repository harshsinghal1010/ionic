package com.google.android.youtube.player.internal;

import com.google.android.youtube.player.YouTubeInitializationResult;

/* renamed from: com.google.android.youtube.player.internal.t */
public interface C0494t {

    /* renamed from: com.google.android.youtube.player.internal.t$a */
    public interface C0492a {
        /* renamed from: a */
        void mo3427a();

        /* renamed from: b */
        void mo3428b();
    }

    /* renamed from: com.google.android.youtube.player.internal.t$b */
    public interface C0493b {
        /* renamed from: a */
        void mo3429a(YouTubeInitializationResult youTubeInitializationResult);
    }

    /* renamed from: d */
    void mo3515d();

    /* renamed from: e */
    void mo3516e();
}
