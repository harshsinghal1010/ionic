package com.google.android.youtube.player;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.sherdle.universal.providers.youtube.player.YouTubePlayerActivity;
import java.util.ArrayList;
import java.util.List;

public final class YouTubeStandalonePlayer {
    private YouTubeStandalonePlayer() {
    }

    /* renamed from: a */
    private static Intent m44a(Intent intent, Activity activity, String str, int i, boolean z, boolean z2) {
        YouTubeIntents.m36a(intent, (Context) activity).putExtra("developer_key", str).putExtra("autoplay", z).putExtra("lightbox_mode", z2).putExtra("start_time_millis", i).putExtra("window_has_status_bar", (activity.getWindow().getAttributes().flags & 1024) == 0);
        return intent;
    }

    public static Intent createPlaylistIntent(Activity activity, String str, String str2) {
        return createPlaylistIntent(activity, str, str2, 0, 0, false, false);
    }

    public static Intent createPlaylistIntent(Activity activity, String str, String str2, int i, int i2, boolean z, boolean z2) {
        if (str2 == null) {
            throw new NullPointerException("The playlistId cannot be null");
        } else if (str != null) {
            return m44a(new Intent("com.google.android.youtube.api.StandalonePlayerActivity.START").putExtra("playlist_id", str2).putExtra("current_index", i), activity, str, i2, z, z2);
        } else {
            throw new NullPointerException("The developerKey cannot be null");
        }
    }

    public static Intent createVideoIntent(Activity activity, String str, String str2) {
        return createVideoIntent(activity, str, str2, 0, false, false);
    }

    public static Intent createVideoIntent(Activity activity, String str, String str2, int i, boolean z, boolean z2) {
        if (str2 == null) {
            throw new NullPointerException("The videoId cannot be null");
        } else if (str != null) {
            return m44a(new Intent("com.google.android.youtube.api.StandalonePlayerActivity.START").putExtra(YouTubePlayerActivity.EXTRA_VIDEO_ID, str2), activity, str, i, z, z2);
        } else {
            throw new NullPointerException("The developerKey cannot be null");
        }
    }

    public static Intent createVideosIntent(Activity activity, String str, List<String> list) {
        return createVideosIntent(activity, str, list, 0, 0, false, false);
    }

    public static Intent createVideosIntent(Activity activity, String str, List<String> list, int i, int i2, boolean z, boolean z2) {
        if (list == null) {
            throw new NullPointerException("The list of videoIds cannot be null");
        } else if (list.isEmpty()) {
            throw new IllegalStateException("The list of videoIds cannot be empty");
        } else if (str != null) {
            return m44a(new Intent("com.google.android.youtube.api.StandalonePlayerActivity.START").putStringArrayListExtra("video_ids", new ArrayList(list)).putExtra("current_index", i), activity, str, i2, z, z2);
        } else {
            throw new NullPointerException("The developerKey cannot be null");
        }
    }

    public static com.google.android.youtube.player.YouTubeInitializationResult getReturnedInitializationResult(android.content.Intent r1) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r1 = r1.getExtras();
        r0 = "initialization_result";
        r1 = r1.getString(r0);
        r1 = com.google.android.youtube.player.YouTubeInitializationResult.valueOf(r1);	 Catch:{ IllegalArgumentException -> 0x0012, NullPointerException -> 0x000f }
        return r1;
    L_0x000f:
        r1 = com.google.android.youtube.player.YouTubeInitializationResult.UNKNOWN_ERROR;
        return r1;
    L_0x0012:
        r1 = com.google.android.youtube.player.YouTubeInitializationResult.UNKNOWN_ERROR;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.youtube.player.YouTubeStandalonePlayer.getReturnedInitializationResult(android.content.Intent):com.google.android.youtube.player.YouTubeInitializationResult");
    }
}
