package com.google.android.youtube.player;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.youtube.player.YouTubePlayer.OnInitializedListener;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerView.C0472b;
import com.google.android.youtube.player.internal.ab;

public class YouTubePlayerFragment extends Fragment implements Provider {
    /* renamed from: a */
    private final C0874a f57a = new C0874a();
    /* renamed from: b */
    private Bundle f58b;
    /* renamed from: c */
    private YouTubePlayerView f59c;
    /* renamed from: d */
    private String f60d;
    /* renamed from: e */
    private OnInitializedListener f61e;
    /* renamed from: f */
    private boolean f62f;

    /* renamed from: com.google.android.youtube.player.YouTubePlayerFragment$a */
    private final class C0874a implements C0472b {
        /* renamed from: a */
        final /* synthetic */ YouTubePlayerFragment f56a;

        private C0874a(YouTubePlayerFragment youTubePlayerFragment) {
            this.f56a = youTubePlayerFragment;
        }

        /* renamed from: a */
        public final void mo3424a(YouTubePlayerView youTubePlayerView) {
        }

        /* renamed from: a */
        public final void mo3425a(YouTubePlayerView youTubePlayerView, String str, OnInitializedListener onInitializedListener) {
            YouTubePlayerFragment youTubePlayerFragment = this.f56a;
            youTubePlayerFragment.initialize(str, youTubePlayerFragment.f61e);
        }
    }

    /* renamed from: a */
    private void m170a() {
        YouTubePlayerView youTubePlayerView = this.f59c;
        if (youTubePlayerView != null && this.f61e != null) {
            youTubePlayerView.m191a(this.f62f);
            this.f59c.m190a(getActivity(), this, this.f60d, this.f61e, this.f58b);
            this.f58b = null;
            this.f61e = null;
        }
    }

    public static YouTubePlayerFragment newInstance() {
        return new YouTubePlayerFragment();
    }

    public void initialize(String str, OnInitializedListener onInitializedListener) {
        this.f60d = ab.m56a(str, (Object) "Developer key cannot be null or empty");
        this.f61e = onInitializedListener;
        m170a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f58b = bundle != null ? bundle.getBundle("YouTubePlayerFragment.KEY_PLAYER_VIEW_STATE") : null;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f59c = new YouTubePlayerView(getActivity(), null, 0, this.f57a);
        m170a();
        return this.f59c;
    }

    public void onDestroy() {
        if (this.f59c != null) {
            boolean z;
            Activity activity = getActivity();
            YouTubePlayerView youTubePlayerView = this.f59c;
            if (activity != null) {
                if (!activity.isFinishing()) {
                    z = false;
                    youTubePlayerView.m193b(z);
                }
            }
            z = true;
            youTubePlayerView.m193b(z);
        }
        super.onDestroy();
    }

    public void onDestroyView() {
        this.f59c.m195c(getActivity().isFinishing());
        this.f59c = null;
        super.onDestroyView();
    }

    public void onPause() {
        this.f59c.m194c();
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.f59c.m192b();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        YouTubePlayerView youTubePlayerView = this.f59c;
        bundle.putBundle("YouTubePlayerFragment.KEY_PLAYER_VIEW_STATE", youTubePlayerView != null ? youTubePlayerView.m197e() : this.f58b);
    }

    public void onStart() {
        super.onStart();
        this.f59c.m189a();
    }

    public void onStop() {
        this.f59c.m196d();
        super.onStop();
    }
}
