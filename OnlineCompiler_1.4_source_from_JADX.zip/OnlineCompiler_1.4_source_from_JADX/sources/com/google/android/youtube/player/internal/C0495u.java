package com.google.android.youtube.player.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* renamed from: com.google.android.youtube.player.internal.u */
public interface C0495u extends IInterface {

    /* renamed from: com.google.android.youtube.player.internal.u$a */
    public static abstract class C0905a extends Binder implements C0495u {

        /* renamed from: com.google.android.youtube.player.internal.u$a$a */
        private static class C0904a implements C0495u {
            /* renamed from: a */
            private IBinder f111a;

            C0904a(IBinder iBinder) {
                this.f111a = iBinder;
            }

            public final IBinder asBinder() {
                return this.f111a;
            }
        }

        public C0905a() {
            attachInterface(this, "com.google.android.youtube.player.internal.dynamic.IObjectWrapper");
        }

        /* renamed from: a */
        public static C0495u m333a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.youtube.player.internal.dynamic.IObjectWrapper");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0495u)) ? new C0904a(iBinder) : (C0495u) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i != 1598968902) {
                return super.onTransact(i, parcel, parcel2, i2);
            }
            parcel2.writeString("com.google.android.youtube.player.internal.dynamic.IObjectWrapper");
            return true;
        }
    }
}
