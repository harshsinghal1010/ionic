package com.google.android.youtube.player.internal;

import android.text.TextUtils;

public final class ab {
    /* renamed from: a */
    public static <T> T m54a(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException("null reference");
    }

    /* renamed from: a */
    public static <T> T m55a(T t, Object obj) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(String.valueOf(obj));
    }

    /* renamed from: a */
    public static String m56a(String str, Object obj) {
        if (!TextUtils.isEmpty(str)) {
            return str;
        }
        throw new IllegalArgumentException(String.valueOf(obj));
    }

    /* renamed from: a */
    public static void m57a(boolean z) {
        if (!z) {
            throw new IllegalStateException();
        }
    }
}
