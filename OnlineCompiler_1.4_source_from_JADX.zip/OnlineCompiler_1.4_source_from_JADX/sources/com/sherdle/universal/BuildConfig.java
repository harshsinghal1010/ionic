package com.sherdle.universal;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.codeintelligent.onlinecompiler";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 12;
    public static final String VERSION_NAME = "1.4";
}
