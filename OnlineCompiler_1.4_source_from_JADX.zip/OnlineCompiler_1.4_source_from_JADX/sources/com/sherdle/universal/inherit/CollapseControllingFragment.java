package com.sherdle.universal.inherit;

public interface CollapseControllingFragment {
    boolean dynamicToolbarElevation();

    boolean supportsCollapse();
}
