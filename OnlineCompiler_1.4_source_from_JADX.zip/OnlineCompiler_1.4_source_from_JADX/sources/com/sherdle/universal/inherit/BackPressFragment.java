package com.sherdle.universal.inherit;

public interface BackPressFragment {
    boolean handleBackPress();
}
