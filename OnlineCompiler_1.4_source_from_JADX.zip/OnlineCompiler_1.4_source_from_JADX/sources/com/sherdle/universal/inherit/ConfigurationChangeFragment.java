package com.sherdle.universal.inherit;

public interface ConfigurationChangeFragment {
}
