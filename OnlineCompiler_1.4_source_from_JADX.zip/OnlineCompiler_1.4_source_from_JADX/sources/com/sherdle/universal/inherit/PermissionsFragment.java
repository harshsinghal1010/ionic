package com.sherdle.universal.inherit;

public interface PermissionsFragment {
    String[] requiredPermissions();
}
