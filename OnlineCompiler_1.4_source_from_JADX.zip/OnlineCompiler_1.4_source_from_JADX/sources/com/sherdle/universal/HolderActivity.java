package com.sherdle.universal;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebViewFragment;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.inherit.BackPressFragment;
import com.sherdle.universal.providers.CustomIntent;
import com.sherdle.universal.providers.web.WebviewFragment;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;

public class HolderActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private Class<? extends Fragment> queueItem;
    private String[] queueItemData;

    public static void startActivity(Context context, Class<? extends Fragment> cls, String[] strArr) {
        Bundle bundle = new Bundle();
        bundle.putStringArray(MainActivity.FRAGMENT_DATA, strArr);
        bundle.putSerializable(MainActivity.FRAGMENT_CLASS, cls);
        cls = new Intent(context, HolderActivity.class);
        cls.putExtras(bundle);
        context.startActivity(cls);
    }

    public static void startWebViewActivity(Context context, String str, boolean z, boolean z2, String str2, int i) {
        if (z && str2 == null) {
            z = new Intent("android.intent.action.VIEW", Uri.parse(str));
            z.addFlags(i);
            if (z.resolveActivity(context.getPackageManager())) {
                context.startActivity(z);
            } else {
                z2 = new StringBuilder();
                z2.append("No activity to resolve url: ");
                z2.append(str);
                Log.m161v("INFO", z2.toString());
                Toast.makeText(context, R.string.no_app, 0).show();
            }
            return;
        }
        z = new Bundle();
        z.putStringArray(MainActivity.FRAGMENT_DATA, new String[]{str});
        z.putSerializable(MainActivity.FRAGMENT_CLASS, WebViewFragment.class);
        z.putBoolean(WebviewFragment.HIDE_NAVIGATION, z2);
        z.putString(WebviewFragment.LOAD_DATA, str2);
        str = new Intent(context, HolderActivity.class);
        str.putExtras(z);
        str.addFlags(i);
        context.startActivity(str);
    }

    public static void startWebViewActivity(Context context, String str, boolean z, boolean z2, String str2) {
        startWebViewActivity(context, str, z, z2, str2, 0);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ThemeUtils.setTheme(this);
        setContentView((int) R.layout.activity_holder);
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Class cls = (Class) getIntent().getExtras().getSerializable(MainActivity.FRAGMENT_CLASS);
        String[] stringArray = getIntent().getExtras().getStringArray(MainActivity.FRAGMENT_DATA);
        if (CustomIntent.class.isAssignableFrom(cls)) {
            CustomIntent.performIntent(this, stringArray);
            finish();
        } else {
            if (!getIntent().hasExtra(WebviewFragment.HIDE_NAVIGATION)) {
                if (!getIntent().hasExtra(WebviewFragment.LOAD_DATA)) {
                    openFragment(cls, stringArray);
                }
            }
            openWebFragment(stringArray, getIntent().getExtras().getBoolean(WebviewFragment.HIDE_NAVIGATION), getIntent().getExtras().getString(WebviewFragment.LOAD_DATA));
        }
        Helper.admobLoader(this, findViewById(R.id.adView));
    }

    public void openFragment(Class<? extends Fragment> cls, String[] strArr) {
        if (checkPermissionsHandleIfNeeded(cls, strArr)) {
            try {
                Fragment fragment = (Fragment) cls.newInstance();
                Bundle bundle = new Bundle();
                bundle.putStringArray(MainActivity.FRAGMENT_DATA, strArr);
                fragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.container, fragment).commit();
            } catch (Class<? extends Fragment> cls2) {
                cls2.printStackTrace();
            } catch (Class<? extends Fragment> cls22) {
                cls22.printStackTrace();
            }
        }
    }

    public void openWebFragment(String[] strArr, boolean z, String str) {
        Fragment webviewFragment = new WebviewFragment();
        Bundle bundle = new Bundle();
        bundle.putStringArray(MainActivity.FRAGMENT_DATA, strArr);
        bundle.putBoolean(WebviewFragment.HIDE_NAVIGATION, z);
        if (str != null) {
            bundle.putString(WebviewFragment.LOAD_DATA, str);
        }
        webviewFragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction().replace(true, webviewFragment).commit();
        if (str == null) {
            setTitle(getResources().getString(true));
        } else {
            setTitle("");
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.settings_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            finish();
            return true;
        } else if (itemId != R.id.settings) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            openFragment(SettingsFragment.class, new String[0]);
            return true;
        }
    }

    public void onBackPressed() {
        Fragment findFragmentById = getSupportFragmentManager().findFragmentById(R.id.container);
        if (!(findFragmentById instanceof BackPressFragment)) {
            super.onBackPressed();
        } else if (!((BackPressFragment) findFragmentById).handleBackPress()) {
            super.onBackPressed();
        }
    }

    private boolean checkPermissionsHandleIfNeeded(java.lang.Class<? extends android.support.v4.app.Fragment> r7, java.lang.String[] r8) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r6 = this;
        r0 = android.os.Build.VERSION.SDK_INT;
        r1 = 1;
        r2 = 23;
        if (r0 >= r2) goto L_0x0008;
    L_0x0007:
        return r1;
    L_0x0008:
        r0 = new java.util.ArrayList;
        r0.<init>();
        r2 = com.sherdle.universal.inherit.PermissionsFragment.class;
        r2 = r2.isAssignableFrom(r7);
        if (r2 == 0) goto L_0x0028;
    L_0x0015:
        r2 = r7.newInstance();	 Catch:{ Exception -> 0x0027 }
        r2 = (com.sherdle.universal.inherit.PermissionsFragment) r2;	 Catch:{ Exception -> 0x0027 }
        r2 = r2.requiredPermissions();	 Catch:{ Exception -> 0x0027 }
        r2 = java.util.Arrays.asList(r2);	 Catch:{ Exception -> 0x0027 }
        r0.addAll(r2);	 Catch:{ Exception -> 0x0027 }
        goto L_0x0028;
    L_0x0028:
        r2 = r0.size();
        if (r2 <= r1) goto L_0x005b;
    L_0x002e:
        r2 = r0.iterator();
        r3 = 1;
    L_0x0033:
        r4 = r2.hasNext();
        r5 = 0;
        if (r4 == 0) goto L_0x0048;
    L_0x003a:
        r4 = r2.next();
        r4 = (java.lang.String) r4;
        r4 = r6.checkSelfPermission(r4);
        if (r4 == 0) goto L_0x0033;
    L_0x0046:
        r3 = 0;
        goto L_0x0033;
    L_0x0048:
        if (r3 != 0) goto L_0x005a;
    L_0x004a:
        r2 = new java.lang.String[r5];
        r0 = r0.toArray(r2);
        r0 = (java.lang.String[]) r0;
        r6.requestPermissions(r0, r1);
        r6.queueItem = r7;
        r6.queueItemData = r8;
        return r5;
    L_0x005a:
        return r1;
    L_0x005b:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.HolderActivity.checkPermissionsHandleIfNeeded(java.lang.Class, java.lang.String[]):boolean");
    }

    @SuppressLint({"NewApi"})
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 1) {
            super.onRequestPermissionsResult(i, strArr, iArr);
            return;
        }
        Object obj = null;
        for (int i2 : iArr) {
            if (i2 != 0) {
                obj = 1;
            }
        }
        if (obj == null) {
            openFragment(this.queueItem, this.queueItemData);
        } else {
            Toast.makeText(this, getResources().getString(2131624110), 0).show();
        }
    }

    public void onResume() {
        super.onResume();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }
}
