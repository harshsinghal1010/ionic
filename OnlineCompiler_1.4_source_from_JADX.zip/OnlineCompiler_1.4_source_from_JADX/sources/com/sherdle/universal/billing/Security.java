package com.sherdle.universal.billing;

import android.text.TextUtils;
import android.util.Base64;
import com.sherdle.universal.util.Log;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;

class Security {
    private static final String KEY_FACTORY_ALGORITHM = "RSA";
    private static final String SIGNATURE_ALGORITHM = "SHA1withRSA";
    private static final String TAG = "IABUtil/Security";

    Security() {
    }

    public static boolean verifyPurchase(String str, String str2, String str3, String str4) {
        if (TextUtils.isEmpty(str3) == null && TextUtils.isEmpty(str2) == null) {
            if (TextUtils.isEmpty(str4) == null) {
                return verify(generatePublicKey(str2), str3, str4);
            }
        }
        Log.m158e(TAG, "Purchase verification failed: missing data.");
        return null;
    }

    public static PublicKey generatePublicKey(String str) {
        try {
            return KeyFactory.getInstance(KEY_FACTORY_ALGORITHM).generatePublic(new X509EncodedKeySpec(Base64.decode(str, 0)));
        } catch (String str2) {
            throw new RuntimeException(str2);
        } catch (String str22) {
            Log.m158e(TAG, "Invalid key specification.");
            throw new IllegalArgumentException(str22);
        } catch (String str222) {
            Log.m158e(TAG, "Base64 decoding failed.");
            throw str222;
        }
    }

    public static boolean verify(java.security.PublicKey r2, java.lang.String r3, java.lang.String r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = 0;
        r1 = "SHA1withRSA";	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
        r1 = java.security.Signature.getInstance(r1);	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
        r1.initVerify(r2);	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
        r2 = r3.getBytes();	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
        r1.update(r2);	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
        r2 = android.util.Base64.decode(r4, r0);	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
        r2 = r1.verify(r2);	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
        if (r2 != 0) goto L_0x0023;	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
    L_0x001b:
        r2 = "IABUtil/Security";	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
        r3 = "Signature verification failed.";	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
        com.sherdle.universal.util.Log.m158e(r2, r3);	 Catch:{ NoSuchAlgorithmException -> 0x003d, InvalidKeyException -> 0x0035, SignatureException -> 0x002d, IllegalArgumentException -> 0x0025 }
        return r0;
    L_0x0023:
        r2 = 1;
        return r2;
    L_0x0025:
        r2 = "IABUtil/Security";
        r3 = "Base64 decoding failed.";
        com.sherdle.universal.util.Log.m158e(r2, r3);
        goto L_0x0044;
    L_0x002d:
        r2 = "IABUtil/Security";
        r3 = "Signature exception.";
        com.sherdle.universal.util.Log.m158e(r2, r3);
        goto L_0x0044;
    L_0x0035:
        r2 = "IABUtil/Security";
        r3 = "Invalid key specification.";
        com.sherdle.universal.util.Log.m158e(r2, r3);
        goto L_0x0044;
    L_0x003d:
        r2 = "IABUtil/Security";
        r3 = "NoSuchAlgorithmException.";
        com.sherdle.universal.util.Log.m158e(r2, r3);
    L_0x0044:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.billing.Security.verify(java.security.PublicKey, java.lang.String, java.lang.String):boolean");
    }
}
