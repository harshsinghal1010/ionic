package com.sherdle.universal.billing;

import com.sherdle.universal.util.Log;
import java.util.Date;
import org.json.JSONObject;

public class PurchaseInfo {
    public final String responseData;
    public final String signature;

    public enum PurchaseState {
        PurchasedSuccessfully,
        Canceled,
        Refunded,
        SubscriptionExpired
    }

    public class ResponseData {
        public boolean autoRenewing;
        public String developerPayload;
        public String orderId;
        public String packageName;
        public String productId;
        public PurchaseState purchaseState;
        public Date purchaseTime;
        public String purchaseToken;
    }

    PurchaseInfo(String str, String str2) {
        this.responseData = str;
        this.signature = str2;
    }

    public static PurchaseState getPurchaseState(int i) {
        switch (i) {
            case 0:
                return PurchaseState.PurchasedSuccessfully;
            case 1:
                return PurchaseState.Canceled;
            case 2:
                return PurchaseState.Refunded;
            case 3:
                return PurchaseState.SubscriptionExpired;
            default:
                return PurchaseState.Canceled;
        }
    }

    public ResponseData parseResponseData() {
        try {
            JSONObject jSONObject = new JSONObject(this.responseData);
            ResponseData responseData = new ResponseData();
            responseData.orderId = jSONObject.optString(Constants.RESPONSE_ORDER_ID);
            responseData.packageName = jSONObject.optString("packageName");
            responseData.productId = jSONObject.optString(Constants.RESPONSE_PRODUCT_ID);
            long optLong = jSONObject.optLong(Constants.RESPONSE_PURCHASE_TIME, 0);
            responseData.purchaseTime = optLong != 0 ? new Date(optLong) : null;
            responseData.purchaseState = getPurchaseState(jSONObject.optInt("purchaseState", 1));
            responseData.developerPayload = jSONObject.optString(Constants.RESPONSE_PAYLOAD);
            responseData.purchaseToken = jSONObject.getString(Constants.RESPONSE_PURCHASE_TOKEN);
            responseData.autoRenewing = jSONObject.optBoolean("autoRenewing");
            return responseData;
        } catch (Exception e) {
            Log.printStackTrace(e);
            return null;
        }
    }
}
