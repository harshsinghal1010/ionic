package com.sherdle.universal.billing;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import java.lang.ref.WeakReference;

class BillingBase {
    private WeakReference<Context> contextReference;

    public BillingBase(Context context) {
        this.contextReference = new WeakReference(context);
    }

    public Context getContext() {
        return (Context) this.contextReference.get();
    }

    protected String getPreferencesBaseKey() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(((Context) this.contextReference.get()).getPackageName());
        stringBuilder.append("_preferences");
        return stringBuilder.toString();
    }

    private SharedPreferences getPreferences() {
        return this.contextReference.get() != null ? PreferenceManager.getDefaultSharedPreferences((Context) this.contextReference.get()) : null;
    }

    public void release() {
        WeakReference weakReference = this.contextReference;
        if (weakReference != null) {
            weakReference.clear();
        }
    }

    protected boolean saveString(String str, String str2) {
        SharedPreferences preferences = getPreferences();
        if (preferences == null) {
            return null;
        }
        Editor edit = preferences.edit();
        edit.putString(str, str2);
        edit.commit();
        return true;
    }

    protected String loadString(String str, String str2) {
        SharedPreferences preferences = getPreferences();
        return preferences != null ? preferences.getString(str, str2) : str2;
    }

    protected boolean saveBoolean(String str, Boolean bool) {
        SharedPreferences preferences = getPreferences();
        if (preferences == null) {
            return null;
        }
        Editor edit = preferences.edit();
        edit.putBoolean(str, bool.booleanValue());
        edit.commit();
        return true;
    }

    protected boolean loadBoolean(String str, boolean z) {
        SharedPreferences preferences = getPreferences();
        return preferences != null ? preferences.getBoolean(str, z) : z;
    }
}
