package com.sherdle.universal.billing;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import com.android.vending.billing.IInAppBillingService;
import com.android.vending.billing.IInAppBillingService.Stub;
import com.sherdle.universal.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.json.JSONObject;

public class BillingProcessor extends BillingBase {
    private static final String LOG_TAG = "iabv3";
    private static final String MANAGED_PRODUCTS_CACHE_KEY = ".products.cache.v2_6";
    private static final int PURCHASE_FLOW_REQUEST_CODE = 32459;
    private static final String PURCHASE_PAYLOAD_CACHE_KEY = ".purchase.last.v2_6";
    private static final String RESTORE_KEY = ".products.restored.v2_6";
    private static final String SETTINGS_VERSION = ".v2_6";
    private static final String SUBSCRIPTIONS_CACHE_KEY = ".subscriptions.cache.v2_6";
    private IInAppBillingService billingService;
    private BillingCache cachedProducts;
    private BillingCache cachedSubscriptions;
    private String contextPackageName;
    private IBillingHandler eventHandler;
    private ServiceConnection serviceConnection = new C05721();
    private String signatureBase64;

    /* renamed from: com.sherdle.universal.billing.BillingProcessor$1 */
    class C05721 implements ServiceConnection {
        C05721() {
        }

        public void onServiceDisconnected(ComponentName componentName) {
            BillingProcessor.this.billingService = null;
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            BillingProcessor.this.billingService = Stub.asInterface(iBinder);
            if (BillingProcessor.this.isPurchaseHistoryRestored() == null && BillingProcessor.this.loadOwnedPurchasesFromGoogle() != null) {
                BillingProcessor.this.setPurchaseHistoryRestored();
                if (BillingProcessor.this.eventHandler != null) {
                    BillingProcessor.this.eventHandler.onPurchaseHistoryRestored();
                }
            }
            if (BillingProcessor.this.eventHandler != null) {
                BillingProcessor.this.eventHandler.onBillingInitialized();
            }
        }
    }

    public interface IBillingHandler {
        void onBillingError(int i, Throwable th);

        void onBillingInitialized();

        void onProductPurchased(String str, TransactionDetails transactionDetails);

        void onPurchaseHistoryRestored();
    }

    public /* bridge */ /* synthetic */ Context getContext() {
        return super.getContext();
    }

    public BillingProcessor(Context context, String str, IBillingHandler iBillingHandler) {
        super(context);
        this.signatureBase64 = str;
        this.eventHandler = iBillingHandler;
        this.contextPackageName = context.getApplicationContext().getPackageName();
        this.cachedProducts = new BillingCache(context, MANAGED_PRODUCTS_CACHE_KEY);
        this.cachedSubscriptions = new BillingCache(context, SUBSCRIPTIONS_CACHE_KEY);
        bindPlayServices();
    }

    private void bindPlayServices() {
        try {
            Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
            intent.setPackage("com.android.vending");
            getContext().bindService(intent, this.serviceConnection, 1);
        } catch (Exception e) {
            Log.m158e(LOG_TAG, e.toString());
        }
    }

    public void release() {
        if (!(this.serviceConnection == null || getContext() == null)) {
            try {
                getContext().unbindService(this.serviceConnection);
            } catch (Exception e) {
                Log.m158e(LOG_TAG, e.toString());
            }
            this.billingService = null;
        }
        this.cachedProducts.release();
        super.release();
    }

    public boolean isInitialized() {
        return this.billingService != null;
    }

    public boolean isPurchased(String str) {
        return this.cachedProducts.includesProduct(str);
    }

    public boolean isSubscribed(String str) {
        return this.cachedSubscriptions.includesProduct(str);
    }

    public List<String> listOwnedProducts() {
        return this.cachedProducts.getContents();
    }

    public List<String> listOwnedSubscriptions() {
        return this.cachedSubscriptions.getContents();
    }

    private boolean loadPurchasesByType(String str, BillingCache billingCache) {
        if (!isInitialized()) {
            return false;
        }
        try {
            str = this.billingService.getPurchases(3, this.contextPackageName, str, null);
            if (str.getInt(Constants.RESPONSE_CODE) == 0) {
                billingCache.clear();
                ArrayList stringArrayList = str.getStringArrayList(Constants.INAPP_PURCHASE_DATA_LIST);
                str = str.getStringArrayList(Constants.INAPP_DATA_SIGNATURE_LIST);
                int i = 0;
                while (i < stringArrayList.size()) {
                    String str2 = (String) stringArrayList.get(i);
                    JSONObject jSONObject = new JSONObject(str2);
                    String str3 = (str == null || str.size() <= i) ? null : (String) str.get(i);
                    billingCache.put(jSONObject.getString(Constants.RESPONSE_PRODUCT_ID), str2, str3);
                    i++;
                }
            }
            return true;
        } catch (String str4) {
            billingCache = this.eventHandler;
            if (billingCache != null) {
                billingCache.onBillingError(100, str4);
            }
            Log.m158e(LOG_TAG, str4.toString());
            return false;
        }
    }

    public boolean loadOwnedPurchasesFromGoogle() {
        return isInitialized() && loadPurchasesByType(Constants.PRODUCT_TYPE_MANAGED, this.cachedProducts) && loadPurchasesByType(Constants.PRODUCT_TYPE_SUBSCRIPTION, this.cachedSubscriptions);
    }

    public boolean purchase(Activity activity, String str) {
        return purchase(activity, str, Constants.PRODUCT_TYPE_MANAGED);
    }

    public boolean subscribe(Activity activity, String str) {
        return purchase(activity, str, Constants.PRODUCT_TYPE_SUBSCRIPTION);
    }

    private boolean purchase(Activity activity, String str, String str2) {
        if (isInitialized() && !TextUtils.isEmpty(str)) {
            if (!TextUtils.isEmpty(str2)) {
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(str2);
                    stringBuilder.append(":");
                    stringBuilder.append(UUID.randomUUID().toString());
                    String stringBuilder2 = stringBuilder.toString();
                    savePurchasePayload(stringBuilder2);
                    str2 = this.billingService.getBuyIntent(3, this.contextPackageName, str, str2, stringBuilder2);
                    if (str2 != null) {
                        int i = str2.getInt(Constants.RESPONSE_CODE);
                        if (i == 0) {
                            PendingIntent pendingIntent = (PendingIntent) str2.getParcelable(Constants.BUY_INTENT);
                            if (activity != null) {
                                activity.startIntentSenderForResult(pendingIntent.getIntentSender(), PURCHASE_FLOW_REQUEST_CODE, new Intent(), 0, 0, 0);
                            } else if (this.eventHandler != null) {
                                this.eventHandler.onBillingError(103, null);
                            }
                        } else if (i == 7) {
                            if (isPurchased(str) == null && isSubscribed(str) == null) {
                                loadOwnedPurchasesFromGoogle();
                            }
                            if (this.eventHandler != null) {
                                activity = getPurchaseTransactionDetails(str);
                                if (activity == null) {
                                    activity = getSubscriptionTransactionDetails(str);
                                }
                                this.eventHandler.onProductPurchased(str, activity);
                            }
                        } else if (this.eventHandler != null) {
                            this.eventHandler.onBillingError(101, null);
                        }
                    }
                    return true;
                } catch (Activity activity2) {
                    Log.m158e(LOG_TAG, activity2.toString());
                    return false;
                }
            }
        }
        return false;
    }

    private com.sherdle.universal.billing.TransactionDetails getPurchaseTransactionDetails(java.lang.String r3, com.sherdle.universal.billing.BillingCache r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r2 = this;
        r4 = r4.getDetails(r3);
        if (r4 == 0) goto L_0x002a;
    L_0x0006:
        r0 = r4.responseData;
        r0 = android.text.TextUtils.isEmpty(r0);
        if (r0 != 0) goto L_0x002a;
    L_0x000e:
        r0 = new com.sherdle.universal.billing.TransactionDetails;	 Catch:{ JSONException -> 0x0014 }
        r0.<init>(r4);	 Catch:{ JSONException -> 0x0014 }
        return r0;
    L_0x0014:
        r4 = "iabv3";
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r1 = "Failed to load saved purchase details for ";
        r0.append(r1);
        r0.append(r3);
        r3 = r0.toString();
        com.sherdle.universal.util.Log.m158e(r4, r3);
    L_0x002a:
        r3 = 0;
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.billing.BillingProcessor.getPurchaseTransactionDetails(java.lang.String, com.sherdle.universal.billing.BillingCache):com.sherdle.universal.billing.TransactionDetails");
    }

    public boolean consumePurchase(String str) {
        if (!isInitialized()) {
            return false;
        }
        try {
            TransactionDetails purchaseTransactionDetails = getPurchaseTransactionDetails(str, this.cachedProducts);
            if (!(purchaseTransactionDetails == null || TextUtils.isEmpty(purchaseTransactionDetails.purchaseToken))) {
                int consumePurchase = this.billingService.consumePurchase(3, this.contextPackageName, purchaseTransactionDetails.purchaseToken);
                if (consumePurchase == 0) {
                    this.cachedProducts.remove(str);
                    String str2 = LOG_TAG;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Successfully consumed ");
                    stringBuilder.append(str);
                    stringBuilder.append(" purchase.");
                    Log.m157d(str2, stringBuilder.toString());
                    return true;
                }
                if (this.eventHandler != null) {
                    this.eventHandler.onBillingError(consumePurchase, null);
                }
                Log.m158e(LOG_TAG, String.format("Failed to consume %s: error %d", new Object[]{str, Integer.valueOf(consumePurchase)}));
            }
        } catch (String str3) {
            Log.m158e(LOG_TAG, str3.toString());
        }
        return false;
    }

    private SkuDetails getSkuDetails(String str, String str2) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(str);
        str = getSkuDetails(arrayList, str2);
        return (str == null || str.size() <= null) ? null : (SkuDetails) str.get(null);
    }

    private List<SkuDetails> getSkuDetails(ArrayList<String> arrayList, String str) {
        if (!(this.billingService == null || arrayList == null || arrayList.size() <= 0)) {
            try {
                Bundle bundle = new Bundle();
                bundle.putStringArrayList(Constants.PRODUCTS_LIST, arrayList);
                str = this.billingService.getSkuDetails(3, this.contextPackageName, str, bundle);
                int i = str.getInt(Constants.RESPONSE_CODE);
                if (i == 0) {
                    arrayList = new ArrayList();
                    str = str.getStringArrayList(Constants.DETAILS_LIST).iterator();
                    while (str.hasNext()) {
                        arrayList.add(new SkuDetails(new JSONObject((String) str.next())));
                    }
                    return arrayList;
                }
                if (this.eventHandler != null) {
                    this.eventHandler.onBillingError(i, null);
                }
                Log.m158e(LOG_TAG, String.format("Failed to retrieve info for %d products, %d", new Object[]{Integer.valueOf(arrayList.size()), Integer.valueOf(i)}));
            } catch (ArrayList<String> arrayList2) {
                Log.m158e(LOG_TAG, String.format("Failed to call getSkuDetails %s", new Object[]{arrayList2.toString()}));
            }
        }
        return null;
    }

    public SkuDetails getPurchaseListingDetails(String str) {
        return getSkuDetails(str, Constants.PRODUCT_TYPE_MANAGED);
    }

    public SkuDetails getSubscriptionListingDetails(String str) {
        return getSkuDetails(str, Constants.PRODUCT_TYPE_SUBSCRIPTION);
    }

    public List<SkuDetails> getPurchaseListingDetails(ArrayList<String> arrayList) {
        return getSkuDetails((ArrayList) arrayList, Constants.PRODUCT_TYPE_MANAGED);
    }

    public List<SkuDetails> getSubscriptionListingDetails(ArrayList<String> arrayList) {
        return getSkuDetails((ArrayList) arrayList, Constants.PRODUCT_TYPE_SUBSCRIPTION);
    }

    public TransactionDetails getPurchaseTransactionDetails(String str) {
        return getPurchaseTransactionDetails(str, this.cachedProducts);
    }

    public TransactionDetails getSubscriptionTransactionDetails(String str) {
        return getPurchaseTransactionDetails(str, this.cachedSubscriptions);
    }

    public boolean handleActivityResult(int i, int i2, Intent intent) {
        if (i != PURCHASE_FLOW_REQUEST_CODE) {
            return false;
        }
        if (intent == null) {
            Log.m158e(LOG_TAG, "handleActivityResult: data is null!");
            return false;
        }
        i = intent.getIntExtra(Constants.RESPONSE_CODE, 0);
        Log.m157d(LOG_TAG, String.format("resultCode = %d, responseCode = %d", new Object[]{Integer.valueOf(i2), Integer.valueOf(i)}));
        String purchasePayload = getPurchasePayload();
        if (i2 == -1 && i == 0 && TextUtils.isEmpty(purchasePayload) == 0) {
            i = intent.getStringExtra(Constants.INAPP_PURCHASE_DATA);
            i2 = intent.getStringExtra(Constants.RESPONSE_INAPP_SIGNATURE);
            try {
                intent = new JSONObject(i);
                String string = intent.getString(Constants.RESPONSE_PRODUCT_ID);
                intent = intent.getString(Constants.RESPONSE_PAYLOAD);
                if (intent == null) {
                    intent = "";
                }
                boolean startsWith = purchasePayload.startsWith(Constants.PRODUCT_TYPE_SUBSCRIPTION);
                if (!purchasePayload.equals(intent)) {
                    Log.m158e(LOG_TAG, String.format("Payload mismatch: %s != %s", new Object[]{purchasePayload, intent}));
                    if (this.eventHandler != 0) {
                        this.eventHandler.onBillingError(102, null);
                    }
                } else if (verifyPurchaseSignature(string, i, i2) != null) {
                    (startsWith ? this.cachedSubscriptions : this.cachedProducts).put(string, i, i2);
                    if (this.eventHandler != null) {
                        this.eventHandler.onProductPurchased(string, new TransactionDetails(new PurchaseInfo(i, i2)));
                    }
                } else {
                    Log.m158e(LOG_TAG, "Public key signature doesn't match!");
                    if (this.eventHandler != 0) {
                        this.eventHandler.onBillingError(102, null);
                    }
                }
            } catch (int i3) {
                Log.m158e(LOG_TAG, i3.toString());
                i3 = this.eventHandler;
                if (i3 != 0) {
                    i3.onBillingError(110, null);
                }
            }
        } else {
            i2 = this.eventHandler;
            if (i2 != 0) {
                i2.onBillingError(i3, null);
            }
        }
        return true;
    }

    private boolean verifyPurchaseSignature(java.lang.String r2, java.lang.String r3, java.lang.String r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r1 = this;
        r0 = r1.signatureBase64;	 Catch:{ Exception -> 0x0011 }
        r0 = android.text.TextUtils.isEmpty(r0);	 Catch:{ Exception -> 0x0011 }
        if (r0 == 0) goto L_0x000a;	 Catch:{ Exception -> 0x0011 }
    L_0x0008:
        r2 = 1;	 Catch:{ Exception -> 0x0011 }
        return r2;	 Catch:{ Exception -> 0x0011 }
    L_0x000a:
        r0 = r1.signatureBase64;	 Catch:{ Exception -> 0x0011 }
        r2 = com.sherdle.universal.billing.Security.verifyPurchase(r2, r0, r3, r4);	 Catch:{ Exception -> 0x0011 }
        return r2;
    L_0x0011:
        r2 = 0;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.billing.BillingProcessor.verifyPurchaseSignature(java.lang.String, java.lang.String, java.lang.String):boolean");
    }

    public boolean isValid(TransactionDetails transactionDetails) {
        return verifyPurchaseSignature(transactionDetails.productId, transactionDetails.purchaseInfo.responseData, transactionDetails.purchaseInfo.signature);
    }

    private boolean isPurchaseHistoryRestored() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getPreferencesBaseKey());
        stringBuilder.append(RESTORE_KEY);
        return loadBoolean(stringBuilder.toString(), false);
    }

    public void setPurchaseHistoryRestored() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getPreferencesBaseKey());
        stringBuilder.append(RESTORE_KEY);
        saveBoolean(stringBuilder.toString(), Boolean.valueOf(true));
    }

    private void savePurchasePayload(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getPreferencesBaseKey());
        stringBuilder.append(PURCHASE_PAYLOAD_CACHE_KEY);
        saveString(stringBuilder.toString(), str);
    }

    private String getPurchasePayload() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getPreferencesBaseKey());
        stringBuilder.append(PURCHASE_PAYLOAD_CACHE_KEY);
        return loadString(stringBuilder.toString(), null);
    }
}
