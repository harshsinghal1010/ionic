package com.sherdle.universal;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import com.sherdle.universal.drawer.NavItem;
import com.sherdle.universal.drawer.SimpleMenu;
import com.sherdle.universal.drawer.SimpleSubMenu;
import com.sherdle.universal.providers.CustomIntent;
import com.sherdle.universal.providers.facebook.FacebookFragment;
import com.sherdle.universal.providers.flickr.ui.FlickrFragment;
import com.sherdle.universal.providers.instagram.InstagramFragment;
import com.sherdle.universal.providers.maps.MapsFragment;
import com.sherdle.universal.providers.overview.ui.OverviewFragment;
import com.sherdle.universal.providers.pinterest.PinterestFragment;
import com.sherdle.universal.providers.radio.ui.RadioFragment;
import com.sherdle.universal.providers.rss.ui.RssFragment;
import com.sherdle.universal.providers.soundcloud.ui.SoundCloudFragment;
import com.sherdle.universal.providers.tumblr.ui.TumblrFragment;
import com.sherdle.universal.providers.tv.TvFragment;
import com.sherdle.universal.providers.twitter.ui.TweetsFragment;
import com.sherdle.universal.providers.web.WebviewFragment;
import com.sherdle.universal.providers.woocommerce.ui.OrdersFragment;
import com.sherdle.universal.providers.woocommerce.ui.WooCommerceFragment;
import com.sherdle.universal.providers.wordpress.ui.WordpressFragment;
import com.sherdle.universal.providers.youtube.ui.YoutubeFragment;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ConfigParser extends AsyncTask<Void, Void, Void> {
    private static String CACHE_FILE = "menuCache.srl";
    private static JSONArray jsonMenu;
    final long MAX_FILE_AGE = 172800000;
    private CallBack callback;
    private Activity context;
    private boolean facedException;
    private SimpleMenu menu;
    private String sourceLocation;

    public interface CallBack {
        void configLoaded(boolean z);
    }

    public ConfigParser(String str, SimpleMenu simpleMenu, Activity activity, CallBack callBack) {
        this.sourceLocation = str;
        this.context = activity;
        this.menu = simpleMenu;
        this.callback = callBack;
    }

    protected void onPreExecute() {
        super.onPreExecute();
    }

    protected Void doInBackground(Void... voidArr) {
        if (jsonMenu == null) {
            try {
                if (this.sourceLocation.contains("http") != null) {
                    jsonMenu = getJSONFromCache();
                    if (getJSONFromCache() == null) {
                        Log.m161v("INFO", "Loading Menu Config from url.");
                        voidArr = Helper.getDataFromUrl(this.sourceLocation);
                        jsonMenu = new JSONArray(voidArr);
                        saveJSONToCache(voidArr);
                    } else {
                        Log.m161v("INFO", "Loading Menu Config from cache.");
                    }
                } else {
                    jsonMenu = new JSONArray(Helper.loadJSONFromAsset(this.context, this.sourceLocation));
                }
            } catch (Void[] voidArr2) {
                voidArr2.printStackTrace();
            }
        }
        voidArr2 = jsonMenu;
        if (voidArr2 != null) {
            this.context.runOnUiThread(new Runnable() {
                public void run() {
                    SimpleSubMenu simpleSubMenu = null;
                    int i = 0;
                    while (i < voidArr2.length()) {
                        try {
                            JSONObject jSONObject = voidArr2.getJSONObject(i);
                            String string = jSONObject.getString("title");
                            int access$100 = (!jSONObject.has("drawable") || jSONObject.getString("drawable") == null || jSONObject.getString("drawable").isEmpty() || jSONObject.getString("drawable").equals("0")) ? 0 : ConfigParser.getDrawableByName(ConfigParser.this.context, jSONObject.getString("drawable"));
                            if (!jSONObject.has("submenu") || jSONObject.getString("submenu") == null || jSONObject.getString("submenu").isEmpty()) {
                                simpleSubMenu = null;
                            } else {
                                String string2 = jSONObject.getString("submenu");
                                if (simpleSubMenu == null || !simpleSubMenu.getSubMenuTitle().equals(string2)) {
                                    simpleSubMenu = new SimpleSubMenu(ConfigParser.this.menu, string2);
                                }
                            }
                            boolean z = jSONObject.has("iap") && jSONObject.getBoolean("iap");
                            List arrayList = new ArrayList();
                            JSONArray jSONArray = jSONObject.getJSONArray("tabs");
                            for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                                arrayList.add(ConfigParser.navItemFromJSON(ConfigParser.this.context, jSONArray.getJSONObject(i2)));
                            }
                            if (simpleSubMenu != null) {
                                simpleSubMenu.add(string, access$100, arrayList, z);
                            } else {
                                ConfigParser.this.menu.add(string, access$100, arrayList, z);
                            }
                            i++;
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.m158e("INFO", "JSON was invalid");
                            ConfigParser.this.facedException = true;
                            return;
                        }
                    }
                }
            });
        } else {
            Log.m158e("INFO", "JSON Could not be retrieved");
            this.facedException = 1;
        }
        return null;
    }

    public static NavItem navItemFromJSON(Context context, JSONObject jSONObject) throws JSONException {
        Class cls;
        String string = jSONObject.getString("title");
        String string2 = jSONObject.getString("provider");
        JSONArray jSONArray = jSONObject.getJSONArray("arguments");
        List arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(jSONArray.getString(i));
        }
        if (string2.equals("wordpress")) {
            cls = WordpressFragment.class;
        } else if (string2.equals("facebook")) {
            cls = FacebookFragment.class;
        } else if (string2.equals("rss")) {
            cls = RssFragment.class;
        } else if (string2.equals("youtube")) {
            cls = YoutubeFragment.class;
        } else if (string2.equals("instagram")) {
            cls = InstagramFragment.class;
        } else if (string2.equals("webview")) {
            cls = WebviewFragment.class;
        } else if (string2.equals("tumblr")) {
            cls = TumblrFragment.class;
        } else if (string2.equals("flickr")) {
            cls = FlickrFragment.class;
        } else if (string2.equals("stream")) {
            cls = TvFragment.class;
        } else {
            if (!string2.equals("soundcloud")) {
                if (!string2.equals("wordpress_audio")) {
                    if (string2.equals("maps")) {
                        cls = MapsFragment.class;
                    } else if (string2.equals("twitter")) {
                        cls = TweetsFragment.class;
                    } else if (string2.equals("radio")) {
                        cls = RadioFragment.class;
                    } else if (string2.equals("pinterest")) {
                        cls = PinterestFragment.class;
                    } else if (string2.equals("woocommerce") && jSONArray.get(0) != null && jSONArray.get(0).equals("orders")) {
                        cls = OrdersFragment.class;
                    } else if (string2.equals("woocommerce")) {
                        cls = WooCommerceFragment.class;
                    } else if (string2.equals("custom")) {
                        cls = CustomIntent.class;
                    } else if (string2.equals("overview")) {
                        cls = OverviewFragment.class;
                    } else {
                        throw new RuntimeException("Invalid type specified for tab");
                    }
                }
            }
            Class cls2 = SoundCloudFragment.class;
            if (string2.equals("wordpress_audio")) {
                arrayList.add("wordpress");
            }
            cls = cls2;
        }
        NavItem navItem = new NavItem(string, cls, (String[]) arrayList.toArray(new String[0]));
        if (!(!jSONObject.has("image") || jSONObject.getString("image") == null || jSONObject.getString("image").isEmpty())) {
            if (jSONObject.getString("image").startsWith("http")) {
                navItem.setCategoryImageUrl(jSONObject.getString("image"));
            } else {
                navItem.setTabIcon(getDrawableByName(context, jSONObject.getString("image")));
            }
        }
        return navItem;
    }

    protected void onPostExecute(Void voidR) {
        voidR = this.callback;
        if (voidR != null) {
            voidR.configLoaded(this.facedException);
        }
    }

    private static int getDrawableByName(Context context, String str) {
        return context.getResources().getIdentifier(str, "drawable", context.getPackageName());
    }

    public void saveJSONToCache(String str) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(new File(this.context.getCacheDir(), ""));
            stringBuilder.append(CACHE_FILE);
            ObjectOutput objectOutputStream = new ObjectOutputStream(new FileOutputStream(stringBuilder.toString()));
            objectOutputStream.writeObject(str);
            objectOutputStream.close();
        } catch (String str2) {
            str2.printStackTrace();
        }
    }

    private JSONArray getJSONFromCache() {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(new File(this.context.getCacheDir(), ""));
            stringBuilder.append(CACHE_FILE);
            File file = new File(stringBuilder.toString());
            ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(file));
            String str = (String) objectInputStream.readObject();
            objectInputStream.close();
            if (file.lastModified() + 172800000 > System.currentTimeMillis()) {
                return new JSONArray(str);
            }
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (ClassNotFoundException e2) {
            e2.printStackTrace();
            return null;
        } catch (JSONException e3) {
            e3.printStackTrace();
            return null;
        }
    }
}
