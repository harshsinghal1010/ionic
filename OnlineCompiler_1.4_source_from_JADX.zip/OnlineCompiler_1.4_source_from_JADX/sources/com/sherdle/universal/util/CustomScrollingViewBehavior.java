package com.sherdle.universal.util;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.AppBarLayout.ScrollingViewBehavior;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewGroup;
import com.codeintelligent.onlinecompiler.R;

public class CustomScrollingViewBehavior extends ScrollingViewBehavior implements OnLayoutChangeListener {
    private static final int SCROLL_DIRECTION_UP = -1;
    private View appBarLayout;
    private boolean dynamicElevation;
    private boolean isElevated;

    public CustomScrollingViewBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean layoutDependsOn(CoordinatorLayout coordinatorLayout, View view, View view2) {
        coordinatorLayout.addOnLayoutChangeListener(this);
        if (view2 instanceof AppBarLayout) {
            this.appBarLayout = view2;
        }
        return super.layoutDependsOn(coordinatorLayout, view, view2);
    }

    public boolean onStartNestedScroll(@NonNull CoordinatorLayout coordinatorLayout, @NonNull View view, @NonNull View view2, @NonNull View view3, int i, int i2) {
        if (i != 2) {
            if (super.onStartNestedScroll(coordinatorLayout, view, view2, view3, i, i2) == null) {
                return null;
            }
        }
        return true;
    }

    public void onNestedPreScroll(@NonNull CoordinatorLayout coordinatorLayout, @NonNull View view, @NonNull View view2, int i, int i2, @NonNull int[] iArr, int i3) {
        View view3;
        View view4 = view2;
        if (this.dynamicElevation) {
            if (view4 instanceof SwipeRefreshLayout) {
                SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) view4;
                if (swipeRefreshLayout.getChildCount() > 0 && (swipeRefreshLayout.getChildAt(0) instanceof RecyclerView)) {
                    view4 = swipeRefreshLayout.getChildAt(0);
                }
            }
            if (view4 instanceof RecyclerView) {
                if (((RecyclerView) view4).canScrollVertically(-1)) {
                    if (!(r8.isElevated || ((ViewGroup) view.getParent()) == null)) {
                        setElevated(true, view.getContext());
                    }
                    r8.isElevated = true;
                } else {
                    if (r8.isElevated && ((ViewGroup) view.getParent()) != null) {
                        setElevated(false, view.getContext());
                    }
                    r8.isElevated = false;
                }
            }
            view3 = view4;
        } else {
            view3 = view4;
        }
        super.onNestedPreScroll(coordinatorLayout, view, view3, i, i2, iArr, i3);
    }

    public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        if (this.dynamicElevation != 0) {
            setElevated(false, view.getContext());
            this.isElevated = false;
            return;
        }
        setElevated(true, view.getContext());
        this.isElevated = true;
    }

    private void setElevated(boolean z, Context context) {
        View view = this.appBarLayout;
        if (view != null) {
            ViewCompat.setElevation(view, z ? toolbarElevation(context) : false);
        }
    }

    public void setDynamicElevation(boolean z) {
        this.dynamicElevation = z;
    }

    private static float toolbarElevation(Context context) {
        return context.getResources().getDimension(R.dimen.toolbar_elevation);
    }
}
