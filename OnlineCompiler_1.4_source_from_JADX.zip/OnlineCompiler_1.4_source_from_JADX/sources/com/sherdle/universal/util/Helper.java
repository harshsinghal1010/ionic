package com.sherdle.universal.util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.app.DownloadManager.Request;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.C0361C;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.common.util.CrashUtils.ErrorDialogData;
import com.sherdle.universal.SettingsFragment;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import org.json.JSONArray;
import org.json.JSONObject;

public class Helper {
    private static boolean DISPLAY_DEBUG = false;

    public static int getGradient(int i) {
        switch (i) {
            case 1:
                return R.drawable.gradient_one;
            case 2:
                return R.drawable.gradient_two;
            case 3:
                return R.drawable.gradient_five;
            case 4:
                return R.drawable.gradient_four;
            default:
                return R.drawable.gradient_three;
        }
    }

    public static void noConnection(Activity activity, String str) {
        Builder builder = new Builder(activity);
        if (isOnline(activity)) {
            String str2 = "";
            if (str != null && DISPLAY_DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("\n\n");
                stringBuilder.append(str);
                str2 = stringBuilder.toString();
            }
            str = new StringBuilder();
            str.append(activity.getResources().getString(R.string.dialog_connection_description));
            str.append(str2);
            builder.setMessage(str.toString());
            builder.setPositiveButton(activity.getResources().getString(R.string.ok), null);
            builder.setTitle(activity.getResources().getString(R.string.dialog_connection_title));
        } else {
            builder.setMessage(activity.getResources().getString(R.string.dialog_internet_description));
            builder.setPositiveButton(activity.getResources().getString(R.string.ok), null);
            builder.setTitle(activity.getResources().getString(R.string.dialog_internet_title));
        }
        if (activity.isFinishing() == null) {
            builder.show();
        }
    }

    public static void noConnection(Activity activity) {
        noConnection(activity, null);
    }

    public static boolean isOnline(Context context) {
        context = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        return (context == null || context.isConnected() == null) ? null : true;
    }

    public static boolean isOnlineShowDialog(Activity activity) {
        if (isOnline(activity)) {
            return true;
        }
        noConnection(activity);
        return null;
    }

    @Deprecated
    public static void admobLoader(Context context, Resources resources, View view) {
        admobLoader(context, view);
    }

    public static void admobLoader(Context context, View view) {
        if (!context.getResources().getString(R.string.admob_banner_id).equals("") && SettingsFragment.getIsPurchased(context) == null) {
            AdView adView = (AdView) view;
            adView.setVisibility(null);
            context = new AdRequest.Builder();
            context.addTestDevice("B3EEABB8EE11C2BE770B684D95219ECB");
            adView.loadAd(context.build());
        }
    }

    @SuppressLint({"NewApi"})
    public static void setStatusBarColor(Activity activity, int i) {
        try {
            if (VERSION.SDK_INT >= 21) {
                activity.getWindow().setStatusBarColor(i);
            }
        } catch (Activity activity2) {
            Log.printStackTrace(activity2);
        }
    }

    public static String loadJSONFromAsset(Context context, String str) {
        try {
            context = context.getAssets().open(str);
            str = new byte[context.available()];
            context.read(str);
            context.close();
            return new String(str, C0361C.UTF8_NAME);
        } catch (Context context2) {
            context2.printStackTrace();
            return null;
        }
    }

    public static void showEmptyView(Fragment fragment, int i, int i2) {
        if (fragment != null) {
            if (fragment.getActivity() != null) {
                ViewGroup viewGroup = (ViewGroup) fragment.getView();
                viewGroup.findViewById(R.id.empty_view).setVisibility(0);
                viewGroup.findViewById(R.id.list).setVisibility(8);
                ((TextView) viewGroup.findViewById(R.id.title)).setText(fragment.getString(i));
                ((TextView) viewGroup.findViewById(R.id.subtitle)).setText(fragment.getString(i2));
            }
        }
    }

    public static void hideEmptyView(Fragment fragment) {
        ViewGroup viewGroup = (ViewGroup) fragment.getView();
        if (viewGroup != null && viewGroup.findViewById(R.id.empty_view) != null) {
            viewGroup.findViewById(R.id.empty_view).setVisibility(8);
            viewGroup.findViewById(R.id.list).setVisibility(0);
        }
    }

    public static String formatValue(double d) {
        if (d <= 0.0d) {
            return "0";
        }
        int log10 = ((int) StrictMath.log10(d)) / 3;
        d = new DecimalFormat("#,###.#").format(d / Math.pow(10.0d, (double) (log10 * 3)));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(d);
        stringBuilder.append(" kmbt".charAt(log10));
        d = stringBuilder.toString();
        if (d.length() > 4) {
            d = d.replaceAll("\\.[0-9]+", "");
        }
        return d;
    }

    public static String getDataFromUrl(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Requesting: ");
        stringBuilder.append(str);
        Log.m161v("INFO", stringBuilder.toString());
        StringBuffer stringBuffer = new StringBuffer("");
        try {
            str = (HttpURLConnection) new URL(str).openConnection();
            str.setRequestProperty("User-Agent", "Universal/2.0 (Android)");
            str.setRequestMethod("GET");
            str.setDoInput(true);
            str.connect();
            int responseCode = str.getResponseCode();
            if (responseCode != 200 && (responseCode == 302 || responseCode == 301 || responseCode == 303)) {
                String headerField = str.getHeaderField("Location");
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(headerField).openConnection();
                httpURLConnection.setRequestProperty("Cookie", str.getHeaderField("Set-Cookie"));
                httpURLConnection.setRequestProperty("User-Agent", "Universal/2.0 (Android)");
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setDoInput(true);
                stringBuilder = new StringBuilder();
                stringBuilder.append("Redirect to URL : ");
                stringBuilder.append(headerField);
                Log.m161v("INFO", stringBuilder.toString());
                str = httpURLConnection;
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(str.getInputStream()));
            while (true) {
                str = bufferedReader.readLine();
                if (str == null) {
                    break;
                }
                stringBuffer.append(str);
            }
        } catch (String str2) {
            Log.printStackTrace(str2);
        }
        return stringBuffer.toString();
    }

    public static JSONObject getJSONObjectFromUrl(String str) {
        try {
            return new JSONObject(getDataFromUrl(str));
        } catch (String str2) {
            Log.m158e("INFO", "Error parsing JSON. Printing stacktrace now");
            Log.printStackTrace(str2);
            return null;
        }
    }

    public static JSONArray getJSONArrayFromUrl(String str) {
        try {
            return new JSONArray(getDataFromUrl(str));
        } catch (String str2) {
            Log.m158e("INFO", "Error parsing JSON. Printing stacktrace now");
            Log.printStackTrace(str2);
            return null;
        }
    }

    public static void updateAndroidSecurityProvider(android.app.Activity r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = android.os.Build.VERSION.SDK_INT;
        r1 = 21;
        if (r0 >= r1) goto L_0x001f;
    L_0x0006:
        com.google.android.gms.security.ProviderInstaller.installIfNeeded(r3);	 Catch:{ GooglePlayServicesRepairableException -> 0x0012, GooglePlayServicesNotAvailableException -> 0x000a }
        goto L_0x001f;
    L_0x000a:
        r3 = "SecurityException";
        r0 = "Google Play Services not available.";
        com.sherdle.universal.util.Log.m158e(r3, r0);
        goto L_0x001f;
    L_0x0012:
        r0 = move-exception;
        r1 = com.google.android.gms.common.GoogleApiAvailability.getInstance();
        r0 = r0.getConnectionStatusCode();
        r2 = 0;
        r1.getErrorDialog(r3, r0, r2);
    L_0x001f:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.util.Helper.updateAndroidSecurityProvider(android.app.Activity):void");
    }

    public static void download(Activity activity, String str) {
        if (!hasPermissionToDownload(activity)) {
            return;
        }
        if (str == null) {
            Toast.makeText(activity, activity.getResources().getString(R.string.download_unavailable), 1).show();
            return;
        }
        DownloadManager downloadManager = (DownloadManager) activity.getSystemService("download");
        Uri parse = Uri.parse(str);
        str = str.substring(str.lastIndexOf("/"), str.length());
        Request request = new Request(parse);
        request.setAllowedNetworkTypes(3);
        request.setNotificationVisibility(1);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, str);
        str = Long.valueOf(downloadManager.enqueue(request));
        activity.registerReceiver(new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                long longExtra = intent.getLongExtra("extra_download_id", 0);
                if (longExtra == str.longValue()) {
                    context.unregisterReceiver(this);
                    DownloadManager downloadManager = (DownloadManager) context.getSystemService("download");
                    Query query = new Query();
                    query.setFilterById(new long[]{longExtra});
                    Cursor query2 = downloadManager.query(query);
                    if (!query2.moveToFirst()) {
                        return;
                    }
                    if (8 != query2.getInt(query2.getColumnIndex(NotificationCompat.CATEGORY_STATUS))) {
                        Toast.makeText(context, context.getResources().getString(R.string.download_failed), 1).show();
                        return;
                    }
                    String string = query2.getString(query2.getColumnIndex("local_uri"));
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(context.getApplicationContext().getPackageName());
                    stringBuilder.append(".provider");
                    Uri uriForFile = FileProvider.getUriForFile(context, stringBuilder.toString(), new File(Uri.parse(string).getPath()));
                    Intent intent2 = new Intent("android.intent.action.VIEW");
                    intent2.setData(uriForFile);
                    intent2.setFlags(ErrorDialogData.BINDER_CRASH).setFlags(1);
                    intent2.setDataAndType(uriForFile, downloadManager.getMimeTypeForDownloadedFile(longExtra));
                    if (context.getPackageManager().queryIntentActivities(intent2, 0).size() > null) {
                        context.startActivity(intent2);
                    } else {
                        Toast.makeText(context, context.getResources().getString(R.string.download_open_failed), 1).show();
                    }
                }
            }
        }, new IntentFilter("android.intent.action.DOWNLOAD_COMPLETE"));
    }

    public static boolean hasPermissionToDownload(final Activity activity) {
        if (VERSION.SDK_INT >= 23) {
            if (ContextCompat.checkSelfPermission(activity, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setMessage((int) R.string.download_permission_explaination);
                builder.setPositiveButton((int) R.string.download_permission_grant, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (VERSION.SDK_INT >= 23) {
                            activity.requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
                        }
                    }
                });
                builder.create().show();
                return null;
            }
        }
        return true;
    }
}
