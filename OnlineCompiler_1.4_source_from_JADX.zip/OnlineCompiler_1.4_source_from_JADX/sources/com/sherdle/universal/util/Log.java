package com.sherdle.universal.util;

public class Log {
    public static final boolean LOG = true;

    /* renamed from: i */
    public static void m160i(String str, String str2) {
        android.util.Log.i(str, str2);
    }

    /* renamed from: e */
    public static void m158e(String str, String str2) {
        android.util.Log.e(str, str2);
    }

    /* renamed from: e */
    public static void m159e(String str, String str2, Exception exception) {
        android.util.Log.e(str, str2, exception);
    }

    /* renamed from: d */
    public static void m157d(String str, String str2) {
        android.util.Log.d(str, str2);
    }

    /* renamed from: v */
    public static void m161v(String str, String str2) {
        android.util.Log.v(str, str2);
    }

    /* renamed from: w */
    public static void m162w(String str, String str2) {
        android.util.Log.w(str, str2);
    }

    /* renamed from: w */
    public static void m163w(String str, String str2, Exception exception) {
        android.util.Log.w(str, str2, exception);
    }

    public static void printStackTrace(Exception exception) {
        exception.printStackTrace();
    }
}
