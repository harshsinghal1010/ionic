package com.sherdle.universal.util;

import android.content.Context;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.rss.ui.RssFragment;
import com.sherdle.universal.providers.woocommerce.ui.WooCommerceFragment;
import com.sherdle.universal.providers.wordpress.ui.WordpressFragment;
import com.sherdle.universal.providers.youtube.ui.YoutubeFragment;

public class ViewModeUtils {
    public static final int COMPACT = 0;
    public static final int IMMERSIVE = 2;
    public static final int NORMAL = 1;
    public static final int UNKNOWN = -1;
    private Context context;
    private Class mClass;

    public interface ChangeListener {
        void modeChanged();
    }

    public void inflateOptionsMenu(Menu menu, MenuInflater menuInflater) {
    }

    public ViewModeUtils(Context context, Class cls) {
        this.context = context;
        this.mClass = cls;
    }

    private boolean immersiveSupported() {
        if (!this.mClass.equals(WordpressFragment.class)) {
            if (!this.mClass.equals(YoutubeFragment.class)) {
                return false;
            }
        }
        return true;
    }

    public boolean handleSelection(MenuItem menuItem, ChangeListener changeListener) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.compact) {
            menuItem.setChecked(true);
            saveToPreferences(0);
            changeListener.modeChanged();
            return true;
        } else if (itemId == R.id.immersive) {
            menuItem.setChecked(true);
            saveToPreferences(2);
            changeListener.modeChanged();
            return true;
        } else if (itemId != R.id.normal) {
            return false;
        } else {
            menuItem.setChecked(true);
            saveToPreferences(1);
            changeListener.modeChanged();
            return true;
        }
    }

    public void saveToPreferences(int i) {
        PreferenceManager.getDefaultSharedPreferences(this.context).edit().putInt(this.mClass.getName(), i).apply();
    }

    private int getFromPreferences() {
        return PreferenceManager.getDefaultSharedPreferences(this.context).getInt(this.mClass.getName(), -1);
    }

    public int getViewMode() {
        int i = this.mClass.equals(WordpressFragment.class) ? 1 : this.mClass.equals(RssFragment.class) ? 1 : this.mClass.equals(YoutubeFragment.class) ? 1 : this.mClass.equals(WooCommerceFragment.class) ? 1 : -1;
        return ((i != 2 || immersiveSupported()) && i != -1) ? i : 1;
    }
}
