package com.sherdle.universal.util.layout;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ItemDecoration;
import android.support.v7.widget.RecyclerView.State;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.support.v7.widget.StaggeredGridLayoutManager.LayoutParams;
import android.view.View;

public class StaggeredGridSpacingItemDecoration extends ItemDecoration {
    private boolean headerItemNoSpacing;
    private int spacing;

    public StaggeredGridSpacingItemDecoration(int i, boolean z) {
        this.spacing = i;
        this.headerItemNoSpacing = z;
    }

    public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, State state) {
        View spanCount = ((StaggeredGridLayoutManager) recyclerView.getLayoutManager()).getSpanCount();
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int i = 0;
        if (!layoutParams.isFullSpan()) {
            view = layoutParams.getSpanIndex();
            int viewLayoutPosition = layoutParams.getViewLayoutPosition();
            recyclerView = recyclerView.getAdapter().getItemCount();
            Object obj = 1;
            Object obj2 = view == null ? 1 : null;
            Object obj3 = view == spanCount + -1 ? 1 : null;
            view = view < spanCount ? true : null;
            if (viewLayoutPosition < recyclerView - spanCount) {
                obj = null;
            }
            recyclerView = this.spacing;
            state = recyclerView / 2;
            if (obj2 == null) {
                recyclerView = state;
            }
            view = view != null ? this.spacing : state;
            if (obj3 != null) {
                state = this.spacing;
            }
            if (obj != null) {
                i = this.spacing;
            }
            rect.set(recyclerView, view, state, i);
        } else if (this.headerItemNoSpacing != null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect = this.spacing;
            view.setPadding(rect, rect, rect, rect);
        }
    }
}
