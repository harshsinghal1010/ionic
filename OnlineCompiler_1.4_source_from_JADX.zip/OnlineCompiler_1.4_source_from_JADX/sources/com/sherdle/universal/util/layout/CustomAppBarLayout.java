package com.sherdle.universal.util.layout;

import android.content.Context;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.AppBarLayout.OnOffsetChangedListener;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.CoordinatorLayout.LayoutParams;
import android.util.AttributeSet;
import java.util.ArrayList;
import java.util.List;

public class CustomAppBarLayout extends AppBarLayout implements OnOffsetChangedListener {
    private List<OnStateChangeListener> onStateChangeListeners;
    private State state;

    public interface OnStateChangeListener {
        void onStateChange(State state);
    }

    public enum State {
        COLLAPSED,
        EXPANDED,
        IDLE
    }

    public CustomAppBarLayout(Context context) {
        super(context);
    }

    public CustomAppBarLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean isToolbarHidden() {
        return this.state == State.COLLAPSED;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if ((getLayoutParams() instanceof LayoutParams) && (getParent() instanceof CoordinatorLayout)) {
            addOnOffsetChangedListener(this);
            return;
        }
        throw new IllegalStateException("MyAppBarLayout must be a direct child of CoordinatorLayout.");
    }

    public void onOffsetChanged(AppBarLayout appBarLayout, int i) {
        if (i == 0) {
            if (this.state != State.EXPANDED) {
                notifyListeners(State.EXPANDED);
            }
            this.state = State.EXPANDED;
        } else if (Math.abs(i) >= appBarLayout.getTotalScrollRange()) {
            if (this.state != State.COLLAPSED) {
                notifyListeners(State.COLLAPSED);
            }
            this.state = State.COLLAPSED;
        } else {
            if (this.state != State.IDLE) {
                notifyListeners(State.IDLE);
            }
            this.state = State.IDLE;
        }
    }

    private void notifyListeners(State state) {
        List<OnStateChangeListener> list = this.onStateChangeListeners;
        if (list != null) {
            for (OnStateChangeListener onStateChange : list) {
                onStateChange.onStateChange(state);
            }
        }
    }

    public void addOnStateChangeListener(OnStateChangeListener onStateChangeListener) {
        if (this.onStateChangeListeners == null) {
            this.onStateChangeListeners = new ArrayList();
        }
        this.onStateChangeListeners.add(onStateChangeListener);
    }

    public void removeOnStateChangeListener(OnStateChangeListener onStateChangeListener) {
        List list = this.onStateChangeListeners;
        if (list != null) {
            list.remove(onStateChangeListener);
        }
    }
}
