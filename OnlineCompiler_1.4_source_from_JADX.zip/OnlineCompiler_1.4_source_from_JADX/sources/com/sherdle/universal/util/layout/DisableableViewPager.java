package com.sherdle.universal.util.layout;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import com.duolingo.open.rtlviewpager.RtlViewPager;

public class DisableableViewPager extends RtlViewPager {
    private boolean enabled = true;

    public DisableableViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        return this.enabled ? super.onTouchEvent(motionEvent) : null;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.enabled ? super.onInterceptTouchEvent(motionEvent) : null;
    }

    public void setPagingEnabled(boolean z) {
        this.enabled = z;
    }
}
