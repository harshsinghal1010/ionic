package com.sherdle.universal.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build.VERSION;
import android.preference.PreferenceManager;
import org.jsoup.nodes.Document;

public class WebHelper {
    @SuppressLint({"NewApi"})
    public static String docToBetterHTML(Document document, Context context) {
        try {
            document.select("img[src]").removeAttr("width");
        } catch (Exception e) {
            Log.printStackTrace(e);
        }
        try {
            document.select("a[href]").removeAttr(TtmlNode.TAG_STYLE);
        } catch (Exception e2) {
            Log.printStackTrace(e2);
        }
        try {
            document.select(TtmlNode.TAG_DIV).removeAttr(TtmlNode.TAG_STYLE);
        } catch (Exception e22) {
            Log.printStackTrace(e22);
        }
        try {
            document.select("iframe").attr("width", "100%");
        } catch (Exception e222) {
            Log.printStackTrace(e222);
        }
        context = (VERSION.SDK_INT < 17 || context.getResources().getConfiguration().getLayoutDirection() != 1) ? "" : "direction:RTL; unicode-bidi:embed;";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<style>img{max-width: 100%; width: auto; height: auto;} p{max-width: 100%; width:auto; height: auto;}@font-face {font-family: 'Currents-Light-Sans';font-style: normal;font-weight: normal;src: local('sans-serif-light'), url('file:///android_asset/fonts/Roboto-Light.ttf') format('truetype');} body p {  font-family: 'Currents-Light-Sans', serif;} .list-inline {display: inline;list-style: none;} body {  max-width: 100% !important;font-family: 'Currents-Light-Sans', serif;margin: 0;padding: 0;");
        stringBuilder.append(context);
        stringBuilder.append("}</style>");
        document.head().append(stringBuilder.toString());
        return document.toString();
    }

    public static int getWebViewFontSize(Context context) {
        return Integer.parseInt(PreferenceManager.getDefaultSharedPreferences(context).getString(TtmlNode.ATTR_TTS_FONT_SIZE, "16"));
    }

    public static int getTextViewFontSize(Context context) {
        context = Integer.parseInt(PreferenceManager.getDefaultSharedPreferences(context).getString(TtmlNode.ATTR_TTS_FONT_SIZE, "16"));
        if (context >= 16) {
            return context - 2;
        }
        if (context == 7) {
            return context + 1;
        }
        return context < 16 ? context - 1 : context;
    }
}
