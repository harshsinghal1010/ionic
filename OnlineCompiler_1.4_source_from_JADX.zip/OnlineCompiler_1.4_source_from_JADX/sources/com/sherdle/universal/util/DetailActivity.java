package com.sherdle.universal.util;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.Menu;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.util.layout.TrackingScrollView;
import com.sherdle.universal.util.layout.TrackingScrollView.OnScrollChangedListener;

public abstract class DetailActivity extends AppCompatActivity {
    boolean FadeBar = true;
    protected RelativeLayout coolblue;
    protected int latestAlpha;
    protected int mScrollableHeaderHeight;
    protected Toolbar mToolbar;
    protected ImageView thumb;

    /* renamed from: com.sherdle.universal.util.DetailActivity$1 */
    class C07151 implements OnGlobalLayoutListener {
        C07151() {
        }

        public void onGlobalLayout() {
            DetailActivity.this.thumb.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            DetailActivity detailActivity = DetailActivity.this;
            detailActivity.mScrollableHeaderHeight = detailActivity.thumb.getHeight();
        }
    }

    /* renamed from: com.sherdle.universal.util.DetailActivity$2 */
    class C10212 implements OnScrollChangedListener {
        C10212() {
        }

        public void onScrollChanged(TrackingScrollView trackingScrollView, int i, int i2, int i3, int i4) {
            DetailActivity.this.handleScroll(i2);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ThemeUtils.setTheme(this);
    }

    protected void setUpHeader(String str) {
        if (isTablet()) {
            this.FadeBar = false;
        } else {
            this.coolblue.setVisibility(8);
        }
        if (str != null && !str.equals("") && str.equals("null") == null) {
            setParralaxHeader();
        } else if (isTablet() == null) {
            this.thumb.getLayoutParams().height = getActionBarHeight();
            this.FadeBar = false;
        } else if (isTablet() != null) {
            setParralaxHeader();
            this.thumb.getLayoutParams().height = 0;
        }
        if (this.FadeBar != null) {
            this.mToolbar.getBackground().mutate().setAlpha(0);
            Helper.setStatusBarColor(this, getStartColor(this));
            getSupportActionBar().setDisplayShowTitleEnabled(false);
            ThemeUtils.setToolbarContentColor(this.mToolbar, ContextCompat.getColor(this, R.color.white));
        }
    }

    private void setParralaxHeader() {
        if (isTablet()) {
            this.mScrollableHeaderHeight = this.coolblue.getLayoutParams().height;
        } else {
            this.mScrollableHeaderHeight = this.thumb.getLayoutParams().height;
            this.thumb.getViewTreeObserver().addOnGlobalLayoutListener(new C07151());
        }
        ((TrackingScrollView) findViewById(R.id.scroller)).setOnScrollChangedListener(new C10212());
    }

    private void handleScroll(int i) {
        LayoutParams layoutParams;
        int i2;
        int min = !isTablet() ? Math.min(this.mScrollableHeaderHeight, Math.max(0, i)) : i;
        if (isTablet()) {
            layoutParams = (MarginLayoutParams) this.coolblue.getLayoutParams();
            i2 = this.mScrollableHeaderHeight - (min / 2);
        } else {
            layoutParams = (MarginLayoutParams) this.thumb.getLayoutParams();
            i2 = this.mScrollableHeaderHeight - min;
        }
        if (layoutParams.height != i2) {
            layoutParams.height = i2;
            if (isTablet()) {
                this.coolblue.setLayoutParams(layoutParams);
            } else {
                layoutParams.topMargin = min;
                this.thumb.setLayoutParams(layoutParams);
            }
        }
        if (this.FadeBar) {
            min = this.thumb.getHeight() - getSupportActionBar().getHeight();
            i = ((float) Math.min(Math.max(i, 0), min)) / ((float) min);
            min = (int) (255.0f * i);
            if (min != this.latestAlpha) {
                this.mToolbar.getBackground().mutate().setAlpha(min);
                if (ThemeUtils.lightToolbarThemeActive(this)) {
                    ThemeUtils.setToolbarContentColor(this.mToolbar, blendToolbarContentColors(i));
                } else {
                    Helper.setStatusBarColor(this, blendStatusBarColors(i, this));
                }
            }
            this.latestAlpha = min;
        }
    }

    protected void onMenuItemsSet(Menu menu) {
        if (!this.FadeBar) {
            ThemeUtils.tintAllIcons(menu, this);
        }
    }

    private boolean isTablet() {
        return getResources().getBoolean(R.bool.isTablet);
    }

    private int getActionBarHeight() {
        int height = getSupportActionBar().getHeight();
        if (height != 0) {
            return height;
        }
        TypedValue typedValue = new TypedValue();
        if (getTheme().resolveAttribute(16843499, typedValue, true)) {
            height = TypedValue.complexToDimensionPixelSize(typedValue.data, getResources().getDisplayMetrics());
        }
        return height;
    }

    private static int blendStatusBarColors(float f, Context context) {
        return blendColors(ThemeUtils.getPrimaryDarkColor(context), ContextCompat.getColor(context, R.color.black), f);
    }

    private static int blendToolbarContentColors(float f) {
        return blendColors(ViewCompat.MEASURED_STATE_MASK, -1, f);
    }

    private static int blendColors(int i, int i2, float f) {
        float f2 = 1.0f - f;
        return Color.rgb((int) ((((float) Color.red(i)) * f) + (((float) Color.red(i2)) * f2)), (int) ((((float) Color.green(i)) * f) + (((float) Color.green(i2)) * f2)), (int) ((((float) Color.blue(i)) * f) + (((float) Color.blue(i2)) * f2)));
    }

    private static int getStartColor(Context context) {
        if (ThemeUtils.lightToolbarThemeActive(context)) {
            return ThemeUtils.getPrimaryDarkColor(context);
        }
        return ContextCompat.getColor(context, R.color.black);
    }

    public void onPause() {
        super.onPause();
        this.mToolbar.getBackground().mutate().setAlpha(255);
    }

    public void onResume() {
        super.onResume();
        if (this.FadeBar) {
            this.mToolbar.getBackground().mutate().setAlpha(this.latestAlpha);
        }
    }
}
