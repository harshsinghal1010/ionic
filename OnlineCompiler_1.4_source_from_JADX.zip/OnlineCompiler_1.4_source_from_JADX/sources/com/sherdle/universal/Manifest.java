package com.sherdle.universal;

public final class Manifest {

    public static final class permission {
        public static final String C2D_MESSAGE = "com.codeintelligent.onlinecompiler.permission.C2D_MESSAGE";
    }
}
