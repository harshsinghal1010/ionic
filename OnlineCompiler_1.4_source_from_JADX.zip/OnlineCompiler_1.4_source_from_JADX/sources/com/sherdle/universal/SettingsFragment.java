package com.sherdle.universal;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceCategory;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.support.v4.preference.PreferenceFragment;
import android.text.Html;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.gms.oss.licenses.OssLicensesMenuActivity;
import com.sherdle.universal.billing.BillingProcessor;
import com.sherdle.universal.billing.BillingProcessor.IBillingHandler;
import com.sherdle.universal.billing.TransactionDetails;
import com.sherdle.universal.util.Log;

public class SettingsFragment extends PreferenceFragment implements IBillingHandler {
    private static String PRODUCT_ID_BOUGHT = "item_1_bought";
    public static String SHOW_DIALOG = "show_dialog";
    boolean HIDE_RATE_MY_APP = false;
    private BillingProcessor bp;
    private AlertDialog dialog;
    private Preference preferencepurchase;

    /* renamed from: com.sherdle.universal.SettingsFragment$1 */
    class C05601 implements OnPreferenceClickListener {
        C05601() {
        }

        public boolean onPreferenceClick(android.preference.Preference r4) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
            /*
            r3 = this;
            r4 = new java.lang.StringBuilder;
            r4.<init>();
            r0 = "market://details?id=";
            r4.append(r0);
            r0 = com.sherdle.universal.SettingsFragment.this;
            r0 = r0.getActivity();
            r0 = r0.getPackageName();
            r4.append(r0);
            r4 = r4.toString();
            r4 = android.net.Uri.parse(r4);
            r0 = new android.content.Intent;
            r1 = "android.intent.action.VIEW";
            r0.<init>(r1, r4);
            r4 = 1;
            r1 = com.sherdle.universal.SettingsFragment.this;	 Catch:{ ActivityNotFoundException -> 0x002d }
            r1.startActivity(r0);	 Catch:{ ActivityNotFoundException -> 0x002d }
            return r4;
        L_0x002d:
            r0 = com.sherdle.universal.SettingsFragment.this;
            r0 = r0.getActivity();
            r1 = "Could not open Play Store";
            r2 = 0;
            r0 = android.widget.Toast.makeText(r0, r1, r2);
            r0.show();
            return r4;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.SettingsFragment.1.onPreferenceClick(android.preference.Preference):boolean");
        }
    }

    /* renamed from: com.sherdle.universal.SettingsFragment$2 */
    class C05612 implements OnPreferenceClickListener {
        C05612() {
        }

        public boolean onPreferenceClick(Preference preference) {
            preference = new Builder(SettingsFragment.this.getActivity());
            preference.setMessage(Html.fromHtml(SettingsFragment.this.getResources().getString(R.string.about_text)));
            preference.setPositiveButton(SettingsFragment.this.getResources().getString(R.string.ok), null);
            preference.setTitle(SettingsFragment.this.getResources().getString(R.string.about_header));
            preference.show();
            return true;
        }
    }

    /* renamed from: com.sherdle.universal.SettingsFragment$3 */
    class C05623 implements OnPreferenceClickListener {
        C05623() {
        }

        public boolean onPreferenceClick(Preference preference) {
            preference = SettingsFragment.this;
            preference.startActivity(new Intent(preference.getActivity(), OssLicensesMenuActivity.class));
            return true;
        }
    }

    /* renamed from: com.sherdle.universal.SettingsFragment$4 */
    class C05634 implements OnPreferenceClickListener {
        C05634() {
        }

        public boolean onPreferenceClick(Preference preference) {
            SettingsFragment.this.bp.purchase(SettingsFragment.this.getActivity(), SettingsFragment.this.PRODUCT_ID());
            return true;
        }
    }

    /* renamed from: com.sherdle.universal.SettingsFragment$5 */
    class C05645 implements OnClickListener {
        C05645() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            SettingsFragment.this.bp.purchase(SettingsFragment.this.getActivity(), SettingsFragment.this.PRODUCT_ID());
        }
    }

    /* renamed from: com.sherdle.universal.SettingsFragment$6 */
    class C05656 implements OnClickListener {
        public void onClick(DialogInterface dialogInterface, int i) {
        }

        C05656() {
        }
    }

    public void onBillingInitialized() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        addPreferencesFromResource(R.xml.activity_settings);
        findPreference("rate").setOnPreferenceClickListener(new C05601());
        findPreference("about").setOnPreferenceClickListener(new C05612());
        findPreference("licenses").setOnPreferenceClickListener(new C05623());
        ((PreferenceScreen) findPreference("preferenceScreen")).removePreference(findPreference("menuOpenOnStart"));
        this.preferencepurchase = findPreference("purchase");
        bundle = getResources().getString(R.string.google_play_license);
        if (bundle == null || bundle.equals("")) {
            ((PreferenceScreen) findPreference("preferenceScreen")).removePreference((PreferenceCategory) findPreference("billing"));
        } else {
            this.bp = new BillingProcessor(getActivity(), bundle, this);
            this.bp.loadOwnedPurchasesFromGoogle();
            this.preferencepurchase.setOnPreferenceClickListener(new C05634());
            if (getIsPurchased(getActivity()) != null) {
                this.preferencepurchase.setIcon(C0559R.drawable.ic_action_action_done);
            }
        }
        bundle = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        if (!(bundle == null || bundle.length == 0 || bundle[0].equals(SHOW_DIALOG) == null)) {
            bundle = new Builder(getActivity());
            bundle.setPositiveButton(R.string.settings_purchase, new C05645());
            bundle.setNegativeButton(R.string.cancel, new C05656());
            bundle.setTitle(getResources().getString(R.string.dialog_purchase_title));
            bundle.setMessage(getResources().getString(R.string.dialog_purchase));
            this.dialog = bundle.create();
            this.dialog.show();
        }
        if (this.HIDE_RATE_MY_APP != null) {
            ((PreferenceCategory) findPreference("other")).removePreference(findPreference("rate"));
        }
    }

    public void onProductPurchased(String str, TransactionDetails transactionDetails) {
        if (str.equals(PRODUCT_ID()) != null) {
            setIsPurchased(true, getActivity());
            this.preferencepurchase.setIcon(C0559R.drawable.ic_action_action_done);
            Toast.makeText(getActivity(), getResources().getString(R.string.settings_purchase_success), 1).show();
        }
        Log.m161v("INFO", "Purchase purchased");
    }

    public void onBillingError(int i, Throwable th) {
        Toast.makeText(getActivity(), getResources().getString(R.string.settings_purchase_fail), 1).show();
        Log.m161v("INFO", "Error");
    }

    public void onPurchaseHistoryRestored() {
        if (this.bp.isPurchased(PRODUCT_ID())) {
            setIsPurchased(true, getActivity());
            Log.m161v("INFO", "Purchase actually restored");
            this.preferencepurchase.setIcon(C0559R.drawable.ic_action_action_done);
            AlertDialog alertDialog = this.dialog;
            if (alertDialog != null) {
                alertDialog.cancel();
            }
            Toast.makeText(getActivity(), getResources().getString(R.string.settings_restore_purchase_success), 1).show();
        }
        Log.m161v("INFO", "Purchase restored called");
    }

    public void setIsPurchased(boolean z, Context context) {
        context = PreferenceManager.getDefaultSharedPreferences(context).edit();
        context.putBoolean(PRODUCT_ID_BOUGHT, z);
        context.apply();
    }

    public static boolean getIsPurchased(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context).getBoolean(PRODUCT_ID_BOUGHT, false);
    }

    private String PRODUCT_ID() {
        return getResources().getString(R.string.product_id);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        this.bp.handleActivityResult(i, i2, intent);
    }

    public void onDestroy() {
        BillingProcessor billingProcessor = this.bp;
        if (billingProcessor != null) {
            billingProcessor.release();
        }
        super.onDestroy();
    }
}
