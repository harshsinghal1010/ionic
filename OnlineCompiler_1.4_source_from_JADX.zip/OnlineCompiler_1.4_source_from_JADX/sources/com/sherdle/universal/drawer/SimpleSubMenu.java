package com.sherdle.universal.drawer;

import android.view.MenuItem;
import android.view.SubMenu;
import java.util.List;

public class SimpleSubMenu {
    private SimpleMenu parent;
    private SubMenu subMenu;
    private String subMenuTitle;

    public SimpleSubMenu(SimpleMenu simpleMenu, String str) {
        this.parent = simpleMenu;
        this.subMenuTitle = str;
        this.subMenu = simpleMenu.getMenu().addSubMenu(str);
    }

    public MenuItem add(String str, int i, List<NavItem> list) {
        return this.parent.add(this.subMenu, str, i, list);
    }

    public MenuItem add(String str, int i, List<NavItem> list, boolean z) {
        return this.parent.add(this.subMenu, str, i, list, z);
    }

    public String getSubMenuTitle() {
        return this.subMenuTitle;
    }
}
