package com.sherdle.universal.drawer;

import java.util.List;

public interface MenuItemCallback {
    void menuItemClicked(List<NavItem> list, int i, boolean z);
}
