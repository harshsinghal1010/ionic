package com.sherdle.universal.drawer;

import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import com.codeintelligent.onlinecompiler.R;
import java.util.ArrayList;
import java.util.List;

public abstract class SimpleAbstractMenu {
    protected MenuItemCallback callback;
    protected Menu menu;
    protected ArrayList<List<NavItem>> menuContent = new ArrayList();
    protected ArrayList<MenuItem> menuItems = new ArrayList();

    protected MenuItem add(Menu menu, String str, int i, List<NavItem> list) {
        return add(menu, str, i, list, false);
    }

    protected MenuItem add(Menu menu, String str, int i, final List<NavItem> list, final boolean z) {
        menu = menu.add(R.id.main_group, this.menuItems.size(), 0, str).setCheckable(true).setOnMenuItemClickListener(new OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem menuItem) {
                SimpleAbstractMenu.this.callback.menuItemClicked(list, menuItem.getItemId(), z);
                return true;
            }
        });
        if (i != 0) {
            menu.setIcon(i);
        }
        this.menuContent.add(list);
        this.menuItems.add(menu);
        return menu;
    }

    protected Menu getMenu() {
        return this.menu;
    }

    protected MenuItemCallback getMenuItemCallback() {
        return this.callback;
    }

    public List<NavItem> getFirstMenuItem() {
        if (this.menuContent.size() < 1) {
            return null;
        }
        return (List) this.menuContent.get(0);
    }

    public List<MenuItem> getMenuItems() {
        return this.menuItems;
    }
}
