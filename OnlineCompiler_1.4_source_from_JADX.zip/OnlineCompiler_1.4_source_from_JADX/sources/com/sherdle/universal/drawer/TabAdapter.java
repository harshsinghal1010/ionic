package com.sherdle.universal.drawer;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.view.ViewGroup;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.util.Log;
import java.util.List;

public class TabAdapter extends FragmentStatePagerAdapter {
    private List<NavItem> actions;
    private Context context;
    private boolean isRtl = false;
    private Fragment mCurrentFragment;

    public TabAdapter(FragmentManager fragmentManager, List<NavItem> list, Context context) {
        super(fragmentManager);
        this.actions = list;
        this.context = context;
        fragmentManager = null;
        if (VERSION.SDK_INT >= 17) {
            if (context.getResources().getConfiguration().getLayoutDirection() == 1) {
                fragmentManager = true;
            }
            this.isRtl = fragmentManager;
        }
    }

    public Fragment getItem(int i) {
        return fragmentFromAction((NavItem) this.actions.get(i));
    }

    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        super.destroyItem(viewGroup, i, obj);
    }

    public int getCount() {
        return this.actions.size();
    }

    public void setPrimaryItem(ViewGroup viewGroup, int i, Object obj) {
        if (getCurrentFragment() != obj) {
            this.mCurrentFragment = (Fragment) obj;
        }
        super.setPrimaryItem(viewGroup, i, obj);
    }

    public Fragment getCurrentFragment() {
        return this.mCurrentFragment;
    }

    public CharSequence getPageTitle(int i) {
        List list = this.actions;
        if (this.isRtl) {
            i = (list.size() - 1) - i;
        }
        return ((NavItem) list.get(i)).getText(this.context);
    }

    private static Fragment fragmentFromAction(NavItem navItem) {
        try {
            Fragment fragment = (Fragment) navItem.getFragment().newInstance();
            Bundle bundle = new Bundle();
            bundle.putStringArray(MainActivity.FRAGMENT_DATA, navItem.getData());
            fragment.setArguments(bundle);
            return fragment;
        } catch (NavItem navItem2) {
            Log.printStackTrace(navItem2);
            return null;
        } catch (NavItem navItem22) {
            Log.printStackTrace(navItem22);
            return null;
        }
    }

    public List<NavItem> getActions() {
        return this.actions;
    }
}
