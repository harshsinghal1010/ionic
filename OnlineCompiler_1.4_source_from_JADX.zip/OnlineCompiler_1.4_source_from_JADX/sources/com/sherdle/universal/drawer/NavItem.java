package com.sherdle.universal.drawer;

import android.content.Context;
import android.support.v4.app.Fragment;
import java.io.Serializable;

public class NavItem implements Serializable {
    private String categoryImageUrl;
    private String[] mData;
    private Class<? extends Fragment> mFragment;
    private String mText;
    private int mTextResource;
    private int tabIcon;

    public NavItem(int i, Class<? extends Fragment> cls, String[] strArr) {
        this(null, (Class) cls, strArr);
        this.mTextResource = i;
    }

    public NavItem(String str, Class<? extends Fragment> cls, String[] strArr) {
        this.mText = str;
        this.mFragment = cls;
        this.mData = strArr;
    }

    public String getText(Context context) {
        String str = this.mText;
        if (str != null) {
            return str;
        }
        return context.getResources().getString(this.mTextResource);
    }

    public Class<? extends Fragment> getFragment() {
        return this.mFragment;
    }

    public String[] getData() {
        return this.mData;
    }

    public void setCategoryImageUrl(String str) {
        this.categoryImageUrl = str;
    }

    public String getCategoryImageUrl() {
        return this.categoryImageUrl;
    }

    public void setTabIcon(int i) {
        this.tabIcon = i;
    }

    public int getTabIcon() {
        return this.tabIcon;
    }
}
