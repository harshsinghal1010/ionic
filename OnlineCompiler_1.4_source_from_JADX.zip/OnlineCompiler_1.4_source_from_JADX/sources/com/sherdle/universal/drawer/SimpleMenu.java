package com.sherdle.universal.drawer;

import android.view.Menu;
import android.view.MenuItem;
import java.util.List;

public class SimpleMenu extends SimpleAbstractMenu {
    public SimpleMenu(Menu menu, MenuItemCallback menuItemCallback) {
        this.menu = menu;
        this.callback = menuItemCallback;
    }

    public MenuItem add(String str, int i, List<NavItem> list) {
        return add(this.menu, str, i, list);
    }

    public MenuItem add(String str, int i, List<NavItem> list, boolean z) {
        return add(this.menu, str, i, list, z);
    }
}
