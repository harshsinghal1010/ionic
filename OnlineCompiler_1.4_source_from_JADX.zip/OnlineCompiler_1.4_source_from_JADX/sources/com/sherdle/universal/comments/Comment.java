package com.sherdle.universal.comments;

public class Comment {
    public int id;
    public int linesCount;
    public int parentId;
    public String profileUrl;
    public String text;
    public String username;
}
