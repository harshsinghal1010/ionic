package com.sherdle.universal.comments;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.gms.common.data.DataBufferSafeParcelable;
import com.google.firebase.analytics.FirebaseAnalytics.Event;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.providers.soundcloud.api.SoundCloudClient;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import java.util.ArrayList;
import java.util.Collections;
import org.json.JSONArray;
import org.json.JSONObject;

public class CommentsActivity extends AppCompatActivity {
    public static String DATA_ID = "id";
    public static String DATA_PARSEABLE = "parseable";
    public static String DATA_TYPE = "type";
    public static int DISQUS = 7;
    public static int FACEBOOK = 2;
    public static int INSTAGRAM = 1;
    public static int WORDPRESS_JETPACK = 4;
    public static int WORDPRESS_JSON = 5;
    public static int WORDPRESS_REST = 6;
    public static int YOUTUBE = 3;
    ArrayList<Comment> comments;
    ArrayAdapter<Comment> commentsAdapter;
    String id;
    private Toolbar mToolbar;
    int type;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ThemeUtils.setTheme(this);
        setContentView((int) R.layout.activity_comments);
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle(getResources().getString(R.string.comments));
        Helper.admobLoader(this, findViewById(R.id.adView));
        bundle = getIntent().getExtras();
        String string = bundle.getString(DATA_PARSEABLE);
        this.type = bundle.getInt(DATA_TYPE);
        this.id = bundle.getString(DATA_ID);
        this.comments = new ArrayList();
        this.commentsAdapter = new CommentsAdapter(this, this.comments, this.type);
        ListView listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(this.commentsAdapter);
        listView.setEmptyView(findViewById(R.id.empty));
        this.commentsAdapter.notifyDataSetChanged();
        fetchComments(string);
    }

    private void fetchComments(final String str) {
        int i = this.type;
        if (i == INSTAGRAM) {
            ((TextView) findViewById(R.id.empty)).setText(getResources().getString(R.string.loading));
            new Thread(new Runnable() {

                /* renamed from: com.sherdle.universal.comments.CommentsActivity$1$1 */
                class C05731 implements Runnable {
                    C05731() {
                    }

                    public void run() {
                        CommentsActivity.this.commentsAdapter.notifyDataSetChanged();
                        ((TextView) CommentsActivity.this.findViewById(R.id.empty)).setText(CommentsActivity.this.getResources().getString(R.string.no_results));
                    }
                }

                public void run() {
                    try {
                        CommentsActivity.this.comments.clear();
                        JSONArray jSONArray = new JSONObject(str).getJSONArray(DataBufferSafeParcelable.DATA_FIELD);
                        for (int i = 0; i < jSONArray.length(); i++) {
                            JSONObject jSONObject = jSONArray.getJSONObject(i);
                            Comment comment = new Comment();
                            comment.text = jSONObject.getString(MimeTypes.BASE_TYPE_TEXT);
                            comment.username = jSONObject.getString("username");
                            CommentsActivity.this.comments.add(comment);
                        }
                    } catch (Exception e) {
                        Log.printStackTrace(e);
                    }
                    CommentsActivity.this.runOnUiThread(new C05731());
                }
            }).start();
        } else {
            int i2 = 0;
            if (i == FACEBOOK) {
                try {
                    JSONArray jSONArray = new JSONArray(str);
                    while (i2 < jSONArray.length()) {
                        str = jSONArray.getJSONObject(i2);
                        Comment comment = new Comment();
                        comment.text = str.getString(NotificationTable.COLUMN_NAME_MESSAGE);
                        if (str.has("from")) {
                            comment.username = str.getJSONObject("from").getString("name");
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("https://graph.facebook.com/");
                            stringBuilder.append(str.getJSONObject("from").getString(TtmlNode.ATTR_ID));
                            stringBuilder.append("/picture?type=large");
                            comment.profileUrl = stringBuilder.toString();
                        }
                        this.comments.add(comment);
                        i2++;
                    }
                } catch (String str2) {
                    Log.printStackTrace(str2);
                }
            } else if (i == YOUTUBE) {
                str2 = new StringBuilder();
                str2.append("https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&maxResults=100&videoId=");
                str2.append(this.id);
                str2.append("&key=");
                str2.append(getResources().getString(R.string.google_server_key));
                str2 = str2.toString();
                ((TextView) findViewById(R.id.empty)).setText(getResources().getString(R.string.loading));
                new Thread(new Runnable() {

                    /* renamed from: com.sherdle.universal.comments.CommentsActivity$2$1 */
                    class C05751 implements Runnable {
                        C05751() {
                        }

                        public void run() {
                            CommentsActivity.this.commentsAdapter.notifyDataSetChanged();
                            ((TextView) CommentsActivity.this.findViewById(R.id.empty)).setText(CommentsActivity.this.getResources().getString(R.string.no_results));
                        }
                    }

                    public void run() {
                        try {
                            JSONArray jSONArray = Helper.getJSONObjectFromUrl(str2).getJSONArray("items");
                            for (int i = 0; i < jSONArray.length(); i++) {
                                JSONObject jSONObject = jSONArray.getJSONObject(i);
                                if (jSONObject.getJSONObject("snippet").has("topLevelComment")) {
                                    jSONObject = jSONObject.getJSONObject("snippet").getJSONObject("topLevelComment").getJSONObject("snippet");
                                    Comment comment = new Comment();
                                    comment.text = jSONObject.getString("textDisplay");
                                    comment.username = jSONObject.getString("authorDisplayName");
                                    comment.profileUrl = jSONObject.getString("authorProfileImageUrl");
                                    CommentsActivity.this.comments.add(comment);
                                }
                            }
                        } catch (Exception e) {
                            Log.printStackTrace(e);
                        }
                        CommentsActivity.this.runOnUiThread(new C05751());
                    }
                }).start();
            } else if (i == WORDPRESS_JSON) {
                ((TextView) findViewById(R.id.empty)).setText(getResources().getString(R.string.loading));
                new Thread(new Runnable() {

                    /* renamed from: com.sherdle.universal.comments.CommentsActivity$3$1 */
                    class C05771 implements Runnable {
                        C05771() {
                        }

                        public void run() {
                            CommentsActivity.this.commentsAdapter.notifyDataSetChanged();
                            ((TextView) CommentsActivity.this.findViewById(R.id.empty)).setText(CommentsActivity.this.getResources().getString(R.string.no_results));
                        }
                    }

                    public void run() {
                        try {
                            JSONArray jSONArray = new JSONArray(str2);
                            ArrayList arrayList = new ArrayList();
                            for (int i = 0; i < jSONArray.length(); i++) {
                                JSONObject jSONObject = jSONArray.getJSONObject(i);
                                Comment comment = new Comment();
                                comment.text = jSONObject.getString(Param.CONTENT).trim().replace("<p>", "").replace("</p>", "");
                                comment.username = jSONObject.getString("name");
                                comment.id = jSONObject.getInt(TtmlNode.ATTR_ID);
                                comment.parentId = jSONObject.getInt("parent");
                                comment.linesCount = 0;
                                if (comment.parentId == 0) {
                                    CommentsActivity.this.comments.add(comment);
                                } else {
                                    arrayList.add(comment);
                                }
                            }
                            CommentsActivity.this.orderComments(arrayList);
                        } catch (Exception e) {
                            Log.printStackTrace(e);
                        }
                        CommentsActivity.this.runOnUiThread(new C05771());
                    }
                }).start();
            } else if (i == WORDPRESS_REST) {
                ((TextView) findViewById(R.id.empty)).setText(getResources().getString(R.string.loading));
                new Thread(new Runnable() {

                    /* renamed from: com.sherdle.universal.comments.CommentsActivity$4$1 */
                    class C05791 implements Runnable {
                        C05791() {
                        }

                        public void run() {
                            CommentsActivity.this.commentsAdapter.notifyDataSetChanged();
                            ((TextView) CommentsActivity.this.findViewById(R.id.empty)).setText(CommentsActivity.this.getResources().getString(R.string.no_results));
                        }
                    }

                    public void run() {
                        try {
                            JSONArray jSONArrayFromUrl = Helper.getJSONArrayFromUrl(str2);
                            ArrayList arrayList = new ArrayList();
                            for (int i = 0; i < jSONArrayFromUrl.length(); i++) {
                                JSONObject jSONObject = jSONArrayFromUrl.getJSONObject(i);
                                Comment comment = new Comment();
                                comment.text = jSONObject.getJSONObject(Param.CONTENT).getString("rendered").trim().replace("<p>", "").replace("</p>", "");
                                comment.username = jSONObject.getString("author_name");
                                comment.id = jSONObject.getInt(TtmlNode.ATTR_ID);
                                comment.profileUrl = jSONObject.getJSONObject("author_avatar_urls").getString("96");
                                comment.parentId = jSONObject.getInt("parent");
                                comment.linesCount = 0;
                                if (comment.parentId == 0) {
                                    CommentsActivity.this.comments.add(comment);
                                } else {
                                    arrayList.add(comment);
                                }
                            }
                            CommentsActivity.this.orderComments(arrayList);
                        } catch (Exception e) {
                            Log.printStackTrace(e);
                        }
                        CommentsActivity.this.runOnUiThread(new C05791());
                    }
                }).start();
            } else if (i == WORDPRESS_JETPACK) {
                ((TextView) findViewById(R.id.empty)).setText(getResources().getString(R.string.loading));
                new Thread(new Runnable() {

                    /* renamed from: com.sherdle.universal.comments.CommentsActivity$5$1 */
                    class C05811 implements Runnable {
                        C05811() {
                        }

                        public void run() {
                            CommentsActivity.this.commentsAdapter.notifyDataSetChanged();
                            ((TextView) CommentsActivity.this.findViewById(R.id.empty)).setText(CommentsActivity.this.getResources().getString(R.string.no_results));
                        }
                    }

                    public void run() {
                        try {
                            JSONArray jSONArray = Helper.getJSONObjectFromUrl(str2).getJSONArray(SoundCloudClient.COMMENTS);
                            ArrayList arrayList = new ArrayList();
                            for (int i = 0; i < jSONArray.length(); i++) {
                                JSONObject jSONObject = jSONArray.getJSONObject(i);
                                Comment comment = new Comment();
                                comment.text = jSONObject.getString(Param.CONTENT).trim().replace("<p>", "").replace("</p>", "");
                                comment.username = jSONObject.getJSONObject("author").getString(Event.LOGIN);
                                comment.profileUrl = jSONObject.getJSONObject("author").getString("avatar_URL");
                                comment.id = jSONObject.getInt("ID");
                                jSONObject = jSONObject.optJSONObject("parent");
                                if (jSONObject != null) {
                                    comment.parentId = jSONObject.getInt("ID");
                                } else {
                                    comment.parentId = 0;
                                }
                                comment.linesCount = 0;
                                if (comment.parentId == 0) {
                                    CommentsActivity.this.comments.add(comment);
                                } else {
                                    arrayList.add(comment);
                                }
                            }
                            CommentsActivity.this.orderComments(arrayList);
                        } catch (Exception e) {
                            Log.printStackTrace(e);
                        }
                        CommentsActivity.this.runOnUiThread(new C05811());
                    }
                }).start();
            } else if (i == DISQUS) {
                str2 = str2.split(";");
                HolderActivity.startWebViewActivity(this, str2[0], false, true, getHtmlComment(str2[2].replace("%d", this.id), str2[1]));
                finish();
            }
        }
        this.commentsAdapter.notifyDataSetChanged();
    }

    private int checkIfContains(int i) {
        for (int i2 = 0; i2 < this.comments.size(); i2++) {
            if (((Comment) this.comments.get(i2)).id == i) {
                return i2;
            }
        }
        return -1;
    }

    private void orderComments(ArrayList<Comment> arrayList) {
        Collections.reverse(arrayList);
        do {
            for (int i = 0; i < arrayList.size(); i++) {
                int checkIfContains = checkIfContains(((Comment) arrayList.get(i)).parentId);
                if (checkIfContains >= 0) {
                    ((Comment) arrayList.get(i)).linesCount = ((Comment) this.comments.get(checkIfContains)).linesCount + 1;
                    this.comments.add(checkIfContains + 1, arrayList.get(i));
                    arrayList.remove(i);
                }
            }
        } while (arrayList.size() > 0);
    }

    public String getHtmlComment(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"></head><body><div id='disqus_thread'></div></body><script type='text/javascript'>var disqus_identifier = '");
        stringBuilder.append(str);
        stringBuilder.append("';var disqus_shortname = '");
        stringBuilder.append(str2);
        stringBuilder.append("'; (function() { var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;dsq.src = '/embed.js';(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq); })();</script></html>");
        return stringBuilder.toString();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finish();
        return true;
    }
}
