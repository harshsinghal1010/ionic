package com.sherdle.universal.comments;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.squareup.picasso.Picasso;
import java.util.List;

public class CommentsAdapter extends ArrayAdapter<Comment> {
    private Context context;
    private int type;

    public class CommentViewHolder {
        ImageView ivProfilePhoto;
        TextView tvComment;
        TextView tvUsername;
    }

    public CommentsAdapter(Context context, List<Comment> list, int i) {
        super(context, 0, list);
        this.context = context;
        this.type = i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        Comment comment = (Comment) getItem(i);
        int i2 = 0;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.activity_comments_row, viewGroup, false);
            viewGroup = new CommentViewHolder();
            viewGroup.ivProfilePhoto = (ImageView) view.findViewById(R.id.ivProfilePhoto);
            viewGroup.tvUsername = (TextView) view.findViewById(R.id.tvUsername);
            viewGroup.tvComment = (TextView) view.findViewById(R.id.tvComment);
            view.setTag(viewGroup);
        } else {
            viewGroup = (CommentViewHolder) view.getTag();
        }
        viewGroup.ivProfilePhoto.setImageDrawable(null);
        if (comment.profileUrl != null) {
            viewGroup.ivProfilePhoto.setVisibility(0);
            Picasso.get().load(comment.profileUrl).into(viewGroup.ivProfilePhoto);
        } else {
            viewGroup.ivProfilePhoto.setVisibility(8);
        }
        if (comment.username != null) {
            viewGroup.tvUsername.setText(comment.username);
            viewGroup.tvUsername.setVisibility(0);
        } else {
            viewGroup.tvUsername.setVisibility(8);
        }
        viewGroup.tvComment.setText(Html.fromHtml(comment.text.replaceAll("<img.+?>", "")));
        if (this.type == CommentsActivity.WORDPRESS_JETPACK || this.type == CommentsActivity.WORDPRESS_JSON || this.type == CommentsActivity.WORDPRESS_REST) {
            LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.lineView);
            linearLayout.removeAllViews();
            while (i2 < comment.linesCount) {
                linearLayout.addView(View.inflate(this.context, R.layout.activity_comment_sub, null));
                i2++;
            }
        }
        return view;
    }
}
