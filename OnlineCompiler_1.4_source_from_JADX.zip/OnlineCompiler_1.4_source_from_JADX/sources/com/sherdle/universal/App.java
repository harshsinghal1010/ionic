package com.sherdle.universal;

import android.content.Intent;
import android.support.multidex.MultiDexApplication;
import android.text.TextUtils;
import com.codeintelligent.onlinecompiler.R;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions.Builder;
import com.onesignal.OSNotificationOpenResult;
import com.onesignal.OneSignal;
import com.onesignal.OneSignal.NotificationOpenedHandler;
import org.json.JSONObject;

public class App extends MultiDexApplication {

    private class NotificationHandler implements NotificationOpenedHandler {
        private NotificationHandler() {
        }

        public void notificationOpened(OSNotificationOpenResult oSNotificationOpenResult) {
            try {
                JSONObject jSONObject = oSNotificationOpenResult.notification.payload.additionalData;
                String str = null;
                if (jSONObject != null) {
                    str = jSONObject.optString("url", null);
                }
                String str2 = oSNotificationOpenResult.notification.payload.launchURL;
                if (str == null) {
                    if (str2 == null) {
                        if (oSNotificationOpenResult.notification.isAppInFocus == null) {
                            oSNotificationOpenResult = new Intent(App.this, MainActivity.class);
                            oSNotificationOpenResult.addFlags(268566528);
                            App.this.startActivity(oSNotificationOpenResult);
                            return;
                        }
                        return;
                    }
                }
                if (str != null) {
                    HolderActivity.startWebViewActivity(App.this, str, false, false, null, 268566528);
                } else {
                    HolderActivity.startWebViewActivity(App.this, str2, true, false, null, 268566528);
                }
            } catch (OSNotificationOpenResult oSNotificationOpenResult2) {
                oSNotificationOpenResult2.printStackTrace();
            }
        }
    }

    public void onCreate() {
        super.onCreate();
        FirebaseApp.initializeApp(this, new Builder().setApiKey("<VAL>").setApplicationId("<VAL>").build());
        if (!TextUtils.isEmpty(getString(R.string.onesignal_app_id))) {
            OneSignal.init(this, getString(R.string.onesignal_google_project_number), getString(R.string.onesignal_app_id), new NotificationHandler());
        }
    }
}
