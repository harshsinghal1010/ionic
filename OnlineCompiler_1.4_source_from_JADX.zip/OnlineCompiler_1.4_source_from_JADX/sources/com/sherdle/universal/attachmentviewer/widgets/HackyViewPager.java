package com.sherdle.universal.attachmentviewer.widgets;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

public class HackyViewPager extends ViewPager {
    private boolean isLocked = null;

    public HackyViewPager(Context context) {
        super(context);
    }

    public HackyViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        try {
            return super.onInterceptTouchEvent(motionEvent);
        } catch (MotionEvent motionEvent2) {
            motionEvent2.printStackTrace();
            return null;
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        try {
            return super.onTouchEvent(motionEvent);
        } catch (MotionEvent motionEvent2) {
            motionEvent2.printStackTrace();
            return null;
        }
    }

    public void setLocked(boolean z) {
        this.isLocked = z;
    }

    public boolean isLocked() {
        return this.isLocked;
    }
}
