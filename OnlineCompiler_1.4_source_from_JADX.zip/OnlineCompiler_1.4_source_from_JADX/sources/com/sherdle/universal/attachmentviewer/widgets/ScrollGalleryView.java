package com.sherdle.universal.attachmentviewer.widgets;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.media.ThumbnailUtils;
import android.os.Build.VERSION;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v4.view.ViewPager.SimpleOnPageChangeListener;
import android.util.AttributeSet;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.attachmentviewer.ScreenSlidePagerAdapter;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader.SuccessCallback;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ScrollGalleryView extends LinearLayout {
    private static float SELECTED_ALPHA = 0.5f;
    private Context context;
    private Point displayProps;
    private FragmentManager fragmentManager;
    private HorizontalScrollView horizontalScrollView;
    private List<MediaLoader> mListOfMedia;
    private PagerAdapter pagerAdapter;
    private final OnClickListener thumbnailOnClickListener = new C05712();
    private int thumbnailSize;
    private LinearLayout thumbnailsContainer;
    private boolean thumbnailsHiddenEnabled;
    private ViewPager viewPager;
    private final SimpleOnPageChangeListener viewPagerChangeListener = new C10981();
    private boolean zoomEnabled;

    /* renamed from: com.sherdle.universal.attachmentviewer.widgets.ScrollGalleryView$2 */
    class C05712 implements OnClickListener {
        C05712() {
        }

        public void onClick(View view) {
            ScrollGalleryView.this.scroll(view);
            ScrollGalleryView.this.viewPager.setCurrentItem(((Integer) view.getTag()).intValue(), true);
        }
    }

    /* renamed from: com.sherdle.universal.attachmentviewer.widgets.ScrollGalleryView$4 */
    class C09794 implements SuccessCallback {
        final /* synthetic */ ImageView val$thumbnail;

        C09794(ImageView imageView) {
            this.val$thumbnail = imageView;
        }

        public void onSuccess() {
            this.val$thumbnail.setScaleType(ScaleType.FIT_CENTER);
        }
    }

    /* renamed from: com.sherdle.universal.attachmentviewer.widgets.ScrollGalleryView$1 */
    class C10981 extends SimpleOnPageChangeListener {
        C10981() {
        }

        public void onPageSelected(int i) {
            ScrollGalleryView scrollGalleryView = ScrollGalleryView.this;
            scrollGalleryView.scroll(scrollGalleryView.thumbnailsContainer.getChildAt(i));
        }
    }

    public com.sherdle.universal.attachmentviewer.widgets.ScrollGalleryView addMedia(java.util.List<com.sherdle.universal.attachmentviewer.loader.MediaLoader> r5) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:9:0x0046 in {4, 6, 8} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r4 = this;
        if (r5 == 0) goto L_0x003e;
    L_0x0002:
        r5 = r5.iterator();
    L_0x0006:
        r0 = r5.hasNext();
        if (r0 == 0) goto L_0x0031;
    L_0x000c:
        r0 = r5.next();
        r0 = (com.sherdle.universal.attachmentviewer.loader.MediaLoader) r0;
        r1 = r4.mListOfMedia;
        r1.add(r0);
        r1 = r4.getDefaultThumbnail();
        r1 = r4.addThumbnail(r1);
        r2 = r4.getContext();
        r3 = new com.sherdle.universal.attachmentviewer.widgets.ScrollGalleryView$4;
        r3.<init>(r1);
        r0.loadThumbnail(r2, r1, r3);
        r0 = r4.pagerAdapter;
        r0.notifyDataSetChanged();
        goto L_0x0006;
    L_0x0031:
        r5 = r4.thumbnailsContainer;
        r0 = 0;
        r5 = r5.getChildAt(r0);
        r0 = SELECTED_ALPHA;
        r5.setAlpha(r0);
        return r4;
    L_0x003e:
        r5 = new java.lang.NullPointerException;
        r0 = "Infos may not be null!";
        r5.<init>(r0);
        throw r5;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.attachmentviewer.widgets.ScrollGalleryView.addMedia(java.util.List):com.sherdle.universal.attachmentviewer.widgets.ScrollGalleryView");
    }

    public ScrollGalleryView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.context = context;
        this.mListOfMedia = new ArrayList();
        setOrientation(1);
        this.displayProps = getDisplaySize();
        LayoutInflater.from(context).inflate(R.layout.activity_attachment_gallery_view, this, true);
        this.horizontalScrollView = (HorizontalScrollView) findViewById(R.id.thumbnails_scroll_view);
        this.thumbnailsContainer = (LinearLayout) findViewById(R.id.thumbnails_container);
        this.thumbnailsContainer.setPadding(this.displayProps.x / 2, 0, this.displayProps.x / 2, 0);
    }

    public ScrollGalleryView setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
        initializeViewPager();
        return this;
    }

    public ViewPager getViewPager() {
        return this.viewPager;
    }

    public void addOnPageChangeListener(final OnPageChangeListener onPageChangeListener) {
        this.viewPager.clearOnPageChangeListeners();
        this.viewPager.addOnPageChangeListener(new OnPageChangeListener() {
            public void onPageScrolled(int i, float f, int i2) {
                onPageChangeListener.onPageScrolled(i, f, i2);
            }

            public void onPageSelected(int i) {
                ScrollGalleryView scrollGalleryView = ScrollGalleryView.this;
                scrollGalleryView.scroll(scrollGalleryView.thumbnailsContainer.getChildAt(i));
                onPageChangeListener.onPageSelected(i);
            }

            public void onPageScrollStateChanged(int i) {
                onPageChangeListener.onPageScrollStateChanged(i);
            }
        });
    }

    public ScrollGalleryView addMedia(MediaLoader mediaLoader) {
        if (mediaLoader != null) {
            return addMedia(Collections.singletonList(mediaLoader));
        }
        throw new NullPointerException("Infos may not be null!");
    }

    public ScrollGalleryView setCurrentItem(int i) {
        this.viewPager.setCurrentItem(i, false);
        return this;
    }

    public ScrollGalleryView setThumbnailSize(int i) {
        this.thumbnailSize = i;
        return this;
    }

    public ScrollGalleryView setZoom(boolean z) {
        this.zoomEnabled = z;
        return this;
    }

    public ScrollGalleryView hideThumbnails(boolean z) {
        this.thumbnailsHiddenEnabled = z;
        if (z) {
            this.horizontalScrollView.setVisibility(8);
        } else {
            this.horizontalScrollView.setVisibility(0);
        }
        return this;
    }

    public boolean thumbnailsHidden() {
        return this.thumbnailsHiddenEnabled;
    }

    private Bitmap getDefaultThumbnail() {
        return ((BitmapDrawable) getContext().getResources().getDrawable(R.drawable.placeholder)).getBitmap();
    }

    private Point getDisplaySize() {
        Display defaultDisplay = ((WindowManager) this.context.getSystemService("window")).getDefaultDisplay();
        Point point = new Point();
        if (VERSION.SDK_INT >= 13) {
            defaultDisplay.getSize(point);
        } else {
            point.set(defaultDisplay.getWidth(), defaultDisplay.getHeight());
        }
        return point;
    }

    private ImageView addThumbnail(Bitmap bitmap) {
        int i = this.thumbnailSize;
        LayoutParams layoutParams = new LayoutParams(i, i);
        layoutParams.setMargins(10, 10, 10, 10);
        bitmap = createThumbnailView(layoutParams, createThumbnail(bitmap));
        this.thumbnailsContainer.addView(bitmap);
        return bitmap;
    }

    private ImageView createThumbnailView(LayoutParams layoutParams, Bitmap bitmap) {
        ImageView imageView = new ImageView(this.context);
        imageView.setLayoutParams(layoutParams);
        imageView.setImageBitmap(bitmap);
        imageView.setTag(Integer.valueOf(this.mListOfMedia.size() - 1));
        imageView.setOnClickListener(this.thumbnailOnClickListener);
        imageView.setScaleType(ScaleType.CENTER);
        return imageView;
    }

    private Bitmap createThumbnail(Bitmap bitmap) {
        int i = this.thumbnailSize;
        return ThumbnailUtils.extractThumbnail(bitmap, i, i);
    }

    private void initializeViewPager() {
        this.viewPager = (HackyViewPager) findViewById(R.id.viewPager);
        this.pagerAdapter = new ScreenSlidePagerAdapter(this.fragmentManager, this.mListOfMedia, this.zoomEnabled);
        this.viewPager.setAdapter(this.pagerAdapter);
        this.viewPager.addOnPageChangeListener(this.viewPagerChangeListener);
    }

    private void scroll(View view) {
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        int i = 0;
        this.horizontalScrollView.smoothScrollBy(-((this.displayProps.x / 2) - (iArr[0] + (this.thumbnailSize / 2))), 0);
        while (i < this.mListOfMedia.size()) {
            this.thumbnailsContainer.getChildAt(i).setAlpha(1.0f);
            i++;
        }
        view.setAlpha(SELECTED_ALPHA);
    }

    private int calculateInSampleSize(int i, int i2, int i3, int i4) {
        int i5 = 1;
        while (true) {
            if (i / i5 <= i3) {
                if (i2 / i5 <= i4) {
                    return i5;
                }
            }
            i5 *= 2;
        }
    }
}
