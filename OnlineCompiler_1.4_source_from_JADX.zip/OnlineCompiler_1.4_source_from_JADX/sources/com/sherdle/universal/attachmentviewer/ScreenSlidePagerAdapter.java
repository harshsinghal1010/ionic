package com.sherdle.universal.attachmentviewer;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader;
import com.sherdle.universal.attachmentviewer.ui.AttachmentFragment;
import java.util.List;

public class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter {
    private boolean isZoomable = null;
    private List<MediaLoader> mListOfMedia;

    public ScreenSlidePagerAdapter(FragmentManager fragmentManager, List<MediaLoader> list, boolean z) {
        super(fragmentManager);
        this.mListOfMedia = list;
        this.isZoomable = z;
    }

    public Fragment getItem(int i) {
        return i < this.mListOfMedia.size() ? loadImageFragment((MediaLoader) this.mListOfMedia.get(i)) : 0;
    }

    private Fragment loadImageFragment(MediaLoader mediaLoader) {
        Fragment attachmentFragment = new AttachmentFragment();
        attachmentFragment.setMediaLoader(mediaLoader);
        mediaLoader = new Bundle();
        mediaLoader.putBoolean(AttachmentFragment.ZOOM, this.isZoomable);
        attachmentFragment.setArguments(mediaLoader);
        return attachmentFragment;
    }

    public int getCount() {
        return this.mListOfMedia.size();
    }
}
