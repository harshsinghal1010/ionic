package com.sherdle.universal.attachmentviewer.model;

import java.io.Serializable;

public abstract class Attachment implements Serializable {
    public abstract String getDescription();
}
