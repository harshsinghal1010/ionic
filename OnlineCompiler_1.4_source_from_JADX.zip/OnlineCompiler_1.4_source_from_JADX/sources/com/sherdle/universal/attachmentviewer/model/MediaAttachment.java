package com.sherdle.universal.attachmentviewer.model;

public class MediaAttachment extends Attachment {
    public static String MIME_PATTERN_AUDIO = "audio/";
    public static String MIME_PATTERN_IMAGE = "image/";
    public static String MIME_PATTERN_VID = "video/";
    private String album;
    private String artist;
    private String description;
    private long duration;
    private String mime;
    private String thumburl;
    private String url;

    public MediaAttachment(String str, String str2, String str3, String str4) {
        if (!(str4 == null || str4.equals(""))) {
            this.description = str4;
        }
        this.mime = str2;
        this.url = str;
        this.thumburl = str3;
    }

    public static MediaAttachment withImage(String str) {
        return new MediaAttachment(str, MIME_PATTERN_IMAGE, null, null);
    }

    public static MediaAttachment withVideo(String str) {
        return new MediaAttachment(str, MIME_PATTERN_VID, null, null);
    }

    public static MediaAttachment withAudio(String str) {
        return new MediaAttachment(str, MIME_PATTERN_AUDIO, null, null);
    }

    public String getUrl() {
        return this.url;
    }

    public String getThumbnailUrl() {
        return this.thumburl;
    }

    public String getMime() {
        return this.mime;
    }

    public void setAudioMeta(String str, String str2, long j) {
        this.artist = str;
        this.album = str2;
        this.duration = j;
    }

    public String getArtist() {
        return this.artist;
    }

    public String getAlbum() {
        return this.album;
    }

    public long getDuration() {
        return this.duration;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String str) {
        this.description = str;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Url: ");
        stringBuilder.append(this.url);
        stringBuilder.append(" Mime: ");
        stringBuilder.append(this.mime);
        return stringBuilder.toString();
    }
}
