package com.sherdle.universal.attachmentviewer.loader;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.C0559R;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader.SuccessCallback;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentFragment;
import com.sherdle.universal.util.Helper;

public class DefaultFileLoader extends MediaLoader {
    public boolean isImage() {
        return false;
    }

    public DefaultFileLoader(MediaAttachment mediaAttachment) {
        super(mediaAttachment);
    }

    public void loadMedia(final AttachmentFragment attachmentFragment, ImageView imageView, View view, SuccessCallback successCallback) {
        imageView = ((MediaAttachment) getAttachment()).getUrl();
        view.findViewById(R.id.playButton).setVisibility(0);
        view.findViewById(R.id.playButton).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Helper.download(attachmentFragment.getActivity(), imageView);
            }
        });
        ((ImageView) view.findViewById(R.id.playButton)).setImageResource(C0559R.drawable.ic_download);
        successCallback.onSuccess();
    }

    public void loadThumbnail(Context context, ImageView imageView, SuccessCallback successCallback) {
        imageView.setImageResource(C0559R.drawable.ic_download);
        successCallback.onSuccess();
    }
}
