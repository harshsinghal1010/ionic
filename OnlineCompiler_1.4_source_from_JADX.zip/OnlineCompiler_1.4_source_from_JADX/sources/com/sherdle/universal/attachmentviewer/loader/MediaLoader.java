package com.sherdle.universal.attachmentviewer.loader;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import com.sherdle.universal.attachmentviewer.model.Attachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentFragment;
import java.io.Serializable;

public abstract class MediaLoader implements Serializable {
    private Attachment attachment;

    public interface SuccessCallback {
        void onSuccess();
    }

    public abstract boolean isImage();

    public abstract void loadMedia(AttachmentFragment attachmentFragment, ImageView imageView, View view, SuccessCallback successCallback);

    public abstract void loadThumbnail(Context context, ImageView imageView, SuccessCallback successCallback);

    public MediaLoader(Attachment attachment) {
        this.attachment = attachment;
    }

    public Attachment getAttachment() {
        return this.attachment;
    }
}
