package com.sherdle.universal.attachmentviewer.loader;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.C0559R;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader.SuccessCallback;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentFragment;
import com.sherdle.universal.attachmentviewer.ui.AudioPlayerActivity;

public class DefaultAudioLoader extends MediaLoader {
    public boolean isImage() {
        return false;
    }

    public DefaultAudioLoader(MediaAttachment mediaAttachment) {
        super(mediaAttachment);
    }

    public void loadMedia(final AttachmentFragment attachmentFragment, ImageView imageView, View view, SuccessCallback successCallback) {
        imageView.setImageResource(R.drawable.placeholder_coverart);
        OnClickListener c05661 = new OnClickListener() {
            public void onClick(View view) {
                DefaultAudioLoader.this.playAudio(attachmentFragment.getContext(), ((MediaAttachment) DefaultAudioLoader.this.getAttachment()).getUrl(), DefaultAudioLoader.this.getAttachment().getDescription() != null ? DefaultAudioLoader.this.getAttachment().getDescription() : "");
            }
        };
        imageView.setOnClickListener(c05661);
        view.findViewById(R.id.playButton).setVisibility(0);
        view.findViewById(R.id.playButton).setOnClickListener(c05661);
        successCallback.onSuccess();
    }

    public void loadThumbnail(Context context, ImageView imageView, SuccessCallback successCallback) {
        imageView.setImageResource(C0559R.drawable.ic_album_white);
        successCallback.onSuccess();
    }

    private void playAudio(Context context, String str, String str2) {
        AudioPlayerActivity.startActivity(context, str, str2);
    }
}
