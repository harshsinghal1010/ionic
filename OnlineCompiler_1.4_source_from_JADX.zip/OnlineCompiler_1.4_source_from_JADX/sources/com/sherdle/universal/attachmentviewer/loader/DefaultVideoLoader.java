package com.sherdle.universal.attachmentviewer.loader;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.C0559R;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader.SuccessCallback;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentFragment;
import com.sherdle.universal.attachmentviewer.ui.VideoPlayerActivity;

public class DefaultVideoLoader extends MediaLoader {

    private class BitmapOperation extends AsyncTask<String, Void, Bitmap> {
        private ImageView imageView;

        protected android.graphics.Bitmap doInBackground(java.lang.String... r6) {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:25:0x003a in {6, 7, 8, 9, 11, 13, 15, 19, 20, 21, 23, 24} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
            /*
            r5 = this;
            r0 = 0;
            r1 = new android.media.MediaMetadataRetriever;	 Catch:{ Exception -> 0x002a, all -> 0x0027 }
            r1.<init>();	 Catch:{ Exception -> 0x002a, all -> 0x0027 }
            r2 = android.os.Build.VERSION.SDK_INT;	 Catch:{ Exception -> 0x0025 }
            r3 = 14;	 Catch:{ Exception -> 0x0025 }
            r4 = 0;	 Catch:{ Exception -> 0x0025 }
            if (r2 < r3) goto L_0x0018;	 Catch:{ Exception -> 0x0025 }
        L_0x000d:
            r6 = r6[r4];	 Catch:{ Exception -> 0x0025 }
            r2 = new java.util.HashMap;	 Catch:{ Exception -> 0x0025 }
            r2.<init>();	 Catch:{ Exception -> 0x0025 }
            r1.setDataSource(r6, r2);	 Catch:{ Exception -> 0x0025 }
            goto L_0x001d;	 Catch:{ Exception -> 0x0025 }
        L_0x0018:
            r6 = r6[r4];	 Catch:{ Exception -> 0x0025 }
            r1.setDataSource(r6);	 Catch:{ Exception -> 0x0025 }
        L_0x001d:
            r0 = r1.getFrameAtTime();	 Catch:{ Exception -> 0x0025 }
        L_0x0021:
            r1.release();
            goto L_0x0032;
        L_0x0025:
            r6 = move-exception;
            goto L_0x002c;
        L_0x0027:
            r6 = move-exception;
            r1 = r0;
            goto L_0x0034;
        L_0x002a:
            r6 = move-exception;
            r1 = r0;
        L_0x002c:
            r6.printStackTrace();	 Catch:{ all -> 0x0033 }
            if (r1 == 0) goto L_0x0032;
        L_0x0031:
            goto L_0x0021;
        L_0x0032:
            return r0;
        L_0x0033:
            r6 = move-exception;
        L_0x0034:
            if (r1 == 0) goto L_0x0039;
        L_0x0036:
            r1.release();
        L_0x0039:
            throw r6;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.attachmentviewer.loader.DefaultVideoLoader.BitmapOperation.doInBackground(java.lang.String[]):android.graphics.Bitmap");
        }

        protected void onPreExecute() {
        }

        protected void onProgressUpdate(Void... voidArr) {
        }

        public BitmapOperation(ImageView imageView) {
            this.imageView = imageView;
        }

        protected void onPostExecute(Bitmap bitmap) {
            this.imageView.setImageBitmap(bitmap);
        }
    }

    public boolean isImage() {
        return false;
    }

    public DefaultVideoLoader(MediaAttachment mediaAttachment) {
        super(mediaAttachment);
    }

    public void loadMedia(final AttachmentFragment attachmentFragment, ImageView imageView, View view, SuccessCallback successCallback) {
        new BitmapOperation(imageView).execute(new String[]{((MediaAttachment) getAttachment()).getUrl()});
        OnClickListener c05681 = new OnClickListener() {
            public void onClick(View view) {
                VideoPlayerActivity.startActivity(attachmentFragment.getContext(), ((MediaAttachment) DefaultVideoLoader.this.getAttachment()).getUrl());
            }
        };
        imageView.setImageResource(R.drawable.placeholder_video);
        imageView.setOnClickListener(c05681);
        view.findViewById(R.id.playButton).setVisibility(0);
        view.findViewById(R.id.playButton).setOnClickListener(c05681);
        successCallback.onSuccess();
    }

    public void loadThumbnail(Context context, ImageView imageView, SuccessCallback successCallback) {
        imageView.setImageResource(C0559R.drawable.ic_action_play);
        successCallback.onSuccess();
    }
}
