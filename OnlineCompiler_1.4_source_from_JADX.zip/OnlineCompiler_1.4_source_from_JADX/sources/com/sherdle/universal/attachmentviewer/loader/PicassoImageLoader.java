package com.sherdle.universal.attachmentviewer.loader;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader.SuccessCallback;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentFragment;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

public class PicassoImageLoader extends MediaLoader {

    private static class ImageCallback implements Callback {
        private final SuccessCallback callback;

        public void onError(Exception exception) {
        }

        public ImageCallback(SuccessCallback successCallback) {
            this.callback = successCallback;
        }

        public void onSuccess() {
            this.callback.onSuccess();
        }
    }

    public boolean isImage() {
        return true;
    }

    public PicassoImageLoader(MediaAttachment mediaAttachment) {
        super(mediaAttachment);
    }

    public void loadMedia(AttachmentFragment attachmentFragment, ImageView imageView, View view, SuccessCallback successCallback) {
        Picasso.get().load(((MediaAttachment) getAttachment()).getUrl()).into(imageView, new ImageCallback(successCallback));
    }

    public void loadThumbnail(Context context, ImageView imageView, SuccessCallback successCallback) {
        MediaAttachment mediaAttachment = (MediaAttachment) getAttachment();
        Picasso.get().load(mediaAttachment.getThumbnailUrl() == null ? mediaAttachment.getThumbnailUrl() : mediaAttachment.getUrl()).resize(100, 100).placeholder((int) R.drawable.placeholder).centerInside().into(imageView, new ImageCallback(successCallback));
    }
}
