package com.sherdle.universal.attachmentviewer.loader;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.widget.ImageView;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader.SuccessCallback;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentFragment;

public class DefaultImageLoader extends MediaLoader {
    private Bitmap mBitmap;
    private int mId;

    public boolean isImage() {
        return true;
    }

    public DefaultImageLoader(MediaAttachment mediaAttachment, int i) {
        super(mediaAttachment);
        this.mId = i;
    }

    public DefaultImageLoader(MediaAttachment mediaAttachment, Bitmap bitmap) {
        super(mediaAttachment);
        this.mBitmap = bitmap;
    }

    public void loadMedia(AttachmentFragment attachmentFragment, ImageView imageView, View view, SuccessCallback successCallback) {
        imageView.setImageBitmap(this.mBitmap);
        if (successCallback != null) {
            successCallback.onSuccess();
        }
    }

    public void loadThumbnail(Context context, ImageView imageView, SuccessCallback successCallback) {
        loadBitmap(context);
        imageView.setImageBitmap(this.mBitmap);
        if (successCallback != null) {
            successCallback.onSuccess();
        }
    }

    private void loadBitmap(Context context) {
        if (this.mBitmap == null) {
            this.mBitmap = ((BitmapDrawable) context.getResources().getDrawable(this.mId)).getBitmap();
        }
    }
}
