package com.sherdle.universal.attachmentviewer.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;
import com.codeintelligent.onlinecompiler.R;

public class VideoPlayerActivity extends Activity {
    private static String URL = "url";

    public static void startActivity(Context context, String str) {
        Intent intent = new Intent(context, VideoPlayerActivity.class);
        intent.putExtra(URL, str);
        context.startActivity(intent);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        bundle = getIntent().getExtras().getString(URL);
        setContentView(R.layout.activity_attachment_video);
        final VideoView videoView = (VideoView) findViewById(R.id.videoView);
        videoView.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                VideoPlayerActivity.this.findViewById(R.id.videoProgress).setVisibility(8);
                videoView.requestFocus();
                mediaPlayer = new MediaController(VideoPlayerActivity.this);
                mediaPlayer.setAnchorView(videoView);
                videoView.setMediaController(mediaPlayer);
                videoView.start();
            }
        });
        videoView.setVideoURI(Uri.parse(bundle));
    }
}
