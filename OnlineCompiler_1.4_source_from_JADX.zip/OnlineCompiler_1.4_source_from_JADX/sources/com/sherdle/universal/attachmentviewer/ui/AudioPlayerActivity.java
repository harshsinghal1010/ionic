package com.sherdle.universal.attachmentviewer.ui;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.MediaController;
import android.widget.MediaController.MediaPlayerControl;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.attachmentviewer.MusicService;
import com.sherdle.universal.attachmentviewer.MusicService.MusicServiceBinder;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;

public class AudioPlayerActivity extends AppCompatActivity implements MediaPlayerControl {
    public static final String SERVICE = "service";
    private static String TAG = "PlayQueueActivity";
    static final int UPDATE_INTERVAL = 250;
    public static final String URL = "url";
    private MusicService MusicService;
    private Intent MusicServiceIntent;
    private Handler handler = new Handler();
    private MediaController mediaController;
    private ServiceConnection serviceConnection = new MusicServiceServiceConnection();
    private String title = "";
    private String url = "";

    /* renamed from: com.sherdle.universal.attachmentviewer.ui.AudioPlayerActivity$1 */
    class C05691 implements Runnable {
        C05691() {
        }

        public void run() {
            AudioPlayerActivity.this.mediaController.setEnabled(true);
            AudioPlayerActivity.this.mediaController.show();
        }
    }

    private final class MusicServiceServiceConnection implements ServiceConnection {
        private MusicServiceServiceConnection() {
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            Log.m157d(AudioPlayerActivity.TAG, "MusicServiceServiceConnection: Service connected");
            AudioPlayerActivity.this.MusicService = ((MusicServiceBinder) iBinder).getService();
            componentName = AudioPlayerActivity.this;
            componentName.startService(componentName.MusicServiceIntent);
            if (AudioPlayerActivity.this.MusicService.getMediaPlayer() == null && AudioPlayerActivity.this.url != null) {
                AudioPlayerActivity.this.MusicService.play(AudioPlayerActivity.this.url, AudioPlayerActivity.this.title);
            } else if (AudioPlayerActivity.this.url != null && AudioPlayerActivity.this.url.equals(AudioPlayerActivity.this.MusicService.getUrl()) == null) {
                AudioPlayerActivity.this.MusicService.play(AudioPlayerActivity.this.url, AudioPlayerActivity.this.title);
            }
            AudioPlayerActivity.this.connectMediaControl();
        }

        public void onServiceDisconnected(ComponentName componentName) {
            Log.m157d(AudioPlayerActivity.TAG, "MusicServiceServiceConnection: Service disconnected");
            AudioPlayerActivity.this.MusicService = null;
        }
    }

    public boolean canPause() {
        return true;
    }

    public boolean canSeekBackward() {
        return true;
    }

    public boolean canSeekForward() {
        return true;
    }

    public int getAudioSessionId() {
        return 0;
    }

    public int getBufferPercentage() {
        return 0;
    }

    public static void startActivity(Context context, String str, String str2) {
        Intent intent = new Intent(context, AudioPlayerActivity.class);
        intent.putExtra("url", str);
        intent.putExtra("service", str2);
        context.startActivity(intent);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ThemeUtils.setTheme(this);
        setContentView((int) R.layout.activity_audio);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar_actionbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.mediaController = new MediaController(this);
        this.url = getIntent().getStringExtra("url");
        this.title = getIntent().getStringExtra("service");
        ((TextView) findViewById(R.id.now_playing_text)).setText(this.title);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            finish();
            return true;
        } else if (itemId != R.id.action_download) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            Helper.download(this, this.url);
            return true;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_download, menu);
        ThemeUtils.tintAllIcons(menu, this);
        return true;
    }

    protected void onResume() {
        super.onResume();
        this.MusicServiceIntent = new Intent(this, MusicService.class);
        bindService(this.MusicServiceIntent, this.serviceConnection, 1);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        this.mediaController.show();
        return null;
    }

    protected void onPause() {
        unbindService(this.serviceConnection);
        super.onPause();
    }

    protected void onDestroy() {
        super.onDestroy();
    }

    public void connectMediaControl() {
        this.mediaController.setMediaPlayer(this);
        this.mediaController.setAnchorView(findViewById(R.id.main_audio_view));
        this.handler.post(new C05691());
    }

    public void start() {
        this.MusicService.start();
    }

    public void pause() {
        this.MusicService.pause();
    }

    public int getDuration() {
        return this.MusicService.getMediaPlayer().getDuration();
    }

    public int getCurrentPosition() {
        return this.MusicService.getMediaPlayer().getCurrentPosition();
    }

    public void seekTo(int i) {
        this.MusicService.getMediaPlayer().seekTo(i);
    }

    public boolean isPlaying() {
        return this.MusicService.getMediaPlayer().isPlaying();
    }
}
