package com.sherdle.universal.attachmentviewer.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.attachmentviewer.loader.DefaultAudioLoader;
import com.sherdle.universal.attachmentviewer.loader.DefaultFileLoader;
import com.sherdle.universal.attachmentviewer.loader.DefaultVideoLoader;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader;
import com.sherdle.universal.attachmentviewer.loader.PicassoImageLoader;
import com.sherdle.universal.attachmentviewer.model.Attachment;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.widgets.ScrollGalleryView;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.ThemeUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AttachmentActivity extends AppCompatActivity {
    public static String IMAGES = "images";
    private List<MediaLoader> mediaList;
    private ScrollGalleryView scrollGalleryView;

    public static void startActivity(Context context, MediaAttachment mediaAttachment) {
        Intent intent = new Intent(context, AttachmentActivity.class);
        intent.putExtra(IMAGES, new ArrayList(Collections.singleton(mediaAttachment)));
        context.startActivity(intent);
    }

    public static void startActivity(Context context, ArrayList<MediaAttachment> arrayList) {
        Intent intent = new Intent(context, AttachmentActivity.class);
        intent.putExtra(IMAGES, arrayList);
        context.startActivity(intent);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ThemeUtils.setTheme(this);
        setContentView((int) R.layout.activity_attachment);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Helper.setStatusBarColor(this, R.color.black);
        ArrayList arrayList = (ArrayList) getIntent().getSerializableExtra(IMAGES);
        this.scrollGalleryView = (ScrollGalleryView) findViewById(R.id.scroll_gallery_view);
        Helper.admobLoader(this, findViewById(R.id.adView));
        this.mediaList = easyInitView(this.scrollGalleryView, arrayList, getSupportFragmentManager());
    }

    public static List<MediaLoader> easyInitView(ScrollGalleryView scrollGalleryView, ArrayList<Attachment> arrayList, FragmentManager fragmentManager) {
        List arrayList2 = new ArrayList(arrayList.size());
        arrayList = arrayList.iterator();
        while (arrayList.hasNext()) {
            Attachment attachment = (Attachment) arrayList.next();
            if (attachment instanceof MediaAttachment) {
                MediaAttachment mediaAttachment = (MediaAttachment) attachment;
                if (mediaAttachment.getMime().contains(MediaAttachment.MIME_PATTERN_IMAGE)) {
                    arrayList2.add(new PicassoImageLoader(mediaAttachment));
                } else if (mediaAttachment.getMime().contains(MediaAttachment.MIME_PATTERN_VID)) {
                    arrayList2.add(new DefaultVideoLoader(mediaAttachment));
                } else if (mediaAttachment.getMime().contains(MediaAttachment.MIME_PATTERN_AUDIO)) {
                    arrayList2.add(new DefaultAudioLoader(mediaAttachment));
                } else {
                    arrayList2.add(new DefaultFileLoader(mediaAttachment));
                }
            }
        }
        scrollGalleryView.setThumbnailSize((int) scrollGalleryView.getContext().getResources().getDimension(R.dimen.thumbnail_height)).setZoom(true).setFragmentManager(fragmentManager).addMedia(arrayList2);
        if (arrayList2.size() == 1) {
            scrollGalleryView.hideThumbnails(true);
        }
        return arrayList2;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finish();
        return true;
    }
}
