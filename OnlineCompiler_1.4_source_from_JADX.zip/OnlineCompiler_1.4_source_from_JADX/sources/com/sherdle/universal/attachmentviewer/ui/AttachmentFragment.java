package com.sherdle.universal.attachmentviewer.ui;

import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.attachmentviewer.loader.DefaultImageLoader;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader;
import com.sherdle.universal.attachmentviewer.loader.MediaLoader.SuccessCallback;
import com.sherdle.universal.attachmentviewer.loader.PicassoImageLoader;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.widgets.HackyViewPager;
import com.sherdle.universal.attachmentviewer.widgets.ScrollGalleryView;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Picasso.LoadedFrom;
import com.squareup.picasso.Target;
import uk.co.senab.photoview.PhotoViewAttacher;
import uk.co.senab.photoview.PhotoViewAttacher.OnPhotoTapListener;

public class AttachmentFragment extends Fragment {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    public static final String MEDIALOADER = "loader";
    public static final String ZOOM = "zoom";
    private AttachmentActivity activity;
    private ImageView backgroundImage;
    private TextView descriptionView;
    private MediaLoader mMediaLoader;
    private PhotoViewAttacher photoViewAttacher;
    private View rootView;
    private ScrollGalleryView scrollGalleryView;
    private boolean systemUIVisible = true;
    private HackyViewPager viewPager;

    /* renamed from: com.sherdle.universal.attachmentviewer.ui.AttachmentFragment$2 */
    class C09762 implements OnPhotoTapListener {
        public void onOutsidePhotoTap() {
        }

        C09762() {
        }

        public void onPhotoTap(View view, float f, float f2) {
            if (AttachmentFragment.this.systemUIVisible != null) {
                AttachmentFragment.this.hideSystemUI();
            } else {
                AttachmentFragment.this.showSystemUI();
            }
        }
    }

    /* renamed from: com.sherdle.universal.attachmentviewer.ui.AttachmentFragment$3 */
    class C09773 implements Target {
        public void onBitmapFailed(Exception exception, Drawable drawable) {
        }

        public void onPrepareLoad(Drawable drawable) {
        }

        C09773() {
        }

        public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
            try {
                WallpaperManager.getInstance(AttachmentFragment.this.getContext()).setBitmap(bitmap);
                Toast.makeText(AttachmentFragment.this.getContext(), AttachmentFragment.this.getString(R.string.wallpaper_success), 0).show();
            } catch (Bitmap bitmap2) {
                bitmap2.printStackTrace();
            }
        }
    }

    public void setMediaLoader(MediaLoader mediaLoader) {
        this.mMediaLoader = mediaLoader;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreate(bundle);
        setHasOptionsMenu(true);
        this.rootView = layoutInflater.inflate(R.layout.fragment_attachment, viewGroup, false);
        this.backgroundImage = (ImageView) this.rootView.findViewById(R.id.backgroundImage);
        this.descriptionView = (TextView) this.rootView.findViewById(R.id.description);
        this.viewPager = (HackyViewPager) getActivity().findViewById(R.id.viewPager);
        this.scrollGalleryView = (ScrollGalleryView) getActivity().findViewById(R.id.scroll_gallery_view);
        if (bundle != null) {
            this.mMediaLoader = (MediaLoader) bundle.getSerializable(MEDIALOADER);
        }
        loadMediaToView(this.rootView, bundle);
        layoutInflater = this.mMediaLoader.getAttachment().getDescription();
        if (layoutInflater != null && layoutInflater.isEmpty() == null) {
            this.descriptionView.setText(Html.fromHtml(layoutInflater));
            this.descriptionView.setVisibility(0);
        }
        if (this.scrollGalleryView.thumbnailsHidden() != null) {
            this.rootView.findViewById(R.id.thumbnail_container_padding).setVisibility(8);
        }
        return this.rootView;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.activity = (AttachmentActivity) getActivity();
    }

    private void loadMediaToView(final View view, Bundle bundle) {
        this.mMediaLoader.loadMedia(this, this.backgroundImage, view, new SuccessCallback() {
            public void onSuccess() {
                if ((AttachmentFragment.this.mMediaLoader instanceof PicassoImageLoader) || (AttachmentFragment.this.mMediaLoader instanceof DefaultImageLoader)) {
                    AttachmentFragment attachmentFragment = AttachmentFragment.this;
                    attachmentFragment.createViewAttacher(attachmentFragment.getArguments());
                }
                view.findViewById(R.id.attachmentProgress).setVisibility(8);
            }
        });
    }

    private void createViewAttacher(Bundle bundle) {
        if (bundle.getBoolean(ZOOM) != null) {
            Log.m161v("INFO", "Attaching zoom stuff");
            this.photoViewAttacher = new PhotoViewAttacher(this.backgroundImage);
            this.photoViewAttacher.setOnPhotoTapListener(new C09762());
        }
    }

    public void onSaveInstanceState(@NonNull Bundle bundle) {
        bundle.putSerializable(MEDIALOADER, this.mMediaLoader);
        bundle.putBoolean(ZOOM, this.photoViewAttacher != null);
        super.onSaveInstanceState(bundle);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.action_download) {
            Helper.download(getActivity(), ((MediaAttachment) this.mMediaLoader.getAttachment()).getUrl());
            return true;
        } else if (itemId != R.id.action_wallpaper) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            Picasso.get().load(((MediaAttachment) this.mMediaLoader.getAttachment()).getUrl()).into(new C09773());
            return true;
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menu.clear();
        if (this.mMediaLoader.getAttachment() instanceof MediaAttachment) {
            menuInflater.inflate(R.menu.menu_download, menu);
            if ((this.mMediaLoader.getAttachment() instanceof MediaAttachment) && ((MediaAttachment) this.mMediaLoader.getAttachment()).getMime().contains(MediaAttachment.MIME_PATTERN_IMAGE)) {
                menuInflater.inflate(R.menu.menu_image, menu);
            }
        }
        if (ThemeUtils.lightToolbarThemeActive(getActivity())) {
            ThemeUtils.setToolbarContentColor((Toolbar) getActivity().findViewById(R.id.toolbar), -1);
        }
        super.onCreateOptionsMenu(menu, menuInflater);
    }

    private void showSystemUI() {
        this.scrollGalleryView.hideThumbnails(false);
        if (!this.scrollGalleryView.thumbnailsHidden()) {
            this.rootView.findViewById(R.id.bottomHolder).setVisibility(0);
        }
        if (this.activity.getSupportActionBar() != null && VERSION.SDK_INT > 19) {
            this.activity.getSupportActionBar().show();
        }
        if (VERSION.SDK_INT >= 19) {
            this.activity.getWindow().getDecorView().setSystemUiVisibility(256);
        }
        this.systemUIVisible = true;
    }

    private void hideSystemUI() {
        this.scrollGalleryView.hideThumbnails(true);
        this.rootView.findViewById(R.id.bottomHolder).setVisibility(8);
        if (this.activity.getSupportActionBar() != null && VERSION.SDK_INT > 19) {
            this.activity.getSupportActionBar().hide();
        }
        if (VERSION.SDK_INT >= 19) {
            this.activity.getWindow().getDecorView().setSystemUiVisibility(5894);
        }
        this.systemUIVisible = false;
    }
}
