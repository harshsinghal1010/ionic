package com.sherdle.universal.attachmentviewer;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Binder;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat.Builder;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.C0559R;
import com.sherdle.universal.attachmentviewer.ui.AudioPlayerActivity;
import com.sherdle.universal.providers.radio.player.MediaNotificationManager;
import com.sherdle.universal.util.Log;

public class MusicService extends Service implements OnCompletionListener {
    private final IBinder MusicServiceBinder = new MusicServiceBinder();
    private final String TAG = "MusicService";
    private int mNid = 123;
    private MediaPlayer mediaPlayer;
    private boolean paused = false;
    private String title;
    private String url;

    public class MusicServiceBinder extends Binder {
        public MusicService getService() {
            Log.m161v("MusicService", "MusicServiceBinder: getService() called");
            return MusicService.this;
        }
    }

    public IBinder onBind(Intent intent) {
        Log.m161v("MusicService", "MusicService: onBind() called");
        return this.MusicServiceBinder;
    }

    public void onCreate() {
        Log.m161v("MusicService", "MusicService: onCreate() called");
    }

    public void onStart(Intent intent, int i) {
        i = new StringBuilder();
        i.append("MusicService: onStart() called, instance=");
        i.append(hashCode());
        Log.m160i("MusicService", i.toString());
    }

    public void onDestroy() {
        Log.m160i("MusicService", "MusicService: onDestroy() called");
        release();
    }

    public void onCompletion(MediaPlayer mediaPlayer) {
        release();
    }

    private void release() {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                this.mediaPlayer.stop();
            }
            this.mediaPlayer.release();
            this.mediaPlayer = null;
        }
    }

    public void play(String str, String str2) {
        this.url = str;
        this.title = str2;
        if (this.mediaPlayer == null || this.paused == null) {
            if (this.mediaPlayer != null) {
                release();
            }
            try {
                this.mediaPlayer = new MediaPlayer();
                this.mediaPlayer.setDataSource(str);
                this.mediaPlayer.prepare();
                start();
                this.mediaPlayer.setOnCompletionListener(this);
            } catch (String str22) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error trying to play ");
                stringBuilder.append(str);
                Log.m159e("MusicService", stringBuilder.toString(), str22);
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("error trying to play track: ");
                stringBuilder2.append(str);
                stringBuilder2.append(".\nError: ");
                stringBuilder2.append(str22.getMessage());
                Toast.makeText(this, stringBuilder2.toString(), 1).show();
            }
            return;
        }
        start();
        this.paused = null;
    }

    public MediaPlayer getMediaPlayer() {
        return this.mediaPlayer;
    }

    public String getUrl() {
        return this.url;
    }

    public void stop() {
        release();
        hideNotification();
    }

    public int elapsed() {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer == null) {
            return 0;
        }
        return mediaPlayer.getCurrentPosition();
    }

    public void seek(int i) {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            this.mediaPlayer.seekTo(i);
        }
    }

    public void start() {
        this.mediaPlayer.start();
        showNotification();
    }

    public void pause() {
        this.mediaPlayer.pause();
        hideNotification();
    }

    public int getDuration() {
        return this.mediaPlayer.getDuration();
    }

    public int getCurrentPosition() {
        return this.mediaPlayer.getCurrentPosition();
    }

    public void seekTo(int i) {
        this.mediaPlayer.seekTo(i);
    }

    public boolean isPlaying() {
        return this.mediaPlayer.isPlaying();
    }

    public void showNotification() {
        CharSequence charSequence;
        NotificationManager notificationManager;
        Builder contentText;
        String str = this.title;
        if (str != null) {
            if (!str.isEmpty()) {
                charSequence = this.title;
                notificationManager = (NotificationManager) getSystemService(NotificationTable.TABLE_NAME);
                if (VERSION.SDK_INT >= 26) {
                    notificationManager.createNotificationChannel(new NotificationChannel(MediaNotificationManager.NOTIFICATION_CHANNEL_ID, getString(R.string.audio_notification), 3));
                }
                contentText = new Builder(this, MediaNotificationManager.NOTIFICATION_CHANNEL_ID).setSmallIcon(C0559R.drawable.ic_radio_playing).setContentTitle(charSequence).setContentText(getResources().getString(R.string.background_audio));
                contentText.setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, AudioPlayerActivity.class), 134217728));
                ((NotificationManager) getSystemService(NotificationTable.TABLE_NAME)).notify(this.mNid, contentText.build());
            }
        }
        charSequence = getResources().getString(R.string.background_audio);
        notificationManager = (NotificationManager) getSystemService(NotificationTable.TABLE_NAME);
        if (VERSION.SDK_INT >= 26) {
            notificationManager.createNotificationChannel(new NotificationChannel(MediaNotificationManager.NOTIFICATION_CHANNEL_ID, getString(R.string.audio_notification), 3));
        }
        contentText = new Builder(this, MediaNotificationManager.NOTIFICATION_CHANNEL_ID).setSmallIcon(C0559R.drawable.ic_radio_playing).setContentTitle(charSequence).setContentText(getResources().getString(R.string.background_audio));
        contentText.setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, AudioPlayerActivity.class), 134217728));
        ((NotificationManager) getSystemService(NotificationTable.TABLE_NAME)).notify(this.mNid, contentText.build());
    }

    public void hideNotification() {
        ((NotificationManager) getSystemService(NotificationTable.TABLE_NAME)).cancel(this.mNid);
    }
}
