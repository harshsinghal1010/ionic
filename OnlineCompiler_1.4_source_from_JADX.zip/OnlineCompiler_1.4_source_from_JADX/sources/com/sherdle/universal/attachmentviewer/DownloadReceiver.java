package com.sherdle.universal.attachmentviewer;

import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

public class DownloadReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        long longExtra = intent.getLongExtra("extra_download_id", -1);
        DownloadManager downloadManager = (DownloadManager) context.getSystemService("download");
        intent = new Query();
        intent.setFilterById(new long[]{longExtra});
        context = downloadManager.query(intent);
        intent = context.getColumnIndex(NotificationCompat.CATEGORY_STATUS);
        if (context.moveToFirst()) {
            context.getInt(intent);
        }
        context.close();
    }
}
