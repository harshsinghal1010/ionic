package com.sherdle.universal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout.LayoutParams;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.BottomNavigationView.OnNavigationItemSelectedListener;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest.Builder;
import com.google.android.gms.ads.InterstitialAd;
import com.sherdle.universal.ConfigParser.CallBack;
import com.sherdle.universal.drawer.MenuItemCallback;
import com.sherdle.universal.drawer.NavItem;
import com.sherdle.universal.drawer.SimpleMenu;
import com.sherdle.universal.drawer.TabAdapter;
import com.sherdle.universal.inherit.BackPressFragment;
import com.sherdle.universal.inherit.CollapseControllingFragment;
import com.sherdle.universal.inherit.ConfigurationChangeFragment;
import com.sherdle.universal.providers.CustomIntent;
import com.sherdle.universal.util.CustomScrollingViewBehavior;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import com.sherdle.universal.util.layout.CustomAppBarLayout;
import com.sherdle.universal.util.layout.DisableableViewPager;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements MenuItemCallback, CallBack {
    public static String FRAGMENT_CLASS = "transation_target";
    public static String FRAGMENT_DATA = "transaction_data";
    private static final int PERMISSION_REQUESTCODE = 123;
    private static final String STATE_ACTIONS = "ACTIONS";
    private static final String STATE_MENU_INDEX = "MENUITEMINDEX";
    private static final String STATE_PAGER_INDEX = "VIEWPAGERPOSITION";
    private static SimpleMenu menu;
    private TabAdapter adapter;
    private BottomNavigationView bottomNavigation;
    public DrawerLayout drawer;
    private int interstitialCount = -1;
    private InterstitialAd mInterstitialAd;
    public Toolbar mToolbar;
    private NavigationView navigationView;
    List<NavItem> queueItem;
    int queueMenuItemId;
    private Bundle savedInstanceState;
    private TabLayout tabLayout;
    private ActionBarDrawerToggle toggle;
    private DisableableViewPager viewPager;

    /* renamed from: com.sherdle.universal.MainActivity$1 */
    class C09721 extends AdListener {
        C09721() {
        }

        public void onAdClosed() {
            MainActivity.this.mInterstitialAd.loadAd(new Builder().addTestDevice("B3EEABB8EE11C2BE770B684D95219ECB").build());
        }
    }

    /* renamed from: com.sherdle.universal.MainActivity$2 */
    class C09732 implements OnPageChangeListener {
        public void onPageScrollStateChanged(int i) {
        }

        public void onPageScrolled(int i, float f, int i2) {
        }

        C09732() {
        }

        public void onPageSelected(int i) {
            if (MainActivity.this.bottomNavigation.getMenu().findItem(i) != null) {
                MainActivity.this.bottomNavigation.getMenu().findItem(i).setChecked(true);
            }
            MainActivity.this.onTabBecomesActive(i);
        }
    }

    /* renamed from: com.sherdle.universal.MainActivity$3 */
    class C09743 implements OnNavigationItemSelectedListener {
        C09743() {
        }

        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            MainActivity.this.viewPager.setCurrentItem(menuItem.getItemId());
            return null;
        }
    }

    public void configLoaded(boolean z) {
        if (!z) {
            if (menu.getFirstMenuItem()) {
                z = this.savedInstanceState;
                if (z) {
                    ArrayList arrayList = (ArrayList) z.getSerializable(STATE_ACTIONS);
                    int i = this.savedInstanceState.getInt(STATE_MENU_INDEX);
                    int i2 = this.savedInstanceState.getInt(STATE_PAGER_INDEX);
                    menuItemClicked(arrayList, i, false);
                    this.viewPager.setCurrentItem(i2);
                    return;
                }
                menuItemClicked(menu.getFirstMenuItem(), 0, false);
                return;
            }
        }
        if (Helper.isOnlineShowDialog(this)) {
            Toast.makeText(this, true, 1).show();
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.savedInstanceState = bundle;
        ThemeUtils.setTheme(this);
        if (useTabletMenu() != null) {
            setContentView((int) R.layout.activity_main_tablet);
            Helper.setStatusBarColor(this, ThemeUtils.getPrimaryDarkColor(this));
        } else {
            setContentView((int) R.layout.activity_main);
        }
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(this.mToolbar);
        if (useTabletMenu() == null) {
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        } else {
            getSupportActionBar().setDisplayShowHomeEnabled(false);
        }
        if (useTabletMenu() == null) {
            this.drawer = (DrawerLayout) findViewById(R.id.drawer);
            this.toggle = new ActionBarDrawerToggle(this, this.drawer, this.mToolbar, R.string.drawer_open, R.string.drawer_close);
            this.drawer.setDrawerListener(this.toggle);
            this.toggle.syncState();
        }
        this.tabLayout = (TabLayout) findViewById(R.id.tabs);
        this.viewPager = (DisableableViewPager) findViewById(R.id.viewpager);
        this.bottomNavigation = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        this.navigationView = (NavigationView) findViewById(R.id.nav_view);
        menu = new SimpleMenu(this.navigationView.getMenu(), this);
        if (Config.USE_HARDCODED_CONFIG != null) {
            Config.configureMenu(menu, this);
        } else if ("".isEmpty() != null || "".contains("http") == null) {
            new ConfigParser("config.json", menu, this, this).execute(new Void[0]);
        } else {
            new ConfigParser("", menu, this, this).execute(new Void[0]);
        }
        this.tabLayout.setupWithViewPager(this.viewPager);
        if (useTabletMenu() == null) {
            this.drawer.setStatusBarBackgroundColor(ThemeUtils.getPrimaryDarkColor(this));
        }
        applyDrawerLocks();
        Helper.admobLoader(this, findViewById(R.id.adView));
        if (getResources().getString(R.string.admob_interstitial_id).length() > null && SettingsFragment.getIsPurchased(this) == null) {
            this.mInterstitialAd = new InterstitialAd(this);
            this.mInterstitialAd.setAdUnitId(getResources().getString(R.string.admob_interstitial_id));
            this.mInterstitialAd.loadAd(new Builder().addTestDevice("B3EEABB8EE11C2BE770B684D95219ECB").build());
            this.mInterstitialAd.setAdListener(new C09721());
        }
        Helper.updateAndroidSecurityProvider(this);
        this.viewPager.addOnPageChangeListener(new C09732());
    }

    @SuppressLint({"NewApi"})
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != PERMISSION_REQUESTCODE) {
            super.onRequestPermissionsResult(i, strArr, iArr);
            return;
        }
        Object obj = 1;
        for (int i2 : iArr) {
            if (i2 != 0) {
                obj = null;
            }
        }
        if (obj != null) {
            menuItemClicked(this.queueItem, this.queueMenuItemId, false);
        } else {
            Toast.makeText(this, getResources().getString(2131624110), 0).show();
        }
    }

    public void menuItemClicked(List<NavItem> list, int i, boolean z) {
        boolean z2 = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getBoolean("menuOpenOnStart", false);
        if (this.drawer != null) {
            Object obj = (this.savedInstanceState == null && this.adapter == null) ? 1 : null;
            if (!z2 || useTabletMenu() || obj == null) {
                this.drawer.closeDrawer((int) GravityCompat.START);
            } else {
                this.drawer.openDrawer((int) GravityCompat.START);
            }
        }
        if ((!z || isPurchased()) && checkPermissionsHandleIfNeeded(list, i) && !isCustomIntent(list)) {
            for (MenuItem menuItem : menu.getMenuItems()) {
                if (menuItem.getItemId() == i) {
                    menuItem.setChecked(true);
                } else {
                    menuItem.setChecked(false);
                }
            }
            this.adapter = new TabAdapter(getSupportFragmentManager(), list, this);
            this.viewPager.setAdapter(this.adapter);
            configureBottomNavigation(list);
            if (list.size() == 1) {
                this.bottomNavigation.setVisibility(8);
                this.tabLayout.setVisibility(8);
                this.viewPager.setPagingEnabled(false);
            } else {
                if (Config.BOTTOM_TABS != null) {
                    this.bottomNavigation.setVisibility(0);
                } else {
                    this.tabLayout.setVisibility(0);
                }
                this.viewPager.setPagingEnabled(true);
            }
            showInterstitial();
            onTabBecomesActive(0);
        }
    }

    private void configureBottomNavigation(List<NavItem> list) {
        if (Config.BOTTOM_TABS) {
            this.bottomNavigation.getMenu().clear();
            int i = 0;
            for (NavItem navItem : list) {
                if (i == 5) {
                    Toast.makeText(this, "With BottomTabs, you can not shown more than 5 entries. Remove some tabs to hide this message.", 1).show();
                    break;
                } else {
                    this.bottomNavigation.getMenu().add(0, i, 0, navItem.getText(this)).setIcon(navItem.getTabIcon());
                    i++;
                }
            }
            this.bottomNavigation.setOnNavigationItemSelectedListener(new C09743());
        }
    }

    private void onTabBecomesActive(int i) {
        Fragment item = this.adapter.getItem(i);
        boolean z = item instanceof CollapseControllingFragment;
        if ((!z || ((CollapseControllingFragment) item).supportsCollapse()) && VERSION.SDK_INT > 19) {
            unlockAppBar();
        } else {
            lockAppBar();
        }
        if ((!z || ((CollapseControllingFragment) item).dynamicToolbarElevation()) && ThemeUtils.lightToolbarThemeActive(this)) {
            dynamicElevationAppBar(true);
        } else {
            dynamicElevationAppBar(false);
        }
        ((CustomAppBarLayout) this.mToolbar.getParent()).setExpanded(true, true);
        if (i != 0) {
            showInterstitial();
        }
    }

    public void showInterstitial() {
        int i = this.interstitialCount;
        if (i == 0) {
            InterstitialAd interstitialAd = this.mInterstitialAd;
            if (interstitialAd != null && interstitialAd.isLoaded()) {
                this.mInterstitialAd.show();
            }
            this.interstitialCount = 0;
            return;
        }
        this.interstitialCount = i + 1;
    }

    private boolean isCustomIntent(List<NavItem> list) {
        NavItem navItem = null;
        for (NavItem navItem2 : list) {
            if (CustomIntent.class.isAssignableFrom(navItem2.getFragment())) {
                navItem = navItem2;
            }
        }
        if (navItem == null) {
            return null;
        }
        if (list.size() > 1) {
            Log.m158e("INFO", "Custom Intent Item must be only child of menu item! Ignoring all other tabs");
        }
        CustomIntent.performIntent(this, navItem.getData());
        return true;
    }

    private boolean isPurchased() {
        String string = getResources().getString(R.string.google_play_license);
        if (SettingsFragment.getIsPurchased(this) || string.equals("")) {
            return true;
        }
        HolderActivity.startActivity(this, SettingsFragment.class, new String[]{SettingsFragment.SHOW_DIALOG});
        return false;
    }

    private boolean checkPermissionsHandleIfNeeded(java.util.List<com.sherdle.universal.drawer.NavItem> r9, int r10) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r8 = this;
        r0 = android.os.Build.VERSION.SDK_INT;
        r1 = 1;
        r2 = 23;
        if (r0 >= r2) goto L_0x0008;
    L_0x0007:
        return r1;
    L_0x0008:
        r0 = new java.util.ArrayList;
        r0.<init>();
        r2 = r9.iterator();
    L_0x0011:
        r3 = r2.hasNext();
        r4 = 0;
        if (r3 == 0) goto L_0x0049;
    L_0x0018:
        r3 = r2.next();
        r3 = (com.sherdle.universal.drawer.NavItem) r3;
        r5 = com.sherdle.universal.inherit.PermissionsFragment.class;
        r6 = r3.getFragment();
        r5 = r5.isAssignableFrom(r6);
        if (r5 == 0) goto L_0x0011;
    L_0x002a:
        r3 = r3.getFragment();	 Catch:{ Exception -> 0x0011 }
        r3 = r3.newInstance();	 Catch:{ Exception -> 0x0011 }
        r3 = (com.sherdle.universal.inherit.PermissionsFragment) r3;	 Catch:{ Exception -> 0x0011 }
        r3 = r3.requiredPermissions();	 Catch:{ Exception -> 0x0011 }
        r5 = r3.length;	 Catch:{ Exception -> 0x0011 }
    L_0x0039:
        if (r4 >= r5) goto L_0x0011;	 Catch:{ Exception -> 0x0011 }
    L_0x003b:
        r6 = r3[r4];	 Catch:{ Exception -> 0x0011 }
        r7 = r0.contains(r6);	 Catch:{ Exception -> 0x0011 }
        if (r7 != 0) goto L_0x0046;	 Catch:{ Exception -> 0x0011 }
    L_0x0043:
        r0.add(r6);	 Catch:{ Exception -> 0x0011 }
    L_0x0046:
        r4 = r4 + 1;
        goto L_0x0039;
    L_0x0049:
        r2 = r0.size();
        if (r2 <= r1) goto L_0x007d;
    L_0x004f:
        r2 = r0.iterator();
        r3 = 1;
    L_0x0054:
        r5 = r2.hasNext();
        if (r5 == 0) goto L_0x0068;
    L_0x005a:
        r5 = r2.next();
        r5 = (java.lang.String) r5;
        r5 = r8.checkSelfPermission(r5);
        if (r5 == 0) goto L_0x0054;
    L_0x0066:
        r3 = 0;
        goto L_0x0054;
    L_0x0068:
        if (r3 != 0) goto L_0x007c;
    L_0x006a:
        r1 = new java.lang.String[r4];
        r0 = r0.toArray(r1);
        r0 = (java.lang.String[]) r0;
        r1 = 123; // 0x7b float:1.72E-43 double:6.1E-322;
        r8.requestPermissions(r0, r1);
        r8.queueItem = r9;
        r8.queueMenuItemId = r10;
        return r4;
    L_0x007c:
        return r1;
    L_0x007d:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.MainActivity.checkPermissionsHandleIfNeeded(java.util.List, int):boolean");
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.settings_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != R.id.settings) {
            return super.onOptionsItemSelected(menuItem);
        }
        HolderActivity.startActivity(this, SettingsFragment.class, null);
        return true;
    }

    public void onBackPressed() {
        TabAdapter tabAdapter = this.adapter;
        Fragment currentFragment = tabAdapter != null ? tabAdapter.getCurrentFragment() : null;
        DrawerLayout drawerLayout = this.drawer;
        if (drawerLayout != null && drawerLayout.isDrawerOpen((int) GravityCompat.START)) {
            this.drawer.closeDrawer((int) GravityCompat.START);
        } else if (!(currentFragment instanceof BackPressFragment)) {
            super.onBackPressed();
        } else if (!((BackPressFragment) currentFragment).handleBackPress()) {
            super.onBackPressed();
        }
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        if (fragments != null) {
            for (Fragment fragment : fragments) {
                if (fragment != null) {
                    fragment.onActivityResult(i, i2, intent);
                }
            }
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        configuration = this.adapter;
        if (configuration != null && (configuration.getCurrentFragment() instanceof ConfigurationChangeFragment) == null) {
            recreate();
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (this.adapter != null) {
            int i = 0;
            for (MenuItem menuItem : menu.getMenuItems()) {
                if (menuItem.isChecked()) {
                    i = menuItem.getItemId();
                    break;
                }
            }
            bundle.putSerializable(STATE_ACTIONS, (ArrayList) this.adapter.getActions());
            bundle.putInt(STATE_MENU_INDEX, i);
            bundle.putInt(STATE_PAGER_INDEX, this.viewPager.getCurrentItem());
        }
    }

    public boolean useTabletMenu() {
        return getResources().getBoolean(R.bool.isWideTablet);
    }

    public void applyDrawerLocks() {
        DrawerLayout drawerLayout = this.drawer;
        if (drawerLayout != null) {
            drawerLayout.setDrawerLockMode(0);
        }
    }

    private void lockAppBar() {
        ((LayoutParams) this.mToolbar.getLayoutParams()).setScrollFlags(0);
    }

    private void unlockAppBar() {
        ((LayoutParams) this.mToolbar.getLayoutParams()).setScrollFlags(5);
    }

    private void dynamicElevationAppBar(boolean z) {
        ((CustomScrollingViewBehavior) ((CoordinatorLayout.LayoutParams) ((RelativeLayout) this.viewPager.getParent()).getLayoutParams()).getBehavior()).setDynamicElevation(z);
        this.mToolbar.requestLayout();
    }
}
