package com.sherdle.universal.providers.facebook;

import java.util.Date;
import org.json.JSONArray;

public class FacebookItem {
    public String caption;
    public String captionUsername;
    public JSONArray commentsArray;
    public int commentsCount;
    public Date createdTime;
    public String id;
    public String imageUrl;
    public int likesCount;
    public String link;
    public String profilePhotoUrl;
    public String type;
    public String username;
    public String videoUrl;
}
