package com.sherdle.universal.providers.facebook;

import android.content.Context;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.text.Html;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.util.MimeTypes;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentActivity;
import com.sherdle.universal.attachmentviewer.ui.VideoPlayerActivity;
import com.sherdle.universal.comments.CommentsActivity;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.WebHelper;
import com.squareup.picasso.Picasso;
import java.util.List;
import java.util.Locale;

public class FacebookAdapter extends InfiniteRecyclerViewAdapter {
    private Context context;
    private List<FacebookItem> objects;

    private class FacebookItemViewHolder extends ViewHolder {
        ImageView commentsBtn;
        TextView commentsCountView;
        TextView contentView;
        TextView dateView;
        ImageView inlineImg;
        FloatingActionButton inlineImgBtn;
        TextView likesCountView;
        ImageView openBtn;
        ImageView profilePicImg;
        ImageView shareBtn;
        TextView userNameView;

        FacebookItemViewHolder(View view) {
            super(view);
            this.profilePicImg = (ImageView) view.findViewById(R.id.profile_image);
            this.userNameView = (TextView) view.findViewById(R.id.name);
            this.dateView = (TextView) view.findViewById(R.id.date);
            this.inlineImg = (ImageView) view.findViewById(R.id.photo);
            this.inlineImgBtn = (FloatingActionButton) view.findViewById(R.id.playbutton);
            this.likesCountView = (TextView) view.findViewById(R.id.like_count);
            this.commentsCountView = (TextView) view.findViewById(R.id.comments_count);
            this.contentView = (TextView) view.findViewById(R.id.message);
            this.shareBtn = (ImageView) view.findViewById(R.id.share);
            this.openBtn = (ImageView) view.findViewById(R.id.open);
            this.commentsBtn = (ImageView) view.findViewById(R.id.comments);
        }
    }

    protected int getViewType(int i) {
        return 0;
    }

    public FacebookAdapter(Context context, List<FacebookItem> list, LoadMoreListener loadMoreListener) {
        super(context, loadMoreListener);
        this.objects = list;
        this.context = context;
    }

    protected ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        return new FacebookItemViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_fb_insta_row, viewGroup, false));
    }

    protected void doBindViewHolder(ViewHolder viewHolder, int i) {
        FacebookAdapter facebookAdapter = this;
        ViewHolder viewHolder2 = viewHolder;
        if (viewHolder2 instanceof FacebookItemViewHolder) {
            final FacebookItemViewHolder facebookItemViewHolder = (FacebookItemViewHolder) viewHolder2;
            final FacebookItem facebookItem = (FacebookItem) facebookAdapter.objects.get(i);
            facebookItemViewHolder.profilePicImg.setImageDrawable(null);
            Picasso.get().load(facebookItem.profilePhotoUrl).into(facebookItemViewHolder.profilePicImg);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(facebookItem.username.substring(0, 1).toUpperCase(Locale.getDefault()));
            stringBuilder.append(facebookItem.username.substring(1).toLowerCase(Locale.getDefault()));
            facebookItemViewHolder.userNameView.setText(stringBuilder.toString());
            facebookItemViewHolder.dateView.setText(DateUtils.getRelativeDateTimeString(facebookAdapter.context, facebookItem.createdTime.getTime(), 1000, 604800000, 524288));
            facebookItemViewHolder.inlineImg.setImageDrawable(null);
            Picasso.get().load(facebookItem.imageUrl).placeholder((int) R.drawable.placeholder).into(facebookItemViewHolder.inlineImg);
            facebookItemViewHolder.inlineImg.setTag(Integer.valueOf(i));
            if (facebookItem.type.equals(MimeTypes.BASE_TYPE_VIDEO)) {
                facebookItemViewHolder.inlineImgBtn.setVisibility(0);
            } else {
                facebookItemViewHolder.inlineImgBtn.setVisibility(8);
            }
            if (facebookItem.type.equals("photo")) {
                facebookItemViewHolder.inlineImg.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        AttachmentActivity.startActivity(FacebookAdapter.this.context, MediaAttachment.withImage(((FacebookItem) FacebookAdapter.this.objects.get(((Integer) facebookItemViewHolder.inlineImg.getTag()).intValue())).imageUrl));
                    }
                });
            } else if (facebookItem.type.equals(MimeTypes.BASE_TYPE_VIDEO)) {
                OnClickListener c05852 = new OnClickListener() {
                    public void onClick(View view) {
                        VideoPlayerActivity.startActivity(FacebookAdapter.this.context, ((FacebookItem) FacebookAdapter.this.objects.get(((Integer) facebookItemViewHolder.inlineImg.getTag()).intValue())).videoUrl);
                    }
                };
                facebookItemViewHolder.inlineImgBtn.setOnClickListener(c05852);
                facebookItemViewHolder.inlineImg.setOnClickListener(c05852);
            }
            facebookItemViewHolder.likesCountView.setText(Helper.formatValue((double) facebookItem.likesCount));
            facebookItemViewHolder.contentView.setText(Html.fromHtml(facebookItem.caption.replace("\n", "<br>")));
            facebookItemViewHolder.contentView.setTextSize(2, (float) WebHelper.getTextViewFontSize(facebookAdapter.context));
            facebookItemViewHolder.shareBtn.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    view = new Intent();
                    view.setAction("android.intent.action.SEND");
                    view.putExtra("android.intent.extra.TEXT", facebookItem.link);
                    view.setType("text/plain");
                    FacebookAdapter.this.context.startActivity(Intent.createChooser(view, FacebookAdapter.this.context.getResources().getString(R.string.share_header)));
                }
            });
            facebookItemViewHolder.openBtn.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    HolderActivity.startWebViewActivity(FacebookAdapter.this.context, facebookItem.link, true, false, null);
                }
            });
            facebookItemViewHolder.commentsCountView.setText(Helper.formatValue((double) facebookItem.commentsCount));
            facebookItemViewHolder.commentsBtn.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    view = new Intent(FacebookAdapter.this.context, CommentsActivity.class);
                    view.putExtra(CommentsActivity.DATA_PARSEABLE, facebookItem.commentsArray.toString());
                    view.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.FACEBOOK);
                    FacebookAdapter.this.context.startActivity(view);
                }
            });
        }
    }

    protected int getCount() {
        return this.objects.size();
    }
}
