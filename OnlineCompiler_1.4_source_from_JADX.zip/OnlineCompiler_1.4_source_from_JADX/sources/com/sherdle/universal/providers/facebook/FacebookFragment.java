package com.sherdle.universal.providers.facebook;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.gms.common.data.DataBufferSafeParcelable;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.providers.soundcloud.api.SoundCloudClient;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import java.util.ArrayList;
import java.util.Date;
import org.json.JSONObject;

public class FacebookFragment extends Fragment implements LoadMoreListener {
    private static String API_URL_BEGIN = "https://graph.facebook.com/v3.1/";
    private static String API_URL_END = "&date_format=U&fields=comments.limit(50).summary(1),likes.limit(0).summary(1),from,picture,message,story,name,link,id,created_time,full_picture,source,type&limit=10";
    private static String API_URL_MIDDLE = "/posts/?access_token=";
    Boolean isLoading = Boolean.valueOf(false);
    private RecyclerView listView = null;
    private RelativeLayout ll;
    private Activity mAct;
    String nextpageurl;
    private FacebookAdapter postListAdapter = null;
    private ArrayList<FacebookItem> postsList;
    String username;

    private class DownloadFilesTask extends AsyncTask<String, Integer, ArrayList<FacebookItem>> {
        boolean initialload;

        DownloadFilesTask(boolean z) {
            this.initialload = z;
        }

        protected void onPreExecute() {
            if (FacebookFragment.this.isLoading.booleanValue()) {
                cancel(true);
            } else {
                FacebookFragment.this.isLoading = Boolean.valueOf(true);
            }
            if (this.initialload) {
                FacebookFragment facebookFragment = FacebookFragment.this;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(FacebookFragment.API_URL_BEGIN);
                stringBuilder.append(FacebookFragment.this.username);
                stringBuilder.append(FacebookFragment.API_URL_MIDDLE);
                stringBuilder.append(FacebookFragment.this.getResources().getString(R.string.facebook_access_token));
                stringBuilder.append(FacebookFragment.API_URL_END);
                facebookFragment.nextpageurl = stringBuilder.toString();
            }
        }

        protected void onPostExecute(ArrayList<FacebookItem> arrayList) {
            if (arrayList != null && arrayList.size() > 0) {
                FacebookFragment.this.updateList(arrayList);
            } else if (arrayList == null) {
                arrayList = FacebookFragment.this.getResources().getString(R.string.facebook_access_token);
                String str = null;
                if (arrayList.equals("YOURFACEBOOKTOKENHERE") || arrayList.equals("") != null) {
                    str = "Debug info: You have not entered a (valid) ACCESS token.";
                }
                Helper.noConnection(FacebookFragment.this.mAct, str);
                FacebookFragment.this.postListAdapter.setModeAndNotify(2);
            }
            FacebookFragment.this.isLoading = Boolean.valueOf(false);
        }

        protected ArrayList<FacebookItem> doInBackground(String... strArr) {
            return FacebookFragment.this.parseJson(Helper.getJSONObjectFromUrl(FacebookFragment.this.nextpageurl));
        }
    }

    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreate(bundle);
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list, viewGroup, false);
        setHasOptionsMenu(true);
        this.username = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        this.listView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.postsList = new ArrayList();
        this.postListAdapter = new FacebookAdapter(getContext(), this.postsList, this);
        this.postListAdapter.setModeAndNotify(3);
        this.listView.setAdapter(this.postListAdapter);
        this.listView.setLayoutManager(new LinearLayoutManager(getContext(), 1, false));
        return this.ll;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        refreshItems();
    }

    public void updateList(ArrayList<FacebookItem> arrayList) {
        if (arrayList.size() > 0) {
            this.postsList.addAll(arrayList);
        }
        if (this.nextpageurl == null) {
            this.postListAdapter.setHasMore(false);
        }
        this.postListAdapter.setModeAndNotify(1);
    }

    public void onMoreRequested() {
        if (!this.isLoading.booleanValue() && this.nextpageurl != null) {
            new DownloadFilesTask(false).execute(new String[0]);
        }
    }

    public ArrayList<FacebookItem> parseJson(JSONObject jSONObject) {
        ArrayList<FacebookItem> arrayList = new ArrayList();
        try {
            if (jSONObject.has("paging") && jSONObject.getJSONObject("paging").has("next")) {
                this.nextpageurl = jSONObject.getJSONObject("paging").getString("next");
            } else {
                this.nextpageurl = null;
            }
            jSONObject = jSONObject.getJSONArray(DataBufferSafeParcelable.DATA_FIELD);
            for (int i = 0; i < jSONObject.length(); i++) {
                StringBuilder stringBuilder;
                try {
                    JSONObject jSONObject2 = jSONObject.getJSONObject(i);
                    FacebookItem facebookItem = new FacebookItem();
                    facebookItem.id = jSONObject2.getString(TtmlNode.ATTR_ID);
                    facebookItem.type = jSONObject2.getString("type");
                    facebookItem.username = jSONObject2.getJSONObject("from").getString("name");
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("https://graph.facebook.com/");
                    stringBuilder.append(jSONObject2.getJSONObject("from").getString(TtmlNode.ATTR_ID));
                    stringBuilder.append("/picture?type=large");
                    facebookItem.profilePhotoUrl = stringBuilder.toString();
                    facebookItem.createdTime = new Date(jSONObject2.getLong(NotificationTable.COLUMN_NAME_CREATED_TIME) * 1000);
                    facebookItem.likesCount = jSONObject2.getJSONObject("likes").getJSONObject("summary").getInt("total_count");
                    if (jSONObject2.has("link")) {
                        facebookItem.link = jSONObject2.getString("link");
                    } else {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("https://www.facebook.com/");
                        stringBuilder.append(facebookItem.id);
                        facebookItem.link = stringBuilder.toString();
                    }
                    if (facebookItem.type.equals(MimeTypes.BASE_TYPE_VIDEO)) {
                        facebookItem.videoUrl = jSONObject2.getString(Param.SOURCE);
                    }
                    if (jSONObject2.has(NotificationTable.COLUMN_NAME_MESSAGE)) {
                        facebookItem.caption = jSONObject2.getString(NotificationTable.COLUMN_NAME_MESSAGE);
                    } else if (jSONObject2.has("story")) {
                        facebookItem.caption = jSONObject2.getString("story");
                    } else if (jSONObject2.has("name")) {
                        facebookItem.caption = jSONObject2.getString("name");
                    } else {
                        facebookItem.caption = "";
                    }
                    if (jSONObject2.has("full_picture")) {
                        facebookItem.imageUrl = jSONObject2.getString("full_picture");
                    }
                    facebookItem.commentsCount = jSONObject2.getJSONObject(SoundCloudClient.COMMENTS).getJSONObject("summary").getInt("total_count");
                    facebookItem.commentsArray = jSONObject2.getJSONObject(SoundCloudClient.COMMENTS).getJSONArray(DataBufferSafeParcelable.DATA_FIELD);
                    arrayList.add(facebookItem);
                } catch (Exception e) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("Item ");
                    stringBuilder.append(i);
                    stringBuilder.append(" skipped because of exception");
                    Log.m158e("INFO", stringBuilder.toString());
                    Log.printStackTrace(e);
                }
            }
            return arrayList;
        } catch (JSONObject jSONObject3) {
            Log.printStackTrace(jSONObject3);
            return null;
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.refresh_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    public void refreshItems() {
        this.postsList.clear();
        this.postListAdapter.setHasMore(true);
        this.postListAdapter.setModeAndNotify(3);
        new DownloadFilesTask(true).execute(new String[0]);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.refresh) {
            if (this.isLoading.booleanValue()) {
                Toast.makeText(this.mAct, getString(R.string.already_loading), 1).show();
            } else {
                refreshItems();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
