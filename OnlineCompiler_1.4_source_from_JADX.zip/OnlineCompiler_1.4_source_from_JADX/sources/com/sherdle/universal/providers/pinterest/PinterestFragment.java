package com.sherdle.universal.providers.pinterest;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.gms.common.data.DataBufferSafeParcelable;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.providers.soundcloud.api.SoundCloudClient;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONObject;

public class PinterestFragment extends Fragment implements LoadMoreListener {
    private static String API_URL = "https://api.pinterest.com/v1/boards/";
    private static String API_URL_END = "/pins/?fields=id,original_link,note,image,media,attribution,created_at,creator(image,first_name),counts&limit=100&access_token=";
    String id;
    Boolean isLoading = Boolean.valueOf(false);
    private RecyclerView listView = null;
    private RelativeLayout ll;
    private Activity mAct;
    String nextpageurl;
    private ArrayList<Pin> pinList = null;
    private PinterestAdapter pinListAdapter = null;

    private class DownloadFilesTask extends AsyncTask<String, Integer, ArrayList<Pin>> {
        boolean initialload;

        DownloadFilesTask(boolean z) {
            this.initialload = z;
        }

        protected void onPreExecute() {
            if (PinterestFragment.this.isLoading.booleanValue()) {
                cancel(true);
            } else {
                PinterestFragment.this.isLoading = Boolean.valueOf(true);
            }
            if (this.initialload) {
                PinterestFragment pinterestFragment = PinterestFragment.this;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(PinterestFragment.API_URL);
                stringBuilder.append(PinterestFragment.this.id);
                stringBuilder.append(PinterestFragment.API_URL_END);
                stringBuilder.append(PinterestFragment.this.getResources().getString(R.string.pinterest_access_token));
                pinterestFragment.nextpageurl = stringBuilder.toString();
            }
        }

        protected void onPostExecute(ArrayList<Pin> arrayList) {
            if (arrayList == null || arrayList.size() <= 0) {
                Helper.noConnection(PinterestFragment.this.mAct);
                PinterestFragment.this.pinListAdapter.setModeAndNotify(2);
            } else {
                PinterestFragment.this.updateList(arrayList);
            }
            PinterestFragment.this.isLoading = Boolean.valueOf(false);
        }

        protected ArrayList<Pin> doInBackground(String... strArr) {
            return PinterestFragment.this.parseJson(Helper.getJSONObjectFromUrl(PinterestFragment.this.nextpageurl));
        }
    }

    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreate(bundle);
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list, viewGroup, false);
        setHasOptionsMenu(true);
        this.id = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        this.listView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.pinList = new ArrayList();
        this.pinListAdapter = new PinterestAdapter(getContext(), this.pinList, this);
        this.pinListAdapter.setModeAndNotify(3);
        this.listView.setAdapter(this.pinListAdapter);
        this.listView.setLayoutManager(new LinearLayoutManager(getContext(), 1, false));
        return this.ll;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        refreshItems();
    }

    public void updateList(ArrayList<Pin> arrayList) {
        if (arrayList.size() > 0) {
            this.pinList.addAll(arrayList);
        }
        if (this.nextpageurl == null) {
            this.pinListAdapter.setHasMore(false);
        }
        this.pinListAdapter.setModeAndNotify(1);
    }

    public void onMoreRequested() {
        if (!this.isLoading.booleanValue() && this.nextpageurl != null) {
            new DownloadFilesTask(false).execute(new String[0]);
        }
    }

    public ArrayList<Pin> parseJson(JSONObject jSONObject) {
        ArrayList<Pin> arrayList = new ArrayList();
        try {
            if (jSONObject.getJSONObject("page").has("next") && jSONObject.getJSONObject("page").getString("next").contains("http")) {
                this.nextpageurl = jSONObject.getJSONObject("page").getString("next");
            } else {
                this.nextpageurl = null;
            }
            jSONObject = jSONObject.getJSONArray(DataBufferSafeParcelable.DATA_FIELD);
            for (int i = 0; i < jSONObject.length(); i++) {
                JSONObject jSONObject2 = jSONObject.getJSONObject(i);
                Pin pin = new Pin();
                pin.id = jSONObject2.getString(TtmlNode.ATTR_ID);
                pin.type = jSONObject2.getJSONObject("media").getString("type");
                pin.creatorName = jSONObject2.getJSONObject("creator").getString("first_name");
                pin.creatorImageUrl = jSONObject2.getJSONObject("creator").getJSONObject("image").getJSONObject("60x60").getString("url");
                pin.caption = jSONObject2.getString("note");
                pin.imageUrl = jSONObject2.getJSONObject("image").getJSONObject("original").getString("url");
                pin.createdTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).parse(jSONObject2.getString("created_at"));
                pin.repinCount = jSONObject2.getJSONObject("counts").getInt("saves");
                pin.commentsCount = jSONObject2.getJSONObject("counts").getInt(SoundCloudClient.COMMENTS);
                pin.link = jSONObject2.getString("original_link");
                if (pin.type.equals(MimeTypes.BASE_TYPE_VIDEO) && jSONObject2.getJSONObject("attribution").getString("url") != null) {
                    pin.videoUrl = jSONObject2.getJSONObject("attribution").getString("url");
                }
                arrayList.add(pin);
            }
        } catch (JSONObject jSONObject3) {
            Log.printStackTrace(jSONObject3);
        }
        return arrayList;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.refresh_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    public void refreshItems() {
        this.pinList.clear();
        this.pinListAdapter.setHasMore(true);
        this.pinListAdapter.setModeAndNotify(3);
        new DownloadFilesTask(true).execute(new String[0]);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.refresh) {
            if (this.isLoading.booleanValue()) {
                Toast.makeText(this.mAct, getString(R.string.already_loading), 1).show();
            } else {
                refreshItems();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
