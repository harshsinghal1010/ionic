package com.sherdle.universal.providers.pinterest;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.text.Html;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentActivity;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.WebHelper;
import com.squareup.picasso.Picasso;
import java.util.List;

class PinterestAdapter extends InfiniteRecyclerViewAdapter {
    private Context context;
    private List<Pin> objects;

    private class PinterestViewHolder extends ViewHolder {
        TextView commentsCountView;
        ImageView commentsView;
        TextView dateView;
        TextView descriptionView;
        ImageView inlineImg;
        ImageView openBtn;
        ImageView profileImg;
        TextView repinCountView;
        ImageView shareBtn;
        TextView userNameView;

        private PinterestViewHolder(View view) {
            super(view);
            this.profileImg = (ImageView) view.findViewById(R.id.profile_image);
            this.userNameView = (TextView) view.findViewById(R.id.name);
            this.dateView = (TextView) view.findViewById(R.id.date);
            this.inlineImg = (ImageView) view.findViewById(R.id.photo);
            this.repinCountView = (TextView) view.findViewById(R.id.like_count);
            this.descriptionView = (TextView) view.findViewById(R.id.message);
            this.commentsView = (ImageView) view.findViewById(R.id.comments);
            this.commentsCountView = (TextView) view.findViewById(R.id.comments_count);
            this.shareBtn = (ImageView) view.findViewById(R.id.share);
            this.openBtn = (ImageView) view.findViewById(R.id.open);
        }
    }

    protected int getViewType(int i) {
        return 0;
    }

    PinterestAdapter(Context context, List<Pin> list, LoadMoreListener loadMoreListener) {
        super(context, loadMoreListener);
        this.objects = list;
        this.context = context;
    }

    protected ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        return new PinterestViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_pinterest_row, viewGroup, false));
    }

    protected void doBindViewHolder(ViewHolder viewHolder, int i) {
        if (viewHolder instanceof PinterestViewHolder) {
            final Pin pin = (Pin) this.objects.get(i);
            PinterestViewHolder pinterestViewHolder = (PinterestViewHolder) viewHolder;
            pinterestViewHolder.profileImg.setImageDrawable(null);
            Picasso.get().load(pin.creatorImageUrl).into(pinterestViewHolder.profileImg);
            pinterestViewHolder.userNameView.setText(pin.creatorName);
            pinterestViewHolder.dateView.setText(DateUtils.getRelativeDateTimeString(this.context, pin.createdTime.getTime(), 1000, 604800000, 524288));
            pinterestViewHolder.inlineImg.setImageDrawable(null);
            Picasso.get().load(pin.imageUrl).placeholder((int) R.drawable.placeholder).into(pinterestViewHolder.inlineImg);
            if (pin.type.equals("image")) {
                pinterestViewHolder.inlineImg.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        AttachmentActivity.startActivity(PinterestAdapter.this.context, MediaAttachment.withImage(pin.imageUrl));
                    }
                });
            } else {
                pinterestViewHolder.inlineImg.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        HolderActivity.startWebViewActivity(PinterestAdapter.this.context, pin.link, true, false, null);
                    }
                });
            }
            pinterestViewHolder.repinCountView.setText(Helper.formatValue((double) pin.repinCount));
            if (pin.caption != null) {
                pinterestViewHolder.descriptionView.setText(Html.fromHtml(pin.caption));
                pinterestViewHolder.descriptionView.setTextSize(2, (float) WebHelper.getTextViewFontSize(this.context));
            }
            pinterestViewHolder.shareBtn.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    view = new Intent();
                    view.setAction("android.intent.action.SEND");
                    view.putExtra("android.intent.extra.TEXT", pin.link);
                    view.setType("text/plain");
                    PinterestAdapter.this.context.startActivity(Intent.createChooser(view, PinterestAdapter.this.context.getResources().getString(R.string.share_header)));
                }
            });
            pinterestViewHolder.openBtn.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    HolderActivity.startWebViewActivity(PinterestAdapter.this.context, pin.link, true, false, null);
                }
            });
            if (pin.commentsCount == 0) {
                pinterestViewHolder.commentsView.setVisibility(8);
                return;
            }
            pinterestViewHolder.commentsView.setVisibility(0);
            pinterestViewHolder.commentsCountView.setText(Helper.formatValue((double) pin.commentsCount));
        }
    }

    protected int getCount() {
        return this.objects.size();
    }
}
