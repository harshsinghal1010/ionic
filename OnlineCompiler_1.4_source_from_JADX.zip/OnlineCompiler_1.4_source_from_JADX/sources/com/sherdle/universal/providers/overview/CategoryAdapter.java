package com.sherdle.universal.providers.overview;

import android.content.Context;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.drawer.NavItem;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.squareup.picasso.Picasso;
import java.util.List;

public class CategoryAdapter extends InfiniteRecyclerViewAdapter {
    private static final int IMAGE_TYPE = 1;
    private static final int TEXT_TYPE = 0;
    private OnOverViewClick callback;
    private Context context;
    private List<NavItem> data;
    private int number;

    public interface OnOverViewClick {
        void onOverViewSelected(NavItem navItem);
    }

    private class ImageViewHolder extends ViewHolder {
        public ImageView image;
        public View itemView;
        public TextView title;

        private ImageViewHolder(View view) {
            super(view);
            this.itemView = view;
            this.title = (TextView) view.findViewById(R.id.title);
            this.image = (ImageView) view.findViewById(R.id.image);
        }
    }

    private class TextViewHolder extends ViewHolder {
        public View background;
        public View itemView;
        public TextView title;

        private TextViewHolder(View view) {
            super(view);
            this.itemView = view;
            this.background = view.findViewById(R.id.background);
            this.title = (TextView) view.findViewById(R.id.title);
        }
    }

    public CategoryAdapter(List<NavItem> list, Context context, OnOverViewClick onOverViewClick) {
        super(context, null);
        this.data = list;
        this.context = context;
        this.callback = onOverViewClick;
    }

    protected int getViewType(int i) {
        if (i < 0 || i >= this.data.size()) {
            return super.getItemViewType(i);
        }
        return (((NavItem) this.data.get(i)).getCategoryImageUrl() == null || ((NavItem) this.data.get(i)).getCategoryImageUrl().isEmpty() != 0) ? 0 : 1;
    }

    protected ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new TextViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_overview_card_text, viewGroup, false));
        }
        if (i == 1) {
            return new ImageViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_overview_card_image, viewGroup, false));
        }
        return null;
    }

    protected void doBindViewHolder(final ViewHolder viewHolder, int i) {
        viewHolder.itemView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CategoryAdapter.this.callback.onOverViewSelected((NavItem) CategoryAdapter.this.data.get(viewHolder.getAdapterPosition()));
            }
        });
        if (viewHolder instanceof TextViewHolder) {
            TextViewHolder textViewHolder = (TextViewHolder) viewHolder;
            textViewHolder.title.setText(((NavItem) this.data.get(i)).getText(this.context));
            textViewHolder.background.setBackgroundResource(randomGradientResource());
        } else if (viewHolder instanceof ImageViewHolder) {
            ImageViewHolder imageViewHolder = (ImageViewHolder) viewHolder;
            Picasso.get().load(((NavItem) this.data.get(i)).getCategoryImageUrl()).placeholder((int) R.color.black_more_translucent).into(imageViewHolder.image);
            imageViewHolder.title.setText(((NavItem) this.data.get(i)).getText(this.context));
        }
    }

    protected int getCount() {
        return this.data.size();
    }

    private int randomGradientResource() {
        this.number++;
        if (this.number == 6) {
            this.number = 1;
        }
        return Helper.getGradient(this.number);
    }
}
