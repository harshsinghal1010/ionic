package com.sherdle.universal.providers.overview;

import android.app.Activity;
import android.os.AsyncTask;
import com.sherdle.universal.ConfigParser;
import com.sherdle.universal.drawer.NavItem;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;

public class OverviewParser extends AsyncTask<Void, Void, Void> {
    private CallBack callback;
    private Activity context;
    private boolean facedException;
    private ArrayList<NavItem> result;
    private String sourceLocation;

    public interface CallBack {
        void categoriesLoaded(ArrayList<NavItem> arrayList, boolean z);
    }

    public OverviewParser(String str, Activity activity, CallBack callBack) {
        this.sourceLocation = str;
        this.context = activity;
        this.callback = callBack;
    }

    protected void onPreExecute() {
        super.onPreExecute();
    }

    protected Void doInBackground(Void... voidArr) {
        JSONArray jSONArray;
        try {
            if (this.sourceLocation.contains("http")) {
                jSONArray = new JSONArray(Helper.getDataFromUrl(this.sourceLocation));
            } else {
                String loadJSONFromAsset = Helper.loadJSONFromAsset(this.context, this.sourceLocation);
                jSONArray = loadJSONFromAsset != null ? new JSONArray(loadJSONFromAsset) : null;
            }
        } catch (JSONException e) {
            Log.m158e("INFO", "JSON was invalid");
            this.facedException = true;
            e.printStackTrace();
            jSONArray = null;
        }
        if (jSONArray != null) {
            this.result = new ArrayList();
            int i = 0;
            while (i < jSONArray.length()) {
                try {
                    this.result.add(ConfigParser.navItemFromJSON(this.context, jSONArray.getJSONObject(i)));
                    i++;
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    Log.m158e("INFO", "JSON was invalid");
                    this.facedException = true;
                }
            }
        } else {
            Log.m158e("INFO", "JSON Could not be retrieved");
            this.facedException = true;
        }
        return null;
    }

    protected void onPostExecute(Void voidR) {
        voidR = this.callback;
        if (voidR != null) {
            voidR.categoriesLoaded(this.result, this.facedException);
        }
    }
}
