package com.sherdle.universal.providers.woocommerce.checkout;

import android.content.Context;
import com.sherdle.universal.providers.woocommerce.model.products.Product;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class Cart implements Serializable {
    private static ArrayList<CartProduct> productsInCart;
    private String CACHE_FILE = "cart";
    private CartListener callback;
    private Context context;

    public interface CartListener {
        void onCartUpdated();
    }

    private Cart(Context context) {
        this.context = context;
        if (productsInCart == null) {
            context = retrieveCart();
            if (context != null) {
                productsInCart = context;
            } else {
                productsInCart = new ArrayList();
            }
        }
    }

    public static Cart getInstance(Context context) {
        return new Cart(context);
    }

    boolean addProductToCart(Product product, Product product2) {
        Iterator it = productsInCart.iterator();
        while (it.hasNext()) {
            CartProduct cartProduct = (CartProduct) it.next();
            if (cartProduct.getProduct().getId().equals(product.getId()) && (cartProduct.getVariation() == null || cartProduct.getVariation().getId().equals(product2.getId()))) {
                if (productIsInStock(product, cartProduct.getQuantity() + 1, product2) == null) {
                    return false;
                }
                cartProduct.updateQuantity(1);
                return true;
            }
        }
        if (!productIsInStock(product, 1, product2)) {
            return false;
        }
        addProductToCart(new CartProduct(product, product2));
        return true;
    }

    private void addProductToCart(CartProduct cartProduct) {
        productsInCart.add(cartProduct);
        saveCart();
    }

    public boolean removeProductFromCart(Product product, Product product2) {
        Iterator listIterator = productsInCart.listIterator();
        while (listIterator.hasNext()) {
            CartProduct cartProduct = (CartProduct) listIterator.next();
            if (cartProduct.getProduct().getId().equals(product.getId()) && (cartProduct.getVariation() == null || cartProduct.getVariation().getId().equals(product2.getId()))) {
                product2 = true;
                if (cartProduct.getQuantity() > 1) {
                    cartProduct.updateQuantity(-1);
                    product2 = null;
                } else {
                    listIterator.remove();
                }
                saveCart();
                return product2;
            }
        }
        return false;
    }

    public boolean setProductQuantity(CartProduct cartProduct, int i) {
        if (!productsInCart.contains(cartProduct) || !productIsInStock(cartProduct.getProduct(), i, cartProduct.getVariation())) {
            return false;
        }
        cartProduct.setQuantity(i);
        saveCart();
        return true;
    }

    public void clearCart() {
        productsInCart.clear();
        saveCart();
    }

    public ArrayList<CartProduct> getCartProducts() {
        return productsInCart;
    }

    private boolean productIsInStock(Product product, int i, Product product2) {
        if (product2 != null) {
            product = product2;
        }
        if (product.getManageStock().booleanValue() == null) {
            return product.getInStock().booleanValue();
        }
        return product.getStockQuantity().intValue() > i ? true : null;
    }

    private void saveCart() {
        CartListener cartListener = this.callback;
        if (cartListener != null) {
            cartListener.onCartUpdated();
        }
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(new File(this.context.getCacheDir(), ""));
            stringBuilder.append(this.CACHE_FILE);
            ObjectOutput objectOutputStream = new ObjectOutputStream(new FileOutputStream(stringBuilder.toString()));
            objectOutputStream.writeObject(productsInCart);
            objectOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private ArrayList<CartProduct> retrieveCart() {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(new File(this.context.getCacheDir(), ""));
            stringBuilder.append(this.CACHE_FILE);
            ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(new File(stringBuilder.toString())));
            ArrayList<CartProduct> arrayList = (ArrayList) objectInputStream.readObject();
            objectInputStream.close();
            return arrayList;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (ClassNotFoundException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public void setCartListener(CartListener cartListener) {
        this.callback = cartListener;
    }
}
