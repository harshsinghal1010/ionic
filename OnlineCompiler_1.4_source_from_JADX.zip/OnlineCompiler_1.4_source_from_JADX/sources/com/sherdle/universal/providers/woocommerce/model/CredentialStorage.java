package com.sherdle.universal.providers.woocommerce.model;

import android.content.Context;
import android.content.SharedPreferences;

public class CredentialStorage {
    private static final String ID = "WOO_CREDENTIALS_ID";
    private static final String KEY = "WOO_CREDENTIALS";
    private static final String MAIL = "WOO_CREDENTIALS_MAIL";
    private static final String NAME = "WOO_CREDENTIALS_NAME";
    private static final String PASS = "WOO_CREDENTIALS_PASS";
    private static SharedPreferences sharedPreferences;

    public static void saveCredentials(Context context, String str, String str2, int i, String str3) {
        context = getSharedPreferences(context).edit();
        context.putString(MAIL, str);
        context.putString(PASS, str2);
        context.putInt(ID, i);
        context.putString(NAME, str3);
        context.apply();
    }

    public static void clearCredentials(Context context) {
        context = getSharedPreferences(context).edit();
        context.clear();
        context.apply();
    }

    public static boolean credentialsAvailable(Context context) {
        context = getSharedPreferences(context);
        return (!context.contains(MAIL) || context.contains(PASS) == null) ? null : true;
    }

    public static String getEmail(Context context) {
        return getSharedPreferences(context).getString(MAIL, null);
    }

    public static String getPassword(Context context) {
        return getSharedPreferences(context).getString(PASS, null);
    }

    public static String getName(Context context) {
        return getSharedPreferences(context).getString(NAME, null);
    }

    public static Integer getId(Context context) {
        return Integer.valueOf(getSharedPreferences(context).getInt(ID, 0));
    }

    private static SharedPreferences getSharedPreferences(Context context) {
        if (sharedPreferences == null) {
            sharedPreferences = context.getSharedPreferences(KEY, 0);
        }
        return sharedPreferences;
    }
}
