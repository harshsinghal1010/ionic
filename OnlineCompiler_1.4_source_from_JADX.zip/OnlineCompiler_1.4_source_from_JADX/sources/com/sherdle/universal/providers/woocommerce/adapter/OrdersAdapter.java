package com.sherdle.universal.providers.woocommerce.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.woocommerce.checkout.PriceFormat;
import com.sherdle.universal.providers.woocommerce.model.orders.LineItem;
import com.sherdle.universal.providers.woocommerce.model.orders.Order;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import java.util.List;

public class OrdersAdapter extends InfiniteRecyclerViewAdapter {
    private static final int TYPE_HEADER = 1;
    private static final int TYPE_NORMAL = 0;
    private View headerView;
    private float itemWidth;
    private Context mContext;
    private List<Order> ordersList;

    private class HeaderViewHolder extends ViewHolder {
        HeaderViewHolder(View view) {
            super(view);
        }
    }

    private class OrderViewHolder extends ViewHolder {
        TextView orderDate;
        TextView orderDescription;
        TextView orderStatus;
        TextView orderTotal;
        View view;

        OrderViewHolder(View view) {
            super(view);
            this.view = view;
            this.orderDescription = (TextView) view.findViewById(R.id.orderDescription);
            this.orderDate = (TextView) view.findViewById(R.id.orderDate);
            this.orderTotal = (TextView) view.findViewById(R.id.orderTotal);
            this.orderStatus = (TextView) view.findViewById(R.id.orderStatus);
        }
    }

    public OrdersAdapter(Context context, List<Order> list, LoadMoreListener loadMoreListener) {
        super(context, loadMoreListener);
        this.mContext = context;
        this.ordersList = list;
    }

    protected int getViewType(int i) {
        return (this.headerView == null || i != 0) ? 0 : 1;
    }

    public ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new OrderViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_wc_order, viewGroup, false));
        }
        if (i != 1) {
            return null;
        }
        viewGroup = new HeaderViewHolder(this.headerView);
        requestFullSpan(viewGroup);
        return viewGroup;
    }

    protected void doBindViewHolder(ViewHolder viewHolder, int i) {
        if (viewHolder instanceof OrderViewHolder) {
            CharSequence format;
            OrderViewHolder orderViewHolder = (OrderViewHolder) viewHolder;
            Order order = (Order) this.ordersList.get(i - (this.headerView == null ? 0 : 1));
            if (order.getLineItems().size() == 1) {
                format = String.format(this.mContext.getString(R.string.order_item), new Object[]{order.getId(), ((LineItem) order.getLineItems().get(0)).getName()});
            } else {
                format = String.format(this.mContext.getString(R.string.order_items), new Object[]{order.getId(), Integer.valueOf(order.getLineItems().size())});
            }
            CharSequence formatPrice = PriceFormat.formatPrice(Float.valueOf(order.getTotal()));
            CharSequence status = order.getStatus();
            i = DateUtils.getRelativeDateTimeString(this.mContext, order.getDateCreated().getTime(), 1000, 604800000, 524288).toString();
            orderViewHolder.orderDescription.setText(format);
            orderViewHolder.orderTotal.setText(formatPrice);
            orderViewHolder.orderDate.setText(i);
            orderViewHolder.orderStatus.setText(status);
            if (this.itemWidth > 0) {
                orderViewHolder.view.getLayoutParams().width = (int) this.itemWidth;
            }
        } else if ((viewHolder instanceof HeaderViewHolder) != 0) {
            requestFullSpan(viewHolder);
        }
    }

    public void setItemWidth(float f) {
        this.itemWidth = f;
    }

    public void onViewAttachedToWindow(ViewHolder viewHolder) {
        super.onViewAttachedToWindow(viewHolder);
        if (viewHolder instanceof HeaderViewHolder) {
            requestFullSpan(viewHolder);
        }
    }

    public int getCount() {
        return this.ordersList.size() + (this.headerView == null ? 0 : 1);
    }

    public void setHeader(View view) {
        this.headerView = view;
        notifyDataSetChanged();
    }
}
