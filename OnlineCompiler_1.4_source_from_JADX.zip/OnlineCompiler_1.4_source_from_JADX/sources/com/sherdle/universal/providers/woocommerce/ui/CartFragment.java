package com.sherdle.universal.providers.woocommerce.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.providers.woocommerce.adapter.CartAdapter;
import com.sherdle.universal.providers.woocommerce.checkout.Cart;
import com.sherdle.universal.providers.woocommerce.checkout.Cart.CartListener;
import com.sherdle.universal.providers.woocommerce.checkout.CartAssistant;
import com.sherdle.universal.providers.woocommerce.checkout.CartProduct;
import com.sherdle.universal.providers.woocommerce.checkout.CartWithCookies;
import com.sherdle.universal.providers.woocommerce.checkout.CartWithCookies.AllProductsAddedCallback;
import com.sherdle.universal.providers.woocommerce.checkout.PriceFormat;
import java.util.Iterator;
import java.util.List;
import okhttp3.Cookie;

public class CartFragment extends Fragment implements CartListener {
    private Button btnFinish;
    private Cart cart;
    private View loadingView;
    private Activity mAct;
    private CartAdapter productsAdapter;
    private RecyclerView recyclerView;
    private TextView textViewCheckOutPrice;
    private float total;
    private View view;

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.CartFragment$1 */
    class C06681 implements OnClickListener {

        /* renamed from: com.sherdle.universal.providers.woocommerce.ui.CartFragment$1$1 */
        class C10041 implements AllProductsAddedCallback {

            /* renamed from: com.sherdle.universal.providers.woocommerce.ui.CartFragment$1$1$2 */
            class C06672 implements Runnable {
                C06672() {
                }

                public void run() {
                    CartFragment.this.loadingView.setVisibility(8);
                    Toast.makeText(CartFragment.this.mAct, R.string.cart_failed, 1).show();
                }
            }

            C10041() {
            }

            public void success(final List<Cookie> list) {
                CartFragment.this.mAct.runOnUiThread(new Runnable() {
                    public void run() {
                        CartFragment.this.cart.clearCart();
                        CartFragment.this.productsAdapter.notifyDataSetChanged();
                        CartFragment.this.updateQuantity();
                        CheckoutActivity.startActivity(CartFragment.this.mAct, list);
                        CartFragment.this.mAct.finish();
                    }
                });
            }

            public void failure() {
                CartFragment.this.mAct.runOnUiThread(new C06672());
            }
        }

        C06681() {
        }

        public void onClick(View view) {
            if (CartFragment.this.cart.getCartProducts().size() != null) {
                CartFragment.this.loadingView.setVisibility(0);
                new CartWithCookies(CartFragment.this.mAct, new C10041()).addProductsToCart(CartFragment.this.cart.getCartProducts());
            }
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_wc_cart, viewGroup, false);
    }

    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.view = view;
        this.mAct = getActivity();
        bundle = this.mAct;
        if (bundle instanceof HolderActivity) {
            ((HolderActivity) bundle).getSupportActionBar().setTitle((int) R.string.cart_title);
        }
        this.recyclerView = (RecyclerView) view.findViewById(R.id.recycleViewCheckOut);
        this.textViewCheckOutPrice = (TextView) view.findViewById(R.id.textViewCheckOutPrice);
        this.btnFinish = (Button) view.findViewById(R.id.btnFinish);
        this.loadingView = view.findViewById(R.id.loading_view);
        this.cart = Cart.getInstance(this.mAct);
        this.cart.setCartListener(this);
        this.productsAdapter = new CartAdapter(this.mAct, this.cart);
        this.recyclerView.addItemDecoration(new DividerItemDecoration(this.recyclerView.getContext(), 1));
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this.mAct, 1, false));
        this.recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.recyclerView.setAdapter(this.productsAdapter);
        updateQuantity();
        this.btnFinish.setOnClickListener(new C06681());
    }

    private void updateQuantity() {
        if (this.cart.getCartProducts().size() == 0) {
            this.view.findViewById(R.id.empty_view).setVisibility(0);
        } else {
            this.view.findViewById(R.id.empty_view).setVisibility(8);
        }
        this.total = 0.0f;
        Iterator it = this.cart.getCartProducts().iterator();
        while (it.hasNext()) {
            CartProduct cartProduct = (CartProduct) it.next();
            this.total += CartAssistant.getPrice(cartProduct.getProduct(), cartProduct.getVariation()) * ((float) cartProduct.getQuantity());
        }
        this.textViewCheckOutPrice.setText(PriceFormat.formatPrice(Float.valueOf(this.total)));
    }

    public void onCartUpdated() {
        updateQuantity();
    }
}
