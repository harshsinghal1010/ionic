package com.sherdle.universal.providers.woocommerce.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.woocommerce.checkout.Cart;
import com.sherdle.universal.providers.woocommerce.checkout.CartAssistant;
import com.sherdle.universal.providers.woocommerce.checkout.CartProduct;
import com.sherdle.universal.providers.woocommerce.checkout.PriceFormat;
import com.sherdle.universal.providers.woocommerce.model.products.Category;
import com.sherdle.universal.providers.woocommerce.model.products.Image;
import com.sherdle.universal.providers.woocommerce.model.products.Product;
import com.sherdle.universal.providers.woocommerce.ui.ProductActivity;
import com.squareup.picasso.Picasso;

public class CartAdapter extends Adapter<MyViewHolder> {
    public static int MAX_QUANTITY = 15;
    private Cart cart;
    private Context mContext;

    /* renamed from: com.sherdle.universal.providers.woocommerce.adapter.CartAdapter$4 */
    class C06594 implements OnClickListener {
        C06594() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            dialogInterface.cancel();
        }
    }

    class MyViewHolder extends ViewHolder {
        TextView overflowDelete;
        TextView overflowEdit;
        TextView productDetails;
        ImageView productImage;
        TextView productName;
        TextView productPrice;
        TextView productPriceRegular;
        TextView productQuantity;

        MyViewHolder(View view) {
            super(view);
            this.productName = (TextView) view.findViewById(R.id.productName);
            this.productPrice = (TextView) view.findViewById(R.id.productPrice);
            this.productPriceRegular = (TextView) view.findViewById(R.id.productPriceRegular);
            this.productQuantity = (TextView) view.findViewById(R.id.productQuantity);
            this.productDetails = (TextView) view.findViewById(R.id.productDetails);
            this.productImage = (ImageView) view.findViewById(R.id.productImage);
            this.overflowDelete = (TextView) view.findViewById(R.id.overflowDelete);
            this.overflowEdit = (TextView) view.findViewById(R.id.overflowEdit);
        }
    }

    public CartAdapter(Context context, Cart cart) {
        this.mContext = context;
        this.cart = cart;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_wc_cart_item, viewGroup, false));
    }

    public void onBindViewHolder(final MyViewHolder myViewHolder, int i) {
        CharSequence name;
        final CartProduct cartProduct = (CartProduct) this.cart.getCartProducts().get(i);
        final Product product = cartProduct.getProduct();
        CharSequence name2 = product.getName();
        String src = ((Image) product.getImages().get(0)).getSrc();
        float price = CartAssistant.getPrice(product, cartProduct.getVariation());
        if (product.getCategories().size() > 0) {
            name = ((Category) product.getCategories().get(0)).getName();
        } else {
            name = product.getDescription().replaceAll("<[^>]*>", "").trim();
        }
        if (cartProduct.getVariation() != null) {
            name = CartAssistant.getVariationDescription(cartProduct.getVariation());
        }
        myViewHolder.productName.setText(name2);
        myViewHolder.productPrice.setText(PriceFormat.formatPrice(Float.valueOf(price)));
        myViewHolder.productDetails.setText(name);
        myViewHolder.productQuantity.setText(String.format(this.mContext.getString(R.string.quantity), new Object[]{Integer.valueOf(cartProduct.getQuantity())}).trim());
        myViewHolder.overflowDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (CartAdapter.this.cart.removeProductFromCart(product, cartProduct.getVariation()) != null) {
                    CartAdapter.this.notifyItemRemoved(myViewHolder.getAdapterPosition());
                } else {
                    CartAdapter.this.notifyDataSetChanged();
                }
            }
        });
        myViewHolder.overflowEdit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                CartAdapter.this.showQuantityEditor(myViewHolder.getAdapterPosition());
            }
        });
        Picasso.get().load(src).into(myViewHolder.productImage);
        myViewHolder.productImage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                view = new Intent(CartAdapter.this.mContext, ProductActivity.class);
                view.putExtra(ProductActivity.PRODUCT, product);
                CartAdapter.this.mContext.startActivity(view);
            }
        });
        if (product.getOnSale().booleanValue() != 0) {
            myViewHolder.productPriceRegular.setVisibility(0);
            myViewHolder.productPriceRegular.setText(PriceFormat.formatPrice(Float.valueOf(product.getRegularPrice())));
            myViewHolder.productPriceRegular.setPaintFlags(myViewHolder.productPriceRegular.getPaintFlags() | 16);
            myViewHolder.productPrice.setText(PriceFormat.formatPrice(Float.valueOf(product.getSalePrice())));
            return;
        }
        myViewHolder.productPrice.setText(PriceFormat.formatPrice(Float.valueOf(price)));
    }

    private void showQuantityEditor(int i) {
        final CartProduct cartProduct = (CartProduct) this.cart.getCartProducts().get(i);
        View relativeLayout = new RelativeLayout(this.mContext);
        final View numberPicker = new NumberPicker(this.mContext);
        numberPicker.setMaxValue(cartProduct.getProduct().getManageStock().booleanValue() ? cartProduct.getProduct().getStockQuantity().intValue() : MAX_QUANTITY);
        numberPicker.setMinValue(1);
        numberPicker.setValue(cartProduct.getQuantity());
        LayoutParams layoutParams = new RelativeLayout.LayoutParams(50, 50);
        LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(14);
        relativeLayout.setLayoutParams(layoutParams);
        relativeLayout.addView(numberPicker, layoutParams2);
        Builder builder = new Builder(this.mContext);
        builder.setTitle((int) R.string.quantity_picker);
        builder.setView(relativeLayout);
        builder.setCancelable(false).setPositiveButton((int) R.string.ok, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                CartAdapter.this.cart.setProductQuantity(cartProduct, numberPicker.getValue());
                CartAdapter.this.notifyDataSetChanged();
            }
        }).setNegativeButton((int) R.string.cancel, new C06594());
        builder.create().show();
    }

    public int getItemCount() {
        return this.cart.getCartProducts().size();
    }
}
