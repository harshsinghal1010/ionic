package com.sherdle.universal.providers.woocommerce.model.orders;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Order {
    private static final SimpleDateFormat ORDER_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault());
    @SerializedName("billing")
    @Expose
    private Billing billing;
    @SerializedName("cart_hash")
    @Expose
    private String cartHash;
    @SerializedName("cart_tax")
    @Expose
    private String cartTax;
    @SerializedName("coupon_lines")
    @Expose
    private List<Object> couponLines = new ArrayList();
    @SerializedName("created_via")
    @Expose
    private String createdVia;
    @SerializedName("currency")
    @Expose
    private String currency;
    @SerializedName("customer_id")
    @Expose
    private Integer customerId;
    @SerializedName("customer_ip_address")
    @Expose
    private String customerIpAddress;
    @SerializedName("customer_note")
    @Expose
    private String customerNote;
    @SerializedName("customer_user_agent")
    @Expose
    private String customerUserAgent;
    @SerializedName("date_completed")
    @Expose
    private String dateCompleted;
    @SerializedName("date_created")
    @Expose
    private String dateCreated;
    @SerializedName("date_modified")
    @Expose
    private String dateModified;
    @SerializedName("date_paid")
    @Expose
    private String datePaid;
    @SerializedName("discount_tax")
    @Expose
    private String discountTax;
    @SerializedName("discount_total")
    @Expose
    private String discountTotal;
    @SerializedName("fee_lines")
    @Expose
    private List<Object> feeLines = new ArrayList();
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("line_items")
    @Expose
    private List<LineItem> lineItems = new ArrayList();
    @SerializedName("_links")
    @Expose
    private Links links;
    @SerializedName("number")
    @Expose
    private Integer number;
    @SerializedName("order_key")
    @Expose
    private String orderKey;
    @SerializedName("parent_id")
    @Expose
    private Integer parentId;
    @SerializedName("payment_method")
    @Expose
    private String paymentMethod;
    @SerializedName("payment_method_title")
    @Expose
    private String paymentMethodTitle;
    @SerializedName("prices_include_tax")
    @Expose
    private Boolean pricesIncludeTax;
    @SerializedName("refunds")
    @Expose
    private List<Object> refunds = new ArrayList();
    @SerializedName("shipping")
    @Expose
    private Shipping shipping;
    @SerializedName("shipping_lines")
    @Expose
    private List<ShippingLine> shippingLines = new ArrayList();
    @SerializedName("shipping_tax")
    @Expose
    private String shippingTax;
    @SerializedName("shipping_total")
    @Expose
    private String shippingTotal;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("tax_lines")
    @Expose
    private List<Object> taxLines = new ArrayList();
    @SerializedName("total")
    @Expose
    private String total;
    @SerializedName("total_tax")
    @Expose
    private String totalTax;
    @SerializedName("transaction_id")
    @Expose
    private String transactionId;
    @SerializedName("version")
    @Expose
    private String version;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer num) {
        this.id = num;
    }

    public Integer getParentId() {
        return this.parentId;
    }

    public void setParentId(Integer num) {
        this.parentId = num;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public String getOrderKey() {
        return this.orderKey;
    }

    public void setOrderKey(String str) {
        this.orderKey = str;
    }

    public Integer getNumber() {
        return this.number;
    }

    public void setNumber(Integer num) {
        this.number = num;
    }

    public String getCurrency() {
        return this.currency;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public String getVersion() {
        return this.version;
    }

    public void setVersion(String str) {
        this.version = str;
    }

    public Boolean getPricesIncludeTax() {
        return this.pricesIncludeTax;
    }

    public void setPricesIncludeTax(Boolean bool) {
        this.pricesIncludeTax = bool;
    }

    public Date getDateCreated() {
        try {
            return ORDER_DATE_FORMAT.parse(this.dateCreated);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void setDateCreated(String str) {
        this.dateCreated = str;
    }

    public Date getDateModified() {
        try {
            return ORDER_DATE_FORMAT.parse(this.dateModified);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void setDateModified(String str) {
        this.dateModified = str;
    }

    public Integer getCustomerId() {
        return this.customerId;
    }

    public void setCustomerId(Integer num) {
        this.customerId = num;
    }

    public String getDiscountTotal() {
        return this.discountTotal;
    }

    public void setDiscountTotal(String str) {
        this.discountTotal = str;
    }

    public String getDiscountTax() {
        return this.discountTax;
    }

    public void setDiscountTax(String str) {
        this.discountTax = str;
    }

    public String getShippingTotal() {
        return this.shippingTotal;
    }

    public void setShippingTotal(String str) {
        this.shippingTotal = str;
    }

    public String getShippingTax() {
        return this.shippingTax;
    }

    public void setShippingTax(String str) {
        this.shippingTax = str;
    }

    public String getCartTax() {
        return this.cartTax;
    }

    public void setCartTax(String str) {
        this.cartTax = str;
    }

    public float getTotal() {
        if (this.total.isEmpty()) {
            return 0.0f;
        }
        return Float.parseFloat(this.total);
    }

    public void setTotal(String str) {
        this.total = str;
    }

    public String getTotalTax() {
        return this.totalTax;
    }

    public void setTotalTax(String str) {
        this.totalTax = str;
    }

    public Billing getBilling() {
        return this.billing;
    }

    public void setBilling(Billing billing) {
        this.billing = billing;
    }

    public Shipping getShipping() {
        return this.shipping;
    }

    public void setShipping(Shipping shipping) {
        this.shipping = shipping;
    }

    public String getPaymentMethod() {
        return this.paymentMethod;
    }

    public void setPaymentMethod(String str) {
        this.paymentMethod = str;
    }

    public String getPaymentMethodTitle() {
        return this.paymentMethodTitle;
    }

    public void setPaymentMethodTitle(String str) {
        this.paymentMethodTitle = str;
    }

    public String getTransactionId() {
        return this.transactionId;
    }

    public void setTransactionId(String str) {
        this.transactionId = str;
    }

    public String getCustomerIpAddress() {
        return this.customerIpAddress;
    }

    public void setCustomerIpAddress(String str) {
        this.customerIpAddress = str;
    }

    public String getCustomerUserAgent() {
        return this.customerUserAgent;
    }

    public void setCustomerUserAgent(String str) {
        this.customerUserAgent = str;
    }

    public String getCreatedVia() {
        return this.createdVia;
    }

    public void setCreatedVia(String str) {
        this.createdVia = str;
    }

    public String getCustomerNote() {
        return this.customerNote;
    }

    public void setCustomerNote(String str) {
        this.customerNote = str;
    }

    public Date getDateCompleted() {
        try {
            return ORDER_DATE_FORMAT.parse(this.dateCompleted);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void setDateCompleted(String str) {
        this.dateCompleted = str;
    }

    public Date getDatePaid() {
        try {
            return ORDER_DATE_FORMAT.parse(this.datePaid);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void setDatePaid(String str) {
        this.datePaid = str;
    }

    public String getCartHash() {
        return this.cartHash;
    }

    public void setCartHash(String str) {
        this.cartHash = str;
    }

    public List<LineItem> getLineItems() {
        return this.lineItems;
    }

    public void setLineItems(List<LineItem> list) {
        this.lineItems = list;
    }

    public List<Object> getTaxLines() {
        return this.taxLines;
    }

    public void setTaxLines(List<Object> list) {
        this.taxLines = list;
    }

    public List<ShippingLine> getShippingLines() {
        return this.shippingLines;
    }

    public void setShippingLines(List<ShippingLine> list) {
        this.shippingLines = list;
    }

    public List<Object> getFeeLines() {
        return this.feeLines;
    }

    public void setFeeLines(List<Object> list) {
        this.feeLines = list;
    }

    public List<Object> getCouponLines() {
        return this.couponLines;
    }

    public void setCouponLines(List<Object> list) {
        this.couponLines = list;
    }

    public List<Object> getRefunds() {
        return this.refunds;
    }

    public void setRefunds(List<Object> list) {
        this.refunds = list;
    }

    public Links getLinks() {
        return this.links;
    }

    public void setLinks(Links links) {
        this.links = links;
    }

    public Order(String str, String str2) {
        this.paymentMethod = str;
        this.paymentMethodTitle = str2;
    }
}
