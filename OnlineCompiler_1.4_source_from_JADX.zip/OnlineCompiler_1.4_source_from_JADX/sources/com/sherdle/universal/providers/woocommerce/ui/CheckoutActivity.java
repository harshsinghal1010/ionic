package com.sherdle.universal.providers.woocommerce.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.woocommerce.model.RestAPI;
import com.sherdle.universal.util.ThemeUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import okhttp3.Cookie;

public class CheckoutActivity extends AppCompatActivity {
    private static String COOKIE_LIST = "LIST";
    private SwipeRefreshLayout mRefreshLayout;
    private WebView mWebView;

    public static void startActivity(Activity activity, List<Cookie> list) {
        Intent intent = new Intent(activity, CheckoutActivity.class);
        Bundle bundle = new Bundle();
        ArrayList arrayList = new ArrayList();
        for (Cookie cookie : list) {
            arrayList.add(cookie.toString());
        }
        bundle.putStringArrayList(COOKIE_LIST, arrayList);
        intent.putExtras(bundle);
        activity.startActivity(intent);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ThemeUtils.setTheme(this);
        setContentView((int) R.layout.activity_woocommerce_checkout);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar_actionbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle((int) R.string.checkout);
        bundle = new RestAPI(this);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(bundle.getHost());
        stringBuilder.append(bundle.getCheckout());
        String stringBuilder2 = stringBuilder.toString();
        Iterator it = getIntent().getExtras().getStringArrayList(COOKIE_LIST).iterator();
        while (it.hasNext()) {
            CookieManager.getInstance().setCookie(stringBuilder2, (String) it.next());
        }
        this.mRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        this.mRefreshLayout.setEnabled(false);
        this.mWebView = (WebView) findViewById(R.id.webView);
        this.mWebView.loadUrl(stringBuilder2);
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.setWebViewClient(new WebViewClient() {

            /* renamed from: com.sherdle.universal.providers.woocommerce.ui.CheckoutActivity$1$1 */
            class C06691 implements OnClickListener {
                C06691() {
                }

                public void onClick(View view) {
                    CheckoutActivity.this.finish();
                }
            }

            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(bundle.getHost());
                stringBuilder.append(bundle.getCheckoutComplete());
                if (str.contains(stringBuilder.toString())) {
                    CheckoutActivity.this.findViewById(R.id.finished_view).setVisibility(0);
                    CheckoutActivity.this.findViewById(R.id.button_ok).setOnClickListener(new C06691());
                }
                if (str.equals(bundle.getHost())) {
                    CheckoutActivity.this.finish();
                }
                webView.loadUrl(str);
                return true;
            }

            public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                super.onPageStarted(webView, str, bitmap);
                CheckoutActivity.this.mRefreshLayout.setRefreshing(true);
            }

            public void onPageFinished(WebView webView, String str) {
                super.onPageFinished(webView, str);
                CheckoutActivity.this.mRefreshLayout.setRefreshing(null);
                CheckoutActivity.this.findViewById(R.id.loading_view).setVisibility(8);
            }
        });
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || !this.mWebView.canGoBack()) {
            return super.onKeyDown(i, keyEvent);
        }
        this.mWebView.goBack();
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finish();
        return true;
    }
}
