package com.sherdle.universal.providers.woocommerce.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.woocommerce.checkout.CartAssistant;
import com.sherdle.universal.providers.woocommerce.checkout.PriceFormat;
import com.sherdle.universal.providers.woocommerce.model.ViewItem;
import com.sherdle.universal.providers.woocommerce.model.products.Image;
import com.sherdle.universal.providers.woocommerce.model.products.Product;
import com.sherdle.universal.providers.woocommerce.ui.ProductActivity;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;

public class ProductsAdapter extends InfiniteRecyclerViewAdapter {
    private static final int TYPE_CUSTOM = 1;
    private static final int TYPE_PRODUCT = 0;
    private List<ViewItem> headersList = new ArrayList();
    private float itemWidth;
    private Context mContext;
    private List<Product> productList;

    private class HeaderViewHolder extends ViewHolder {
        LinearLayout layout;

        HeaderViewHolder(View view) {
            super(view);
            this.layout = (LinearLayout) view;
        }
    }

    private class ProductViewHolder extends ViewHolder {
        ImageView overflow;
        ImageView productImage;
        TextView productName;
        TextView productPrice;
        TextView productPriceRegular;
        TextView saleLabel;
        View view;

        ProductViewHolder(View view) {
            super(view);
            this.view = view;
            this.productName = (TextView) view.findViewById(R.id.productName);
            this.productPrice = (TextView) view.findViewById(R.id.productPrice);
            this.productPriceRegular = (TextView) view.findViewById(R.id.productPriceRegular);
            this.productImage = (ImageView) view.findViewById(R.id.productImage);
            this.overflow = (ImageView) view.findViewById(R.id.overflow);
            this.saleLabel = (TextView) view.findViewById(R.id.sale_label);
        }
    }

    public ProductsAdapter(Context context, List<Product> list, LoadMoreListener loadMoreListener) {
        super(context, loadMoreListener);
        this.mContext = context;
        this.productList = list;
    }

    protected int getViewType(int i) {
        return i < this.headersList.size() ? 1 : 0;
    }

    public ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new ProductViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_wc_product_card, viewGroup, false));
        }
        i = new HeaderViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_wc_header, viewGroup, false));
        requestFullSpan(i);
        return i;
    }

    protected void doBindViewHolder(ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ProductViewHolder) {
            ProductViewHolder productViewHolder = (ProductViewHolder) viewHolder;
            final Product product = (Product) this.productList.get(i - this.headersList.size());
            CharSequence name = product.getName();
            String src = ((Image) product.getImages().get(0)).getSrc();
            productViewHolder.productName.setText(name);
            if (product.getOnSale().booleanValue()) {
                productViewHolder.productPriceRegular.setVisibility(0);
                productViewHolder.saleLabel.setVisibility(0);
                productViewHolder.productPriceRegular.setText(PriceFormat.formatPrice(Float.valueOf(product.getRegularPrice())));
                productViewHolder.productPriceRegular.setPaintFlags(productViewHolder.productPriceRegular.getPaintFlags() | 16);
                productViewHolder.productPrice.setText(PriceFormat.formatPrice(Float.valueOf(product.getSalePrice())));
            } else {
                productViewHolder.productPriceRegular.setVisibility(8);
                productViewHolder.saleLabel.setVisibility(8);
                productViewHolder.productPrice.setText(PriceFormat.formatPrice(Float.valueOf(product.getPrice())));
            }
            productViewHolder.overflow.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    new CartAssistant(ProductsAdapter.this.mContext, view, product).addProductToCart(null);
                }
            });
            Picasso.get().load(src).into(productViewHolder.productImage);
            productViewHolder.productImage.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    view = new Intent(ProductsAdapter.this.mContext, ProductActivity.class);
                    view.putExtra(ProductActivity.PRODUCT, product);
                    ProductsAdapter.this.mContext.startActivity(view);
                }
            });
            if (this.itemWidth > 0) {
                productViewHolder.view.getLayoutParams().width = (int) this.itemWidth;
            }
        } else if (viewHolder instanceof HeaderViewHolder) {
            HeaderViewHolder headerViewHolder = (HeaderViewHolder) viewHolder;
            headerViewHolder.layout.removeAllViews();
            if (((ViewItem) this.headersList.get(i)).view.getParent() != null) {
                ((ViewGroup) ((ViewItem) this.headersList.get(i)).view.getParent()).removeView(((ViewItem) this.headersList.get(i)).view);
            }
            headerViewHolder.layout.addView(((ViewItem) this.headersList.get(i)).view);
            requestFullSpan(viewHolder);
        }
    }

    public void setItemWidth(float f) {
        this.itemWidth = f;
    }

    public void onViewAttachedToWindow(ViewHolder viewHolder) {
        super.onViewAttachedToWindow(viewHolder);
        if (viewHolder instanceof HeaderViewHolder) {
            requestFullSpan(viewHolder);
        }
    }

    public int getCount() {
        return this.headersList.size() + this.productList.size();
    }

    public void addHeaderToIndex(View view, int i) {
        this.headersList.add(i, new ViewItem(view));
        notifyDataSetChanged();
    }

    public void clearHeaders() {
        if (this.headersList.size() > 0) {
            this.headersList.clear();
            notifyDataSetChanged();
        }
    }
}
