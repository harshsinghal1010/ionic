package com.sherdle.universal.providers.woocommerce.model;

import android.content.Context;
import com.codeintelligent.onlinecompiler.R;

public class RestAPI {
    private static String currencyFormat = "$%s";
    public static String home_banner_one = "featured";
    public static String home_banner_two = "sale";
    private static String unit_size = "cm";
    private static String unit_weight = "kg";
    private String checkout = "/checkout/";
    private String checkout_complete = "/checkout/order-received/";
    private Context context;
    private String login = "/wp-login.php";
    private String login_success_cookie = "wordpress_logged_in_";
    private String path = "/wp-json/wc/v2/";
    private String register = "/my-account/";

    public RestAPI(Context context) {
        this.context = context;
    }

    public String getHost() {
        return this.context.getResources().getString(R.string.woocommerce_url);
    }

    public String getPath() {
        return this.path;
    }

    public String getCheckout() {
        return this.checkout;
    }

    public String getLogin() {
        return this.login;
    }

    public String getRegister() {
        return this.register;
    }

    public String getLoginCookie() {
        return this.login_success_cookie;
    }

    public String getCheckoutComplete() {
        return this.checkout_complete;
    }

    public String getCustomerKey() {
        return this.context.getResources().getString(R.string.woocommerce_consumer_key);
    }

    public String getCustomerSecret() {
        return this.context.getResources().getString(R.string.woocommerce_consumer_secret);
    }

    public static String getCurrencyFormat() {
        return currencyFormat;
    }

    public static String getUnitSize() {
        return unit_size;
    }

    public static String getUnitWeight() {
        return unit_weight;
    }

    public Context getContext() {
        return this.context;
    }
}
