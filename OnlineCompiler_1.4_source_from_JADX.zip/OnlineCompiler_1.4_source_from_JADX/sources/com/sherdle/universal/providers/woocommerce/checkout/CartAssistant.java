package com.sherdle.universal.providers.woocommerce.checkout;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog.Builder;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.providers.woocommerce.WooCommerceTask.Callback;
import com.sherdle.universal.providers.woocommerce.WooCommerceTask.WooCommerceBuilder;
import com.sherdle.universal.providers.woocommerce.model.products.Attribute;
import com.sherdle.universal.providers.woocommerce.model.products.Product;
import com.sherdle.universal.providers.woocommerce.ui.CartFragment;
import java.util.ArrayList;
import java.util.Iterator;

public class CartAssistant {
    private Cart mCart;
    private View mCartButton;
    private Context mContext;
    private Product mProduct;
    private ArrayList<Product> variations;

    /* renamed from: com.sherdle.universal.providers.woocommerce.checkout.CartAssistant$1 */
    class C06631 implements OnClickListener {
        C06631() {
        }

        public void onClick(View view) {
            HolderActivity.startActivity(CartAssistant.this.mContext, CartFragment.class, null);
        }
    }

    /* renamed from: com.sherdle.universal.providers.woocommerce.checkout.CartAssistant$3 */
    class C06643 implements DialogInterface.OnClickListener {
        C06643() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            dialogInterface = CartAssistant.this;
            dialogInterface.addProductToCart((Product) dialogInterface.variations.get(i));
        }
    }

    public CartAssistant(Context context, View view, Product product) {
        this.mCart = Cart.getInstance(context);
        this.mContext = context;
        this.mCartButton = view;
        this.mProduct = product;
    }

    public void addProductToCart(Product product) {
        if (this.mProduct.getExternalUrl() != null && !this.mProduct.getExternalUrl().isEmpty()) {
            HolderActivity.startWebViewActivity(this.mContext, this.mProduct.getExternalUrl(), true, false, null);
        } else if (this.mProduct.getType().equals("variable") && product == null) {
            retrieveVariations();
        } else {
            product = Snackbar.make(this.mCartButton, this.mCart.addProductToCart(this.mProduct, product) != null ? R.string.cart_success : R.string.out_of_stock, 0).setAction((int) R.string.view_cart, new C06631());
            product.show();
            ((TextView) product.getView().findViewById(R.id.snackbar_text)).setTextColor(this.mContext.getResources().getColor(R.color.white));
        }
    }

    private void retrieveVariations() {
        if (this.variations == null) {
            Context context = this.mContext;
            final ProgressDialog show = ProgressDialog.show(context, context.getResources().getString(R.string.loading), this.mContext.getResources().getString(R.string.loading), true);
            new WooCommerceBuilder(this.mContext).getVariationsForProduct(new Callback<Product>() {
                public void success(ArrayList<Product> arrayList) {
                    show.dismiss();
                    CartAssistant.this.variations = arrayList;
                    CartAssistant.this.selectVariation();
                }

                public void failed() {
                    show.dismiss();
                    Toast.makeText(CartAssistant.this.mContext, R.string.varations_missing, 0).show();
                }
            }, this.mProduct.getId().intValue()).execute(new Void[0]);
            return;
        }
        selectVariation();
    }

    private void selectVariation() {
        ArrayList arrayList = new ArrayList();
        Iterator it = this.variations.iterator();
        while (it.hasNext()) {
            Product product = (Product) it.next();
            String variationDescription = getVariationDescription(product);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(variationDescription);
            stringBuilder.append(" (");
            stringBuilder.append(PriceFormat.formatPrice(Float.valueOf(getPrice(this.mProduct, product))));
            stringBuilder.append(")");
            arrayList.add(stringBuilder.toString());
        }
        Builder builder = new Builder(this.mContext);
        builder.setItems((String[]) arrayList.toArray(new String[0]), new C06643());
        if (this.variations.size() == 0) {
            builder.setMessage((int) R.string.out_of_stock);
        }
        builder.setTitle((int) R.string.varations);
        builder.create().show();
    }

    public static String getVariationDescription(Product product) {
        Iterable arrayList = new ArrayList();
        for (Attribute attribute : product.getAttributes()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(attribute.getName());
            stringBuilder.append(": ");
            stringBuilder.append(attribute.getOption());
            arrayList.add(stringBuilder.toString());
        }
        return TextUtils.join(", ", arrayList);
    }

    public static float getPrice(Product product, Product product2) {
        if (product2 != null) {
            if (product2.getPrice() != 0.0f) {
                if (product2.getOnSale().booleanValue() != null) {
                    return product2.getSalePrice();
                }
                return product2.getPrice();
            }
        }
        return product.getPrice();
    }
}
