package com.sherdle.universal.providers.woocommerce.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AlertDialog.Builder;

public class WooCommerceDebugDialog {
    public static void showDialogIfAuthFailed(String str, Context context) {
        if (str != null) {
            if (str.contains("woocommerce_rest_authentication_error") != null) {
                showDialog("Authentication Error", "Universal tried to connect to your API but was refused. You entered the correct API url, and we found your API but we were not allowed to retrieve any products.\n\nThere can be various reasons for this. You might have used the wrong credentials. It can be that your server firewall refuses our requests. Or it can be that your Wordpress installation doesn't accept oAuth.\n\nNote that this is not a problem of Universal, but instead a server side problem.\n\nPlease visit our Help Center and search for WooCommerce for recommendedsteps to take", context);
            }
        }
    }

    public static void showDialogIfNoCookies(Context context) {
        showDialog("Login Error", "Universal tried to authenticate the user against your login page butthe page returned no cookies. This usually means that your login pageis not correctly configured\n\nFor example, it can be that your server refuses post requests or that your login uses an alternative to cookies. Note that this is not a problem of Universal, but instead a server side problem. You can visit our help center and search for WooCommercefor advice on which steps to take next.", context);
    }

    private static void showDialog(final String str, final String str2, final Context context) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {

            /* renamed from: com.sherdle.universal.providers.woocommerce.ui.WooCommerceDebugDialog$1$1 */
            class C06771 implements OnClickListener {
                public void onClick(DialogInterface dialogInterface, int i) {
                }

                C06771() {
                }
            }

            public void run() {
                new Builder(context).setTitle(str).setMessage(str2).setPositiveButton(17039379, new C06771()).show();
            }
        });
    }
}
