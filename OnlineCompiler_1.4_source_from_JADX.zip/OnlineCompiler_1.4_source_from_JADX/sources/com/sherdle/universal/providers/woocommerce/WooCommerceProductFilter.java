package com.sherdle.universal.providers.woocommerce;

public class WooCommerceProductFilter {
    private double maxPrice;
    private double minPrice;
    private boolean onlyFeatured;
    private boolean onlyInStock;
    private boolean onlySale;

    public WooCommerceProductFilter minPrice(double d) {
        this.minPrice = d;
        return this;
    }

    public WooCommerceProductFilter maxPrice(double d) {
        this.maxPrice = d;
        return this;
    }

    public WooCommerceProductFilter onlySale(boolean z) {
        this.onlySale = z;
        return this;
    }

    public WooCommerceProductFilter onlyFeatured(boolean z) {
        this.onlyFeatured = z;
        return this;
    }

    public WooCommerceProductFilter onlyInStock(boolean z) {
        this.onlyInStock = z;
        return this;
    }

    public String getQuery() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.minPrice != 0.0d) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("&min_price=");
            stringBuilder2.append(this.minPrice);
            stringBuilder.append(stringBuilder2.toString());
        }
        if (this.maxPrice != 0.0d) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("&max_price=");
            stringBuilder2.append(this.maxPrice);
            stringBuilder.append(stringBuilder2.toString());
        }
        if (this.onlyFeatured) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("&featured=");
            stringBuilder2.append(Boolean.toString(this.onlyFeatured));
            stringBuilder.append(stringBuilder2.toString());
        }
        if (this.onlySale) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("&on_sale=");
            stringBuilder2.append(Boolean.toString(this.onlySale));
            stringBuilder.append(stringBuilder2.toString());
        }
        if (this.onlyInStock) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("&in_stock=");
            stringBuilder2.append(Boolean.toString(this.onlyInStock));
            stringBuilder.append(stringBuilder2.toString());
        }
        return stringBuilder.toString();
    }

    public double getMaxPrice() {
        return this.maxPrice;
    }

    public double getMinPrice() {
        return this.minPrice;
    }

    public boolean isOnlyFeatured() {
        return this.onlyFeatured;
    }

    public boolean isOnlySale() {
        return this.onlySale;
    }

    public boolean isOnlyInStock() {
        return this.onlyInStock;
    }

    public void clearFilters() {
        this.minPrice = 0.0d;
        this.maxPrice = 0.0d;
    }
}
