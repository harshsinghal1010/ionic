package com.sherdle.universal.providers.woocommerce.interceptor;

public interface SignatureService {
    String getSignature(String str, String str2, String str3);

    String getSignatureMethod();
}
