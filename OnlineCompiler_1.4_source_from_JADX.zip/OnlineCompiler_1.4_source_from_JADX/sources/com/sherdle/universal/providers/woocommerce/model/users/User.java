package com.sherdle.universal.providers.woocommerce.model.users;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sherdle.universal.providers.woocommerce.model.orders.Billing;
import com.sherdle.universal.providers.woocommerce.model.orders.Links;
import com.sherdle.universal.providers.woocommerce.model.orders.Shipping;

public class User {
    @SerializedName("avatar_url")
    @Expose
    private String avatarUrl;
    @SerializedName("billing")
    @Expose
    private Billing billing;
    @SerializedName("date_created")
    @Expose
    private String dateCreated;
    @SerializedName("date_created_gmt")
    @Expose
    private String dateCreatedGmt;
    @SerializedName("date_modified")
    @Expose
    private String dateModified;
    @SerializedName("date_modified_gmt")
    @Expose
    private String dateModifiedGmt;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("is_paying_customer")
    @Expose
    private Boolean isPayingCustomer;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("_links")
    @Expose
    private Links links;
    @SerializedName("orders_count")
    @Expose
    private Integer ordersCount;
    @SerializedName("role")
    @Expose
    private String role;
    @SerializedName("shipping")
    @Expose
    private Shipping shipping;
    @SerializedName("total_spent")
    @Expose
    private String totalSpent;
    @SerializedName("username")
    @Expose
    private String username;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer num) {
        this.id = num;
    }

    public String getDateCreated() {
        return this.dateCreated;
    }

    public void setDateCreated(String str) {
        this.dateCreated = str;
    }

    public String getDateCreatedGmt() {
        return this.dateCreatedGmt;
    }

    public void setDateCreatedGmt(String str) {
        this.dateCreatedGmt = str;
    }

    public String getDateModified() {
        return this.dateModified;
    }

    public void setDateModified(String str) {
        this.dateModified = str;
    }

    public String getDateModifiedGmt() {
        return this.dateModifiedGmt;
    }

    public void setDateModifiedGmt(String str) {
        this.dateModifiedGmt = str;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String str) {
        this.email = str;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String str) {
        this.firstName = str;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String str) {
        this.lastName = str;
    }

    public String getRole() {
        return this.role;
    }

    public void setRole(String str) {
        this.role = str;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String str) {
        this.username = str;
    }

    public Billing getBilling() {
        return this.billing;
    }

    public void setBilling(Billing billing) {
        this.billing = billing;
    }

    public Shipping getShipping() {
        return this.shipping;
    }

    public void setShipping(Shipping shipping) {
        this.shipping = shipping;
    }

    public Boolean getIsPayingCustomer() {
        return this.isPayingCustomer;
    }

    public void setIsPayingCustomer(Boolean bool) {
        this.isPayingCustomer = bool;
    }

    public Integer getOrdersCount() {
        return this.ordersCount;
    }

    public void setOrdersCount(Integer num) {
        this.ordersCount = num;
    }

    public String getTotalSpent() {
        return this.totalSpent;
    }

    public void setTotalSpent(String str) {
        this.totalSpent = str;
    }

    public String getAvatarUrl() {
        return this.avatarUrl;
    }

    public void setAvatarUrl(String str) {
        this.avatarUrl = str;
    }

    public Links getLinks() {
        return this.links;
    }

    public void setLinks(Links links) {
        this.links = links;
    }
}
