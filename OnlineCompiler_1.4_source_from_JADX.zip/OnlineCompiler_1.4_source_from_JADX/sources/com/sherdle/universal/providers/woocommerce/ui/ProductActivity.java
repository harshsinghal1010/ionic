package com.sherdle.universal.providers.woocommerce.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentActivity;
import com.sherdle.universal.providers.fav.FavDbAdapter;
import com.sherdle.universal.providers.woocommerce.WooCommerceTask.Callback;
import com.sherdle.universal.providers.woocommerce.WooCommerceTask.WooCommerceBuilder;
import com.sherdle.universal.providers.woocommerce.adapter.ProductsAdapter;
import com.sherdle.universal.providers.woocommerce.checkout.CartAssistant;
import com.sherdle.universal.providers.woocommerce.checkout.PriceFormat;
import com.sherdle.universal.providers.woocommerce.model.RestAPI;
import com.sherdle.universal.providers.woocommerce.model.products.Attribute;
import com.sherdle.universal.providers.woocommerce.model.products.Category;
import com.sherdle.universal.providers.woocommerce.model.products.Image;
import com.sherdle.universal.providers.woocommerce.model.products.Product;
import com.sherdle.universal.providers.woocommerce.model.products.Tag;
import com.sherdle.universal.util.DetailActivity;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.WebHelper;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class ProductActivity extends DetailActivity {
    public static final String PRODUCT = "product";
    private FloatingActionButton btnCart;
    private CartAssistant mCartAssistant;
    private FavDbAdapter mDbHelper;
    private TextView mPresentation;
    private Product product;
    private TableLayout tableLayout;

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.ProductActivity$1 */
    class C06741 implements OnClickListener {
        C06741() {
        }

        public void onClick(View view) {
            ProductActivity.this.mCartAssistant.addProductToCart(null);
        }
    }

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.ProductActivity$2 */
    class C06752 implements OnClickListener {
        C06752() {
        }

        public void onClick(View view) {
            view = ProductActivity.this;
            view.mDbHelper = new FavDbAdapter(view);
            ProductActivity.this.mDbHelper.open();
            if (ProductActivity.this.mDbHelper.checkEvent(ProductActivity.this.product.getName(), ProductActivity.this.product, 5) != null) {
                ProductActivity.this.mDbHelper.addFavorite(ProductActivity.this.product.getName(), ProductActivity.this.product, 5);
                view = ProductActivity.this;
                Toast.makeText(view, view.getResources().getString(R.string.favorite_success), 1).show();
                return;
            }
            view = ProductActivity.this;
            Toast.makeText(view, view.getResources().getString(R.string.favorite_duplicate), 1).show();
        }
    }

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.ProductActivity$3 */
    class C06763 implements OnClickListener {
        C06763() {
        }

        public void onClick(View view) {
            ArrayList arrayList = new ArrayList();
            for (Image image : ProductActivity.this.product.getImages()) {
                arrayList.add(new MediaAttachment(image.getSrc(), MediaAttachment.MIME_PATTERN_IMAGE, null, image.getName()));
            }
            AttachmentActivity.startActivity(ProductActivity.this, arrayList);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_details);
        ViewStub viewStub = (ViewStub) findViewById(R.id.layout_stub);
        viewStub.setLayoutResource(R.layout.activity_woocommerce_product);
        viewStub.inflate();
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        TextView textView = (TextView) findViewById(R.id.description);
        TextView textView2 = (TextView) findViewById(R.id.subtitle);
        TextView textView3 = (TextView) findViewById(R.id.price_text);
        TextView textView4 = (TextView) findViewById(R.id.price_original_text);
        ImageButton imageButton = (ImageButton) findViewById(R.id.favorite);
        this.thumb = (ImageView) findViewById(R.id.image);
        this.coolblue = (RelativeLayout) findViewById(R.id.coolblue);
        this.tableLayout = (TableLayout) findViewById(R.id.properties_grid);
        this.btnCart = (FloatingActionButton) findViewById(R.id.cart_button);
        this.mPresentation = (TextView) findViewById(R.id.title);
        this.product = (Product) getIntent().getExtras().getSerializable(PRODUCT);
        CharSequence trim = this.product.getDescription().replaceAll("<[^>]*>", "").trim();
        CharSequence trim2 = this.product.getShortDescription().replaceAll("<[^>]*>", "").trim();
        textView.setTextSize(2, (float) WebHelper.getTextViewFontSize(this));
        this.btnCart.bringToFront();
        this.mCartAssistant = new CartAssistant(this, this.btnCart, this.product);
        Helper.admobLoader(this, findViewById(R.id.adView));
        this.mPresentation.setText(this.product.getName());
        textView.setText(trim);
        if (trim2.isEmpty() == null) {
            textView2.setText(trim2);
        } else {
            textView2.setVisibility(8);
        }
        if (this.product.getOnSale().booleanValue() != null) {
            textView4.setVisibility(0);
            textView4.setText(PriceFormat.formatPrice(Float.valueOf(this.product.getRegularPrice())));
            textView4.setPaintFlags(textView4.getPaintFlags() | 16);
            textView3.setText(PriceFormat.formatPrice(Float.valueOf(this.product.getSalePrice())));
        } else {
            textView3.setText(PriceFormat.formatPrice(Float.valueOf(this.product.getPrice())));
        }
        String src = ((Image) this.product.getImages().get(0)).getSrc();
        Picasso.get().load(src).into(this.thumb);
        setUpHeader(src);
        this.btnCart.setOnClickListener(new C06741());
        imageButton.setOnClickListener(new C06752());
        this.thumb.setOnClickListener(new C06763());
        loadProductProperties();
        loadRating();
        loadRelated();
    }

    public void loadProductProperties() {
        Iterable arrayList;
        if (this.product.getCategories().size() > 0) {
            arrayList = new ArrayList();
            for (Category name : this.product.getCategories()) {
                arrayList.add(name.getName());
            }
            addProperty(getString(R.string.category), TextUtils.join("\n", arrayList));
        }
        if (this.product.getTags().size() > 0) {
            arrayList = new ArrayList();
            for (Tag name2 : this.product.getTags()) {
                arrayList.add(name2.getName());
            }
            addProperty(getString(R.string.tag), TextUtils.join("\n", arrayList));
        }
        if (this.product.getAttributes().size() > 0) {
            for (Attribute attribute : this.product.getAttributes()) {
                String option;
                String name3 = attribute.getName();
                if (attribute.getOptions() == null) {
                    option = attribute.getOption();
                } else {
                    option = TextUtils.join("\n", attribute.getOptions());
                }
                addProperty(name3, option);
            }
        }
        if (!this.product.getWeight().isEmpty()) {
            String string = getString(R.string.weight);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.product.getWeight());
            stringBuilder.append(RestAPI.getUnitWeight());
            addProperty(string, stringBuilder.toString());
        }
        if (!this.product.getDimensions().getHeight().isEmpty()) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(this.product.getDimensions().getLength());
            stringBuilder2.append(" x ");
            stringBuilder2.append(this.product.getDimensions().getWidth());
            string = stringBuilder2.toString();
            stringBuilder = new StringBuilder();
            stringBuilder.append(string);
            if (this.product.getDimensions().getHeight().isEmpty()) {
                string = "";
            } else {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(" x ");
                stringBuilder2.append(this.product.getDimensions().getHeight());
                string = stringBuilder2.toString();
            }
            stringBuilder.append(string);
            string = stringBuilder.toString();
            stringBuilder = new StringBuilder();
            stringBuilder.append(string);
            stringBuilder.append(" ");
            stringBuilder.append(RestAPI.getUnitSize());
            addProperty(getString(R.string.dimensions), stringBuilder.toString());
        }
        addProperty(getString(R.string.sku), Integer.toString(this.product.getId().intValue()));
    }

    private void addProperty(String str, String str2) {
        View inflate = LayoutInflater.from(this).inflate(R.layout.activity_woocommerce_product_row, null);
        ((TextView) inflate.findViewById(R.id.key)).setText(str);
        ((TextView) inflate.findViewById(R.id.value)).setText(str2);
        this.tableLayout.addView(inflate);
    }

    private void loadRating() {
        if (this.product.getRatingCount().intValue() > 0) {
            ((RatingBar) findViewById(R.id.rating)).setRating(Float.parseFloat(this.product.getAverageRating()));
            ((TextView) findViewById(R.id.rating_count)).setText(String.format(getString(R.string.reviews), new Object[]{this.product.getRatingCount()}));
            return;
        }
        ((TextView) findViewById(R.id.rating_count)).setText(getString(R.string.no_reviews));
    }

    private void loadRelated() {
        final RecyclerView recyclerView = (RecyclerView) findViewById(R.id.related_list);
        final Object arrayList = new ArrayList();
        final Adapter productsAdapter = new ProductsAdapter(this, arrayList, null);
        productsAdapter.setModeAndNotify(3);
        productsAdapter.setItemWidth(getResources().getDimension(R.dimen.woocommerce_related_product_width));
        recyclerView.setAdapter(productsAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, 0, false));
        new WooCommerceBuilder(this).getProductsForIds(new Callback<Product>() {
            public void success(ArrayList<Product> arrayList) {
                ((ViewGroup) ProductActivity.this.findViewById(R.id.related_view)).setVisibility(0);
                productsAdapter.setModeAndNotify(1);
                arrayList.addAll(arrayList);
                productsAdapter.notifyDataSetChanged();
            }

            public void failed() {
                recyclerView.setVisibility(8);
            }
        }, this.product.getRelatedIds(), 1).execute(new Void[0]);
    }

    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId != 16908332) {
            switch (itemId) {
                case R.id.menu_share:
                    menuItem = new Intent();
                    menuItem.setAction("android.intent.action.SEND");
                    menuItem.putExtra("android.intent.extra.TEXT", this.product.getPermalink());
                    menuItem.putExtra("android.intent.extra.SUBJECT", this.product.getName());
                    menuItem.setType("text/plain");
                    startActivity(Intent.createChooser(menuItem, getResources().getString(R.string.share_header)));
                    return true;
                case R.id.menu_view:
                    HolderActivity.startWebViewActivity(this, this.product.getPermalink(), true, false, null);
                    return true;
                default:
                    return super.onOptionsItemSelected(menuItem);
            }
        }
        finish();
        return true;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.woocommerce_detail_menu, menu);
        onMenuItemsSet(menu);
        return true;
    }
}
