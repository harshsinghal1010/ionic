package com.sherdle.universal.providers.woocommerce.model.orders;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.List;

public class ShippingLine {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("method_id")
    @Expose
    private String methodId;
    @SerializedName("method_title")
    @Expose
    private String methodTitle;
    @SerializedName("taxes")
    @Expose
    private List<Object> taxes = new ArrayList();
    @SerializedName("total")
    @Expose
    private String total;
    @SerializedName("total_tax")
    @Expose
    private String totalTax;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer num) {
        this.id = num;
    }

    public String getMethodTitle() {
        return this.methodTitle;
    }

    public void setMethodTitle(String str) {
        this.methodTitle = str;
    }

    public String getMethodId() {
        return this.methodId;
    }

    public void setMethodId(String str) {
        this.methodId = str;
    }

    public String getTotal() {
        return this.total;
    }

    public void setTotal(String str) {
        this.total = str;
    }

    public String getTotalTax() {
        return this.totalTax;
    }

    public void setTotalTax(String str) {
        this.totalTax = str;
    }

    public List<Object> getTaxes() {
        return this.taxes;
    }

    public void setTaxes(List<Object> list) {
        this.taxes = list;
    }
}
