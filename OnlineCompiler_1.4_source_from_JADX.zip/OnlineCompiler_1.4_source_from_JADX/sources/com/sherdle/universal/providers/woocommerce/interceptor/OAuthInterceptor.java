package com.sherdle.universal.providers.woocommerce.interceptor;

import com.google.android.exoplayer2.C0361C;
import com.google.android.gms.actions.SearchIntents;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.sherdle.universal.util.Log;
import java.io.IOException;
import java.net.URLEncoder;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.Interceptor.Chain;
import okhttp3.Request;
import okhttp3.Response;

public class OAuthInterceptor implements Interceptor {
    private static final String BASIC_CONSUMER_KEY = "consumer_key";
    private static final String BASIC_CONSUMER_SECRET = "consumer_secret";
    private static final String OAUTH_CONSUMER_KEY = "oauth_consumer_key";
    private static final String OAUTH_NONCE = "oauth_nonce";
    private static final String OAUTH_SIGNATURE = "oauth_signature";
    private static final String OAUTH_SIGNATURE_METHOD = "oauth_signature_method";
    private static final String OAUTH_SIGNATURE_METHOD_VALUE = "HMAC-SHA1";
    private static final String OAUTH_TIMESTAMP = "oauth_timestamp";
    private static final String OAUTH_VERSION = "oauth_version";
    private static final String OAUTH_VERSION_VALUE = "1.0";
    private final boolean OAUTH;
    private final String consumerKey;
    private final String consumerSecret;

    public static final class Builder {
        private String consumerKey;
        private String consumerSecret;
        private int type;

        public Builder consumerKey(String str) {
            if (str != null) {
                this.consumerKey = str;
                return this;
            }
            throw new NullPointerException("consumerKey = null");
        }

        public Builder consumerSecret(String str) {
            if (str != null) {
                this.consumerSecret = str;
                return this;
            }
            throw new NullPointerException("consumerSecret = null");
        }

        public OAuthInterceptor build() {
            String str = this.consumerKey;
            if (str != null) {
                String str2 = this.consumerSecret;
                if (str2 != null) {
                    return new OAuthInterceptor(str, str2);
                }
                throw new IllegalStateException("consumerSecret not set");
            }
            throw new IllegalStateException("consumerKey not set");
        }
    }

    private OAuthInterceptor(String str, String str2) {
        this.OAUTH = true;
        this.consumerKey = str;
        this.consumerSecret = str2;
    }

    public Response intercept(Chain chain) throws IOException {
        String stringBuilder;
        Request request = chain.request();
        HttpUrl url = request.url();
        Log.m157d("URL", request.url().toString());
        Log.m157d("URL", request.url().scheme());
        Log.m157d("encodedpath", request.url().encodedPath());
        String str = SearchIntents.EXTRA_QUERY;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("");
        stringBuilder2.append(request.url().query());
        Log.m157d(str, stringBuilder2.toString());
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("");
        stringBuilder2.append(request.url().host());
        Log.m157d("path", stringBuilder2.toString());
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("");
        stringBuilder2.append(request.url().encodedQuery());
        Log.m157d("encodedQuery", stringBuilder2.toString());
        str = Param.METHOD;
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("");
        stringBuilder2.append(request.method());
        Log.m157d(str, stringBuilder2.toString());
        str = new TimestampServiceImpl().getNonce();
        String timestampInSeconds = new TimestampServiceImpl().getTimestampInSeconds();
        Log.m157d("nonce", str);
        Log.m157d("time", timestampInSeconds);
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(request.url().scheme());
        stringBuilder3.append("://");
        stringBuilder3.append(request.url().host());
        stringBuilder3.append(request.url().encodedPath());
        String stringBuilder4 = stringBuilder3.toString();
        StringBuilder stringBuilder5 = new StringBuilder();
        stringBuilder5.append("");
        stringBuilder5.append(stringBuilder4);
        Log.m157d("ENCODED PATH", stringBuilder5.toString());
        StringBuilder stringBuilder6 = new StringBuilder();
        stringBuilder6.append(request.method());
        stringBuilder6.append("&");
        stringBuilder6.append(urlEncoded(stringBuilder4));
        stringBuilder4 = stringBuilder6.toString();
        Log.m157d("firstBaseString", stringBuilder4);
        if (request.url().encodedQuery() != null) {
            stringBuilder6 = new StringBuilder();
            stringBuilder6.append(request.url().encodedQuery());
            stringBuilder6.append("&oauth_consumer_key=");
            stringBuilder6.append(this.consumerKey);
            stringBuilder6.append("&oauth_nonce=");
            stringBuilder6.append(str);
            stringBuilder6.append("&oauth_signature_method=HMAC-SHA1&oauth_timestamp=");
            stringBuilder6.append(timestampInSeconds);
            stringBuilder6.append("&oauth_version=1.0");
            stringBuilder = stringBuilder6.toString();
        } else {
            stringBuilder6 = new StringBuilder();
            stringBuilder6.append("oauth_consumer_key=");
            stringBuilder6.append(this.consumerKey);
            stringBuilder6.append("&oauth_nonce=");
            stringBuilder6.append(str);
            stringBuilder6.append("&oauth_signature_method=HMAC-SHA1&oauth_timestamp=");
            stringBuilder6.append(timestampInSeconds);
            stringBuilder6.append("&oauth_version=1.0");
            stringBuilder = stringBuilder6.toString();
        }
        ParameterList parameterList = new ParameterList();
        parameterList.addQuerystring(stringBuilder);
        stringBuilder = parameterList.sort().asOauthBaseString();
        StringBuilder stringBuilder7 = new StringBuilder();
        stringBuilder7.append("00--");
        stringBuilder7.append(parameterList.sort().asOauthBaseString());
        Log.m157d("Sorted", stringBuilder7.toString());
        stringBuilder5 = new StringBuilder();
        stringBuilder5.append("&");
        stringBuilder5.append(stringBuilder);
        String stringBuilder8 = stringBuilder5.toString();
        if (stringBuilder4.contains("%3F")) {
            Log.m157d("iff", "yess iff");
            stringBuilder5 = new StringBuilder();
            stringBuilder5.append("%26");
            stringBuilder5.append(urlEncoded(stringBuilder));
            stringBuilder8 = stringBuilder5.toString();
        }
        stringBuilder6 = new StringBuilder();
        stringBuilder6.append(stringBuilder4);
        stringBuilder6.append(stringBuilder8);
        stringBuilder4 = new HMACSha1SignatureService().getSignature(stringBuilder6.toString(), this.consumerSecret, "");
        Log.m157d("Signature", stringBuilder4);
        return chain.proceed(request.newBuilder().url(url.newBuilder().addQueryParameter(OAUTH_SIGNATURE_METHOD, OAUTH_SIGNATURE_METHOD_VALUE).addQueryParameter(OAUTH_CONSUMER_KEY, this.consumerKey).addQueryParameter(OAUTH_VERSION, "1.0").addQueryParameter(OAUTH_TIMESTAMP, timestampInSeconds).addQueryParameter(OAUTH_NONCE, str).addQueryParameter(OAUTH_SIGNATURE, stringBuilder4).build()).build());
    }

    public String urlEncoded(String str) {
        String str2 = "";
        try {
            str2 = URLEncoder.encode(str, C0361C.UTF8_NAME);
            Log.m157d("TEST", str2);
        } catch (String str3) {
            str3.printStackTrace();
        }
        return str2;
    }
}
