package com.sherdle.universal.providers.woocommerce.model.products;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Product implements Serializable {
    @SerializedName("attributes")
    @Expose
    private List<Attribute> attributes = new ArrayList();
    @SerializedName("average_rating")
    @Expose
    private String averageRating;
    @SerializedName("backordered")
    @Expose
    private Boolean backordered;
    @SerializedName("backorders")
    @Expose
    private String backorders;
    @SerializedName("backorders_allowed")
    @Expose
    private Boolean backordersAllowed;
    @SerializedName("button_text")
    @Expose
    private String buttonText;
    @SerializedName("catalog_visibility")
    @Expose
    private String catalogVisibility;
    @SerializedName("categories")
    @Expose
    private List<Category> categories = new ArrayList();
    @SerializedName("cross_sell_ids")
    @Expose
    private List<Integer> crossSellIds = new ArrayList();
    @SerializedName("date_created")
    @Expose
    private String dateCreated;
    @SerializedName("date_modified")
    @Expose
    private String dateModified;
    @SerializedName("date_on_sale_from")
    @Expose
    private String dateOnSaleFrom;
    @SerializedName("date_on_sale_to")
    @Expose
    private String dateOnSaleTo;
    @SerializedName("default_attributes")
    @Expose
    private List<Attribute> defaultAttributes = new ArrayList();
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("dimensions")
    @Expose
    private Dimensions dimensions;
    @SerializedName("download_expiry")
    @Expose
    private Integer downloadExpiry;
    @SerializedName("download_limit")
    @Expose
    private Integer downloadLimit;
    @SerializedName("download_type")
    @Expose
    private String downloadType;
    @SerializedName("downloadable")
    @Expose
    private Boolean downloadable;
    @SerializedName("downloads")
    @Expose
    private List<Object> downloads = new ArrayList();
    @SerializedName("external_url")
    @Expose
    private String externalUrl;
    @SerializedName("featured")
    @Expose
    private Boolean featured;
    @SerializedName("grouped_products")
    @Expose
    private List<Object> groupedProducts = new ArrayList();
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("images")
    @Expose
    private List<Image> images = new ArrayList();
    @SerializedName("in_stock")
    @Expose
    private Boolean inStock;
    @SerializedName("manage_stock")
    @Expose
    private Boolean manageStock;
    @SerializedName("menu_order")
    @Expose
    private Integer menuOrder;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("on_sale")
    @Expose
    private Boolean onSale;
    @SerializedName("parent_id")
    @Expose
    private Integer parentId;
    @SerializedName("permalink")
    @Expose
    private String permalink;
    @SerializedName("price")
    @Expose
    private String price;
    @SerializedName("price_html")
    @Expose
    private String priceHtml;
    @SerializedName("purchasable")
    @Expose
    private Boolean purchasable;
    @SerializedName("purchase_note")
    @Expose
    private String purchaseNote;
    @SerializedName("rating_count")
    @Expose
    private Integer ratingCount;
    @SerializedName("regular_price")
    @Expose
    private String regularPrice;
    @SerializedName("related_ids")
    @Expose
    private List<Integer> relatedIds = new ArrayList();
    @SerializedName("reviews_allowed")
    @Expose
    private Boolean reviewsAllowed;
    @SerializedName("sale_price")
    @Expose
    private String salePrice;
    @SerializedName("shipping_class")
    @Expose
    private String shippingClass;
    @SerializedName("shipping_class_id")
    @Expose
    private Integer shippingClassId;
    @SerializedName("shipping_required")
    @Expose
    private Boolean shippingRequired;
    @SerializedName("shipping_taxable")
    @Expose
    private Boolean shippingTaxable;
    @SerializedName("short_description")
    @Expose
    private String shortDescription;
    @SerializedName("sku")
    @Expose
    private String sku;
    @SerializedName("slug")
    @Expose
    private String slug;
    @SerializedName("sold_individually")
    @Expose
    private Boolean soldIndividually;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("stock_quantity")
    @Expose
    private Integer stockQuantity;
    @SerializedName("tags")
    @Expose
    private List<Tag> tags = new ArrayList();
    @SerializedName("tax_class")
    @Expose
    private String taxClass;
    @SerializedName("tax_status")
    @Expose
    private String taxStatus;
    @SerializedName("total_sales")
    @Expose
    private Integer totalSales;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("upsell_ids")
    @Expose
    private List<Integer> upsellIds = new ArrayList();
    @SerializedName("variations")
    @Expose
    private List<Integer> variations = new ArrayList();
    @SerializedName("virtual")
    @Expose
    private Boolean virtual;
    @SerializedName("weight")
    @Expose
    private String weight;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer num) {
        this.id = num;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getSlug() {
        return this.slug;
    }

    public void setSlug(String str) {
        this.slug = str;
    }

    public String getPermalink() {
        return this.permalink;
    }

    public void setPermalink(String str) {
        this.permalink = str;
    }

    public String getDateCreated() {
        return this.dateCreated;
    }

    public void setDateCreated(String str) {
        this.dateCreated = str;
    }

    public String getDateModified() {
        return this.dateModified;
    }

    public void setDateModified(String str) {
        this.dateModified = str;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String str) {
        this.type = str;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public Boolean getFeatured() {
        return this.featured;
    }

    public void setFeatured(Boolean bool) {
        this.featured = bool;
    }

    public String getCatalogVisibility() {
        return this.catalogVisibility;
    }

    public void setCatalogVisibility(String str) {
        this.catalogVisibility = str;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String str) {
        this.description = str;
    }

    public String getShortDescription() {
        return this.shortDescription;
    }

    public void setShortDescription(String str) {
        this.shortDescription = str;
    }

    public String getSku() {
        return this.sku;
    }

    public void setSku(String str) {
        this.sku = str;
    }

    public float getPrice() {
        if (this.price.isEmpty()) {
            return 0.0f;
        }
        return Float.parseFloat(this.price);
    }

    public void setPrice(String str) {
        this.price = str;
    }

    public float getRegularPrice() {
        return Float.parseFloat(this.regularPrice);
    }

    public void setRegularPrice(String str) {
        this.regularPrice = str;
    }

    public float getSalePrice() {
        return Float.parseFloat(this.salePrice);
    }

    public void setSalePrice(String str) {
        this.salePrice = str;
    }

    public String getDateOnSaleFrom() {
        return this.dateOnSaleFrom;
    }

    public void setDateOnSaleFrom(String str) {
        this.dateOnSaleFrom = str;
    }

    public String getDateOnSaleTo() {
        return this.dateOnSaleTo;
    }

    public void setDateOnSaleTo(String str) {
        this.dateOnSaleTo = str;
    }

    public String getPriceHtml() {
        return this.priceHtml;
    }

    public void setPriceHtml(String str) {
        this.priceHtml = str;
    }

    public Boolean getOnSale() {
        boolean z = this.onSale.booleanValue() && !this.salePrice.isEmpty();
        return Boolean.valueOf(z);
    }

    public void setOnSale(Boolean bool) {
        this.onSale = bool;
    }

    public Boolean getPurchasable() {
        return this.purchasable;
    }

    public void setPurchasable(Boolean bool) {
        this.purchasable = bool;
    }

    public Integer getTotalSales() {
        return this.totalSales;
    }

    public void setTotalSales(Integer num) {
        this.totalSales = num;
    }

    public Boolean getVirtual() {
        return this.virtual;
    }

    public void setVirtual(Boolean bool) {
        this.virtual = bool;
    }

    public Boolean getDownloadable() {
        return this.downloadable;
    }

    public void setDownloadable(Boolean bool) {
        this.downloadable = bool;
    }

    public List<Object> getDownloads() {
        return this.downloads;
    }

    public void setDownloads(List<Object> list) {
        this.downloads = list;
    }

    public Integer getDownloadLimit() {
        return this.downloadLimit;
    }

    public void setDownloadLimit(Integer num) {
        this.downloadLimit = num;
    }

    public Integer getDownloadExpiry() {
        return this.downloadExpiry;
    }

    public void setDownloadExpiry(Integer num) {
        this.downloadExpiry = num;
    }

    public String getDownloadType() {
        return this.downloadType;
    }

    public void setDownloadType(String str) {
        this.downloadType = str;
    }

    public String getExternalUrl() {
        return this.externalUrl;
    }

    public void setExternalUrl(String str) {
        this.externalUrl = str;
    }

    public String getButtonText() {
        return this.buttonText;
    }

    public void setButtonText(String str) {
        this.buttonText = str;
    }

    public String getTaxStatus() {
        return this.taxStatus;
    }

    public void setTaxStatus(String str) {
        this.taxStatus = str;
    }

    public String getTaxClass() {
        return this.taxClass;
    }

    public void setTaxClass(String str) {
        this.taxClass = str;
    }

    public Boolean getManageStock() {
        return this.manageStock;
    }

    public void setManageStock(Boolean bool) {
        this.manageStock = bool;
    }

    public Integer getStockQuantity() {
        return this.stockQuantity;
    }

    public void setStockQuantity(Integer num) {
        this.stockQuantity = num;
    }

    public Boolean getInStock() {
        return this.inStock;
    }

    public void setInStock(Boolean bool) {
        this.inStock = bool;
    }

    public String getBackorders() {
        return this.backorders;
    }

    public void setBackorders(String str) {
        this.backorders = str;
    }

    public Boolean getBackordersAllowed() {
        return this.backordersAllowed;
    }

    public void setBackordersAllowed(Boolean bool) {
        this.backordersAllowed = bool;
    }

    public Boolean getBackordered() {
        return this.backordered;
    }

    public void setBackordered(Boolean bool) {
        this.backordered = bool;
    }

    public Boolean getSoldIndividually() {
        return this.soldIndividually;
    }

    public void setSoldIndividually(Boolean bool) {
        this.soldIndividually = bool;
    }

    public String getWeight() {
        return this.weight;
    }

    public void setWeight(String str) {
        this.weight = str;
    }

    public Dimensions getDimensions() {
        return this.dimensions;
    }

    public void setDimensions(Dimensions dimensions) {
        this.dimensions = dimensions;
    }

    public Boolean getShippingRequired() {
        return this.shippingRequired;
    }

    public void setShippingRequired(Boolean bool) {
        this.shippingRequired = bool;
    }

    public Boolean getShippingTaxable() {
        return this.shippingTaxable;
    }

    public void setShippingTaxable(Boolean bool) {
        this.shippingTaxable = bool;
    }

    public String getShippingClass() {
        return this.shippingClass;
    }

    public void setShippingClass(String str) {
        this.shippingClass = str;
    }

    public Integer getShippingClassId() {
        return this.shippingClassId;
    }

    public void setShippingClassId(Integer num) {
        this.shippingClassId = num;
    }

    public Boolean getReviewsAllowed() {
        return this.reviewsAllowed;
    }

    public void setReviewsAllowed(Boolean bool) {
        this.reviewsAllowed = bool;
    }

    public String getAverageRating() {
        return this.averageRating;
    }

    public void setAverageRating(String str) {
        this.averageRating = str;
    }

    public Integer getRatingCount() {
        return this.ratingCount;
    }

    public void setRatingCount(Integer num) {
        this.ratingCount = num;
    }

    public List<Integer> getRelatedIds() {
        return this.relatedIds;
    }

    public void setRelatedIds(List<Integer> list) {
        this.relatedIds = list;
    }

    public List<Integer> getUpsellIds() {
        return this.upsellIds;
    }

    public void setUpsellIds(List<Integer> list) {
        this.upsellIds = list;
    }

    public List<Integer> getCrossSellIds() {
        return this.crossSellIds;
    }

    public void setCrossSellIds(List<Integer> list) {
        this.crossSellIds = list;
    }

    public Integer getParentId() {
        return this.parentId;
    }

    public void setParentId(Integer num) {
        this.parentId = num;
    }

    public String getPurchaseNote() {
        return this.purchaseNote;
    }

    public void setPurchaseNote(String str) {
        this.purchaseNote = str;
    }

    public List<Category> getCategories() {
        return this.categories;
    }

    public void setCategories(List<Category> list) {
        this.categories = list;
    }

    public List<Tag> getTags() {
        return this.tags;
    }

    public void setTags(List<Tag> list) {
        this.tags = list;
    }

    public List<Image> getImages() {
        return this.images;
    }

    public void setImages(List<Image> list) {
        this.images = list;
    }

    public List<Attribute> getAttributes() {
        return this.attributes;
    }

    public void setAttributes(List<Attribute> list) {
        this.attributes = list;
    }

    public List<Attribute> getDefaultAttributes() {
        return this.defaultAttributes;
    }

    public void setDefaultAttributes(List<Attribute> list) {
        this.defaultAttributes = list;
    }

    public List<Integer> getVariations() {
        return this.variations;
    }

    public void setVariations(List<Integer> list) {
        this.variations = list;
    }

    public List<Object> getGroupedProducts() {
        return this.groupedProducts;
    }

    public void setGroupedProducts(List<Object> list) {
        this.groupedProducts = list;
    }

    public Integer getMenuOrder() {
        return this.menuOrder;
    }

    public void setMenuOrder(Integer num) {
        this.menuOrder = num;
    }

    public Product(List<Image> list, String str, String str2) {
        this.images = list;
        this.name = str;
        this.price = str2;
    }
}
