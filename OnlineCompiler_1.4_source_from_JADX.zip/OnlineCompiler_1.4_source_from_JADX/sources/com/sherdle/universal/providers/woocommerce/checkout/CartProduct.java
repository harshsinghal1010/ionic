package com.sherdle.universal.providers.woocommerce.checkout;

import com.sherdle.universal.providers.woocommerce.model.products.Product;
import java.io.Serializable;

public class CartProduct implements Serializable {
    private Product product;
    private int quantity;
    private Product variation;

    public CartProduct(Product product, Product product2) {
        this.product = product;
        this.quantity = 1;
        this.variation = product2;
    }

    public CartProduct(Product product) {
        this.product = product;
        this.quantity = 1;
        this.variation = null;
    }

    void updateQuantity(int i) {
        this.quantity += i;
    }

    void setQuantity(int i) {
        this.quantity = i;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public Product getVariation() {
        return this.variation;
    }

    public Product getProduct() {
        return this.product;
    }
}
