package com.sherdle.universal.providers.woocommerce.interceptor;

public interface TimestampService {
    String getNonce();

    String getTimestampInSeconds();
}
