package com.sherdle.universal.providers.woocommerce.interceptor;

import java.net.URLDecoder;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class OAuthEncoder {
    private static String CHARSET = "UTF-8";
    private static final Map<String, String> ENCODING_RULES;

    public static java.lang.String encode(java.lang.String r3) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:10:0x0048 in {5, 6, 9} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = CHARSET;	 Catch:{ UnsupportedEncodingException -> 0x002e }
        r3 = java.net.URLEncoder.encode(r3, r0);	 Catch:{ UnsupportedEncodingException -> 0x002e }
        r0 = ENCODING_RULES;
        r0 = r0.entrySet();
        r0 = r0.iterator();
    L_0x0010:
        r1 = r0.hasNext();
        if (r1 == 0) goto L_0x002d;
    L_0x0016:
        r1 = r0.next();
        r1 = (java.util.Map.Entry) r1;
        r2 = r1.getKey();
        r2 = (java.lang.String) r2;
        r1 = r1.getValue();
        r1 = (java.lang.String) r1;
        r3 = applyRule(r3, r2, r1);
        goto L_0x0010;
    L_0x002d:
        return r3;
    L_0x002e:
        r3 = move-exception;
        r0 = new com.sherdle.universal.providers.woocommerce.interceptor.OAuthException;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Charset not found while encoding string: ";
        r1.append(r2);
        r2 = CHARSET;
        r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1, r3);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.woocommerce.interceptor.OAuthEncoder.encode(java.lang.String):java.lang.String");
    }

    static {
        Map hashMap = new HashMap();
        hashMap.put("*", "%2A");
        hashMap.put("+", "%20");
        hashMap.put("%7E", "~");
        ENCODING_RULES = Collections.unmodifiableMap(hashMap);
    }

    private OAuthEncoder() {
    }

    private static String applyRule(String str, String str2, String str3) {
        return str.replaceAll(Pattern.quote(str2), str3);
    }

    public static String decode(String str) {
        try {
            return URLDecoder.decode(str, CHARSET);
        } catch (String str2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Charset not found while decoding string: ");
            stringBuilder.append(CHARSET);
            throw new OAuthException(stringBuilder.toString(), str2);
        }
    }
}
