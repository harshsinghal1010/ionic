package com.sherdle.universal.providers.woocommerce.ui;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.SearchView.OnQueryTextListener;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.C0361C;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.providers.woocommerce.WooCommerceProductFilter;
import com.sherdle.universal.providers.woocommerce.WooCommerceTask.Callback;
import com.sherdle.universal.providers.woocommerce.WooCommerceTask.WooCommerceBuilder;
import com.sherdle.universal.providers.woocommerce.adapter.ProductsAdapter;
import com.sherdle.universal.providers.woocommerce.model.RestAPI;
import com.sherdle.universal.providers.woocommerce.model.products.Category;
import com.sherdle.universal.providers.woocommerce.model.products.Image;
import com.sherdle.universal.providers.woocommerce.model.products.Product;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import com.sherdle.universal.util.ViewModeUtils;
import com.sherdle.universal.util.layout.StaggeredGridSpacingItemDecoration;
import com.squareup.picasso.Picasso;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jsoup.helper.StringUtil;

public class WooCommerceFragment extends Fragment implements Callback<Product>, LoadMoreListener {
    private static final String FEATURED = "featured";
    private static final String HOME = "home";
    private static final String SALE = "sale";
    private int category;
    private WooCommerceProductFilter filter;
    private List<String> headerImages;
    private boolean isHomePage = false;
    private Activity mAct;
    private int page = 1;
    private List<Product> productList;
    private ProductsAdapter productsAdapter;
    private RecyclerView recyclerView;
    private MenuItem searchMenu;
    private String searchQuery;
    private SearchView searchView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ViewModeUtils viewModeUtils;

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.WooCommerceFragment$3 */
    class C06793 implements OnAttachStateChangeListener {
        public void onViewAttachedToWindow(View view) {
        }

        C06793() {
        }

        public void onViewDetachedFromWindow(View view) {
            WooCommerceFragment.this.searchQuery = null;
            WooCommerceFragment.this.updateHeaders();
            WooCommerceFragment.this.refreshItems();
        }
    }

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.WooCommerceFragment$5 */
    class C06815 implements OnClickListener {
        C06815() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            dialogInterface.dismiss();
        }
    }

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.WooCommerceFragment$9 */
    class C06859 implements View.OnClickListener {
        C06859() {
        }

        public void onClick(View view) {
            WooCommerceFragment.this.showFilterDialog();
        }
    }

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.WooCommerceFragment$1 */
    class C10071 implements OnRefreshListener {
        C10071() {
        }

        public void onRefresh() {
            WooCommerceFragment.this.refreshItems();
        }
    }

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.WooCommerceFragment$2 */
    class C10082 implements OnQueryTextListener {
        public boolean onQueryTextChange(String str) {
            return false;
        }

        C10082() {
        }

        public boolean onQueryTextSubmit(String str) {
            try {
                str = URLEncoder.encode(str, C0361C.UTF8_NAME);
            } catch (Exception e) {
                Log.printStackTrace(e);
            }
            WooCommerceFragment.this.searchView.clearFocus();
            WooCommerceFragment.this.searchQuery = str;
            WooCommerceFragment.this.refreshItems();
            WooCommerceFragment.this.updateHeaders();
            return true;
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_list_refresh, viewGroup, false);
    }

    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        setHasOptionsMenu(true);
        this.recyclerView = (RecyclerView) view.findViewById(R.id.list);
        this.swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipeRefreshLayout);
        this.productList = new ArrayList();
        this.productsAdapter = new ProductsAdapter(getContext(), this.productList, this);
        this.productsAdapter.setModeAndNotify(3);
        this.recyclerView.setAdapter(this.productsAdapter);
        this.mAct = getActivity();
        this.filter = new WooCommerceProductFilter();
        view = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        if (view.length > 0 && view[0].matches("^-?\\d+$")) {
            this.category = Integer.parseInt(view[0]);
        } else if (view.length > 0 && view[0].equals(HOME)) {
            this.isHomePage = true;
        } else if (view.length > 0 && view[0].equals(FEATURED)) {
            this.filter.onlyFeatured(true);
        } else if (view.length > 0 && view[0].equals(SALE)) {
            this.filter.onlySale(true);
        }
        this.headerImages = new ArrayList();
        if (view.length > 1 && view[1].startsWith("http")) {
            this.headerImages.add(view[1]);
            if (view.length > 2 && view[2].startsWith("http")) {
                this.headerImages.add(view[2]);
            }
        }
        setViewMode();
        this.recyclerView.addItemDecoration(new StaggeredGridSpacingItemDecoration((int) getResources().getDimension(R.dimen.woocommerce_padding), true));
        this.recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.recyclerView.setBackgroundColor(getResources().getColor(R.color.white));
        if (getString(R.string.woocommerce_url).isEmpty() == null) {
            if (getString(R.string.woocommerce_url).startsWith("http") != null) {
                refreshItems();
                updateHeaders();
                this.swipeRefreshLayout.setOnRefreshListener(new C10071());
                return;
            }
        }
        Toast.makeText(this.mAct, "You need to enter a valid WooCommerce url and API tokens as documented!", 0).show();
    }

    public void success(ArrayList<Product> arrayList) {
        if (arrayList.size() > 0) {
            this.productList.addAll(arrayList);
        } else {
            this.productsAdapter.setHasMore(false);
        }
        this.productsAdapter.setModeAndNotify(1);
        this.swipeRefreshLayout.setRefreshing(false);
    }

    public void failed() {
        this.productsAdapter.setModeAndNotify(2);
        this.swipeRefreshLayout.setRefreshing(false);
    }

    private void refreshItems() {
        this.page = 1;
        this.productList.clear();
        this.filter.clearFilters();
        this.productsAdapter.setHasMore(true);
        this.productsAdapter.setModeAndNotify(3);
        requestItems();
    }

    public void onMoreRequested() {
        this.page++;
        requestItems();
    }

    private void requestItems() {
        WooCommerceBuilder wooCommerceBuilder = new WooCommerceBuilder(this.mAct);
        String str = this.searchQuery;
        if (str != null) {
            wooCommerceBuilder.getProductsForQuery(this, str, this.page, this.filter).execute(new Void[0]);
            return;
        }
        int i = this.category;
        if (i != 0) {
            wooCommerceBuilder.getProductsForCategory(this, i, this.page, this.filter).execute(new Void[0]);
        } else {
            wooCommerceBuilder.getProducts(this, this.page, this.filter).execute(new Void[0]);
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.woocommerce_menu, menu);
        this.searchView = new SearchView(getActivity());
        this.searchView.setQueryHint(getResources().getString(R.string.search_hint));
        this.searchView.setOnQueryTextListener(new C10082());
        this.searchView.addOnAttachStateChangeListener(new C06793());
        this.searchMenu = menu.findItem(R.id.menu_search);
        this.searchMenu.setActionView(this.searchView);
        if (((this.searchQuery == null ? true : null) & this.isHomePage) != null) {
            this.searchMenu.setVisible(false);
        }
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.menu_cart) {
            HolderActivity.startActivity(getActivity(), CartFragment.class, null);
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void showFilterDialog() {
        Builder builder = new Builder(this.mAct);
        View inflate = this.mAct.getLayoutInflater().inflate(R.layout.fragment_wc_filter_dialog, null);
        final EditText editText = (EditText) inflate.findViewById(R.id.min_price);
        final EditText editText2 = (EditText) inflate.findViewById(R.id.max_price);
        final CheckBox checkBox = (CheckBox) inflate.findViewById(R.id.checkbox_sale);
        final CheckBox checkBox2 = (CheckBox) inflate.findViewById(R.id.checkbox_featured);
        TextView textView = (TextView) inflate.findViewById(R.id.currency_min_price);
        ((TextView) inflate.findViewById(R.id.currency_max_price)).setText(String.format(RestAPI.getCurrencyFormat(), new Object[]{""}));
        textView.setText(String.format(RestAPI.getCurrencyFormat(), new Object[]{""}));
        if (this.filter.getMinPrice() != 0.0d) {
            editText.setText(Double.toString(this.filter.getMinPrice()));
        }
        if (this.filter.getMaxPrice() != 0.0d) {
            editText2.setText(Double.toString(this.filter.getMaxPrice()));
        }
        if (this.filter.isOnlySale()) {
            checkBox.setChecked(true);
        }
        if (this.filter.isOnlyFeatured()) {
            checkBox2.setChecked(true);
        }
        builder.setView(inflate);
        builder.setTitle(getResources().getString(R.string.filter));
        builder.setPositiveButton((int) R.string.ok, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                double d = 0.0d;
                if (editText.getText().toString().isEmpty() != null) {
                    dialogInterface = null;
                } else {
                    dialogInterface = Double.parseDouble(editText.getText().toString());
                }
                if (!editText2.getText().toString().isEmpty()) {
                    d = Double.parseDouble(editText2.getText().toString());
                }
                WooCommerceFragment.this.filter.maxPrice(d).minPrice(dialogInterface).onlyFeatured(checkBox2.isChecked()).onlySale(checkBox.isChecked());
                WooCommerceFragment.this.refreshItems();
            }
        });
        builder.setNegativeButton((int) R.string.cancel, new C06815());
        builder.create().show();
    }

    private int randomGradientResource(int i) {
        i++;
        if (i == 6) {
            i = 1;
        }
        return Helper.getGradient(i);
    }

    public void updateHeaders() {
        this.productsAdapter.clearHeaders();
        int i = 0;
        if (this.searchQuery != null) {
            loadFilterHeader(0);
            return;
        }
        if (this.isHomePage) {
            int i2;
            loadSearchHeader(0);
            if (this.headerImages.size() > 0) {
                loadHeaderImage(1, (String) this.headerImages.get(0), RestAPI.home_banner_one);
                i2 = 2;
            } else {
                i2 = 1;
            }
            loadCategorySlider(i2);
            if (this.headerImages.size() > 1) {
                loadTextHeader(i2, getString(R.string.sale));
                i2++;
                loadHeaderImage(i2, (String) this.headerImages.get(1), RestAPI.home_banner_two);
                i2++;
            }
            loadTextHeader(i2, getString(R.string.latest_products));
        } else {
            if (this.headerImages.size() > 0) {
                loadHeaderImage(0, (String) this.headerImages.get(0), null);
            }
            if (this.headerImages.size() > 0) {
                i = 1;
            }
            loadFilterHeader(i);
        }
    }

    private void loadCategorySlider(final int i) {
        new WooCommerceBuilder(this.mAct).getCategories(new Callback<Category>() {
            public void failed() {
            }

            public void success(ArrayList<Category> arrayList) {
                LayoutInflater from = LayoutInflater.from(WooCommerceFragment.this.mAct);
                ViewGroup viewGroup = (ViewGroup) from.inflate(R.layout.fragment_wc_header_slider, null);
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    View view;
                    final Category category = (Category) it.next();
                    if (category.getImage() == null || !(category.getImage() instanceof JsonObject)) {
                        view = (ViewGroup) from.inflate(R.layout.fragment_wc_category_card_text, null);
                        view.findViewById(R.id.background).setBackgroundResource(WooCommerceFragment.this.randomGradientResource(arrayList.indexOf(category)));
                    } else {
                        view = (ViewGroup) from.inflate(R.layout.fragment_wc_category_card_image, null);
                        Picasso.get().load(((Image) new Gson().fromJson(category.getImage(), Image.class)).getSrc()).into((ImageView) view.findViewById(R.id.image));
                    }
                    ((TextView) view.findViewById(R.id.title)).setText(category.getName());
                    view.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {
                            HolderActivity.startActivity(WooCommerceFragment.this.mAct, WooCommerceFragment.class, new String[]{Integer.toString(category.getId().intValue())});
                        }
                    });
                    ((LinearLayout) viewGroup.findViewById(R.id.slider_content)).addView(view);
                }
                WooCommerceFragment.this.productsAdapter.addHeaderToIndex(viewGroup, i);
                viewGroup.setAlpha(null);
                viewGroup.animate().alpha(1.0f).setDuration(500).start();
            }
        }).execute(new Void[0]);
    }

    private void loadSearchHeader(int i) {
        ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(this.mAct).inflate(R.layout.fragment_wc_header_search, null);
        final EditText editText = (EditText) viewGroup.findViewById(R.id.search_bar);
        editText.setOnEditorActionListener(new OnEditorActionListener() {
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i != 6) {
                    return null;
                }
                WooCommerceFragment.this.searchMenu.setVisible(true);
                WooCommerceFragment.this.searchView.onActionViewExpanded();
                WooCommerceFragment.this.searchMenu.expandActionView();
                WooCommerceFragment.this.searchView.setQuery(editText.getText(), true);
                return true;
            }
        });
        this.productsAdapter.addHeaderToIndex(viewGroup, i);
    }

    private void loadHeaderImage(int i, String str, final String str2) {
        if (str != null) {
            ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(this.mAct).inflate(R.layout.fragment_wc_header_image, null);
            Picasso.get().load(str).into((ImageView) viewGroup.findViewById(R.id.header_image));
            viewGroup.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if (StringUtil.isBlank(str2) == null) {
                        HolderActivity.startActivity(WooCommerceFragment.this.mAct, WooCommerceFragment.class, new String[]{str2});
                    }
                }
            });
            this.productsAdapter.addHeaderToIndex(viewGroup, i);
        }
    }

    private void loadTextHeader(int i, String str) {
        ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(this.mAct).inflate(R.layout.fragment_wc_header_text, null);
        ((TextView) viewGroup.findViewById(R.id.text)).setText(str);
        this.productsAdapter.addHeaderToIndex(viewGroup, i);
    }

    private void loadFilterHeader(int i) {
        ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(this.mAct).inflate(R.layout.fragment_wc_filter_header, null);
        final ImageButton imageButton = (ImageButton) viewGroup.findViewById(R.id.normal);
        final ImageButton imageButton2 = (ImageButton) viewGroup.findViewById(R.id.compact);
        updateViewModeButtons(imageButton, imageButton2);
        ((Button) viewGroup.findViewById(R.id.filter)).setOnClickListener(new C06859());
        View.OnClickListener anonymousClass10 = new View.OnClickListener() {
            public void onClick(View view) {
                WooCommerceFragment.this.viewModeUtils.saveToPreferences(view.equals(imageButton2) ^ 1);
                WooCommerceFragment.this.setViewMode();
                WooCommerceFragment.this.updateViewModeButtons(imageButton, imageButton2);
            }
        };
        imageButton.setOnClickListener(anonymousClass10);
        imageButton2.setOnClickListener(anonymousClass10);
        this.productsAdapter.addHeaderToIndex(viewGroup, i);
    }

    private void setViewMode() {
        int i;
        if (this.viewModeUtils == null) {
            this.viewModeUtils = new ViewModeUtils(getContext(), getClass());
        }
        if (this.viewModeUtils.getViewMode() != 0) {
            if (!this.isHomePage || this.searchQuery != null) {
                i = 1;
                this.recyclerView.setLayoutManager(new StaggeredGridLayoutManager(i, 1));
            }
        }
        i = 2;
        this.recyclerView.setLayoutManager(new StaggeredGridLayoutManager(i, 1));
    }

    private void updateViewModeButtons(View view, View view2) {
        if (this.viewModeUtils.getViewMode() == 1) {
            view.setAlpha(1.0f);
            view2.setAlpha(0.5f);
            return;
        }
        view.setAlpha(0.5f);
        view2.setAlpha(1.0f);
    }
}
