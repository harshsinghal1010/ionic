package com.sherdle.universal.providers.woocommerce.checkout;

import com.sherdle.universal.providers.woocommerce.model.RestAPI;
import java.text.DecimalFormat;

public class PriceFormat {
    private static String priceWithDecimal(Float f) {
        return new DecimalFormat("###,###,###.00").format(f);
    }

    private static String priceWithoutDecimal(Float f) {
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###.##");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(decimalFormat.format(f));
        stringBuilder.append(",-");
        return stringBuilder.toString();
    }

    public static String formatDecimal(Float f) {
        if (priceWithoutDecimal(f).indexOf(".") > 0) {
            return priceWithDecimal(f);
        }
        return priceWithoutDecimal(f);
    }

    public static String formatPrice(Float f) {
        return String.format(RestAPI.getCurrencyFormat(), new Object[]{formatDecimal(f)});
    }
}
