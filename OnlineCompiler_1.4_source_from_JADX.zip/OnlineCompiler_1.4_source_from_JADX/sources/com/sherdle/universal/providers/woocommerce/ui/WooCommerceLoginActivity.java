package com.sherdle.universal.providers.woocommerce.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewPropertyAnimator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.providers.woocommerce.WooCommerceTask;
import com.sherdle.universal.providers.woocommerce.WooCommerceTask.WooCommerceBuilder;
import com.sherdle.universal.providers.woocommerce.model.CredentialStorage;
import com.sherdle.universal.providers.woocommerce.model.RestAPI;
import com.sherdle.universal.providers.woocommerce.model.users.User;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody.Builder;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class WooCommerceLoginActivity extends AppCompatActivity {
    private OkHttpClient client;
    private EditText mEmailView;
    private View mLoginFormView;
    private EditText mPasswordView;
    private View mProgressView;

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.WooCommerceLoginActivity$1 */
    class C06861 implements OnEditorActionListener {
        C06861() {
        }

        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            if (i != 6) {
                if (i != 0) {
                    return null;
                }
            }
            WooCommerceLoginActivity.this.attemptLogin();
            return true;
        }
    }

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.WooCommerceLoginActivity$2 */
    class C06872 implements OnClickListener {
        C06872() {
        }

        public void onClick(View view) {
            view = new RestAPI(WooCommerceLoginActivity.this);
            Context context = WooCommerceLoginActivity.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(view.getHost());
            stringBuilder.append(view.getRegister());
            HolderActivity.startWebViewActivity(context, stringBuilder.toString(), true, false, null);
        }
    }

    /* renamed from: com.sherdle.universal.providers.woocommerce.ui.WooCommerceLoginActivity$3 */
    class C06883 implements OnClickListener {
        C06883() {
        }

        public void onClick(View view) {
            WooCommerceLoginActivity.this.attemptLogin();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_woocommerce_login);
        this.mEmailView = (EditText) findViewById(R.id.user);
        this.mPasswordView = (EditText) findViewById(R.id.password);
        this.mPasswordView.setOnEditorActionListener(new C06861());
        Button button = (Button) findViewById(R.id.user_sign_in_button);
        ((TextView) findViewById(R.id.user_register_button)).setOnClickListener(new C06872());
        button.setOnClickListener(new C06883());
        this.mLoginFormView = findViewById(R.id.login_form);
        this.mProgressView = findViewById(R.id.login_progress);
    }

    private void attemptLogin() {
        Object obj;
        View view = null;
        this.mEmailView.setError(null);
        this.mPasswordView.setError(null);
        String obj2 = this.mEmailView.getText().toString();
        String obj3 = this.mPasswordView.getText().toString();
        if (TextUtils.isEmpty(obj3) || isPasswordValid(obj3)) {
            obj = null;
        } else {
            this.mPasswordView.setError(getString(R.string.error_invalid_password));
            view = this.mPasswordView;
            obj = 1;
        }
        if (TextUtils.isEmpty(obj2)) {
            this.mEmailView.setError(getString(R.string.error_field_required));
            view = this.mEmailView;
            obj = 1;
        } else if (!isEmailValid(obj2)) {
            this.mEmailView.setError(getString(R.string.error_invalid_email));
            view = this.mEmailView;
            obj = 1;
        }
        if (obj != null) {
            view.requestFocus();
            return;
        }
        showProgress(true);
        attemptLogin(obj2, obj3);
    }

    private boolean isEmailValid(String str) {
        return (!str.contains("@") || str.contains(".") == null) ? null : true;
    }

    private boolean isPasswordValid(String str) {
        return str.length() > 3 ? true : null;
    }

    @TargetApi(13)
    private void showProgress(final boolean z) {
        int i = 0;
        if (VERSION.SDK_INT >= 13) {
            int integer = getResources().getInteger(17694720);
            this.mLoginFormView.setVisibility(z ? 8 : 0);
            long j = (long) integer;
            float f = 0.0f;
            this.mLoginFormView.animate().setDuration(j).alpha(z ? 0.0f : 1.0f).setListener(new AnimatorListenerAdapter() {
                public void onAnimationEnd(Animator animator) {
                    WooCommerceLoginActivity.this.mLoginFormView.setVisibility(z ? 8 : 0);
                }
            });
            View view = this.mProgressView;
            if (!z) {
                i = 8;
            }
            view.setVisibility(i);
            ViewPropertyAnimator duration = this.mProgressView.animate().setDuration(j);
            if (z) {
                f = 1.0f;
            }
            duration.alpha(f).setListener(new AnimatorListenerAdapter() {
                public void onAnimationEnd(Animator animator) {
                    WooCommerceLoginActivity.this.mProgressView.setVisibility(z ? 0 : 8);
                }
            });
            return;
        }
        this.mProgressView.setVisibility(z ? 0 : 8);
        view = this.mLoginFormView;
        if (z) {
            i = 8;
        }
        view.setVisibility(i);
    }

    void attemptLogin(final String str, final String str2) {
        RequestBody build = new Builder().add("log", str).add("pwd", str2).build();
        final RestAPI restAPI = new RestAPI(getApplication());
        Request.Builder builder = new Request.Builder();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(restAPI.getHost());
        stringBuilder.append(restAPI.getLogin());
        Request build2 = builder.url(stringBuilder.toString()).post(build).build();
        stringBuilder = new StringBuilder();
        stringBuilder.append("Requesting: ");
        stringBuilder.append(build2.url());
        Log.m160i("INFO", stringBuilder.toString());
        new OkHttpClient.Builder().connectTimeout(25, TimeUnit.SECONDS).writeTimeout(25, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build().newCall(build2).enqueue(new Callback() {

            /* renamed from: com.sherdle.universal.providers.woocommerce.ui.WooCommerceLoginActivity$6$1 */
            class C06911 implements Runnable {
                C06911() {
                }

                public void run() {
                    Helper.isOnlineShowDialog(WooCommerceLoginActivity.this);
                }
            }

            public void onFailure(Call call, IOException iOException) {
                iOException.printStackTrace();
                WooCommerceLoginActivity.this.runOnUiThread(new C06911());
                WooCommerceLoginActivity.this.loginAttemptCompleted(Boolean.valueOf(null));
            }

            public void onResponse(Call call, Response response) throws IOException {
                response.close();
                Call<String> values = response.headers().values("Set-Cookie");
                for (String str : values) {
                    Log.m160i("Cookie", str);
                    if (str.startsWith(restAPI.getLoginCookie())) {
                        WooCommerceLoginActivity.this.retrieveUserData(str, str2);
                        return;
                    }
                }
                if (values.size() == null) {
                    WooCommerceDebugDialog.showDialogIfNoCookies(WooCommerceLoginActivity.this);
                }
                WooCommerceLoginActivity.this.loginAttemptCompleted(Boolean.valueOf(null));
            }
        });
    }

    public void retrieveUserData(final String str, final String str2) {
        new WooCommerceBuilder(this).getUsers(new WooCommerceTask.Callback<User>() {
            public void success(ArrayList<User> arrayList) {
                if (arrayList.size() == 1) {
                    User user = (User) arrayList.get(0);
                    CredentialStorage.saveCredentials(WooCommerceLoginActivity.this, str, str2, user.getId().intValue(), user.getFirstName());
                    WooCommerceLoginActivity.this.loginAttemptCompleted(Boolean.valueOf(true));
                    return;
                }
                if (arrayList.size() == null) {
                    Log.m158e("INFO", "No Customers found with this email. Perhaps this person is a user, but not a customer");
                } else {
                    Log.m158e("INFO", "More than 1 Customer found with this email");
                }
                WooCommerceLoginActivity.this.loginAttemptCompleted(Boolean.valueOf(false));
            }

            public void failed() {
                WooCommerceLoginActivity.this.loginAttemptCompleted(Boolean.valueOf(false));
            }
        }, str).execute(new Void[null]);
    }

    public void loginAttemptCompleted(final Boolean bool) {
        runOnUiThread(new Runnable() {
            public void run() {
                WooCommerceLoginActivity.this.showProgress(false);
                if (bool.booleanValue()) {
                    WooCommerceLoginActivity.this.finish();
                    return;
                }
                WooCommerceLoginActivity.this.mEmailView.setError(WooCommerceLoginActivity.this.getString(R.string.error_incorrect_credentials));
                WooCommerceLoginActivity.this.mPasswordView.setError(WooCommerceLoginActivity.this.getString(R.string.error_incorrect_credentials));
                WooCommerceLoginActivity.this.mPasswordView.requestFocus();
            }
        });
    }
}
