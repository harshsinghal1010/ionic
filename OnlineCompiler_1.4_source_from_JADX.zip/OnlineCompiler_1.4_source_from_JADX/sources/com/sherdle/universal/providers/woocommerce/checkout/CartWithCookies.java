package com.sherdle.universal.providers.woocommerce.checkout;

import android.content.Context;
import com.sherdle.universal.providers.woocommerce.model.CredentialStorage;
import com.sherdle.universal.providers.woocommerce.model.RestAPI;
import com.sherdle.universal.util.Log;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.FormBody.Builder;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class CartWithCookies {
    private static OkHttpClient client;
    private AllProductsAddedCallback allProductsAddedCallback;
    private Context mContext;
    private final List<Cookie> mCookieStore = new ArrayList();
    private CookieJar mCookies;
    private ProductAddedCallback productAddedCallBack;

    public interface AllProductsAddedCallback {
        void failure();

        void success(List<Cookie> list);
    }

    private interface ProductAddedCallback {
        void failure();

        void success(CartProduct cartProduct);
    }

    /* renamed from: com.sherdle.universal.providers.woocommerce.checkout.CartWithCookies$1 */
    class C10001 implements CookieJar {
        C10001() {
        }

        public void saveFromResponse(HttpUrl httpUrl, List<Cookie> list) {
            for (Cookie cookie : list) {
                Object obj = null;
                ListIterator listIterator = CartWithCookies.this.mCookieStore.listIterator();
                while (listIterator.hasNext()) {
                    if (cookie.name().equals(((Cookie) listIterator.next()).name())) {
                        listIterator.set(cookie);
                        obj = 1;
                    }
                }
                if (obj == null) {
                    CartWithCookies.this.mCookieStore.add(cookie);
                }
            }
        }

        public List<Cookie> loadForRequest(HttpUrl httpUrl) {
            return CartWithCookies.this.mCookieStore;
        }
    }

    public CartWithCookies(Context context, AllProductsAddedCallback allProductsAddedCallback) {
        this.mContext = context;
        this.allProductsAddedCallback = allProductsAddedCallback;
        this.mCookies = new C10001();
    }

    private void startProductsToCartLoop(List<CartProduct> list) {
        final List arrayList = new ArrayList(list);
        this.productAddedCallBack = new ProductAddedCallback() {
            public void success(CartProduct cartProduct) {
                arrayList.remove(cartProduct);
                if (arrayList.size() > null) {
                    CartWithCookies.this.addProductToCart((CartProduct) arrayList.get(0), CartWithCookies.this.productAddedCallBack);
                } else {
                    CartWithCookies.this.allProductsAddedCallback.success(CartWithCookies.this.mCookieStore);
                }
            }

            public void failure() {
                CartWithCookies.this.allProductsAddedCallback.failure();
            }
        };
        addProductToCart((CartProduct) arrayList.get(null), this.productAddedCallBack);
    }

    public void addProductsToCart(final List<CartProduct> list) {
        if (CredentialStorage.credentialsAvailable(this.mContext)) {
            RequestBody build = new Builder().add("log", CredentialStorage.getEmail(this.mContext)).add("pwd", CredentialStorage.getPassword(this.mContext)).build();
            RestAPI restAPI = new RestAPI(this.mContext);
            Request.Builder builder = new Request.Builder();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(restAPI.getHost());
            stringBuilder.append(restAPI.getLogin());
            Request build2 = builder.url(stringBuilder.toString()).post(build).build();
            if (client == null) {
                client = new OkHttpClient.Builder().cookieJar(this.mCookies).build();
            }
            client.newCall(build2).enqueue(new Callback() {
                public void onFailure(Call call, IOException iOException) {
                    iOException.printStackTrace();
                    CartWithCookies.this.allProductsAddedCallback.failure();
                }

                public void onResponse(Call call, Response response) throws IOException {
                    CartWithCookies.this.startProductsToCartLoop(list);
                    response.close();
                }
            });
            return;
        }
        startProductsToCartLoop(list);
    }

    private void addProductToCart(final CartProduct cartProduct, final ProductAddedCallback productAddedCallback) {
        Integer id;
        OkHttpClient build = new OkHttpClient.Builder().cookieJar(this.mCookies).build();
        if (cartProduct.getVariation() == null) {
            id = cartProduct.getProduct().getId();
        } else {
            id = cartProduct.getVariation().getId();
        }
        int intValue = id.intValue();
        RestAPI restAPI = new RestAPI(this.mContext);
        Request.Builder builder = new Request.Builder();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(restAPI.getHost());
        stringBuilder.append("?add-to-cart=");
        stringBuilder.append(intValue);
        stringBuilder.append("&quantity=");
        stringBuilder.append(cartProduct.getQuantity());
        build.newCall(builder.url(stringBuilder.toString()).get().build()).enqueue(new Callback() {
            public void onFailure(Call call, IOException iOException) {
                iOException.printStackTrace();
                productAddedCallback.failure();
            }

            public void onResponse(Call call, Response response) throws IOException {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("RESPONSE CODE: ");
                stringBuilder.append(response.code());
                Log.m161v("INFO", stringBuilder.toString());
                productAddedCallback.success(cartProduct);
                response.close();
            }
        });
    }
}
