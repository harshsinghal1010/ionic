package com.sherdle.universal.providers.woocommerce;

import android.content.Context;
import android.os.AsyncTask;
import android.text.TextUtils;
import com.google.gson.Gson;
import com.sherdle.universal.providers.woocommerce.interceptor.OAuthInterceptor;
import com.sherdle.universal.providers.woocommerce.model.RestAPI;
import com.sherdle.universal.providers.woocommerce.model.orders.Order;
import com.sherdle.universal.providers.woocommerce.model.products.Category;
import com.sherdle.universal.providers.woocommerce.model.products.Product;
import com.sherdle.universal.providers.woocommerce.model.users.User;
import com.sherdle.universal.providers.woocommerce.ui.WooCommerceDebugDialog;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request.Builder;
import org.json.JSONArray;
import org.json.JSONException;
import org.jsoup.helper.StringUtil;

public class WooCommerceTask<T> extends AsyncTask<Void, Void, ArrayList<T>> {
    private static int CATEGORIES = 10;
    private static String PARAM_ORDER_BY = "&orderby=id";
    private static String PARAM_PER_PAGE = "?per_page=20";
    private static String PARAM_PUBLISHED = "&status=publish";
    private static OkHttpClient client;
    private RestAPI api;
    private Callback callback;
    private Class type;
    private String url;

    public interface Callback<T> {
        void failed();

        void success(ArrayList<T> arrayList);
    }

    public static class WooCommerceBuilder {
        private RestAPI restAPI;

        public WooCommerceBuilder(Context context) {
            this.restAPI = new RestAPI(context);
        }

        public WooCommerceTask<Product> getProducts(Callback<Product> callback, int i, WooCommerceProductFilter wooCommerceProductFilter) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.restAPI.getHost());
            stringBuilder.append(this.restAPI.getPath());
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("products");
            stringBuilder2 = stringBuilder3.toString();
            stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append(WooCommerceTask.PARAM_PER_PAGE);
            stringBuilder3.append(WooCommerceTask.PARAM_PUBLISHED);
            stringBuilder3.append(WooCommerceTask.PARAM_ORDER_BY);
            stringBuilder3.append("&page=");
            stringBuilder3.append(i);
            stringBuilder3.append(wooCommerceProductFilter.getQuery());
            return new WooCommerceTask(Product.class, callback, stringBuilder3.toString(), this.restAPI);
        }

        public WooCommerceTask<Product> getProductsForCategory(Callback<Product> callback, int i, int i2, WooCommerceProductFilter wooCommerceProductFilter) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.restAPI.getHost());
            stringBuilder.append(this.restAPI.getPath());
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("products");
            stringBuilder2 = stringBuilder3.toString();
            stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append(WooCommerceTask.PARAM_PER_PAGE);
            stringBuilder3.append(WooCommerceTask.PARAM_PUBLISHED);
            stringBuilder3.append(WooCommerceTask.PARAM_ORDER_BY);
            stringBuilder3.append("&page=");
            stringBuilder3.append(i2);
            stringBuilder3.append("&category=");
            stringBuilder3.append(i);
            stringBuilder3.append(wooCommerceProductFilter.getQuery());
            return new WooCommerceTask(Product.class, callback, stringBuilder3.toString(), this.restAPI);
        }

        public WooCommerceTask<Product> getProductsForQuery(Callback<Product> callback, String str, int i, WooCommerceProductFilter wooCommerceProductFilter) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.restAPI.getHost());
            stringBuilder.append(this.restAPI.getPath());
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("products");
            stringBuilder2 = stringBuilder3.toString();
            stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append(WooCommerceTask.PARAM_PER_PAGE);
            stringBuilder3.append(WooCommerceTask.PARAM_PUBLISHED);
            stringBuilder3.append("&page=");
            stringBuilder3.append(i);
            stringBuilder3.append("&search=");
            stringBuilder3.append(str);
            stringBuilder3.append(wooCommerceProductFilter.getQuery());
            return new WooCommerceTask(Product.class, callback, stringBuilder3.toString(), this.restAPI);
        }

        public WooCommerceTask<Category> getCategories(Callback<Category> callback) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.restAPI.getHost());
            stringBuilder.append(this.restAPI.getPath());
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("products/categories");
            stringBuilder2 = stringBuilder3.toString();
            stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("?per_page=");
            stringBuilder3.append(WooCommerceTask.CATEGORIES);
            stringBuilder3.append("&orderby=count&order=desc");
            return new WooCommerceTask(Category.class, callback, stringBuilder3.toString(), this.restAPI);
        }

        public WooCommerceTask<Product> getProductsForIds(Callback<Product> callback, List<Integer> list, int i) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.restAPI.getHost());
            stringBuilder.append(this.restAPI.getPath());
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("products");
            stringBuilder2 = stringBuilder3.toString();
            stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("?page=");
            stringBuilder3.append(i);
            stringBuilder3.append(WooCommerceTask.PARAM_PUBLISHED);
            stringBuilder3.append("&include=");
            stringBuilder3.append(TextUtils.join(",", list));
            return new WooCommerceTask(Product.class, callback, stringBuilder3.toString(), this.restAPI);
        }

        public WooCommerceTask<Product> getVariationsForProduct(Callback<Product> callback, int i) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.restAPI.getHost());
            stringBuilder.append(this.restAPI.getPath());
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("products/");
            stringBuilder3.append(i);
            stringBuilder3.append("/variations");
            i = stringBuilder3.toString();
            stringBuilder = new StringBuilder();
            stringBuilder.append(i);
            stringBuilder.append("?per_page=10");
            return new WooCommerceTask(Product.class, callback, stringBuilder.toString(), this.restAPI);
        }

        public WooCommerceTask<Order> getOrders(Callback<Order> callback, int i, int i2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.restAPI.getHost());
            stringBuilder.append(this.restAPI.getPath());
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("orders?customer=");
            stringBuilder3.append(i);
            stringBuilder3.append("&page=");
            stringBuilder3.append(i2);
            return new WooCommerceTask(Order.class, callback, stringBuilder3.toString(), this.restAPI);
        }

        public WooCommerceTask<User> getUsers(Callback<User> callback, String str) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.restAPI.getHost());
            stringBuilder.append(this.restAPI.getPath());
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("customers?email=");
            stringBuilder3.append(str);
            return new WooCommerceTask(User.class, callback, stringBuilder3.toString(), this.restAPI);
        }
    }

    private WooCommerceTask(Class cls, Callback callback, String str, RestAPI restAPI) {
        this.type = cls;
        this.callback = callback;
        this.url = str;
        this.api = restAPI;
    }

    protected ArrayList<T> doInBackground(Void... voidArr) {
        String response;
        JSONArray jSONArray;
        Exception e;
        int i;
        Product product;
        try {
            response = getResponse(this.url);
            try {
                jSONArray = new JSONArray(response);
            } catch (IOException e2) {
                e = e2;
                e.printStackTrace();
                jSONArray = null;
                if (jSONArray == null) {
                    WooCommerceDebugDialog.showDialogIfAuthFailed(response, this.api.getContext());
                    return null;
                }
                voidArr = new ArrayList();
                for (i = 0; i < jSONArray.length(); i++) {
                    try {
                        if (this.type.equals(Product.class)) {
                            product = (Product) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), Product.class);
                            if (!product.getPurchasable().booleanValue()) {
                            }
                            voidArr.add(product);
                        } else if (this.type.equals(Category.class)) {
                            voidArr.add((Category) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), Category.class));
                        } else if (this.type.equals(Order.class)) {
                            voidArr.add((Order) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), Order.class));
                        } else if (this.type.equals(User.class)) {
                            voidArr.add((User) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), User.class));
                        }
                    } catch (JSONException e3) {
                        e3.printStackTrace();
                    }
                }
                return voidArr;
            }
        } catch (IOException e4) {
            e = e4;
            response = null;
            e.printStackTrace();
            jSONArray = null;
            if (jSONArray == null) {
                WooCommerceDebugDialog.showDialogIfAuthFailed(response, this.api.getContext());
                return null;
            }
            voidArr = new ArrayList();
            for (i = 0; i < jSONArray.length(); i++) {
                if (this.type.equals(Product.class)) {
                    product = (Product) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), Product.class);
                    if (product.getPurchasable().booleanValue()) {
                    }
                    voidArr.add(product);
                } else if (this.type.equals(Category.class)) {
                    voidArr.add((Category) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), Category.class));
                } else if (this.type.equals(Order.class)) {
                    voidArr.add((Order) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), Order.class));
                } else if (this.type.equals(User.class)) {
                    voidArr.add((User) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), User.class));
                }
            }
            return voidArr;
        }
        if (jSONArray == null) {
            WooCommerceDebugDialog.showDialogIfAuthFailed(response, this.api.getContext());
            return null;
        }
        voidArr = new ArrayList();
        for (i = 0; i < jSONArray.length(); i++) {
            if (this.type.equals(Product.class)) {
                product = (Product) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), Product.class);
                if (product.getPurchasable().booleanValue() || !StringUtil.isBlank(product.getExternalUrl())) {
                    voidArr.add(product);
                }
            } else if (this.type.equals(Category.class)) {
                voidArr.add((Category) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), Category.class));
            } else if (this.type.equals(Order.class)) {
                voidArr.add((Order) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), Order.class));
            } else if (this.type.equals(User.class)) {
                voidArr.add((User) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), User.class));
            }
        }
        return voidArr;
    }

    private String getResponse(String str) throws IOException, JSONException {
        client = getRestAPIClient(this.api);
        str = client.newCall(new Builder().url(str).build()).execute();
        str.header("x-wp-totalpages");
        return str.body().string();
    }

    public static OkHttpClient getRestAPIClient(RestAPI restAPI) {
        if (client == null) {
            client = new OkHttpClient.Builder().addInterceptor(new OAuthInterceptor.Builder().consumerKey(restAPI.getCustomerKey()).consumerSecret(restAPI.getCustomerSecret()).build()).connectTimeout(25, TimeUnit.SECONDS).writeTimeout(25, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();
        }
        return client;
    }

    protected void onPostExecute(ArrayList<T> arrayList) {
        if (arrayList != null) {
            this.callback.success(arrayList);
        } else {
            this.callback.failed();
        }
    }
}
