package com.sherdle.universal.providers.woocommerce.interceptor;

public class OAuthException extends RuntimeException {
    private static final long serialVersionUID = 1;

    public OAuthException(String str, Exception exception) {
        super(str, exception);
    }

    public OAuthException(String str) {
        super(str, null);
    }
}
