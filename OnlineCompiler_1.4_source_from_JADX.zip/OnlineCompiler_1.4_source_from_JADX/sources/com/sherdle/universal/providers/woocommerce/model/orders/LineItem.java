package com.sherdle.universal.providers.woocommerce.model.orders;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.List;

public class LineItem {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("meta")
    @Expose
    private List<Object> meta = new ArrayList();
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("price")
    @Expose
    private String price;
    @SerializedName("product_id")
    @Expose
    private Integer productId;
    @SerializedName("quantity")
    @Expose
    private Integer quantity;
    @SerializedName("sku")
    @Expose
    private String sku;
    @SerializedName("subtotal")
    @Expose
    private String subtotal;
    @SerializedName("subtotal_tax")
    @Expose
    private String subtotalTax;
    @SerializedName("tax_class")
    @Expose
    private String taxClass;
    @SerializedName("taxes")
    @Expose
    private List<Object> taxes = new ArrayList();
    @SerializedName("total")
    @Expose
    private String total;
    @SerializedName("total_tax")
    @Expose
    private String totalTax;
    @SerializedName("variation_id")
    @Expose
    private Integer variationId;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer num) {
        this.id = num;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getSku() {
        return this.sku;
    }

    public void setSku(String str) {
        this.sku = str;
    }

    public Integer getProductId() {
        return this.productId;
    }

    public void setProductId(Integer num) {
        this.productId = num;
    }

    public Integer getVariationId() {
        return this.variationId;
    }

    public void setVariationId(Integer num) {
        this.variationId = num;
    }

    public Integer getQuantity() {
        return this.quantity;
    }

    public void setQuantity(Integer num) {
        this.quantity = num;
    }

    public String getTaxClass() {
        return this.taxClass;
    }

    public void setTaxClass(String str) {
        this.taxClass = str;
    }

    public String getPrice() {
        return this.price;
    }

    public void setPrice(String str) {
        this.price = str;
    }

    public String getSubtotal() {
        return this.subtotal;
    }

    public void setSubtotal(String str) {
        this.subtotal = str;
    }

    public String getSubtotalTax() {
        return this.subtotalTax;
    }

    public void setSubtotalTax(String str) {
        this.subtotalTax = str;
    }

    public String getTotal() {
        return this.total;
    }

    public void setTotal(String str) {
        this.total = str;
    }

    public String getTotalTax() {
        return this.totalTax;
    }

    public void setTotalTax(String str) {
        this.totalTax = str;
    }

    public List<Object> getTaxes() {
        return this.taxes;
    }

    public void setTaxes(List<Object> list) {
        this.taxes = list;
    }

    public List<Object> getMeta() {
        return this.meta;
    }

    public void setMeta(List<Object> list) {
        this.meta = list;
    }
}
