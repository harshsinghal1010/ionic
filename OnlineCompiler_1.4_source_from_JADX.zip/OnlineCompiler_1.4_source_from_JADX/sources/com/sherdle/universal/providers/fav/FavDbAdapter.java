package com.sherdle.universal.providers.fav;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.sherdle.universal.util.Log;
import java.io.Serializable;

public class FavDbAdapter {
    private static final String DATABASE_CREATE = "create table notes (_id integer primary key autoincrement, title text not null, obj varbinary not null, cat int not null);";
    private static final String DATABASE_NAME = "data";
    private static final String DATABASE_TABLE = "notes";
    private static final int DATABASE_VERSION = 2;
    public static final String KEY_OBJECT = "obj";
    public static final String KEY_PROVIDER = "cat";
    public static final String KEY_ROWID = "_id";
    public static final int KEY_RSS = 2;
    public static final String KEY_TITLE = "title";
    public static final int KEY_WEB = 3;
    public static final int KEY_WOOCOMMERCE = 5;
    public static final int KEY_WORDPRESS = 1;
    public static final int KEY_YOUTUBE = 4;
    private static final String TAG = "NotesDbAdapter";
    private final Context mCtx;
    private SQLiteDatabase mDb;
    private DatabaseHelper mDbHelper;

    private static class DatabaseHelper extends SQLiteOpenHelper {
        DatabaseHelper(Context context) {
            super(context, "data", null, 2);
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL(FavDbAdapter.DATABASE_CREATE);
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
            String str = FavDbAdapter.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Upgrading database ");
            stringBuilder.append(i);
            stringBuilder.append(" to ");
            stringBuilder.append(i2);
            stringBuilder.append(", all data will be destroyed");
            Log.m162w(str, stringBuilder.toString());
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS notes");
            onCreate(sQLiteDatabase);
        }
    }

    public FavDbAdapter(Context context) {
        this.mCtx = context;
    }

    public com.sherdle.universal.providers.fav.FavDbAdapter open() throws android.database.SQLException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = new com.sherdle.universal.providers.fav.FavDbAdapter$DatabaseHelper;	 Catch:{ Exception -> 0x0012 }
        r1 = r2.mCtx;	 Catch:{ Exception -> 0x0012 }
        r0.<init>(r1);	 Catch:{ Exception -> 0x0012 }
        r2.mDbHelper = r0;	 Catch:{ Exception -> 0x0012 }
        r0 = r2.mDbHelper;	 Catch:{ Exception -> 0x0012 }
        r0 = r0.getWritableDatabase();	 Catch:{ Exception -> 0x0012 }
        r2.mDb = r0;	 Catch:{ Exception -> 0x0012 }
        goto L_0x0019;
    L_0x0012:
        r0 = "NotesDbAdapter";
        r1 = "Exception";
        com.sherdle.universal.util.Log.m162w(r0, r1);
    L_0x0019:
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.fav.FavDbAdapter.open():com.sherdle.universal.providers.fav.FavDbAdapter");
    }

    public void close() {
        this.mDbHelper.close();
    }

    public long addFavorite(String str, Serializable serializable, int i) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", str);
        contentValues.put(KEY_OBJECT, getSerializedObject(serializable));
        contentValues.put(KEY_PROVIDER, Integer.valueOf(i));
        return this.mDb.insert(DATABASE_TABLE, 0, contentValues);
    }

    public boolean deleteFav(long j) {
        SQLiteDatabase sQLiteDatabase = this.mDb;
        String str = DATABASE_TABLE;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("_id=");
        stringBuilder.append(j);
        return sQLiteDatabase.delete(str, stringBuilder.toString(), null) > null ? 1 : 0;
    }

    public void emptyDatabase() {
        this.mDb.delete(DATABASE_TABLE, null, null);
    }

    public Cursor getFavorites() {
        return this.mDb.query(DATABASE_TABLE, new String[]{KEY_ROWID, "title", KEY_OBJECT, KEY_PROVIDER}, null, null, null, null, null);
    }

    public Cursor getFavorite(long j) throws SQLException {
        SQLiteDatabase sQLiteDatabase = this.mDb;
        String str = DATABASE_TABLE;
        String[] strArr = new String[]{KEY_ROWID, "title", KEY_OBJECT, KEY_PROVIDER};
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("_id=");
        stringBuilder.append(j);
        j = sQLiteDatabase.query(true, str, strArr, stringBuilder.toString(), null, null, null, null, null);
        if (j != null) {
            j.moveToFirst();
        }
        return j;
    }

    public boolean checkEvent(String str, Serializable serializable, int i) {
        return this.mDb.query(DATABASE_TABLE, new String[]{"title"}, "title = ?", new String[]{str}, null, null, null).moveToFirst() ^ 1;
    }

    public static byte[] getSerializedObject(java.io.Serializable r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = new java.io.ByteArrayOutputStream;
        r0.<init>();
        r1 = 0;
        r2 = new java.io.ObjectOutputStream;	 Catch:{ IOException -> 0x001e, all -> 0x0019 }
        r2.<init>(r0);	 Catch:{ IOException -> 0x001e, all -> 0x0019 }
        r2.writeObject(r3);	 Catch:{ IOException -> 0x001f, all -> 0x0016 }
        r2.close();	 Catch:{ IOException -> 0x0011 }
    L_0x0011:
        r3 = r0.toByteArray();
        return r3;
    L_0x0016:
        r3 = move-exception;
        r1 = r2;
        goto L_0x001a;
    L_0x0019:
        r3 = move-exception;
    L_0x001a:
        r1.close();	 Catch:{ IOException -> 0x001d }
    L_0x001d:
        throw r3;
    L_0x001e:
        r2 = r1;
    L_0x001f:
        r2.close();	 Catch:{ IOException -> 0x0022 }
    L_0x0022:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.fav.FavDbAdapter.getSerializedObject(java.io.Serializable):byte[]");
    }

    public static java.io.Serializable readSerializedObject(byte[] r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = new java.io.ByteArrayInputStream;
        r0.<init>(r2);
        r2 = 0;
        r1 = new java.io.ObjectInputStream;	 Catch:{ Exception -> 0x001c, all -> 0x0017 }
        r1.<init>(r0);	 Catch:{ Exception -> 0x001c, all -> 0x0017 }
        r2 = r1.readObject();	 Catch:{ Exception -> 0x000f, all -> 0x0013 }
    L_0x000f:
        r1.close();	 Catch:{ Throwable -> 0x001e }
        goto L_0x001e;
    L_0x0013:
        r2 = move-exception;
        r0 = r2;
        r2 = r1;
        goto L_0x0018;
    L_0x0017:
        r0 = move-exception;
    L_0x0018:
        r2.close();	 Catch:{ Throwable -> 0x001b }
    L_0x001b:
        throw r0;
    L_0x001c:
        r1 = r2;
        goto L_0x000f;
    L_0x001e:
        r2 = (java.io.Serializable) r2;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.fav.FavDbAdapter.readSerializedObject(byte[]):java.io.Serializable");
    }
}
