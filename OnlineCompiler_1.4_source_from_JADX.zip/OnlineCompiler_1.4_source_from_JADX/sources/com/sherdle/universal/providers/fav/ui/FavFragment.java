package com.sherdle.universal.providers.fav.ui;

import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.providers.fav.FavDbAdapter;
import com.sherdle.universal.providers.rss.ui.RssDetailActivity;
import com.sherdle.universal.providers.woocommerce.ui.ProductActivity;
import com.sherdle.universal.providers.wordpress.ui.WordpressDetailActivity;
import com.sherdle.universal.providers.youtube.ui.YoutubeDetailActivity;
import com.sherdle.universal.util.ThemeUtils;
import java.io.Serializable;

public class FavFragment extends ListFragment {
    private static final int ACTIVITY_CREATE = 0;
    private static final int ACTIVITY_EDIT = 1;
    private static final int DELETE_ID = 2;
    private static final int INSERT_ID = 1;
    private LinearLayout ll;
    private FavDbAdapter mDbHelper;
    String menu;
    String noconnection;

    /* renamed from: com.sherdle.universal.providers.fav.ui.FavFragment$1 */
    class C05891 implements OnClickListener {
        C05891() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            FavFragment.this.mDbHelper.emptyDatabase();
            FavFragment.this.fillData();
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.ll = (LinearLayout) layoutInflater.inflate(R.layout.fragment_fav, viewGroup, false);
        setHasOptionsMenu(true);
        return this.ll;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mDbHelper = new FavDbAdapter(getActivity());
        this.mDbHelper.open();
        fillData();
        registerForContextMenu(getListView());
    }

    private void fillData() {
        Cursor favorites = this.mDbHelper.getFavorites();
        getActivity().startManagingCursor(favorites);
        setListAdapter(new SimpleCursorAdapter(getActivity(), R.layout.fragment_fav_row, favorites, new String[]{"title"}, new int[]{R.id.text1}));
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.favorite_menu, menu);
        ThemeUtils.tintAllIcons(menu, getActivity());
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != R.id.clear) {
            return super.onOptionsItemSelected(menuItem);
        }
        menuItem = new Builder(getActivity());
        menuItem.setMessage(getResources().getString(R.string.item_del_text)).setPositiveButton(getResources().getString(R.string.item_del_confirmation), new C05891()).setCancelable(true);
        menuItem.create();
        menuItem.show();
        return true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenuInfo contextMenuInfo) {
        super.onCreateContextMenu(contextMenu, view, contextMenuInfo);
        contextMenu.add(0, 2, 0, "Delete");
    }

    public boolean onContextItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 2) {
            return super.onContextItemSelected(menuItem);
        }
        this.mDbHelper.deleteFav(((AdapterContextMenuInfo) menuItem.getMenuInfo()).id);
        fillData();
        return true;
    }

    public void onListItemClick(ListView listView, View view, int i, long j) {
        super.onListItemClick(listView, view, i, j);
        openActivity(Long.valueOf(j));
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        fillData();
    }

    private void openActivity(Long l) {
        FavDbAdapter favDbAdapter = new FavDbAdapter(getActivity());
        favDbAdapter.open();
        l = favDbAdapter.getFavorite(l.longValue());
        getActivity().startManagingCursor(l);
        l.getString(l.getColumnIndexOrThrow("title"));
        Serializable readSerializedObject = FavDbAdapter.readSerializedObject(l.getBlob(l.getColumnIndexOrThrow(FavDbAdapter.KEY_OBJECT)));
        l = l.getInt(l.getColumnIndexOrThrow(FavDbAdapter.KEY_PROVIDER));
        if (4 == l) {
            l = new Intent(getActivity(), YoutubeDetailActivity.class);
            l.putExtra(YoutubeDetailActivity.EXTRA_VIDEO, readSerializedObject);
            startActivity(l);
        } else if (2 == l) {
            l = new Intent(getActivity(), RssDetailActivity.class);
            l.putExtra("postitem", readSerializedObject);
            startActivity(l);
        } else if (3 == l) {
            HolderActivity.startWebViewActivity(getActivity(), (String) readSerializedObject, false, false, null);
        } else if (1 == l) {
            l = new Intent(getActivity(), WordpressDetailActivity.class);
            l.putExtra("postitem", readSerializedObject);
            startActivity(l);
        } else if (5 == l) {
            l = new Intent(getActivity(), ProductActivity.class);
            l.putExtra(ProductActivity.PRODUCT, readSerializedObject);
            startActivity(l);
        }
    }
}
