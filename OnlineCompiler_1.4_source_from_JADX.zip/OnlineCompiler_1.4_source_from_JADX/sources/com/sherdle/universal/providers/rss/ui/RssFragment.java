package com.sherdle.universal.providers.rss.ui;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.providers.rss.RSSFeed;
import com.sherdle.universal.providers.rss.RSSHandler;
import com.sherdle.universal.providers.rss.RSSItem;
import com.sherdle.universal.providers.rss.RssAdapter;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import com.sherdle.universal.util.ViewModeUtils;
import com.sherdle.universal.util.ViewModeUtils.ChangeListener;
import java.net.URL;
import java.util.ArrayList;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

public class RssFragment extends Fragment {
    private RssAdapter listAdapter;
    private RelativeLayout ll;
    private Activity mAct;
    private ArrayList<RSSItem> postsList;
    private RSSFeed rssFeed = null;
    private SwipeRefreshLayout swipeRefreshLayout;
    private String url;
    private ViewModeUtils viewModeUtils;

    private class RssTask extends AsyncTask<Void, Void, Void> {
        private RssTask() {
        }

        protected Void doInBackground(Void... voidArr) {
            try {
                voidArr = new URL(RssFragment.this.url);
                XMLReader xMLReader = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
                Object rSSHandler = new RSSHandler();
                xMLReader.setContentHandler(rSSHandler);
                xMLReader.parse(new InputSource(voidArr.openStream()));
                RssFragment.this.rssFeed = rSSHandler.getFeed();
            } catch (Void[] voidArr2) {
                Log.printStackTrace(voidArr2);
            }
            return null;
        }

        protected void onPostExecute(Void voidR) {
            if (RssFragment.this.rssFeed != null) {
                if (RssFragment.this.rssFeed.getList().size() > 0) {
                    RssFragment.this.postsList.addAll(RssFragment.this.rssFeed.getList());
                }
                RssFragment.this.listAdapter.setHasMore(false);
                RssFragment.this.listAdapter.setModeAndNotify(1);
                RssFragment.this.swipeRefreshLayout.setRefreshing(false);
            } else {
                String str = null;
                if (!RssFragment.this.url.startsWith("http")) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Debug info: '");
                    stringBuilder.append(RssFragment.this.url);
                    stringBuilder.append("' is most likely not a valid RSS url. Make sure the url entered in your configuration starts with 'http' and verify if it's valid XML using https://validator.w3.org/feed/");
                    str = stringBuilder.toString();
                }
                Helper.noConnection(RssFragment.this.mAct, str);
                RssFragment.this.listAdapter.setModeAndNotify(2);
                RssFragment.this.swipeRefreshLayout.setRefreshing(false);
            }
            super.onPostExecute(voidR);
        }
    }

    /* renamed from: com.sherdle.universal.providers.rss.ui.RssFragment$1 */
    class C09881 implements OnRefreshListener {
        C09881() {
        }

        public void onRefresh() {
            RssFragment.this.refreshItems();
        }
    }

    /* renamed from: com.sherdle.universal.providers.rss.ui.RssFragment$2 */
    class C09892 implements ChangeListener {
        C09892() {
        }

        public void modeChanged() {
            RssFragment.this.listAdapter.notifyDataSetChanged();
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list_refresh, viewGroup, false);
        return this.ll;
    }

    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        setHasOptionsMenu(true);
        RecyclerView recyclerView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.postsList = new ArrayList();
        this.listAdapter = new RssAdapter(getContext(), this.postsList);
        this.listAdapter.setModeAndNotify(3);
        recyclerView.setAdapter(this.listAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), 1, false));
        this.swipeRefreshLayout = (SwipeRefreshLayout) this.ll.findViewById(R.id.swipeRefreshLayout);
        this.swipeRefreshLayout.setOnRefreshListener(new C09881());
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        this.url = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        refreshItems();
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.rss_menu, menu);
        this.viewModeUtils = new ViewModeUtils(getContext(), getClass());
        this.viewModeUtils.inflateOptionsMenu(menu, menuInflater);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    private void refreshItems() {
        this.postsList.clear();
        this.listAdapter.setModeAndNotify(3);
        new RssTask().execute(new Void[0]);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        this.viewModeUtils.handleSelection(menuItem, new C09892());
        if (menuItem.getItemId() != R.id.info) {
            return super.onOptionsItemSelected(menuItem);
        }
        menuItem = this.rssFeed;
        if (menuItem != null) {
            menuItem = menuItem.getTitle();
            String description = this.rssFeed.getDescription();
            String link = this.rssFeed.getLink();
            Builder builder = new Builder(this.mAct);
            String string = getResources().getString(R.string.feed_title_value);
            String string2 = getResources().getString(R.string.feed_description_value);
            String string3 = getResources().getString(R.string.feed_link_value);
            if (link.equals("")) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string);
                stringBuilder.append(": \n");
                stringBuilder.append(menuItem);
                stringBuilder.append("\n\n");
                stringBuilder.append(string2);
                stringBuilder.append(": \n");
                stringBuilder.append(description);
                builder.setMessage(stringBuilder.toString());
            } else {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(string);
                stringBuilder2.append(": \n");
                stringBuilder2.append(menuItem);
                stringBuilder2.append("\n\n");
                stringBuilder2.append(string2);
                stringBuilder2.append(": \n");
                stringBuilder2.append(description);
                stringBuilder2.append("\n\n");
                stringBuilder2.append(string3);
                stringBuilder2.append(": \n");
                stringBuilder2.append(link);
                builder.setMessage(stringBuilder2.toString());
            }
            builder.setNegativeButton(getResources().getString(R.string.ok), null).setCancelable(true);
            builder.create();
            builder.show();
        }
        return true;
    }
}
