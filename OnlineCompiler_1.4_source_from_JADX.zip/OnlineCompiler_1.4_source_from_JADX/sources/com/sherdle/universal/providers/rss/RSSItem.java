package com.sherdle.universal.providers.rss;

import android.text.Html;
import java.io.Serializable;

public class RSSItem implements Serializable {
    private String audiourl = null;
    private String description = null;
    private String link = null;
    private String pubdate = null;
    private String rowdescription = null;
    private String thumburl = null;
    private String title = null;
    private String videourl = null;

    void setTitle(String str) {
        this.title = str;
    }

    void setDescription(String str) {
        this.description = str;
        this.rowdescription = stripHtml(str).toString();
    }

    void setLink(String str) {
        this.link = str;
    }

    void setPubdate(String str) {
        this.pubdate = str;
    }

    void setThumburl(String str) {
        this.thumburl = str;
    }

    void setVideourl(String str) {
        this.videourl = str;
    }

    void setAudiourl(String str) {
        this.audiourl = str;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public String getRowDescription() {
        return this.rowdescription;
    }

    public String getLink() {
        return this.link;
    }

    public String getPubdate() {
        return this.pubdate;
    }

    public String getAudiourl() {
        return this.audiourl;
    }

    public String getVideourl() {
        return this.videourl;
    }

    public String getThumburl() {
        return this.thumburl;
    }

    public CharSequence stripHtml(String str) {
        return Html.fromHtml(str).toString().replace('\n', ' ').replace(' ', ' ').replace('￼', ' ').trim();
    }
}
