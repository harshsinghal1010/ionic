package com.sherdle.universal.providers.rss.ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewStub;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.C0361C;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentActivity;
import com.sherdle.universal.attachmentviewer.ui.AudioPlayerActivity;
import com.sherdle.universal.attachmentviewer.ui.VideoPlayerActivity;
import com.sherdle.universal.providers.fav.FavDbAdapter;
import com.sherdle.universal.providers.rss.RSSItem;
import com.sherdle.universal.util.DetailActivity;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.WebHelper;
import org.jsoup.Jsoup;

public class RssDetailActivity extends DetailActivity {
    public static final String EXTRA_RSSITEM = "postitem";
    private RSSItem item;
    private FavDbAdapter mDbHelper;
    private WebView wb;

    /* renamed from: com.sherdle.universal.providers.rss.ui.RssDetailActivity$1 */
    class C06161 extends WebViewClient {
        C06161() {
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            if (str == null || !(str.endsWith(".png") || str.endsWith(".jpg") || str.endsWith(".jpeg"))) {
                boolean z = false;
                if (str == null || !(str.startsWith("http://") || str.startsWith("https://"))) {
                    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
                    if (RssDetailActivity.this.getPackageManager().queryIntentActivities(intent, 0).size() > null) {
                        z = true;
                    }
                    if (z) {
                        RssDetailActivity.this.startActivity(intent);
                    }
                    return true;
                }
                HolderActivity.startWebViewActivity(RssDetailActivity.this, str, false, false, null);
                return true;
            }
            AttachmentActivity.startActivity(RssDetailActivity.this, MediaAttachment.withImage(str));
            return true;
        }
    }

    /* renamed from: com.sherdle.universal.providers.rss.ui.RssDetailActivity$3 */
    class C06183 implements OnClickListener {
        C06183() {
        }

        public void onClick(View view) {
            view = RssDetailActivity.this;
            HolderActivity.startWebViewActivity(view, view.item.getLink(), true, false, null);
        }
    }

    /* renamed from: com.sherdle.universal.providers.rss.ui.RssDetailActivity$4 */
    class C06194 implements OnClickListener {
        C06194() {
        }

        public void onClick(View view) {
            view = RssDetailActivity.this;
            view.mDbHelper = new FavDbAdapter(view);
            RssDetailActivity.this.mDbHelper.open();
            if (RssDetailActivity.this.mDbHelper.checkEvent(RssDetailActivity.this.item.getTitle(), RssDetailActivity.this.item, 2) != null) {
                RssDetailActivity.this.mDbHelper.addFavorite(RssDetailActivity.this.item.getTitle(), RssDetailActivity.this.item, 2);
                view = RssDetailActivity.this;
                Toast.makeText(view, view.getResources().getString(R.string.favorite_success), 1).show();
                return;
            }
            view = RssDetailActivity.this;
            Toast.makeText(view, view.getResources().getString(R.string.favorite_duplicate), 1).show();
        }
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_details);
        ViewStub viewStub = (ViewStub) findViewById(R.id.layout_stub);
        viewStub.setLayoutResource(R.layout.activity_rss_details);
        viewStub.inflate();
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.thumb = (ImageView) findViewById(R.id.image);
        this.coolblue = (RelativeLayout) findViewById(R.id.coolblue);
        TextView textView = (TextView) findViewById(R.id.detailstitle);
        TextView textView2 = (TextView) findViewById(R.id.detailspubdate);
        getIntent().getExtras();
        this.item = (RSSItem) getIntent().getSerializableExtra("postitem");
        textView.setText(this.item.getTitle());
        textView2.setText(this.item.getPubdate());
        setUpHeader(null);
        this.wb = (WebView) findViewById(R.id.descriptionwebview);
        String docToBetterHTML = WebHelper.docToBetterHTML(Jsoup.parse(this.item.getDescription()), this);
        this.wb.getSettings().setJavaScriptEnabled(true);
        this.wb.loadDataWithBaseURL(this.item.getLink(), docToBetterHTML, "text/html", C0361C.UTF8_NAME, "");
        this.wb.setBackgroundColor(Color.argb(1, 0, 0, 0));
        this.wb.getSettings().setCacheMode(2);
        this.wb.getSettings().setDefaultFontSize(WebHelper.getWebViewFontSize(this));
        this.wb.setWebViewClient(new C06161());
        Helper.admobLoader(this, findViewById(R.id.adView));
        Button button = (Button) findViewById(R.id.mediabutton);
        final String videourl = this.item.getVideourl();
        final String audiourl = this.item.getAudiourl();
        if (videourl != null) {
            button.setText(getResources().getString(R.string.btn_video));
        } else if (audiourl != null) {
            button.setText(getResources().getString(R.string.btn_audio));
        } else {
            button.setVisibility(8);
        }
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                view = videourl;
                if (view != null) {
                    VideoPlayerActivity.startActivity(RssDetailActivity.this, view);
                    return;
                }
                view = audiourl;
                if (view != null) {
                    Context context = RssDetailActivity.this;
                    AudioPlayerActivity.startActivity(context, view, context.item.getTitle());
                }
            }
        });
        ((Button) findViewById(R.id.openbutton)).setOnClickListener(new C06183());
        ((Button) findViewById(R.id.favoritebutton)).setOnClickListener(new C06194());
    }

    public void onPause() {
        super.onPause();
        this.wb.onPause();
    }

    public void onResume() {
        super.onResume();
        this.wb.onResume();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            finish();
            return true;
        } else if (itemId != R.id.menu_item_share) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            menuItem = new Intent();
            menuItem.setAction("android.intent.action.SEND");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.item.getTitle());
            stringBuilder.append("\n");
            stringBuilder.append(this.item.getLink());
            menuItem.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
            menuItem.setType("text/plain");
            startActivity(Intent.createChooser(menuItem, getResources().getString(R.string.share_header)));
            return true;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_share, menu);
        onMenuItemsSet(menu);
        return true;
    }
}
