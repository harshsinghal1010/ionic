package com.sherdle.universal.providers.rss;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.rss.ui.RssDetailActivity;
import com.sherdle.universal.providers.rss.ui.RssFragment;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.sherdle.universal.util.ViewModeUtils;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Picasso.LoadedFrom;
import com.squareup.picasso.Target;
import java.io.Serializable;
import java.util.List;

public class RssAdapter extends InfiniteRecyclerViewAdapter {
    private static int COMPACT = 0;
    private static int NORMAL = 1;
    private Context context;
    private List<RSSItem> objects;
    private ViewModeUtils viewModeUtils;

    private static class RssLargeViewHolder extends ViewHolder {
        TextView headlineView;
        ImageView imageView;
        TextView reportedDateView;

        RssLargeViewHolder(View view) {
            super(view);
            this.headlineView = (TextView) view.findViewById(R.id.title);
            this.reportedDateView = (TextView) view.findViewById(R.id.date);
            this.imageView = (ImageView) view.findViewById(R.id.thumbImage);
        }
    }

    private class RssViewHolder extends ViewHolder {
        TextView listDescription;
        TextView listPubdate;
        ImageView listThumb;
        TextView listTitle;

        RssViewHolder(View view) {
            super(view);
            this.listTitle = (TextView) view.findViewById(R.id.listtitle);
            this.listPubdate = (TextView) view.findViewById(R.id.listpubdate);
            this.listDescription = (TextView) view.findViewById(R.id.shortdescription);
            this.listThumb = (ImageView) view.findViewById(R.id.listthumb);
        }
    }

    public RssAdapter(Context context, List<RSSItem> list) {
        super(context, null);
        this.context = context;
        this.objects = list;
        this.viewModeUtils = new ViewModeUtils(context, RssFragment.class);
    }

    public int getViewType(int i) {
        if (this.viewModeUtils.getViewMode() == 1) {
            return NORMAL;
        }
        return COMPACT;
    }

    protected ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        if (COMPACT == i) {
            return new RssViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_rss_row, viewGroup, false));
        }
        return i == NORMAL ? new RssLargeViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_row, viewGroup, false)) : null;
    }

    protected void doBindViewHolder(ViewHolder viewHolder, int i) {
        if (viewHolder instanceof RssViewHolder) {
            RssViewHolder rssViewHolder = (RssViewHolder) viewHolder;
            CharSequence rowDescription = ((RSSItem) this.objects.get(i)).getRowDescription();
            rssViewHolder.listTitle.setText(((RSSItem) this.objects.get(i)).getTitle());
            rssViewHolder.listPubdate.setText(((RSSItem) this.objects.get(i)).getPubdate());
            rssViewHolder.listDescription.setText(rowDescription);
            rssViewHolder.listThumb.setImageDrawable(null);
            loadImageIntoView(((RSSItem) this.objects.get(i)).getThumburl(), rssViewHolder.listThumb);
            setOnClickListener(rssViewHolder.itemView, i);
            return;
        }
        RssLargeViewHolder rssLargeViewHolder = (RssLargeViewHolder) viewHolder;
        rssLargeViewHolder.headlineView.setText(((RSSItem) this.objects.get(i)).getTitle());
        rssLargeViewHolder.reportedDateView.setText(((RSSItem) this.objects.get(i)).getPubdate());
        rssLargeViewHolder.imageView.setImageBitmap(null);
        loadImageIntoView(((RSSItem) this.objects.get(i)).getThumburl(), rssLargeViewHolder.imageView);
        setOnClickListener(rssLargeViewHolder.itemView, i);
    }

    private void setOnClickListener(View view, final int i) {
        view.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                view = new Intent(RssAdapter.this.context, RssDetailActivity.class);
                Bundle bundle = new Bundle();
                view.putExtra("postitem", (Serializable) RssAdapter.this.objects.get(i));
                view.putExtras(bundle);
                RssAdapter.this.context.startActivity(view);
            }
        });
    }

    private void loadImageIntoView(String str, final ImageView imageView) {
        if (str == null || str.equals("")) {
            imageView.setVisibility(8);
            return;
        }
        Target c09872 = new Target() {
            public void onBitmapFailed(Exception exception, Drawable drawable) {
            }

            public void onPrepareLoad(Drawable drawable) {
            }

            public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
                if (10 <= bitmap.getWidth()) {
                    if (10 <= bitmap.getHeight()) {
                        imageView.setVisibility(0);
                        imageView.setImageBitmap(bitmap);
                        return;
                    }
                }
                imageView.setVisibility(8);
            }
        };
        imageView.setTag(c09872);
        Picasso.get().load(str).into(c09872);
    }

    protected int getCount() {
        return this.objects.size();
    }
}
