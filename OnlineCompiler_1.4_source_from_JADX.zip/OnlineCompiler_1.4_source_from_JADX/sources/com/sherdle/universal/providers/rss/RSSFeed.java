package com.sherdle.universal.providers.rss;

import java.util.List;
import java.util.Vector;

public class RSSFeed {
    private String description = null;
    private List<RSSItem> itemList = new Vector(0);
    private String link = null;
    private String pubdate = null;
    private String title = null;

    RSSFeed() {
    }

    void addItem(RSSItem rSSItem) {
        this.itemList.add(rSSItem);
    }

    public RSSItem getItem(int i) {
        return (RSSItem) this.itemList.get(i);
    }

    public List<RSSItem> getList() {
        return this.itemList;
    }

    void setTitle(String str) {
        this.title = str;
    }

    void setDescription(String str) {
        this.description = str;
    }

    void setLink(String str) {
        this.link = str;
    }

    void setPubdate(String str) {
        this.pubdate = str;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public String getLink() {
        return this.link;
    }

    String getPubdate() {
        return this.pubdate;
    }
}
