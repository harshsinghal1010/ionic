package com.sherdle.universal.providers.rss;

import android.text.Html;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.sherdle.universal.billing.Constants;
import org.jsoup.Jsoup;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class RSSHandler extends DefaultHandler {
    private State currentState = State.unknown;
    private RSSFeed feed;
    private RSSItem item;
    private boolean itemFound = false;
    private StringBuilder tagContent;

    public enum State {
        unknown,
        title,
        description,
        link,
        pubdate,
        media
    }

    public void startDocument() throws SAXException {
        this.feed = new RSSFeed();
        this.item = new RSSItem();
    }

    public void startElement(String str, String str2, String str3, Attributes attributes) throws SAXException {
        this.currentState = State.unknown;
        this.tagContent = new StringBuilder();
        if (str2.equalsIgnoreCase("item") == null) {
            if (str2.equalsIgnoreCase("entry") == null) {
                if (str3.equalsIgnoreCase("title") != null) {
                    this.currentState = State.title;
                } else {
                    if (str3.equalsIgnoreCase(Constants.RESPONSE_DESCRIPTION) == null && str3.equalsIgnoreCase("content:encoded") == null) {
                        if (str3.equalsIgnoreCase(Param.CONTENT) == null) {
                            if (str3.equalsIgnoreCase("link") == null) {
                                if (str3.equalsIgnoreCase("origLink") == null) {
                                    if (str3.equalsIgnoreCase("pubdate") == null) {
                                        if (str3.equalsIgnoreCase("published") == null) {
                                            if (str3.equalsIgnoreCase("media:thumbnail") != null) {
                                                this.currentState = State.media;
                                                this.item.setThumburl(attributes.getValue("url"));
                                            } else if (str3.equalsIgnoreCase("media:content") != null) {
                                                this.currentState = State.media;
                                                str = attributes.getValue("url");
                                                if (attributes.getValue("type") != null) {
                                                    if (attributes != null) {
                                                        if (attributes.getValue("type").startsWith("image") != null) {
                                                            this.item.setThumburl(str);
                                                        } else if (attributes.getValue("type").startsWith(MimeTypes.BASE_TYPE_VIDEO) != null) {
                                                            this.item.setVideourl(str);
                                                        } else if (attributes.getValue("type").startsWith(MimeTypes.BASE_TYPE_AUDIO) != null) {
                                                            this.item.setAudiourl(str);
                                                        }
                                                    }
                                                }
                                                return;
                                            } else if (str3.equalsIgnoreCase("enclosure") != null) {
                                                this.currentState = State.media;
                                                str = attributes.getValue("url");
                                                if (attributes.getValue("type").startsWith("image") != null) {
                                                    this.item.setThumburl(str);
                                                } else if (attributes.getValue("type").startsWith(MimeTypes.BASE_TYPE_VIDEO) != null) {
                                                    this.item.setVideourl(str);
                                                } else if (attributes.getValue("type").startsWith(MimeTypes.BASE_TYPE_AUDIO) != null) {
                                                    this.item.setAudiourl(str);
                                                }
                                            }
                                        }
                                    }
                                    this.currentState = State.pubdate;
                                }
                            }
                            this.currentState = State.link;
                        }
                    }
                    this.currentState = State.description;
                }
            }
        }
        this.itemFound = true;
        this.item = new RSSItem();
        this.currentState = State.unknown;
    }

    public void endElement(String str, String str2, String str3) throws SAXException {
        if (!(str2.equalsIgnoreCase("item") == null && str2.equalsIgnoreCase("entry") == null)) {
            this.feed.addItem(this.item);
        }
        if (this.itemFound == 1) {
            switch (this.currentState) {
                case title:
                    this.item.setTitle(Html.fromHtml(this.tagContent.toString().trim()).toString());
                    return;
                case description:
                    this.item.setDescription(this.tagContent.toString());
                    if (this.item.getThumburl() == null || this.item.getThumburl().equals("") != null) {
                        this.item.setThumburl(Jsoup.parse(this.tagContent.toString()).select("img").attr("src"));
                        return;
                    }
                    return;
                case link:
                    this.item.setLink(this.tagContent.toString());
                    return;
                case pubdate:
                    this.item.setPubdate(this.tagContent.toString());
                    return;
                case media:
                    return;
                default:
                    return;
            }
        }
        switch (this.currentState) {
            case title:
                this.feed.setTitle(this.tagContent.toString());
                return;
            case description:
                this.feed.setDescription(this.tagContent.toString());
                return;
            case link:
                this.feed.setLink(this.tagContent.toString());
                return;
            case pubdate:
                this.feed.setPubdate(this.tagContent.toString());
                return;
            default:
                return;
        }
    }

    public void characters(char[] cArr, int i, int i2) throws SAXException {
        this.tagContent.append(cArr, i, i2);
    }

    public RSSFeed getFeed() {
        return this.feed;
    }
}
