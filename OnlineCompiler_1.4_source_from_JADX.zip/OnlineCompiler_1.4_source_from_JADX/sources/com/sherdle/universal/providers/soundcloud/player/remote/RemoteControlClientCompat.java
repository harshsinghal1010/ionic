package com.sherdle.universal.providers.soundcloud.player.remote;

import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.os.Looper;
import com.sherdle.universal.util.Log;
import java.lang.reflect.Method;

public class RemoteControlClientCompat {
    private static final String TAG = "RemoteControlCompat";
    private static boolean sHasRemoteControlAPIs = true;
    private static Method sRCCEditMetadataMethod;
    private static Method sRCCSetPlayStateMethod;
    private static Method sRCCSetTransportControlFlags;
    private static Class sRemoteControlClientClass;
    private Object mActualRemoteControlClient;

    public class MetadataEditorCompat {
        public static final int METADATA_KEY_ARTWORK = 100;
        private final Object mActualMetadataEditor;
        private Method mApplyMethod;
        private Method mClearMethod;
        private Method mPutBitmapMethod;
        private Method mPutLongMethod;
        private Method mPutStringMethod;

        private MetadataEditorCompat(Object obj) {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs != null) {
                if (obj == null) {
                    throw new IllegalArgumentException("Remote Control API's exist, should not be given a null MetadataEditor");
                }
            }
            if (RemoteControlClientCompat.sHasRemoteControlAPIs != null) {
                RemoteControlClientCompat remoteControlClientCompat = obj.getClass();
                try {
                    this.mPutStringMethod = remoteControlClientCompat.getMethod("putString", new Class[]{Integer.TYPE, String.class});
                    this.mPutBitmapMethod = remoteControlClientCompat.getMethod("putBitmap", new Class[]{Integer.TYPE, Bitmap.class});
                    this.mPutLongMethod = remoteControlClientCompat.getMethod("putLong", new Class[]{Integer.TYPE, Long.TYPE});
                    this.mClearMethod = remoteControlClientCompat.getMethod("clear", new Class[0]);
                    this.mApplyMethod = remoteControlClientCompat.getMethod("apply", new Class[0]);
                } catch (RemoteControlClientCompat remoteControlClientCompat2) {
                    throw new RuntimeException(remoteControlClientCompat2.getMessage(), remoteControlClientCompat2);
                }
            }
            this.mActualMetadataEditor = obj;
        }

        public MetadataEditorCompat putString(int i, String str) {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                try {
                    this.mPutStringMethod.invoke(this.mActualMetadataEditor, new Object[]{Integer.valueOf(i), str});
                } catch (int i2) {
                    throw new RuntimeException(i2.getMessage(), i2);
                }
            }
            return this;
        }

        public MetadataEditorCompat putBitmap(int i, Bitmap bitmap) {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                try {
                    this.mPutBitmapMethod.invoke(this.mActualMetadataEditor, new Object[]{Integer.valueOf(i), bitmap});
                } catch (int i2) {
                    throw new RuntimeException(i2.getMessage(), i2);
                }
            }
            return this;
        }

        public MetadataEditorCompat putLong(int i, long j) {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                try {
                    this.mPutLongMethod.invoke(this.mActualMetadataEditor, new Object[]{Integer.valueOf(i), Long.valueOf(j)});
                } catch (int i2) {
                    throw new RuntimeException(i2.getMessage(), i2);
                }
            }
            return this;
        }

        public void clear() {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                try {
                    this.mClearMethod.invoke(this.mActualMetadataEditor, (Object[]) null);
                } catch (Throwable e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
            }
        }

        public void apply() {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                try {
                    this.mApplyMethod.invoke(this.mActualMetadataEditor, (Object[]) null);
                } catch (Throwable e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
            }
        }
    }

    static {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = com.sherdle.universal.providers.soundcloud.player.remote.RemoteControlClientCompat.class;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r0 = r0.getClassLoader();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r0 = getActualRemoteControlClientClass(r0);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        sRemoteControlClientClass = r0;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r0 = com.sherdle.universal.providers.soundcloud.player.remote.RemoteControlClientCompat.class;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r0 = r0.getFields();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r1 = r0.length;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r2 = 0;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r3 = 0;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
    L_0x0015:
        if (r3 >= r1) goto L_0x009a;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
    L_0x0017:
        r4 = r0[r3];	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r5 = sRemoteControlClientClass;	 Catch:{ NoSuchFieldException -> 0x007c, IllegalArgumentException -> 0x0054, IllegalAccessException -> 0x002c }
        r6 = r4.getName();	 Catch:{ NoSuchFieldException -> 0x007c, IllegalArgumentException -> 0x0054, IllegalAccessException -> 0x002c }
        r5 = r5.getField(r6);	 Catch:{ NoSuchFieldException -> 0x007c, IllegalArgumentException -> 0x0054, IllegalAccessException -> 0x002c }
        r6 = 0;	 Catch:{ NoSuchFieldException -> 0x007c, IllegalArgumentException -> 0x0054, IllegalAccessException -> 0x002c }
        r5 = r5.get(r6);	 Catch:{ NoSuchFieldException -> 0x007c, IllegalArgumentException -> 0x0054, IllegalAccessException -> 0x002c }
        r4.set(r6, r5);	 Catch:{ NoSuchFieldException -> 0x007c, IllegalArgumentException -> 0x0054, IllegalAccessException -> 0x002c }
        goto L_0x0096;
    L_0x002c:
        r5 = move-exception;
        r6 = "RemoteControlCompat";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7 = new java.lang.StringBuilder;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7.<init>();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r8 = "Error trying to pull field value for: ";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7.append(r8);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = r4.getName();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7.append(r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = " ";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7.append(r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = r5.getMessage();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7.append(r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = r7.toString();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        com.sherdle.universal.util.Log.m162w(r6, r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        goto L_0x0096;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
    L_0x0054:
        r5 = move-exception;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r6 = "RemoteControlCompat";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7 = new java.lang.StringBuilder;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7.<init>();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r8 = "Error trying to pull field value for: ";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7.append(r8);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = r4.getName();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7.append(r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = " ";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7.append(r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = r5.getMessage();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7.append(r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = r7.toString();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        com.sherdle.universal.util.Log.m162w(r6, r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        goto L_0x0096;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
    L_0x007c:
        r5 = "RemoteControlCompat";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r6 = new java.lang.StringBuilder;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r6.<init>();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r7 = "Could not get real field: ";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r6.append(r7);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = r4.getName();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r6.append(r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = r6.toString();	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        com.sherdle.universal.util.Log.m162w(r5, r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
    L_0x0096:
        r3 = r3 + 1;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        goto L_0x0015;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
    L_0x009a:
        r0 = sRemoteControlClientClass;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r1 = "editMetadata";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r3 = 1;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = new java.lang.Class[r3];	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r5 = java.lang.Boolean.TYPE;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4[r2] = r5;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r0 = r0.getMethod(r1, r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        sRCCEditMetadataMethod = r0;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r0 = sRemoteControlClientClass;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r1 = "setPlaybackState";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = new java.lang.Class[r3];	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r5 = java.lang.Integer.TYPE;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4[r2] = r5;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r0 = r0.getMethod(r1, r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        sRCCSetPlayStateMethod = r0;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r0 = sRemoteControlClientClass;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r1 = "setTransportControlFlags";	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4 = new java.lang.Class[r3];	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r5 = java.lang.Integer.TYPE;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r4[r2] = r5;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        r0 = r0.getMethod(r1, r4);	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        sRCCSetTransportControlFlags = r0;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
        sHasRemoteControlAPIs = r3;	 Catch:{ ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd, ClassNotFoundException -> 0x00cd }
    L_0x00cd:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.soundcloud.player.remote.RemoteControlClientCompat.<clinit>():void");
    }

    public static Class getActualRemoteControlClientClass(ClassLoader classLoader) throws ClassNotFoundException {
        return classLoader.loadClass("android.media.RemoteControlClient");
    }

    public RemoteControlClientCompat(PendingIntent pendingIntent) {
        if (sHasRemoteControlAPIs) {
            try {
                this.mActualRemoteControlClient = sRemoteControlClientClass.getConstructor(new Class[]{PendingIntent.class}).newInstance(new Object[]{pendingIntent});
            } catch (PendingIntent pendingIntent2) {
                throw new RuntimeException(pendingIntent2);
            }
        }
    }

    public RemoteControlClientCompat(PendingIntent pendingIntent, Looper looper) {
        if (sHasRemoteControlAPIs) {
            try {
                this.mActualRemoteControlClient = sRemoteControlClientClass.getConstructor(new Class[]{PendingIntent.class, Looper.class}).newInstance(new Object[]{pendingIntent, looper});
            } catch (PendingIntent pendingIntent2) {
                looper = TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Error creating new instance of ");
                stringBuilder.append(sRemoteControlClientClass.getName());
                stringBuilder.append(pendingIntent2.toString());
                Log.m158e(looper, stringBuilder.toString());
            }
        }
    }

    public MetadataEditorCompat editMetadata(boolean z) {
        if (sHasRemoteControlAPIs) {
            try {
                z = sRCCEditMetadataMethod.invoke(this.mActualRemoteControlClient, new Object[]{Boolean.valueOf(z)});
            } catch (boolean z2) {
                throw new RuntimeException(z2);
            }
        }
        z2 = false;
        return new MetadataEditorCompat(z2);
    }

    public void setPlaybackState(int i) {
        if (sHasRemoteControlAPIs) {
            try {
                sRCCSetPlayStateMethod.invoke(this.mActualRemoteControlClient, new Object[]{Integer.valueOf(i)});
            } catch (int i2) {
                throw new RuntimeException(i2);
            }
        }
    }

    public void setTransportControlFlags(int i) {
        if (sHasRemoteControlAPIs) {
            try {
                sRCCSetTransportControlFlags.invoke(this.mActualRemoteControlClient, new Object[]{Integer.valueOf(i)});
            } catch (int i2) {
                throw new RuntimeException(i2);
            }
        }
    }

    public final Object getActualRemoteControlClientObject() {
        return this.mActualRemoteControlClient;
    }
}
