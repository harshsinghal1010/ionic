package com.sherdle.universal.providers.soundcloud.player.player;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnSeekCompleteListener;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.WifiLock;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.support.v4.content.LocalBroadcastManager;
import com.google.android.exoplayer2.source.chunk.ChunkedTrackBlacklistUtil;
import com.google.android.exoplayer2.util.MimeTypes;
import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;
import com.sherdle.universal.providers.soundcloud.player.media.MediaSessionWrapper;
import com.sherdle.universal.providers.soundcloud.player.media.MediaSessionWrapper.MediaSessionWrapperCallback;
import com.sherdle.universal.util.Log;
import com.squareup.picasso.Picasso.LoadedFrom;
import com.squareup.picasso.Target;

public class PlaybackService extends Service implements OnErrorListener, OnCompletionListener, OnSeekCompleteListener, OnAudioFocusChangeListener, OnInfoListener, OnPreparedListener {
    static final String ACTION_AUDIO_BECOMING_NOISY = "sound_cloud_player_becoming_noisy";
    static final String ACTION_CLEAR_NOTIFICATION = "sound_cloud_player_clear";
    static final String ACTION_NEXT_TRACK = "sound_cloud_player_next";
    private static final String ACTION_PAUSE_PLAYER = "sound_cloud_player_resume";
    private static final String ACTION_PLAY = "sound_cloud_play";
    static final String ACTION_PREVIOUS_TRACK = "sound_cloud_player_previous";
    private static final String ACTION_RESUME_PLAYER = "sound_cloud_player_pause";
    private static final String ACTION_SEEK_TO = "sound_cloud_player_seek_to";
    private static final String ACTION_STOP_PLAYER = "sound_cloud_player_stop";
    static final String ACTION_TOGGLE_PLAYBACK = "sound_cloud_toggle_playback";
    private static final String BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID = "sound_cloud_player_bundle_key_client_id";
    private static final String BUNDLE_KEY_SOUND_CLOUD_TRACK = "sound_cloud_player_bundle_key_track_url";
    private static final String BUNDLE_KEY_SOUND_CLOUD_TRACK_POSITION = "sound_cloud_player_bundle_key_seek_to";
    private static final int IDLE_PERIOD_MILLI = 60000;
    private static final int MESSAGE_DELAY_MILLI = 100;
    private static final String SOUND_CLOUD_CLIENT_ID_PARAM = "?client_id=";
    private static final String TAG = "PlaybackService";
    private static final String THREAD_NAME;
    private static final int WHAT_CLEAR_PLAYER = 9;
    private static final int WHAT_NEXT_TRACK = 3;
    private static final int WHAT_PAUSE_PLAYER = 1;
    private static final int WHAT_PLAY = 0;
    private static final int WHAT_PREVIOUS_TRACK = 4;
    private static final int WHAT_RELEASE_PLAYER = 7;
    private static final int WHAT_RESUME_PLAYER = 2;
    private static final int WHAT_SEEK_TO = 5;
    private static final int WHAT_STOP_PLAYER = 6;
    private static final String WIFI_LOCK_TAG;
    private AudioManager mAudioManager;
    private CountDownTimer mCountDown;
    private HandlerThread mHandlerThread;
    private boolean mHasAlreadyPlayed;
    private boolean mIsPaused;
    private LocalBroadcastManager mLocalBroadcastManager;
    private Handler mMainThreadHandler;
    private MediaPlayer mMediaPlayer;
    private MediaSessionWrapper mMediaSession;
    private NotificationManager mNotificationManager;
    private Handler mPlayerHandler;
    private PlayerPlaylist mPlayerPlaylist;
    private String mSoundCloundClientId;
    private Handler mStopServiceHandler;
    private WifiLock mWifiLock;

    private final class PlayerHandler extends Handler {
        public PlayerHandler(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            super.handleMessage(message);
            Bundle data = message.getData();
            message = message.what;
            if (message != 9) {
                switch (message) {
                    case null:
                        PlaybackService.this.playTrack((TrackObject) data.getSerializable(PlaybackService.BUNDLE_KEY_SOUND_CLOUD_TRACK));
                        return;
                    case 1:
                        PlaybackService.this.pause();
                        return;
                    case 2:
                        PlaybackService.this.resume();
                        return;
                    case 3:
                        PlaybackService.this.nextTrack();
                        return;
                    case 4:
                        PlaybackService.this.previousTrack();
                        return;
                    case 5:
                        PlaybackService.this.seekToPosition(data.getInt(PlaybackService.BUNDLE_KEY_SOUND_CLOUD_TRACK_POSITION));
                        return;
                    case 6:
                        PlaybackService.this.stopPlayer();
                        return;
                    default:
                        return;
                }
            }
            PlaybackService.this.stopSelf();
        }
    }

    private class StopHandler extends Handler {
        public StopHandler(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            super.handleMessage(message);
            if (message.what == 7) {
                if (PlaybackService.this.mIsPaused != null) {
                    PlaybackService.this.stopSelf();
                }
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.soundcloud.player.player.PlaybackService$1 */
    class C09931 implements Target {
        public void onBitmapFailed(Exception exception, Drawable drawable) {
        }

        public void onPrepareLoad(Drawable drawable) {
        }

        C09931() {
        }

        public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
            if (PlaybackService.this.mPlayerPlaylist.getCurrentTrack() != null) {
                PlaybackService.this.mMediaSession.setMetaData(PlaybackService.this.mPlayerPlaylist.getCurrentTrack(), bitmap.copy(bitmap.getConfig(), false));
            }
        }
    }

    private final class MediaSessionCallback implements MediaSessionWrapperCallback {
        private MediaSessionCallback() {
        }

        public void onPlay() {
            PlaybackService.this.resume();
        }

        public void onPause() {
            PlaybackService.this.pause();
        }

        public void onSkipToNext() {
            PlaybackService.this.nextTrack();
        }

        public void onSkipToPrevious() {
            PlaybackService.this.previousTrack();
        }

        public void onPlayPauseToggle() {
            if (PlaybackService.this.mIsPaused) {
                PlaybackService.this.resume();
            } else {
                PlaybackService.this.pause();
            }
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    static {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(TAG);
        stringBuilder.append("wifi_lock");
        WIFI_LOCK_TAG = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(TAG);
        stringBuilder.append("player_thread");
        THREAD_NAME = stringBuilder.toString();
    }

    public static void play(Context context, String str, TrackObject trackObject) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(ACTION_PLAY);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID, str);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_TRACK, trackObject);
        context.startService(intent);
    }

    public static void pause(Context context, String str) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(ACTION_PAUSE_PLAYER);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID, str);
        context.startService(intent);
    }

    public static void resume(Context context, String str) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(ACTION_RESUME_PLAYER);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID, str);
        context.startService(intent);
    }

    public static void stop(Context context, String str) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(ACTION_STOP_PLAYER);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID, str);
        context.startService(intent);
    }

    public static void seekTo(Context context, String str, int i) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(ACTION_SEEK_TO);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID, str);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_TRACK_POSITION, i);
        context.startService(intent);
    }

    public static void registerListener(Context context, PlaybackListener playbackListener) {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("simple_sc_listener_action_on_track_played");
        intentFilter.addAction("simple_sc_listener_action_on_track_paused");
        intentFilter.addAction("simple_sc_listener_action_on_player_seek_complete");
        intentFilter.addAction("simple_sc_listener_action_on_player_destroyed");
        intentFilter.addAction("simple_sc_listener_action_on_buffering_start");
        intentFilter.addAction("simple_sc_listener_action_on_buffering_end");
        intentFilter.addAction("simple_sc_listener_action_on_progress_changed");
        intentFilter.addAction("simple_sc_listener_action_on_duration_changed");
        LocalBroadcastManager.getInstance(context.getApplicationContext()).registerReceiver(playbackListener, intentFilter);
    }

    public static void unregisterListener(Context context, PlaybackListener playbackListener) {
        LocalBroadcastManager.getInstance(context.getApplicationContext()).unregisterReceiver(playbackListener);
    }

    public void onCreate() {
        super.onCreate();
        this.mHandlerThread = new HandlerThread(THREAD_NAME, -16);
        this.mHandlerThread.start();
        this.mPlayerHandler = new PlayerHandler(this.mHandlerThread.getLooper());
        this.mMediaPlayer = new MediaPlayer();
        initializeMediaPlayer();
        this.mStopServiceHandler = new StopHandler(this.mHandlerThread.getLooper());
        this.mMainThreadHandler = new Handler(getApplicationContext().getMainLooper());
        this.mWifiLock = ((WifiManager) getBaseContext().getApplicationContext().getSystemService("wifi")).createWifiLock(1, WIFI_LOCK_TAG);
        this.mLocalBroadcastManager = LocalBroadcastManager.getInstance(getApplicationContext());
        this.mNotificationManager = NotificationManager.getInstance(this);
        this.mPlayerPlaylist = PlayerPlaylist.getInstance();
        this.mHasAlreadyPlayed = false;
        this.mAudioManager = (AudioManager) getSystemService(MimeTypes.BASE_TYPE_AUDIO);
        this.mMediaSession = new MediaSessionWrapper(this, new MediaSessionCallback(), this.mAudioManager);
    }

    public void onDestroy() {
        stopTimer();
        this.mAudioManager.abandonAudioFocus(this);
        this.mMediaSession.onDestroy();
        this.mPlayerHandler.removeCallbacksAndMessages(null);
        stopForeground(true);
        this.mLocalBroadcastManager.sendBroadcast(new Intent("simple_sc_listener_action_on_player_destroyed"));
        this.mMediaPlayer.release();
        this.mMediaPlayer = null;
        this.mHandlerThread.quit();
        super.onDestroy();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int onStartCommand(android.content.Intent r10, int r11, int r12) {
        /*
        r9 = this;
        r11 = 1;
        if (r10 == 0) goto L_0x00d3;
    L_0x0003:
        r12 = r9.mPlayerHandler;
        r12 = r12.obtainMessage();
        r0 = r10.getExtras();
        if (r0 == 0) goto L_0x001a;
    L_0x000f:
        r1 = "sound_cloud_player_bundle_key_client_id";
        r1 = r0.getString(r1);
        r9.mSoundCloundClientId = r1;
        r12.setData(r0);
    L_0x001a:
        r10 = r10.getAction();
        r0 = -1;
        r1 = r10.hashCode();
        r2 = 9;
        r3 = 5;
        r4 = 4;
        r5 = 3;
        r6 = 6;
        r7 = 0;
        r8 = 2;
        switch(r1) {
            case -1076183447: goto L_0x008b;
            case -1064489454: goto L_0x0081;
            case -714183333: goto L_0x0077;
            case -311488681: goto L_0x006d;
            case -311325594: goto L_0x0063;
            case 818650158: goto L_0x0059;
            case 1421460369: goto L_0x004f;
            case 1434335596: goto L_0x0045;
            case 1971971927: goto L_0x003a;
            case 1989862078: goto L_0x0030;
            default: goto L_0x002e;
        };
    L_0x002e:
        goto L_0x0096;
    L_0x0030:
        r1 = "sound_cloud_player_seek_to";
        r10 = r10.equals(r1);
        if (r10 == 0) goto L_0x0096;
    L_0x0038:
        r10 = 6;
        goto L_0x0097;
    L_0x003a:
        r1 = "sound_cloud_player_becoming_noisy";
        r10 = r10.equals(r1);
        if (r10 == 0) goto L_0x0096;
    L_0x0042:
        r10 = 8;
        goto L_0x0097;
    L_0x0045:
        r1 = "sound_cloud_toggle_playback";
        r10 = r10.equals(r1);
        if (r10 == 0) goto L_0x0096;
    L_0x004d:
        r10 = 7;
        goto L_0x0097;
    L_0x004f:
        r1 = "sound_cloud_player_resume";
        r10 = r10.equals(r1);
        if (r10 == 0) goto L_0x0096;
    L_0x0057:
        r10 = 1;
        goto L_0x0097;
    L_0x0059:
        r1 = "sound_cloud_play";
        r10 = r10.equals(r1);
        if (r10 == 0) goto L_0x0096;
    L_0x0061:
        r10 = 0;
        goto L_0x0097;
    L_0x0063:
        r1 = "sound_cloud_player_stop";
        r10 = r10.equals(r1);
        if (r10 == 0) goto L_0x0096;
    L_0x006b:
        r10 = 3;
        goto L_0x0097;
    L_0x006d:
        r1 = "sound_cloud_player_next";
        r10 = r10.equals(r1);
        if (r10 == 0) goto L_0x0096;
    L_0x0075:
        r10 = 4;
        goto L_0x0097;
    L_0x0077:
        r1 = "sound_cloud_player_previous";
        r10 = r10.equals(r1);
        if (r10 == 0) goto L_0x0096;
    L_0x007f:
        r10 = 5;
        goto L_0x0097;
    L_0x0081:
        r1 = "sound_cloud_player_pause";
        r10 = r10.equals(r1);
        if (r10 == 0) goto L_0x0096;
    L_0x0089:
        r10 = 2;
        goto L_0x0097;
    L_0x008b:
        r1 = "sound_cloud_player_clear";
        r10 = r10.equals(r1);
        if (r10 == 0) goto L_0x0096;
    L_0x0093:
        r10 = 9;
        goto L_0x0097;
    L_0x0096:
        r10 = -1;
    L_0x0097:
        switch(r10) {
            case 0: goto L_0x00c1;
            case 1: goto L_0x00be;
            case 2: goto L_0x00bb;
            case 3: goto L_0x00b8;
            case 4: goto L_0x00b5;
            case 5: goto L_0x00b2;
            case 6: goto L_0x00af;
            case 7: goto L_0x00a5;
            case 8: goto L_0x009e;
            case 9: goto L_0x009b;
            default: goto L_0x009a;
        };
    L_0x009a:
        goto L_0x00c3;
    L_0x009b:
        r12.what = r2;
        goto L_0x00c3;
    L_0x009e:
        r10 = r9.mIsPaused;
        if (r10 != 0) goto L_0x00c3;
    L_0x00a2:
        r12.what = r11;
        goto L_0x00c3;
    L_0x00a5:
        r10 = r9.mIsPaused;
        if (r10 == 0) goto L_0x00ac;
    L_0x00a9:
        r12.what = r8;
        goto L_0x00c3;
    L_0x00ac:
        r12.what = r11;
        goto L_0x00c3;
    L_0x00af:
        r12.what = r3;
        goto L_0x00c3;
    L_0x00b2:
        r12.what = r4;
        goto L_0x00c3;
    L_0x00b5:
        r12.what = r5;
        goto L_0x00c3;
    L_0x00b8:
        r12.what = r6;
        goto L_0x00c3;
    L_0x00bb:
        r12.what = r8;
        goto L_0x00c3;
    L_0x00be:
        r12.what = r11;
        goto L_0x00c3;
    L_0x00c1:
        r12.what = r7;
    L_0x00c3:
        r9.gotoIdleState();
        r10 = r9.mPlayerHandler;
        r0 = 0;
        r10.removeCallbacksAndMessages(r0);
        r10 = r9.mPlayerHandler;
        r0 = 100;
        r10.sendMessageDelayed(r12, r0);
    L_0x00d3:
        return r11;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.soundcloud.player.player.PlaybackService.onStartCommand(android.content.Intent, int, int):int");
    }

    public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
        mediaPlayer = TAG;
        i2 = new StringBuilder();
        i2.append("MediaPlayer error occurred : ");
        i2.append(i);
        i2.append(" => reset mediaPlayer");
        Log.m158e(mediaPlayer, i2.toString());
        initializeMediaPlayer();
        return true;
    }

    public void onCompletion(MediaPlayer mediaPlayer) {
        if (this.mWifiLock.isHeld() != null) {
            this.mWifiLock.release();
        }
        gotoIdleState();
        this.mPlayerHandler.sendEmptyMessage(3);
    }

    public void onSeekComplete(MediaPlayer mediaPlayer) {
        Intent intent = new Intent("simple_sc_listener_action_on_player_seek_complete");
        intent.putExtra("simple_sc_listener_extra_current_time", mediaPlayer.getCurrentPosition());
        this.mLocalBroadcastManager.sendBroadcast(intent);
        if (this.mIsPaused == null) {
            resumeTimer();
        }
    }

    public void onAudioFocusChange(int i) {
        if (i != 1) {
            switch (i) {
                case -3:
                    if (this.mIsPaused == 0) {
                        this.mMediaPlayer.setVolume(0.1f, 0.1f);
                        return;
                    }
                    return;
                case -2:
                    if (this.mIsPaused == 0) {
                        pause();
                        return;
                    }
                    return;
                case -1:
                    if (this.mIsPaused == 0) {
                        pause();
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
        if (this.mIsPaused != 0) {
            resume();
        }
        this.mMediaPlayer.setVolume(1.0f, 1.0f);
    }

    public boolean onInfo(MediaPlayer mediaPlayer, int i, int i2) {
        switch (i) {
            case 701:
                this.mLocalBroadcastManager.sendBroadcast(new Intent("simple_sc_listener_action_on_buffering_start"));
                return true;
            case 702:
                this.mLocalBroadcastManager.sendBroadcast(new Intent("simple_sc_listener_action_on_buffering_end"));
                return true;
            default:
                return null;
        }
    }

    private void pause() {
        if (this.mHasAlreadyPlayed && !this.mIsPaused) {
            this.mIsPaused = true;
            this.mMediaPlayer.pause();
            this.mLocalBroadcastManager.sendBroadcast(new Intent("simple_sc_listener_action_on_track_paused"));
            updateNotification();
            this.mMediaSession.setPlaybackState(2);
            pauseTimer();
        }
    }

    private void resume() {
        if (this.mIsPaused) {
            this.mIsPaused = false;
            if (this.mAudioManager.requestAudioFocus(this, 3, 1) == 1) {
                this.mMediaPlayer.start();
                Intent intent = new Intent("simple_sc_listener_action_on_track_played");
                intent.putExtra("simple_sc_listener_extra_track", this.mPlayerPlaylist.getCurrentTrack());
                this.mLocalBroadcastManager.sendBroadcast(intent);
                updateNotification();
                this.mMediaSession.setPlaybackState(1);
                resumeTimer();
            }
        }
    }

    private void stopPlayer() {
        this.mMediaSession.setPlaybackState(0);
        this.mMediaPlayer.stop();
        this.mIsPaused = true;
        stopSelf();
    }

    private void nextTrack() {
        playTrack(this.mPlayerPlaylist.next());
    }

    private void previousTrack() {
        playTrack(this.mPlayerPlaylist.previous());
    }

    private void seekToPosition(int i) {
        this.mMediaPlayer.seekTo(i);
    }

    private void initializeMediaPlayer() {
        this.mMediaPlayer.reset();
        this.mMediaPlayer.setWakeMode(getApplicationContext(), 1);
        this.mMediaPlayer.setAudioStreamType(3);
        this.mMediaPlayer.setOnCompletionListener(this);
        this.mMediaPlayer.setOnSeekCompleteListener(this);
        this.mMediaPlayer.setOnInfoListener(this);
        this.mMediaPlayer.setOnPreparedListener(this);
    }

    private void playTrack(final com.sherdle.universal.providers.soundcloud.api.object.TrackObject r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r4 = this;
        r4.pauseTimer();
        r0 = r4.mWifiLock;	 Catch:{ IOException -> 0x0085 }
        r0.acquire();	 Catch:{ IOException -> 0x0085 }
        r0 = r4.mMediaPlayer;	 Catch:{ IOException -> 0x0085 }
        r0.reset();	 Catch:{ IOException -> 0x0085 }
        r0 = r4.mMediaPlayer;	 Catch:{ IOException -> 0x0085 }
        r1 = r5.getLinkStream();	 Catch:{ IOException -> 0x0085 }
        r0.setDataSource(r1);	 Catch:{ IOException -> 0x0085 }
        r0 = 0;	 Catch:{ IOException -> 0x0085 }
        r4.mIsPaused = r0;	 Catch:{ IOException -> 0x0085 }
        r0 = 1;	 Catch:{ IOException -> 0x0085 }
        r4.mHasAlreadyPlayed = r0;	 Catch:{ IOException -> 0x0085 }
        r4.updateNotification();	 Catch:{ IOException -> 0x0085 }
        r1 = r4.mMediaSession;	 Catch:{ IOException -> 0x0085 }
        r1.setPlaybackState(r0);	 Catch:{ IOException -> 0x0085 }
        r1 = new com.sherdle.universal.providers.soundcloud.player.player.PlaybackService$1;	 Catch:{ IOException -> 0x0085 }
        r1.<init>();	 Catch:{ IOException -> 0x0085 }
        r2 = r4.mMainThreadHandler;	 Catch:{ IOException -> 0x0085 }
        r3 = new com.sherdle.universal.providers.soundcloud.player.player.PlaybackService$2;	 Catch:{ IOException -> 0x0085 }
        r3.<init>(r5, r1);	 Catch:{ IOException -> 0x0085 }
        r2.post(r3);	 Catch:{ IOException -> 0x0085 }
        r1 = new android.content.Intent;	 Catch:{ IOException -> 0x0085 }
        r2 = "simple_sc_listener_action_on_track_played";	 Catch:{ IOException -> 0x0085 }
        r1.<init>(r2);	 Catch:{ IOException -> 0x0085 }
        r2 = "simple_sc_listener_extra_track";	 Catch:{ IOException -> 0x0085 }
        r1.putExtra(r2, r5);	 Catch:{ IOException -> 0x0085 }
        r2 = r4.mLocalBroadcastManager;	 Catch:{ IOException -> 0x0085 }
        r2.sendBroadcast(r1);	 Catch:{ IOException -> 0x0085 }
        r1 = new android.content.Intent;	 Catch:{ IOException -> 0x0085 }
        r2 = "simple_sc_listener_action_on_buffering_start";	 Catch:{ IOException -> 0x0085 }
        r1.<init>(r2);	 Catch:{ IOException -> 0x0085 }
        r2 = r4.mLocalBroadcastManager;	 Catch:{ IOException -> 0x0085 }
        r2.sendBroadcast(r1);	 Catch:{ IOException -> 0x0085 }
        r1 = r4.mAudioManager;	 Catch:{ IOException -> 0x0085 }
        r2 = 3;	 Catch:{ IOException -> 0x0085 }
        r1 = r1.requestAudioFocus(r4, r2, r0);	 Catch:{ IOException -> 0x0085 }
        if (r1 != r0) goto L_0x009b;	 Catch:{ IOException -> 0x0085 }
    L_0x0059:
        r0 = r4.mMediaPlayer;	 Catch:{ IOException -> 0x0085 }
        r0.prepare();	 Catch:{ IOException -> 0x0085 }
        r0 = r4.mMediaPlayer;	 Catch:{ IOException -> 0x0085 }
        r0.start();	 Catch:{ IOException -> 0x0085 }
        r0 = r4.mPlayerPlaylist;	 Catch:{ IOException -> 0x0085 }
        r0 = r0.getCurrentTrack();	 Catch:{ IOException -> 0x0085 }
        if (r0 != 0) goto L_0x0071;	 Catch:{ IOException -> 0x0085 }
    L_0x006b:
        r0 = r4.mMediaPlayer;	 Catch:{ IOException -> 0x0085 }
        r0.stop();	 Catch:{ IOException -> 0x0085 }
        goto L_0x0078;	 Catch:{ IOException -> 0x0085 }
    L_0x0071:
        r0 = r0.getDuration();	 Catch:{ IOException -> 0x0085 }
        r4.startTimer(r0);	 Catch:{ IOException -> 0x0085 }
    L_0x0078:
        r0 = new android.content.Intent;	 Catch:{ IOException -> 0x0085 }
        r1 = "simple_sc_listener_action_on_buffering_end";	 Catch:{ IOException -> 0x0085 }
        r0.<init>(r1);	 Catch:{ IOException -> 0x0085 }
        r1 = r4.mLocalBroadcastManager;	 Catch:{ IOException -> 0x0085 }
        r1.sendBroadcast(r0);	 Catch:{ IOException -> 0x0085 }
        goto L_0x009b;
    L_0x0085:
        r0 = TAG;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "File referencing not exist : ";
        r1.append(r2);
        r1.append(r5);
        r5 = r1.toString();
        com.sherdle.universal.util.Log.m158e(r0, r5);
    L_0x009b:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.soundcloud.player.player.PlaybackService.playTrack(com.sherdle.universal.providers.soundcloud.api.object.TrackObject):void");
    }

    private void updateNotification() {
        this.mNotificationManager.notify(this, this.mPlayerPlaylist.getCurrentTrack(), this.mIsPaused);
    }

    private void gotoIdleState() {
        this.mStopServiceHandler.removeCallbacksAndMessages(null);
        this.mStopServiceHandler.sendEmptyMessageDelayed(7, ChunkedTrackBlacklistUtil.DEFAULT_TRACK_BLACKLIST_MS);
    }

    private void startTimer(long j) {
        CountDownTimer countDownTimer = this.mCountDown;
        if (countDownTimer != null) {
            countDownTimer.cancel();
            this.mCountDown = null;
        }
        this.mCountDown = new CountDownTimer(j, 1000) {
            public void onTick(long j) {
                j = new Intent("simple_sc_listener_action_on_progress_changed");
                j.putExtra("simple_sc_listener_extra_current_time", PlaybackService.this.mMediaPlayer.getCurrentPosition());
                PlaybackService.this.mLocalBroadcastManager.sendBroadcast(j);
            }

            public void onFinish() {
                Intent intent = new Intent("simple_sc_listener_action_on_progress_changed");
                intent.putExtra("simple_sc_listener_extra_current_time", (int) PlaybackService.this.mPlayerPlaylist.getCurrentTrack().getDuration());
                PlaybackService.this.mLocalBroadcastManager.sendBroadcast(intent);
            }
        };
        this.mCountDown.start();
    }

    private void pauseTimer() {
        CountDownTimer countDownTimer = this.mCountDown;
        if (countDownTimer != null) {
            countDownTimer.cancel();
            this.mCountDown = null;
        }
    }

    private void resumeTimer() {
        startTimer(this.mPlayerPlaylist.getCurrentTrack().getDuration() - ((long) this.mMediaPlayer.getCurrentPosition()));
    }

    private void stopTimer() {
        CountDownTimer countDownTimer = this.mCountDown;
        if (countDownTimer != null) {
            countDownTimer.cancel();
            this.mCountDown = null;
        }
    }

    public void onPrepared(MediaPlayer mediaPlayer) {
        TrackObject currentTrack = this.mPlayerPlaylist.getCurrentTrack();
        if (currentTrack.getDuration() == 0) {
            currentTrack.setDuration((long) mediaPlayer.getDuration());
            Intent intent = new Intent("simple_sc_listener_action_on_duration_changed");
            intent.putExtra("simple_sc_listener_extra_duration", (long) mediaPlayer.getDuration());
            this.mLocalBroadcastManager.sendBroadcast(intent);
            resumeTimer();
        }
    }
}
