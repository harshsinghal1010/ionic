package com.sherdle.universal.providers.soundcloud.api;

import com.sherdle.universal.providers.soundcloud.api.object.CommentObject;
import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;
import com.sherdle.universal.util.Helper;
import java.util.ArrayList;

public class SoundCloudClient {
    public static final String BASEURL = "http://api.soundcloud.com/";
    public static final String COMMENTS = "comments";
    public static final String FORMAT_CLIENT_ID = "?client_id=%1$s";
    public static final String FORMAT_FILTER_QUERY = "&q=%1$s";
    public static final String FORMAT_OFFSET = "&offset=%1$s&limit=%2$s";
    public static final String FORMAT_STREAM = "https://api.soundcloud.com/tracks/%1$s/stream?client_id=%2$s";
    public static final String JSON_PREFIX = ".json";
    public static final String PLAYLISTS = "playlists";
    public static final String TRACKS = "tracks";
    public static final String USER = "users";
    private String clientId;
    private String mPrefixClientId;

    public SoundCloudClient(String str) {
        this.clientId = str;
        this.mPrefixClientId = String.format(FORMAT_CLIENT_ID, new Object[]{str});
    }

    public ArrayList<TrackObject> getListTrackObjectsByQuery(String str, int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(BASEURL);
        stringBuilder.append(TRACKS);
        stringBuilder.append(JSON_PREFIX);
        stringBuilder.append(this.mPrefixClientId);
        stringBuilder.append(String.format(FORMAT_FILTER_QUERY, new Object[]{str}));
        stringBuilder.append(String.format(FORMAT_OFFSET, new Object[]{String.valueOf(i), String.valueOf(i2)}));
        return SoundCloudParser.parsingListTrackObject(Helper.getJSONArrayFromUrl(stringBuilder.toString()), this);
    }

    public ArrayList<TrackObject> getListTrackObjectsOfUser(long j, int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(BASEURL);
        stringBuilder.append("users/");
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(String.valueOf(j));
        stringBuilder2.append("/");
        stringBuilder.append(stringBuilder2.toString());
        stringBuilder.append(TRACKS);
        stringBuilder.append(JSON_PREFIX);
        stringBuilder.append(this.mPrefixClientId);
        stringBuilder.append(String.format(FORMAT_OFFSET, new Object[]{String.valueOf(i), String.valueOf(i2)}));
        return SoundCloudParser.parsingListTrackObject(Helper.getJSONArrayFromUrl(stringBuilder.toString()), this);
    }

    public ArrayList<TrackObject> getListTrackObjectsOfPlaylist(long j, int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(BASEURL);
        stringBuilder.append("playlists/");
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(String.valueOf(j));
        stringBuilder2.append("/");
        stringBuilder.append(stringBuilder2.toString());
        stringBuilder.append(TRACKS);
        stringBuilder.append(JSON_PREFIX);
        stringBuilder.append(this.mPrefixClientId);
        stringBuilder.append(String.format(FORMAT_OFFSET, new Object[]{String.valueOf(i), String.valueOf(i2)}));
        return SoundCloudParser.parsingListTrackObject(Helper.getJSONArrayFromUrl(stringBuilder.toString()), this);
    }

    public ArrayList<CommentObject> getListCommentObject(long j) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(BASEURL);
        stringBuilder.append("tracks/");
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(String.valueOf(j));
        stringBuilder2.append("/");
        stringBuilder.append(stringBuilder2.toString());
        stringBuilder.append(COMMENTS);
        stringBuilder.append(JSON_PREFIX);
        stringBuilder.append(this.mPrefixClientId);
        return SoundCloudParser.parsingListCommentObject(Helper.getJSONArrayFromUrl(stringBuilder.toString()));
    }

    public String getClientId() {
        return this.clientId;
    }
}
