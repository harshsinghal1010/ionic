package com.sherdle.universal.providers.soundcloud.api;

import com.google.android.gms.measurement.AppMeasurement.Param;
import com.sherdle.universal.billing.Constants;
import com.sherdle.universal.providers.soundcloud.api.object.CommentObject;
import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;
import com.sherdle.universal.util.Log;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONObject;

public class SoundCloudParser {
    public static final String TAG = "SoundCloudParser";

    public static TrackObject parsingTrackObject(JSONObject jSONObject, SoundCloudClient soundCloudClient) {
        JSONObject jSONObject2 = jSONObject;
        if (jSONObject2 != null) {
            try {
                Date parse;
                long j = jSONObject2.getLong(TtmlNode.ATTR_ID);
                try {
                    parse = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss Z").parse(jSONObject2.getString("created_at"));
                } catch (Exception e) {
                    Log.printStackTrace(e);
                    parse = null;
                }
                long j2 = jSONObject2.getLong("user_id");
                long j3 = jSONObject2.getLong("duration");
                String string = jSONObject2.getString("sharing");
                String string2 = jSONObject2.getString("tag_list");
                String string3 = jSONObject2.getString("genre");
                String string4 = jSONObject2.getString("title");
                String string5 = jSONObject2.getString(Constants.RESPONSE_DESCRIPTION);
                JSONObject jSONObject3 = jSONObject2.getJSONObject("user");
                String string6 = jSONObject3.getString("username");
                String string7 = jSONObject3.getString("avatar_url");
                String string8 = jSONObject2.getString("permalink_url");
                String string9 = jSONObject2.getString("artwork_url");
                String string10 = jSONObject2.getString("waveform_url");
                long j4 = jSONObject2.getLong("playback_count");
                long j5 = jSONObject2.getLong("favoritings_count");
                long j6 = jSONObject2.getLong("comment_count");
                boolean z = jSONObject2.getBoolean("streamable");
                TrackObject trackObject = new TrackObject(j, parse, j2, j3, string, string2, string3, string4, string5, string6, string7, string8, string9, string10, j4, j5, j6, String.format(SoundCloudClient.FORMAT_STREAM, new Object[]{Long.valueOf(j), soundCloudClient.getClientId()}));
                trackObject.setStreamAble(z);
                return trackObject;
            } catch (Exception e2) {
                Log.printStackTrace(e2);
            }
        }
        return null;
    }

    public static ArrayList<TrackObject> parsingListTrackObject(JSONArray jSONArray, SoundCloudClient soundCloudClient) {
        try {
            int length = jSONArray.length();
            ArrayList<TrackObject> arrayList = new ArrayList();
            if (length > 0) {
                for (int i = 0; i < length; i++) {
                    TrackObject parsingTrackObject = parsingTrackObject(jSONArray.getJSONObject(i), soundCloudClient);
                    if (parsingTrackObject != null) {
                        arrayList.add(parsingTrackObject);
                    }
                }
            }
            return arrayList;
        } catch (JSONArray jSONArray2) {
            Log.printStackTrace(jSONArray2);
            return null;
        }
    }

    private static CommentObject parsingCommentObject(JSONObject jSONObject) {
        try {
            Date parse;
            long j = jSONObject.getLong(TtmlNode.ATTR_ID);
            try {
                parse = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss Z").parse(jSONObject.getString("created_at"));
            } catch (Exception e) {
                Log.printStackTrace(e);
                parse = null;
            }
            long j2 = jSONObject.getLong("user_id");
            long j3 = jSONObject.getLong("track_id");
            int i = jSONObject.getInt(Param.TIMESTAMP);
            String string = jSONObject.getString(TtmlNode.TAG_BODY);
            jSONObject = jSONObject.getJSONObject("user");
            return new CommentObject(j, j3, j2, parse, i, string, jSONObject.getString("username"), jSONObject.getString("avatar_url"));
        } catch (JSONObject jSONObject2) {
            Log.printStackTrace(jSONObject2);
            return null;
        }
    }

    public static ArrayList<CommentObject> parsingListCommentObject(JSONArray jSONArray) {
        try {
            int length = jSONArray.length();
            if (length > 0) {
                ArrayList<CommentObject> arrayList = new ArrayList();
                for (int i = 0; i < length; i++) {
                    CommentObject parsingCommentObject = parsingCommentObject(jSONArray.getJSONObject(i));
                    if (parsingCommentObject != null) {
                        arrayList.add(parsingCommentObject);
                    }
                }
                return arrayList;
            }
        } catch (JSONArray jSONArray2) {
            Log.printStackTrace(jSONArray2);
        }
        return null;
    }
}
