package com.sherdle.universal.providers.soundcloud.player.player;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;
import com.sherdle.universal.util.Log;

class PlaybackListener extends BroadcastReceiver {
    static final String ACTION_ON_BUFFERING_ENDED = "simple_sc_listener_action_on_buffering_end";
    static final String ACTION_ON_BUFFERING_STARTED = "simple_sc_listener_action_on_buffering_start";
    static final String ACTION_ON_DURATION_CHANGED = "simple_sc_listener_action_on_duration_changed";
    static final String ACTION_ON_PLAYER_DESTROYED = "simple_sc_listener_action_on_player_destroyed";
    static final String ACTION_ON_PLAYER_PAUSED = "simple_sc_listener_action_on_track_paused";
    static final String ACTION_ON_PROGRESS_CHANGED = "simple_sc_listener_action_on_progress_changed";
    static final String ACTION_ON_SEEK_COMPLETE = "simple_sc_listener_action_on_player_seek_complete";
    static final String ACTION_ON_TRACK_PLAYED = "simple_sc_listener_action_on_track_played";
    static final String EXTRA_KEY_CURRENT_TIME = "simple_sc_listener_extra_current_time";
    static final String EXTRA_KEY_DURATION = "simple_sc_listener_extra_duration";
    static final String EXTRA_KEY_TRACK = "simple_sc_listener_extra_track";
    private static final String TAG = "PlaybackListener";

    protected void onBufferingEnded() {
    }

    protected void onBufferingStarted() {
    }

    protected void onDurationChanged(long j) {
    }

    protected void onPause() {
    }

    protected void onPlay(TrackObject trackObject) {
    }

    protected void onPlayerDestroyed() {
    }

    protected void onProgressChanged(int i) {
    }

    protected void onSeekTo(int i) {
    }

    PlaybackListener() {
    }

    public void onReceive(Context context, Intent intent) {
        if (intent != null) {
            context = intent.getAction();
            Object obj = -1;
            switch (context.hashCode()) {
                case -1846616187:
                    if (context.equals(ACTION_ON_BUFFERING_STARTED) != null) {
                        obj = 4;
                        break;
                    }
                    break;
                case -1727713118:
                    if (context.equals(ACTION_ON_PROGRESS_CHANGED) != null) {
                        obj = 6;
                        break;
                    }
                    break;
                case -1427631938:
                    if (context.equals(ACTION_ON_BUFFERING_ENDED) != null) {
                        obj = 5;
                        break;
                    }
                    break;
                case -826120951:
                    if (context.equals(ACTION_ON_DURATION_CHANGED) != null) {
                        obj = 7;
                        break;
                    }
                    break;
                case -317944670:
                    if (context.equals(ACTION_ON_PLAYER_PAUSED) != null) {
                        obj = 1;
                        break;
                    }
                    break;
                case -308375993:
                    if (context.equals(ACTION_ON_TRACK_PLAYED) != null) {
                        obj = null;
                        break;
                    }
                    break;
                case 394759234:
                    if (context.equals(ACTION_ON_SEEK_COMPLETE) != null) {
                        obj = 2;
                        break;
                    }
                    break;
                case 568567867:
                    if (context.equals(ACTION_ON_PLAYER_DESTROYED) != null) {
                        obj = 3;
                        break;
                    }
                    break;
                default:
                    break;
            }
            switch (obj) {
                case null:
                    onPlay((TrackObject) intent.getSerializableExtra(EXTRA_KEY_TRACK));
                    return;
                case 1:
                    onPause();
                    return;
                case 2:
                    onSeekTo(intent.getIntExtra(EXTRA_KEY_CURRENT_TIME, 0));
                    return;
                case 3:
                    onPlayerDestroyed();
                    return;
                case 4:
                    onBufferingStarted();
                    return;
                case 5:
                    onBufferingEnded();
                    return;
                case 6:
                    onProgressChanged(intent.getIntExtra(EXTRA_KEY_CURRENT_TIME, 0));
                    return;
                case 7:
                    onDurationChanged(intent.getLongExtra(EXTRA_KEY_DURATION, 0));
                    return;
                default:
                    context = TAG;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("unknown action : ");
                    stringBuilder.append(intent.getAction());
                    Log.m158e(context, stringBuilder.toString());
                    return;
            }
        }
    }
}
