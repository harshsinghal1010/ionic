package com.sherdle.universal.providers.soundcloud;

import android.content.Context;
import android.support.v7.widget.RecyclerView.LayoutParams;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.View;
import android.view.ViewGroup;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;
import com.sherdle.universal.providers.soundcloud.player.player.CheerleaderPlayerListener;
import com.sherdle.universal.providers.soundcloud.ui.views.TrackView;
import com.sherdle.universal.providers.soundcloud.ui.views.TrackView.Listener;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import java.util.List;

public class TracksAdapter extends InfiniteRecyclerViewAdapter implements CheerleaderPlayerListener {
    private static final int VIEW_TYPE_FOOTER = 3;
    private static final int VIEW_TYPE_HEADER = 2;
    private static final int VIEW_TYPE_TRACK = 1;
    private View mFooterView;
    private View mHeaderView;
    private Listener mListener;
    private int mPlayedTrackPosition = -1;
    private List<TrackObject> mTracks;

    public static abstract class Holder extends ViewHolder {
        private int viewType;

        public Holder(View view, int i) {
            super(view);
            this.viewType = i;
        }
    }

    private static class FooterHolder extends Holder {
        private FooterHolder(View view) {
            super(view, 3);
        }
    }

    private static class HeaderHolder extends Holder {
        private HeaderHolder(View view) {
            super(view, 2);
        }
    }

    private static class TrackHolder extends Holder {
        private TrackView trackView;

        private TrackHolder(TrackView trackView) {
            super(trackView, 1);
            this.trackView = trackView;
        }
    }

    public void onBufferingEnded() {
    }

    public void onBufferingStarted() {
    }

    public void onDurationChanged(long j) {
    }

    public void onPlayerDestroyed() {
    }

    public void onPlayerPause() {
    }

    public void onPlayerSeekTo(int i) {
    }

    public void onProgressChanged(int i) {
    }

    public TracksAdapter(Context context, Listener listener, List<TrackObject> list) {
        super(context, null);
        this.mTracks = list;
        this.mListener = listener;
    }

    protected int getViewType(int i) {
        if (i != 0 || this.mHeaderView == null) {
            return (i != getItemCount() - 1 || this.mFooterView == 0) ? 1 : 3;
        } else {
            return 2;
        }
    }

    protected ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        switch (i) {
            case 1:
                i = new TrackView(viewGroup.getContext());
                i.setListener(this.mListener);
                i.setLayoutParams(new LayoutParams(-1, -2));
                return new TrackHolder(i);
            case 2:
                return new HeaderHolder(this.mHeaderView);
            case 3:
                return new FooterHolder(this.mFooterView);
            default:
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("View type not handled : ");
                stringBuilder.append(i);
                throw new IllegalStateException(stringBuilder.toString());
        }
    }

    protected void doBindViewHolder(ViewHolder viewHolder, int i) {
        switch (viewHolder.getItemViewType()) {
            case 1:
                TrackHolder trackHolder = (TrackHolder) viewHolder;
                trackHolder.trackView.setModel((TrackObject) this.mTracks.get(i - (this.mHeaderView != null ? 1 : 0)));
                if (i == this.mPlayedTrackPosition) {
                    trackHolder.trackView.setBackgroundResource(R.drawable.soundcloud_selectable_background_selected);
                    trackHolder.trackView.setSelected(true);
                } else {
                    trackHolder.trackView.setBackgroundResource(R.drawable.soundcloud_selectable_background_white);
                    trackHolder.trackView.setSelected(false);
                }
                if (i == 0) {
                    trackHolder.trackView.findViewById(R.id.divider).setVisibility(8);
                    return;
                }
                return;
            case 2:
            case 3:
                return;
            default:
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unhandled view type : ");
                stringBuilder.append(viewHolder.getItemViewType());
                throw new IllegalStateException(stringBuilder.toString());
        }
    }

    protected int getCount() {
        int i = 0;
        int i2 = this.mHeaderView == null ? 0 : 1;
        if (this.mFooterView != null) {
            i = 1;
        }
        return (i2 + this.mTracks.size()) + i;
    }

    public void onPlayerPlay(TrackObject trackObject, int i) {
        this.mPlayedTrackPosition = i + (this.mHeaderView == null ? null : true);
        notifyDataSetChanged();
    }

    public void setHeaderView(View view) {
        this.mHeaderView = view;
    }

    public void setFooterView(View view) {
        this.mFooterView = view;
    }
}
