package com.sherdle.universal.providers.soundcloud.ui.views;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.source.chunk.ChunkedTrackBlacklistUtil;
import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;
import com.sherdle.universal.providers.soundcloud.helpers.SoundCloudArtworkHelper;
import com.squareup.picasso.Picasso;

public class TrackView extends FrameLayout implements OnClickListener {
    private TextView mArtist;
    private int mArtistColor;
    private int mArtistColorSelected;
    private ImageView mArtwork;
    private Listener mListener;
    private TrackObject mModel;
    private ImageView mMore;
    private TextView mTitle;
    private int mTrackColor;
    private int mTrackColorSelected;

    /* renamed from: com.sherdle.universal.providers.soundcloud.ui.views.TrackView$1 */
    class C06331 implements OnClickListener {
        C06331() {
        }

        public void onClick(View view) {
            if (TrackView.this.mListener != null) {
                TrackView.this.mListener.onMoreClicked(TrackView.this.mModel, view);
            }
        }
    }

    public interface Listener {
        void onMoreClicked(TrackObject trackObject, View view);

        void onTrackClicked(TrackObject trackObject);
    }

    public TrackView(Context context) {
        super(context);
        if (!isInEditMode()) {
            init(context);
        }
    }

    public TrackView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        if (isInEditMode() == null) {
            init(context);
        }
    }

    public TrackView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (isInEditMode() == null) {
            init(context);
        }
    }

    public void setSelected(boolean z) {
        super.setSelected(z);
        if (z) {
            this.mArtist.setTextColor(this.mArtistColorSelected);
            this.mTitle.setTextColor(this.mTrackColorSelected);
            findViewById(R.id.divider).setVisibility(4);
            return;
        }
        this.mArtist.setTextColor(this.mArtistColor);
        this.mTitle.setTextColor(this.mTrackColor);
        findViewById(R.id.divider).setVisibility(0);
    }

    public void setModel(TrackObject trackObject) {
        this.mModel = trackObject;
        trackObject = this.mModel;
        if (trackObject != null) {
            String artworkUrl = SoundCloudArtworkHelper.getArtworkUrl(trackObject, SoundCloudArtworkHelper.XLARGE);
            if (artworkUrl != null) {
                this.mArtwork.setVisibility(0);
                Picasso.get().load(artworkUrl).into(this.mArtwork);
            } else {
                this.mArtwork.setVisibility(8);
            }
            this.mArtist.setText(this.mModel.getUsername());
            this.mTitle.setText(this.mModel.getTitle());
            long duration = this.mModel.getDuration() / ChunkedTrackBlacklistUtil.DEFAULT_TRACK_BLACKLIST_MS;
            duration = (this.mModel.getDuration() % ChunkedTrackBlacklistUtil.DEFAULT_TRACK_BLACKLIST_MS) / 1000;
        }
    }

    public void setListener(Listener listener) {
        this.mListener = listener;
    }

    private void init(Context context) {
        LayoutInflater.from(context).inflate(R.layout.soundcloud_track_view, this);
        this.mArtwork = (ImageView) findViewById(R.id.track_view_artwork);
        this.mTitle = (TextView) findViewById(R.id.track_view_title);
        this.mArtist = (TextView) findViewById(R.id.track_view_artist);
        this.mMore = (ImageView) findViewById(R.id.track_more);
        setBackgroundResource(R.drawable.soundcloud_selectable_background_white);
        setOnClickListener(this);
        this.mTrackColor = ContextCompat.getColor(context, R.color.track_view_track);
        this.mArtistColor = ContextCompat.getColor(context, R.color.track_view_artist);
        this.mArtistColorSelected = ContextCompat.getColor(context, R.color.track_view_artist_selected);
        this.mTrackColorSelected = ContextCompat.getColor(context, R.color.track_view_track_selected);
        this.mMore.setOnClickListener(new C06331());
    }

    public void onClick(View view) {
        view = this.mListener;
        if (view != null) {
            view.onTrackClicked(this.mModel);
        }
    }
}
