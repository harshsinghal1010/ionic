package com.sherdle.universal.providers.soundcloud.player.player;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.DrawableRes;

final class NotificationConfig {
    private Activity mNotificationActivity;
    private Bundle mNotificationBundle;
    private int mNotificationIcon;
    private int mNotificationIconBackground;

    public int getNotificationIcon() {
        return this.mNotificationIcon;
    }

    public void setNotificationIcon(@DrawableRes int i) {
        this.mNotificationIcon = i;
    }

    public int getNotificationIconBackground() {
        return this.mNotificationIconBackground;
    }

    public void setNotificationIconBackground(@DrawableRes int i) {
        this.mNotificationIconBackground = i;
    }

    public Activity getNotificationActivity() {
        return this.mNotificationActivity;
    }

    public void setNotificationActivity(Activity activity) {
        this.mNotificationActivity = activity;
    }

    public void setNotificationBundle(Bundle bundle) {
        this.mNotificationBundle = bundle;
    }

    public Bundle getNotificationBundle() {
        return this.mNotificationBundle;
    }
}
