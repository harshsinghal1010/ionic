package com.sherdle.universal.providers.soundcloud.player.player;

import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;
import java.util.ArrayList;
import java.util.List;

final class PlayerPlaylist {
    private static PlayerPlaylist sInstance;
    private int mCurrentTrackIndex = -1;
    private ArrayList<TrackObject> mTracks = new ArrayList();

    private PlayerPlaylist() {
    }

    public static PlayerPlaylist getInstance() {
        if (sInstance == null) {
            sInstance = new PlayerPlaylist();
        }
        return sInstance;
    }

    public ArrayList<TrackObject> getTracks() {
        return this.mTracks;
    }

    public TrackObject getCurrentTrack() {
        int i = this.mCurrentTrackIndex;
        return (i <= -1 || i >= getTracks().size()) ? null : (TrackObject) getTracks().get(this.mCurrentTrackIndex);
    }

    public int getCurrentTrackIndex() {
        return this.mCurrentTrackIndex;
    }

    public void add(TrackObject trackObject) {
        add(getTracks().size(), trackObject);
    }

    public void addAll(List<TrackObject> list) {
        for (TrackObject add : list) {
            add(getTracks().size(), add);
        }
    }

    public void add(int i, TrackObject trackObject) {
        if (this.mCurrentTrackIndex == -1) {
            this.mCurrentTrackIndex = 0;
        }
        this.mTracks.add(i, trackObject);
    }

    public TrackObject remove(int i) {
        ArrayList tracks = getTracks();
        if (i < 0 || i >= tracks.size()) {
            return null;
        }
        TrackObject trackObject = (TrackObject) tracks.remove(i);
        if (tracks.size() == 0) {
            this.mCurrentTrackIndex = 0;
            return trackObject;
        } else if (i == tracks.size()) {
            this.mCurrentTrackIndex = (this.mCurrentTrackIndex - 1) % tracks.size();
            return trackObject;
        } else if (i < 0) {
            return trackObject;
        } else {
            int i2 = this.mCurrentTrackIndex;
            if (i >= i2) {
                return trackObject;
            }
            this.mCurrentTrackIndex = (i2 - 1) % tracks.size();
            return trackObject;
        }
    }

    public TrackObject next() {
        this.mCurrentTrackIndex = (this.mCurrentTrackIndex + 1) % getTracks().size();
        return (TrackObject) getTracks().get(this.mCurrentTrackIndex);
    }

    public TrackObject previous() {
        int size = getTracks().size();
        this.mCurrentTrackIndex = ((this.mCurrentTrackIndex + size) - 1) % size;
        return (TrackObject) getTracks().get(this.mCurrentTrackIndex);
    }

    public int size() {
        return getTracks().size();
    }

    public boolean isEmpty() {
        return getTracks().size() == 0;
    }

    void setPlayingTrack(int i) {
        if (i < 0 || i >= getTracks().size()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No tracks a the position ");
            stringBuilder.append(i);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        this.mCurrentTrackIndex = i;
    }
}
