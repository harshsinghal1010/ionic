package com.sherdle.universal.providers.soundcloud.player.player;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PlayerReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.media.AUDIO_BECOMING_NOISY") != null) {
            intent = new Intent(context, PlaybackService.class);
            intent.setAction("sound_cloud_player_becoming_noisy");
            context.startService(intent);
        }
    }
}
