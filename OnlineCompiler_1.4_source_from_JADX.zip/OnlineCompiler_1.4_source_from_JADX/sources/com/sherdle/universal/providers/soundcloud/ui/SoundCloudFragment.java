package com.sherdle.universal.providers.soundcloud.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.LayoutManager;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.support.v7.widget.helper.ItemTouchHelper.SimpleCallback;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.FrameLayout;
import android.widget.PopupMenu;
import android.widget.PopupMenu.OnMenuItemClickListener;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.C0559R;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.inherit.BackPressFragment;
import com.sherdle.universal.inherit.CollapseControllingFragment;
import com.sherdle.universal.providers.soundcloud.TracksAdapter;
import com.sherdle.universal.providers.soundcloud.api.SoundCloudClient;
import com.sherdle.universal.providers.soundcloud.api.WordpressClient;
import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;
import com.sherdle.universal.providers.soundcloud.helpers.EndlessRecyclerOnScrollListener;
import com.sherdle.universal.providers.soundcloud.player.player.CheerleaderPlayer;
import com.sherdle.universal.providers.soundcloud.player.player.CheerleaderPlayer.Builder;
import com.sherdle.universal.providers.soundcloud.player.player.CheerleaderPlaylistListener;
import com.sherdle.universal.providers.soundcloud.ui.views.PlaybackView;
import com.sherdle.universal.providers.soundcloud.ui.views.PlaybackView.Listener;
import com.sherdle.universal.providers.soundcloud.ui.views.TrackView;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.ThemeUtils;
import java.util.ArrayList;
import java.util.List;

public class SoundCloudFragment extends Fragment implements Listener, CheerleaderPlaylistListener, BackPressFragment, CollapseControllingFragment {
    private static final int PER_PAGE = 20;
    private FrameLayout ll;
    private Activity mAct;
    private TracksAdapter mAdapter;
    private CheerleaderPlayer mCheerleaderPlayer;
    private EndlessRecyclerOnScrollListener mEndlessRecyclerOnScrollListener;
    private PlaybackView mPlaybackView;
    private TracksAdapter mPlaylistAdapter;
    private RecyclerView mPlaylistRecyclerView;
    private ArrayList<TrackObject> mPlaylistTracks;
    private TrackView.Listener mPlaylistTracksListener;
    private TrackView.Listener mRetrieveTracksListener;
    private RecyclerView mRetrieveTracksRecyclerView;
    private ArrayList<TrackObject> mRetrievedTracks;

    /* renamed from: com.sherdle.universal.providers.soundcloud.ui.SoundCloudFragment$1 */
    class C06261 implements AnimationListener {
        public void onAnimationRepeat(Animation animation) {
        }

        public void onAnimationStart(Animation animation) {
        }

        C06261() {
        }

        public void onAnimationEnd(Animation animation) {
            SoundCloudFragment.this.mPlaylistRecyclerView.setVisibility(8);
        }
    }

    /* renamed from: com.sherdle.universal.providers.soundcloud.ui.SoundCloudFragment$2 */
    class C06272 implements OnGlobalLayoutListener {
        C06272() {
        }

        public void onGlobalLayout() {
            if (SoundCloudFragment.this.getActivity() != null) {
                if (SoundCloudFragment.this.isAdded()) {
                    int dimensionPixelOffset = SoundCloudFragment.this.getResources().getDimensionPixelOffset(R.dimen.playback_view_height);
                    SoundCloudFragment.this.mPlaylistRecyclerView.setPadding(0, SoundCloudFragment.this.mPlaylistRecyclerView.getMeasuredHeight() - dimensionPixelOffset, 0, 0);
                    SoundCloudFragment.this.mPlaylistRecyclerView.setAdapter(SoundCloudFragment.this.mPlaylistAdapter);
                    if (SoundCloudFragment.this.mPlaylistTracks.isEmpty()) {
                        SoundCloudFragment.this.mPlaylistRecyclerView.setVisibility(8);
                        SoundCloudFragment.this.mPlaylistRecyclerView.setTranslationY((float) dimensionPixelOffset);
                    } else {
                        SoundCloudFragment.this.mRetrieveTracksRecyclerView.setPadding(0, 0, 0, dimensionPixelOffset);
                    }
                }
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.soundcloud.ui.SoundCloudFragment$6 */
    class C09946 implements TrackView.Listener {
        C09946() {
        }

        public void onTrackClicked(TrackObject trackObject) {
            if (SoundCloudFragment.this.mCheerleaderPlayer.isClosed()) {
                SoundCloudFragment soundCloudFragment = SoundCloudFragment.this;
                soundCloudFragment.mCheerleaderPlayer = soundCloudFragment.initPlayer();
            }
            if (SoundCloudFragment.this.mCheerleaderPlayer.getTracks().contains(trackObject)) {
                SoundCloudFragment.this.mCheerleaderPlayer.play(trackObject);
                return;
            }
            boolean isPlaying = SoundCloudFragment.this.mCheerleaderPlayer.isPlaying() ^ true;
            SoundCloudFragment.this.mCheerleaderPlayer.addTrack(trackObject, isPlaying);
            SoundCloudFragment.this.mPlaylistAdapter.notifyDataSetChanged();
            if (!isPlaying) {
                Toast.makeText(SoundCloudFragment.this.mAct, SoundCloudFragment.this.getResources().getString(R.string.toast_track_added), 1).show();
            }
        }

        public void onMoreClicked(TrackObject trackObject, View view) {
            SoundCloudFragment.this.showTrackActionsPopup(trackObject, view);
        }
    }

    /* renamed from: com.sherdle.universal.providers.soundcloud.ui.SoundCloudFragment$8 */
    class C09958 implements TrackView.Listener {
        C09958() {
        }

        public void onTrackClicked(TrackObject trackObject) {
            SoundCloudFragment.this.mCheerleaderPlayer.play(trackObject);
        }

        public void onMoreClicked(TrackObject trackObject, View view) {
            SoundCloudFragment.this.showTrackActionsPopup(trackObject, view);
        }
    }

    public boolean dynamicToolbarElevation() {
        return false;
    }

    public boolean supportsCollapse() {
        return false;
    }

    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreate(bundle);
        this.ll = (FrameLayout) layoutInflater.inflate(R.layout.fragment_soundcloud, viewGroup, false);
        setHasOptionsMenu(true);
        this.mRetrieveTracksRecyclerView = (RecyclerView) this.ll.findViewById(R.id.recyclerview);
        this.mPlaylistRecyclerView = (RecyclerView) this.ll.findViewById(R.id.activity_artist_playlist);
        return this.ll;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        this.mCheerleaderPlayer = initPlayer();
        initRetrieveTracksRecyclerView();
        initPlaylistTracksRecyclerView();
        setTrackListPadding();
        bundle = this.mCheerleaderPlayer.getTracks();
        if (bundle != null) {
            this.mPlaylistTracks.addAll(bundle);
        }
        this.mPlaybackView.synchronize(this.mCheerleaderPlayer);
    }

    private CheerleaderPlayer initPlayer() {
        String[] stringArray = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        Bundle bundle = new Bundle();
        bundle.putStringArray(MainActivity.FRAGMENT_DATA, stringArray);
        bundle.putSerializable(MainActivity.FRAGMENT_CLASS, getClass());
        return new Builder().from(this.mAct).with((int) R.string.soundcloud_id).notificationActivity(new HolderActivity()).notificationIcon(C0559R.drawable.ic_radio_playing).notificationBundle(bundle).build();
    }

    public void onResume() {
        super.onResume();
        if (this.mCheerleaderPlayer.isClosed()) {
            this.mCheerleaderPlayer = initPlayer();
        }
        this.mCheerleaderPlayer.registerPlayerListener(this.mPlaybackView);
        this.mCheerleaderPlayer.registerPlayerListener(this.mPlaylistAdapter);
        this.mCheerleaderPlayer.registerPlaylistListener(this);
    }

    public void onPause() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r2 = this;
        super.onPause();
        r0 = r2.mCheerleaderPlayer;	 Catch:{ Exception -> 0x0017 }
        r1 = r2.mPlaybackView;	 Catch:{ Exception -> 0x0017 }
        r0.unregisterPlayerListener(r1);	 Catch:{ Exception -> 0x0017 }
        r0 = r2.mCheerleaderPlayer;	 Catch:{ Exception -> 0x0017 }
        r1 = r2.mPlaylistAdapter;	 Catch:{ Exception -> 0x0017 }
        r0.unregisterPlayerListener(r1);	 Catch:{ Exception -> 0x0017 }
        r0 = r2.mCheerleaderPlayer;	 Catch:{ Exception -> 0x0017 }
        r0.unregisterPlaylistListener(r2);	 Catch:{ Exception -> 0x0017 }
        goto L_0x001e;
    L_0x0017:
        r0 = "INFO";
        r1 = "Unable to unregister player listeners";
        com.sherdle.universal.util.Log.m161v(r0, r1);
    L_0x001e:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.soundcloud.ui.SoundCloudFragment.onPause():void");
    }

    public void onDestroy() {
        super.onDestroy();
        this.mCheerleaderPlayer.destroy();
    }

    public void onTogglePlayPressed() {
        this.mCheerleaderPlayer.togglePlayback();
    }

    public void onPreviousPressed() {
        this.mCheerleaderPlayer.previous();
    }

    public void onNextPressed() {
        this.mCheerleaderPlayer.next();
    }

    public void onSeekToRequested(int i) {
        this.mCheerleaderPlayer.seekTo(i);
    }

    public void onTrackAdded(TrackObject trackObject) {
        if (this.mPlaylistTracks.isEmpty()) {
            this.mPlaylistRecyclerView.setVisibility(0);
            this.mPlaylistRecyclerView.animate().translationY(0.0f);
            this.mRetrieveTracksRecyclerView.setPadding(0, 0, 0, getResources().getDimensionPixelOffset(R.dimen.playback_view_height));
        }
        this.mPlaylistTracks.add(trackObject);
        this.mPlaylistAdapter.notifyDataSetChanged();
    }

    public void onTrackRemoved(TrackObject trackObject, boolean z) {
        if (this.mPlaylistTracks.remove(trackObject) != null) {
            this.mPlaylistAdapter.notifyDataSetChanged();
        }
        if (z) {
            this.mPlaylistRecyclerView.animate().translationY((float) this.mPlaybackView.getHeight());
            this.mPlaylistRecyclerView.setLayoutAnimationListener(new C06261());
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.soundcloud_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId != R.id.play) {
            if (itemId != R.id.refresh) {
                return super.onOptionsItemSelected(menuItem);
            }
            this.mRetrievedTracks.clear();
            this.mEndlessRecyclerOnScrollListener.reset();
            loadTracks(0);
        }
        this.mCheerleaderPlayer.addTracks(this.mRetrievedTracks);
        if (!this.mCheerleaderPlayer.isPlaying()) {
            this.mCheerleaderPlayer.play();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void setTrackListPadding() {
        final OnGlobalLayoutListener c06272 = new C06272();
        this.mPlaylistRecyclerView.getViewTreeObserver().addOnGlobalLayoutListener(c06272);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                SoundCloudFragment.this.mPlaylistRecyclerView.getViewTreeObserver().removeOnGlobalLayoutListener(c06272);
            }
        }, 500);
    }

    private void loadTracks(int i) {
        boolean z;
        final int i2 = i * 20;
        boolean z2 = false;
        this.mAdapter.setFooterView(LayoutInflater.from(this.mAct).inflate(R.layout.listview_footer, this.mPlaylistRecyclerView, false));
        this.mAdapter.notifyDataSetChanged();
        final String[] stringArray = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        if (stringArray.length <= 2 || stringArray[2].equals("wordpress") == 0) {
            z = stringArray.length > 1 && stringArray[1].equals("playlist") != 0;
        } else {
            z2 = true;
            z = false;
        }
        AsyncTask.execute(new Runnable() {
            public void run() {
                if (SoundCloudFragment.this.getActivity() != null) {
                    if (SoundCloudFragment.this.isAdded()) {
                        List list;
                        boolean z = false;
                        if (z2) {
                            WordpressClient wordpressClient = new WordpressClient(stringArray[0]);
                            ArrayList tracksInCategory = wordpressClient.getTracksInCategory(stringArray[1], i2 / 20);
                            EndlessRecyclerOnScrollListener access$400 = SoundCloudFragment.this.mEndlessRecyclerOnScrollListener;
                            if (i2 / 20 >= wordpressClient.getMaxPages()) {
                                z = true;
                            }
                            access$400.forceCantLoadMore(z);
                            list = tracksInCategory;
                        } else {
                            SoundCloudClient soundCloudClient = new SoundCloudClient(SoundCloudFragment.this.getResources().getString(R.string.soundcloud_id));
                            long parseLong = Long.parseLong(stringArray[0]);
                            if (z) {
                                list = soundCloudClient.getListTrackObjectsOfPlaylist(parseLong, i2, 20);
                            } else {
                                list = soundCloudClient.getListTrackObjectsOfUser(parseLong, i2, 20);
                            }
                        }
                        SoundCloudFragment.this.mAct.runOnUiThread(new Runnable() {
                            public void run() {
                                SoundCloudFragment.this.mAdapter.setFooterView(null);
                                if (list != null) {
                                    SoundCloudFragment.this.mAdapter.setModeAndNotify(1);
                                    if (list.size() > 0) {
                                        SoundCloudFragment.this.mRetrievedTracks.addAll(list);
                                    }
                                } else {
                                    Helper.noConnection(SoundCloudFragment.this.mAct);
                                    SoundCloudFragment.this.mAdapter.setModeAndNotify(2);
                                }
                                SoundCloudFragment.this.mAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                }
            }
        });
    }

    private void showTrackActionsPopup(final TrackObject trackObject, View view) {
        PopupMenu popupMenu = new PopupMenu(this.mAct, view);
        popupMenu.getMenuInflater().inflate(R.menu.soundcloud_track_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem menuItem) {
                menuItem = menuItem.getItemId();
                if (menuItem == R.id.menu_download) {
                    Helper.download(SoundCloudFragment.this.mAct, trackObject.getLinkStream());
                    return true;
                } else if (menuItem != R.id.menu_share) {
                    return null;
                } else {
                    menuItem = new Intent("android.intent.action.SEND");
                    menuItem.setType("text/plain");
                    menuItem.putExtra("android.intent.extra.TEXT", trackObject.getPermalinkUrl());
                    SoundCloudFragment soundCloudFragment = SoundCloudFragment.this;
                    soundCloudFragment.startActivity(Intent.createChooser(menuItem, soundCloudFragment.getResources().getString(R.string.share_header)));
                    return true;
                }
            }
        });
        popupMenu.show();
    }

    private void initRetrieveTracksRecyclerView() {
        this.mRetrieveTracksListener = new C09946();
        this.mRetrievedTracks = new ArrayList();
        this.mAdapter = new TracksAdapter(getContext(), this.mRetrieveTracksListener, this.mRetrievedTracks);
        this.mAdapter.setModeAndNotify(3);
        this.mRetrieveTracksRecyclerView.setAdapter(this.mAdapter);
        LayoutManager linearLayoutManager = new LinearLayoutManager(this.mAct, 1, false);
        this.mRetrieveTracksRecyclerView.setLayoutManager(linearLayoutManager);
        this.mEndlessRecyclerOnScrollListener = new EndlessRecyclerOnScrollListener(linearLayoutManager) {
            public void onLoadMore(final int i) {
                SoundCloudFragment.this.mRetrieveTracksRecyclerView.post(new Runnable() {
                    public void run() {
                        SoundCloudFragment.this.loadTracks(i);
                    }
                });
            }
        };
        this.mRetrieveTracksRecyclerView.addOnScrollListener(this.mEndlessRecyclerOnScrollListener);
    }

    private void initPlaylistTracksRecyclerView() {
        this.mPlaylistTracksListener = new C09958();
        this.mPlaybackView = new PlaybackView(this.mAct);
        this.mPlaybackView.setListener(this);
        this.mPlaylistTracks = new ArrayList();
        this.mPlaylistAdapter = new TracksAdapter(getContext(), this.mPlaylistTracksListener, this.mPlaylistTracks);
        this.mPlaylistAdapter.setHeaderView(this.mPlaybackView);
        this.mPlaylistRecyclerView.setLayoutManager(new LinearLayoutManager(this.mAct, 1, false));
        new ItemTouchHelper(new SimpleCallback(0, 4) {
            public boolean onMove(RecyclerView recyclerView, ViewHolder viewHolder, ViewHolder viewHolder2) {
                return false;
            }

            public int getSwipeDirs(RecyclerView recyclerView, ViewHolder viewHolder) {
                if (viewHolder.getAdapterPosition() == 0) {
                    return null;
                }
                return super.getSwipeDirs(recyclerView, viewHolder);
            }

            public void onSwiped(ViewHolder viewHolder, int i) {
                TrackObject trackObject = (TrackObject) SoundCloudFragment.this.mCheerleaderPlayer.getTracks().get(viewHolder.getAdapterPosition() - 1);
                if (SoundCloudFragment.this.mCheerleaderPlayer.getTracks().contains(trackObject) != 0) {
                    SoundCloudFragment.this.mCheerleaderPlayer.removeTrack(SoundCloudFragment.this.mPlaylistTracks.indexOf(trackObject));
                }
            }

            public void onChildDraw(Canvas canvas, RecyclerView recyclerView, ViewHolder viewHolder, float f, float f2, int i, boolean z) {
                if (i == 1) {
                    View view = viewHolder.itemView;
                    Paint paint = new Paint();
                    if (f < 0.0f) {
                        paint.setColor(ContextCompat.getColor(SoundCloudFragment.this.mAct, R.color.grey));
                        canvas.drawRect(((float) view.getRight()) + f, (float) view.getTop(), (float) view.getRight(), (float) view.getBottom(), paint);
                    }
                    super.onChildDraw(canvas, recyclerView, viewHolder, f, f2, i, z);
                }
            }
        }).attachToRecyclerView(this.mPlaylistRecyclerView);
    }

    public boolean handleBackPress() {
        if (this.mPlaybackView.getTop() >= this.mPlaylistRecyclerView.getHeight() - this.mPlaybackView.getHeight() || this.mPlaylistTracks.size() <= 0) {
            return false;
        }
        this.mPlaylistRecyclerView.getLayoutManager().smoothScrollToPosition(this.mPlaylistRecyclerView, null, 0);
        return true;
    }
}
