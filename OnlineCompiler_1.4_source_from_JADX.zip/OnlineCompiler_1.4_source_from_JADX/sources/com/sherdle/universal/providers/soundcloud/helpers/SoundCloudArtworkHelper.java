package com.sherdle.universal.providers.soundcloud.helpers;

import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;

public final class SoundCloudArtworkHelper {
    public static final String BADGE = "badge";
    public static final String LARGE = "large";
    public static final String MINI = "mini";
    public static final String SMALL = "small";
    public static final String TINY = "tiny";
    public static final String XLARGE = "t300x300";
    public static final String XXLARGE = "crop";
    public static final String XXXLARGE = "t500x500";

    private SoundCloudArtworkHelper() {
    }

    public static String getArtworkUrl(TrackObject trackObject, String str) {
        Object obj;
        String artworkUrl = trackObject.getArtworkUrl();
        trackObject = trackObject.getAvatarUrl();
        if (artworkUrl != null) {
            if (!artworkUrl.equals("null")) {
                trackObject = artworkUrl;
                obj = -1;
                switch (str.hashCode()) {
                    case -257262854:
                        if (str.equals(XLARGE)) {
                            obj = 5;
                            break;
                        }
                        break;
                    case 3062416:
                        if (str.equals(XXLARGE)) {
                            obj = 6;
                            break;
                        }
                        break;
                    case 3351639:
                        if (str.equals(MINI)) {
                            obj = null;
                            break;
                        }
                        break;
                    case 3560192:
                        if (str.equals(TINY)) {
                            obj = 1;
                            break;
                        }
                        break;
                    case 93494179:
                        if (str.equals(BADGE)) {
                            obj = 3;
                            break;
                        }
                        break;
                    case 102742843:
                        if (str.equals(LARGE)) {
                            obj = 4;
                            break;
                        }
                        break;
                    case 109548807:
                        if (str.equals(SMALL)) {
                            obj = 2;
                            break;
                        }
                        break;
                    case 1517746430:
                        if (str.equals(XXXLARGE)) {
                            obj = 7;
                            break;
                        }
                        break;
                    default:
                        break;
                }
                switch (obj) {
                    case null:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                        return trackObject.replace(LARGE, str);
                    default:
                        return trackObject;
                }
            }
        }
        if (trackObject != null) {
            if (trackObject.equals("null")) {
            }
            obj = -1;
            switch (str.hashCode()) {
                case -257262854:
                    if (str.equals(XLARGE)) {
                        obj = 5;
                        break;
                    }
                    break;
                case 3062416:
                    if (str.equals(XXLARGE)) {
                        obj = 6;
                        break;
                    }
                    break;
                case 3351639:
                    if (str.equals(MINI)) {
                        obj = null;
                        break;
                    }
                    break;
                case 3560192:
                    if (str.equals(TINY)) {
                        obj = 1;
                        break;
                    }
                    break;
                case 93494179:
                    if (str.equals(BADGE)) {
                        obj = 3;
                        break;
                    }
                    break;
                case 102742843:
                    if (str.equals(LARGE)) {
                        obj = 4;
                        break;
                    }
                    break;
                case 109548807:
                    if (str.equals(SMALL)) {
                        obj = 2;
                        break;
                    }
                    break;
                case 1517746430:
                    if (str.equals(XXXLARGE)) {
                        obj = 7;
                        break;
                    }
                    break;
                default:
                    break;
            }
            switch (obj) {
                case null:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    return trackObject.replace(LARGE, str);
                default:
                    return trackObject;
            }
        }
        return null;
    }
}
