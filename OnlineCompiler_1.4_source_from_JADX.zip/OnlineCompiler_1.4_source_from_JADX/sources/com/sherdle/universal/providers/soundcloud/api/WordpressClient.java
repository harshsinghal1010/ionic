package com.sherdle.universal.providers.soundcloud.api;

import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.providers.soundcloud.api.object.CommentObject;
import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.api.JsonApiPostLoader.BackgroundPostCompleterListener;
import com.sherdle.universal.providers.wordpress.api.RestApiPostLoader;
import com.sherdle.universal.providers.wordpress.api.WordpressGetTaskInfo;
import com.sherdle.universal.providers.wordpress.api.providers.RestApiProvider;
import com.sherdle.universal.providers.wordpress.api.providers.WordpressProvider;
import java.util.ArrayList;
import java.util.Iterator;
import org.jsoup.helper.StringUtil;

public class WordpressClient {
    private String apiUrl;
    private int maxPages;

    public ArrayList<CommentObject> getListCommentObject(long j) {
        return null;
    }

    public ArrayList<TrackObject> getListTrackObjectsByQuery(String str, int i, int i2) {
        return null;
    }

    public WordpressClient(String str) {
        this.apiUrl = str;
    }

    public ArrayList<TrackObject> getRecentTracks(int i) {
        return getTracksInCategory("", i);
    }

    public ArrayList<TrackObject> getTracksInCategory(String str, int i) {
        String recentPosts;
        WordpressGetTaskInfo wordpressGetTaskInfo = new WordpressGetTaskInfo(null, null, this.apiUrl, Boolean.valueOf(false));
        WordpressProvider wordpressProvider = wordpressGetTaskInfo.provider;
        StringBuilder stringBuilder = new StringBuilder();
        if (StringUtil.isBlank(str)) {
            recentPosts = wordpressGetTaskInfo.provider.getRecentPosts(wordpressGetTaskInfo);
        } else {
            recentPosts = wordpressGetTaskInfo.provider.getCategoryPosts(wordpressGetTaskInfo, str);
        }
        stringBuilder.append(recentPosts);
        stringBuilder.append(i);
        ArrayList parsePostsFromUrl = wordpressProvider.parsePostsFromUrl(wordpressGetTaskInfo, stringBuilder.toString());
        if (wordpressGetTaskInfo.pages != null) {
            if (parsePostsFromUrl != null) {
                r0.maxPages = wordpressGetTaskInfo.pages.intValue();
                final ArrayList<TrackObject> arrayList = new ArrayList();
                Iterator it = parsePostsFromUrl.iterator();
                while (it.hasNext()) {
                    final PostItem postItem = (PostItem) it.next();
                    if (wordpressGetTaskInfo.provider instanceof RestApiProvider) {
                        new RestApiPostLoader(postItem, r0.apiUrl, new BackgroundPostCompleterListener() {
                            public void completed(PostItem postItem) {
                                if (postItem.getAttachments().size() > 0) {
                                    MediaAttachment mediaAttachment = null;
                                    Iterator it = postItem.getAttachments().iterator();
                                    while (it.hasNext()) {
                                        MediaAttachment mediaAttachment2 = (MediaAttachment) it.next();
                                        if (mediaAttachment2.getMime().contains(MediaAttachment.MIME_PATTERN_AUDIO)) {
                                            mediaAttachment = mediaAttachment2;
                                            break;
                                        }
                                    }
                                    if (mediaAttachment != null) {
                                        TrackObject trackObject = r2;
                                        TrackObject trackObject2 = new TrackObject(postItem.getId().longValue(), postItem.getDate(), 0, mediaAttachment.getDuration(), null, null, null, postItem.getTitle(), postItem.getContent(), mediaAttachment.getArtist(), null, postItem.getUrl(), postItem.getThumbnailCandidate(), null, 0, 0, postItem.getCommentCount().longValue(), mediaAttachment.getUrl());
                                        trackObject2 = trackObject;
                                        trackObject2.setStreamAble(true);
                                        arrayList.add(trackObject2);
                                    }
                                }
                            }
                        }).run();
                    } else {
                        MediaAttachment mediaAttachment;
                        Iterator it2 = postItem.getAttachments().iterator();
                        while (it2.hasNext()) {
                            mediaAttachment = (MediaAttachment) it2.next();
                            if (mediaAttachment.getMime().contains(MediaAttachment.MIME_PATTERN_AUDIO)) {
                                break;
                            }
                        }
                        mediaAttachment = null;
                        if (mediaAttachment != null) {
                            TrackObject trackObject = new TrackObject(postItem.getId().longValue(), postItem.getDate(), 0, 0, null, null, null, postItem.getTitle(), postItem.getContent(), postItem.getAuthor(), null, postItem.getUrl(), postItem.getThumbnailCandidate(), null, 0, 0, postItem.getCommentCount().longValue(), mediaAttachment.getUrl());
                            trackObject.setStreamAble(true);
                            arrayList.add(trackObject);
                        }
                    }
                }
                return arrayList;
            }
        }
        return null;
    }

    public int getMaxPages() {
        return this.maxPages;
    }
}
