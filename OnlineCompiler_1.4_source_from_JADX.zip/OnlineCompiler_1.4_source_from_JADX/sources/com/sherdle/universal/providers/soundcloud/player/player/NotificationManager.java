package com.sherdle.universal.providers.soundcloud.player.player;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.NotificationCompat.Builder;
import android.widget.RemoteViews;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.C0559R;
import com.sherdle.universal.providers.radio.player.MediaNotificationManager;
import com.sherdle.universal.providers.soundcloud.api.object.TrackObject;
import com.sherdle.universal.providers.soundcloud.helpers.SoundCloudArtworkHelper;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Picasso.LoadedFrom;
import com.squareup.picasso.Target;

final class NotificationManager {
    private static final int NOTIFICATION_ID = 66;
    private static final int REQUEST_CODE_CLEAR = 64;
    private static final int REQUEST_CODE_NEXT = 32;
    private static final int REQUEST_CODE_PLAYBACK = 16;
    private static final int REQUEST_CODE_PREVIOUS = 48;
    static final int REQUEST_DISPLAYING_CONTROLLER = 1107313152;
    private static NotificationManager sInstance;
    private PendingIntent mClearPendingIntent;
    private Handler mMainThreadHandler;
    private PendingIntent mNextPendingIntent;
    private Builder mNotificationBuilder;
    private NotificationConfig mNotificationConfig;
    private RemoteViews mNotificationExpandedView;
    private android.app.NotificationManager mNotificationManager;
    private RemoteViews mNotificationView;
    private PendingIntent mPreviousPendingIntent;
    private PendingIntent mTogglePlaybackPendingIntent;
    private long mTrackId = -1;

    /* renamed from: com.sherdle.universal.providers.soundcloud.player.player.NotificationManager$1 */
    class C09921 implements Target {
        public void onBitmapFailed(Exception exception, Drawable drawable) {
        }

        public void onPrepareLoad(Drawable drawable) {
        }

        C09921() {
        }

        public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
            NotificationManager.this.mNotificationView.setImageViewBitmap(R.id.simple_sound_cloud_notification_thumbnail, bitmap);
            NotificationManager.this.mNotificationExpandedView.setImageViewBitmap(R.id.simple_sound_cloud_notification_thumbnail, bitmap);
            NotificationManager.this.mNotificationExpandedView.setImageViewBitmap(R.id.simple_sound_cloud_notification_expanded_thumbnail, bitmap);
            NotificationManager.this.mNotificationManager.notify(66, NotificationManager.this.buildNotification());
        }
    }

    private NotificationManager(Context context) {
        this.mMainThreadHandler = new Handler(context.getApplicationContext().getMainLooper());
        this.mNotificationManager = (android.app.NotificationManager) context.getSystemService(NotificationTable.TABLE_NAME);
        initializePendingIntent(context);
    }

    public static NotificationManager getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new NotificationManager(context);
        }
        return sInstance;
    }

    public void setNotificationConfig(NotificationConfig notificationConfig) {
        this.mNotificationConfig = notificationConfig;
    }

    public void notify(Service service, final TrackObject trackObject, boolean z) {
        if (this.mNotificationBuilder == null) {
            initNotificationBuilder(service);
            createNotificationChannel(service);
        }
        this.mNotificationView.setTextViewText(R.id.simple_sound_cloud_notification_title, trackObject.getUsername());
        this.mNotificationView.setTextViewText(R.id.simple_sound_cloud_notification_subtitle, trackObject.getTitle());
        this.mNotificationExpandedView.setTextViewText(R.id.simple_sound_cloud_notification_title, trackObject.getUsername());
        this.mNotificationExpandedView.setTextViewText(R.id.simple_sound_cloud_notification_subtitle, trackObject.getTitle());
        if (z) {
            this.mNotificationView.setImageViewResource(R.id.simple_sound_cloud_notification_play, C0559R.drawable.ic_play_white);
            this.mNotificationExpandedView.setImageViewResource(R.id.simple_sound_cloud_notification_play, C0559R.drawable.ic_play_white);
        } else {
            this.mNotificationView.setImageViewResource(R.id.simple_sound_cloud_notification_play, C0559R.drawable.ic_pause_white);
            this.mNotificationExpandedView.setImageViewResource(R.id.simple_sound_cloud_notification_play, C0559R.drawable.ic_pause_white);
        }
        service.startForeground(true, buildNotification());
        long id = trackObject.getId();
        long j = this.mTrackId;
        if (j == -1 || j != id) {
            service = new C09921();
            this.mMainThreadHandler.post(new Runnable() {
                public void run() {
                    Picasso.get().load(SoundCloudArtworkHelper.getArtworkUrl(trackObject, SoundCloudArtworkHelper.XLARGE)).into(service);
                }
            });
            this.mTrackId = id;
        }
    }

    public void cancel() {
        this.mNotificationManager.cancel(66);
    }

    private void initializePendingIntent(Context context) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction("sound_cloud_toggle_playback");
        this.mTogglePlaybackPendingIntent = PendingIntent.getService(context, 16, intent, 134217728);
        intent = new Intent(context, PlaybackService.class);
        intent.setAction("sound_cloud_player_next");
        this.mNextPendingIntent = PendingIntent.getService(context, 32, intent, 134217728);
        intent = new Intent(context, PlaybackService.class);
        intent.setAction("sound_cloud_player_previous");
        this.mPreviousPendingIntent = PendingIntent.getService(context, 48, intent, 134217728);
        intent = new Intent(context, PlaybackService.class);
        intent.setAction("sound_cloud_player_clear");
        this.mClearPendingIntent = PendingIntent.getService(context, 64, intent, 134217728);
    }

    private void initNotificationBuilder(Context context) {
        this.mNotificationBuilder = new Builder(context, MediaNotificationManager.NOTIFICATION_CHANNEL_ID);
        this.mNotificationView = new RemoteViews(context.getPackageName(), R.layout.soundcloud_notification);
        this.mNotificationExpandedView = new RemoteViews(context.getPackageName(), R.layout.soundcloud_notification_expanded);
        if (VERSION.SDK_INT >= 21) {
            addSmallIcon(this.mNotificationView);
            addSmallIcon(this.mNotificationExpandedView);
        }
        this.mNotificationView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_previous, this.mPreviousPendingIntent);
        this.mNotificationExpandedView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_previous, this.mPreviousPendingIntent);
        this.mNotificationView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_next, this.mNextPendingIntent);
        this.mNotificationExpandedView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_next, this.mNextPendingIntent);
        this.mNotificationView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_play, this.mTogglePlaybackPendingIntent);
        this.mNotificationExpandedView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_play, this.mTogglePlaybackPendingIntent);
        this.mNotificationView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_clear, this.mClearPendingIntent);
        this.mNotificationExpandedView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_clear, this.mClearPendingIntent);
        this.mNotificationBuilder.setSmallIcon(this.mNotificationConfig.getNotificationIcon());
        this.mNotificationBuilder.setContent(this.mNotificationView);
        this.mNotificationBuilder.setPriority(1);
        Class cls = this.mNotificationConfig.getNotificationActivity().getClass();
        if (cls != null) {
            Intent intent = new Intent(context, cls);
            Bundle notificationBundle = this.mNotificationConfig.getNotificationBundle();
            if (notificationBundle != null) {
                intent.putExtras(notificationBundle);
            }
            this.mNotificationBuilder.setContentIntent(PendingIntent.getActivity(context, REQUEST_DISPLAYING_CONTROLLER, intent, 134217728));
        }
    }

    private Notification buildNotification() {
        Notification build = this.mNotificationBuilder.build();
        if (VERSION.SDK_INT >= 16) {
            build.bigContentView = this.mNotificationExpandedView;
        }
        return build;
    }

    private void createNotificationChannel(Context context) {
        android.app.NotificationManager notificationManager = (android.app.NotificationManager) context.getSystemService(NotificationTable.TABLE_NAME);
        if (VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(MediaNotificationManager.NOTIFICATION_CHANNEL_ID, context.getString(R.string.audio_notification), 2);
            notificationChannel.enableVibration(null);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    private void addSmallIcon(RemoteViews remoteViews) {
        remoteViews.setInt(R.layout.soundcloud_notification_icon, "setBackgroundResource", this.mNotificationConfig.getNotificationIconBackground());
        remoteViews.setImageViewResource(R.layout.soundcloud_notification_icon, this.mNotificationConfig.getNotificationIcon());
    }
}
