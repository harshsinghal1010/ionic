package com.sherdle.universal.providers.soundcloud.player.remote;

import android.media.AudioManager;
import com.sherdle.universal.util.Log;
import java.lang.reflect.Method;

public class RemoteControlHelper {
    private static final String TAG = "RemoteControlHelper";
    private static boolean sHasRemoteControlAPIs = true;
    private static Method sRegisterRemoteControlClientMethod;
    private static Method sUnregisterRemoteControlClientMethod;

    static {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = com.sherdle.universal.providers.soundcloud.player.remote.RemoteControlHelper.class;	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r0 = r0.getClassLoader();	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r0 = com.sherdle.universal.providers.soundcloud.player.remote.RemoteControlClientCompat.getActualRemoteControlClientClass(r0);	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r1 = android.media.AudioManager.class;	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r2 = "registerRemoteControlClient";	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r3 = 1;	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r4 = new java.lang.Class[r3];	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r5 = 0;	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r4[r5] = r0;	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r1 = r1.getMethod(r2, r4);	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        sRegisterRemoteControlClientMethod = r1;	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r1 = android.media.AudioManager.class;	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r2 = "unregisterRemoteControlClient";	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r4 = new java.lang.Class[r3];	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r4[r5] = r0;	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        r0 = r1.getMethod(r2, r4);	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        sUnregisterRemoteControlClientMethod = r0;	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
        sHasRemoteControlAPIs = r3;	 Catch:{ ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a, ClassNotFoundException -> 0x002a }
    L_0x002a:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.soundcloud.player.remote.RemoteControlHelper.<clinit>():void");
    }

    public static void registerRemoteControlClient(AudioManager audioManager, RemoteControlClientCompat remoteControlClientCompat) {
        if (sHasRemoteControlAPIs) {
            try {
                sRegisterRemoteControlClientMethod.invoke(audioManager, new Object[]{remoteControlClientCompat.getActualRemoteControlClientObject()});
            } catch (AudioManager audioManager2) {
                remoteControlClientCompat = TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(audioManager2.getMessage());
                stringBuilder.append(audioManager2.toString());
                Log.m158e(remoteControlClientCompat, stringBuilder.toString());
            }
        }
    }

    public static void unregisterRemoteControlClient(AudioManager audioManager, RemoteControlClientCompat remoteControlClientCompat) {
        if (sHasRemoteControlAPIs) {
            try {
                sUnregisterRemoteControlClientMethod.invoke(audioManager, new Object[]{remoteControlClientCompat.getActualRemoteControlClientObject()});
            } catch (AudioManager audioManager2) {
                remoteControlClientCompat = TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(audioManager2.getMessage());
                stringBuilder.append(audioManager2.toString());
                Log.m158e(remoteControlClientCompat, stringBuilder.toString());
            }
        }
    }
}
