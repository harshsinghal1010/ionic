package com.sherdle.universal.providers.soundcloud.helpers;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;

public abstract class EndlessRecyclerOnScrollListener extends OnScrollListener {
    public static String TAG = "EndlessRecyclerOnScrollListener";
    private int current_page = 0;
    int firstVisibleItem;
    private boolean forceCantLoadMore = false;
    private boolean loading = true;
    private LinearLayoutManager mLinearLayoutManager;
    private int previousTotal = 0;
    int totalItemCount;
    int visibleItemCount;
    private int visibleThreshold = 5;

    public abstract void onLoadMore(int i);

    public EndlessRecyclerOnScrollListener(LinearLayoutManager linearLayoutManager) {
        this.mLinearLayoutManager = linearLayoutManager;
    }

    public void onScrolled(RecyclerView recyclerView, int i, int i2) {
        super.onScrolled(recyclerView, i, i2);
        this.visibleItemCount = recyclerView.getChildCount();
        this.totalItemCount = this.mLinearLayoutManager.getItemCount();
        this.firstVisibleItem = this.mLinearLayoutManager.findFirstVisibleItemPosition();
        if (this.loading != null) {
            recyclerView = this.totalItemCount;
            if (recyclerView > this.previousTotal) {
                this.loading = false;
                this.previousTotal = recyclerView;
            }
        }
        if (this.loading == null && this.totalItemCount - this.visibleItemCount <= this.firstVisibleItem + this.visibleThreshold && this.forceCantLoadMore == null) {
            this.current_page += 1;
            onLoadMore(this.current_page);
            this.loading = true;
        }
    }

    public void reset() {
        this.current_page = 0;
        this.loading = false;
        this.forceCantLoadMore = false;
        this.previousTotal = 0;
    }

    public void forceCantLoadMore(boolean z) {
        this.forceCantLoadMore = z;
    }
}
