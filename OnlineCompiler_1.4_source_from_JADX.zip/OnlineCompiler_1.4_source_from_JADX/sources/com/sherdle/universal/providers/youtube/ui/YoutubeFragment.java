package com.sherdle.universal.providers.youtube.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.SearchView.OnQueryTextListener;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.providers.youtube.VideosAdapter;
import com.sherdle.universal.providers.youtube.api.RetrieveVideos;
import com.sherdle.universal.providers.youtube.api.object.ReturnItem;
import com.sherdle.universal.providers.youtube.api.object.Video;
import com.sherdle.universal.providers.youtube.player.YouTubePlayerActivity;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.ThemeUtils;
import com.sherdle.universal.util.ViewModeUtils;
import com.sherdle.universal.util.ViewModeUtils.ChangeListener;
import java.util.ArrayList;

public class YoutubeFragment extends Fragment implements LoadMoreListener {
    private static String TYPE_LIVE = "live";
    private static String TYPE_PLAYLIST = "playlist";
    private static String TYPE_SEARCH = "search";
    private static String TYPE_USER = "channel";
    private String currentType;
    private boolean isLoading = true;
    private RecyclerView listView;
    private RelativeLayout ll;
    private Activity mAct;
    private String searchQuery;
    private SwipeRefreshLayout swipeRefreshLayout;
    private String upcomingPageToken;
    private VideosAdapter videoAdapter;
    private RetrieveVideos videoApiClient;
    private ArrayList<Video> videoList;
    private ViewModeUtils viewModeUtils;

    /* renamed from: com.sherdle.universal.providers.youtube.ui.YoutubeFragment$1 */
    class C07111 implements OnItemClickListener {
        C07111() {
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            Video video = (Video) YoutubeFragment.this.videoList.get(i);
            if (YoutubeFragment.this.currentType.equals(YoutubeFragment.TYPE_LIVE) != null) {
                view = new Intent(YoutubeFragment.this.mAct, YouTubePlayerActivity.class);
                view.putExtra(YouTubePlayerActivity.EXTRA_VIDEO_ID, video.getId());
                view.setFlags(1073741824);
                YoutubeFragment.this.startActivity(view);
                return;
            }
            view = new Intent(YoutubeFragment.this.mAct, YoutubeDetailActivity.class);
            view.putExtra(YoutubeDetailActivity.EXTRA_VIDEO, video);
            YoutubeFragment.this.startActivity(view);
        }
    }

    /* renamed from: com.sherdle.universal.providers.youtube.ui.YoutubeFragment$5 */
    class C07145 implements OnAttachStateChangeListener {
        public void onViewAttachedToWindow(View view) {
        }

        C07145() {
        }

        public void onViewDetachedFromWindow(View view) {
            if (YoutubeFragment.this.isLoading == null) {
                view = YoutubeFragment.this;
                view.currentType = view.getTypeBasedOnParameters();
                YoutubeFragment.this.searchQuery = null;
                YoutubeFragment.this.refreshItems();
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.youtube.ui.YoutubeFragment$2 */
    class C10182 implements OnRefreshListener {
        C10182() {
        }

        public void onRefresh() {
            if (YoutubeFragment.this.isLoading) {
                Toast.makeText(YoutubeFragment.this.mAct, YoutubeFragment.this.getString(R.string.already_loading), 1).show();
            } else {
                YoutubeFragment.this.refreshItems();
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.youtube.ui.YoutubeFragment$6 */
    class C10206 implements ChangeListener {
        C10206() {
        }

        public void modeChanged() {
            YoutubeFragment.this.videoAdapter.notifyDataSetChanged();
        }
    }

    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreate(bundle);
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list_refresh, viewGroup, false);
        return this.ll;
    }

    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        setHasOptionsMenu(true);
        bundle = new C07111();
        this.listView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.swipeRefreshLayout = (SwipeRefreshLayout) this.ll.findViewById(R.id.swipeRefreshLayout);
        this.videoList = new ArrayList();
        this.videoAdapter = new VideosAdapter(getContext(), this.videoList, this, bundle);
        this.videoAdapter.setModeAndNotify(3);
        this.listView.setAdapter(this.videoAdapter);
        this.listView.setLayoutManager(new LinearLayoutManager(this.ll.getContext(), 1, false));
        this.swipeRefreshLayout.setOnRefreshListener(new C10182());
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        this.videoApiClient = new RetrieveVideos(this.mAct, getResources().getString(R.string.google_server_key));
        this.currentType = getTypeBasedOnParameters();
        refreshItems();
    }

    private void refreshItems() {
        this.videoList.clear();
        this.videoAdapter.setHasMore(true);
        this.videoAdapter.setModeAndNotify(3);
        loadVideosInList(null);
    }

    public void updateList(ArrayList<Video> arrayList) {
        if (arrayList.size() > 0) {
            this.videoList.addAll(arrayList);
        }
        if (this.upcomingPageToken == null || arrayList.size() == null) {
            this.videoAdapter.setHasMore(false);
        }
        this.videoAdapter.setModeAndNotify(1);
        this.swipeRefreshLayout.setRefreshing(false);
    }

    private void loadVideosInList(final String str) {
        this.isLoading = true;
        if (str == null) {
            this.upcomingPageToken = null;
        }
        AsyncTask.execute(new Runnable() {
            public void run() {
                ReturnItem searchVideos = YoutubeFragment.this.currentType.equals(YoutubeFragment.TYPE_SEARCH) ? YoutubeFragment.this.videoApiClient.getSearchVideos(YoutubeFragment.this.searchQuery, YoutubeFragment.this.getIdBasedOnParameters(), str) : YoutubeFragment.this.currentType.equals(YoutubeFragment.TYPE_PLAYLIST) ? YoutubeFragment.this.videoApiClient.getPlaylistVideos(YoutubeFragment.this.getIdBasedOnParameters(), str) : YoutubeFragment.this.currentType.equals(YoutubeFragment.TYPE_LIVE) ? YoutubeFragment.this.videoApiClient.getLiveVideos(YoutubeFragment.this.getIdBasedOnParameters(), str) : YoutubeFragment.this.currentType.equals(YoutubeFragment.TYPE_USER) ? YoutubeFragment.this.videoApiClient.getUserVideos(YoutubeFragment.this.getIdBasedOnParameters(), str) : null;
                final ArrayList list = searchVideos.getList();
                YoutubeFragment.this.upcomingPageToken = searchVideos.getPageToken();
                YoutubeFragment.this.mAct.runOnUiThread(new Runnable() {
                    public void run() {
                        YoutubeFragment.this.isLoading = false;
                        if (YoutubeFragment.this.isAdded()) {
                            if (list != null) {
                                YoutubeFragment.this.updateList(list);
                                if (YoutubeFragment.this.currentType.equals(YoutubeFragment.TYPE_LIVE)) {
                                    if (list.size() > 0) {
                                        LayoutInflater.from(YoutubeFragment.this.mAct).inflate(R.layout.fragment_youtube_livefooter, YoutubeFragment.this.ll);
                                        View findViewById = YoutubeFragment.this.ll.findViewById(R.id.youtube_live_bottom);
                                        if (list.size() == 1) {
                                            findViewById.setVisibility(0);
                                        } else if (findViewById.getVisibility() == 0) {
                                            findViewById.setVisibility(8);
                                        }
                                    } else {
                                        YoutubeFragment.this.videoAdapter.setEmptyViewText(YoutubeFragment.this.getString(R.string.video_no_live_title), YoutubeFragment.this.getString(R.string.video_no_live));
                                        YoutubeFragment.this.videoAdapter.setModeAndNotify(2);
                                        YoutubeFragment.this.swipeRefreshLayout.setRefreshing(false);
                                    }
                                }
                            } else {
                                Helper.noConnection(YoutubeFragment.this.mAct);
                                YoutubeFragment.this.videoAdapter.setModeAndNotify(2);
                                YoutubeFragment.this.swipeRefreshLayout.setRefreshing(false);
                            }
                        }
                    }
                });
            }
        });
    }

    private String[] getPassedData() {
        return getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        this.viewModeUtils = new ViewModeUtils(getContext(), getClass());
        this.viewModeUtils.inflateOptionsMenu(menu, menuInflater);
        menuInflater.inflate(R.menu.menu_search, menu);
        menuInflater = new SearchView(this.mAct);
        menuInflater.setQueryHint(getResources().getString(R.string.search_hint));
        menuInflater.setOnQueryTextListener(new OnQueryTextListener() {
            public boolean onQueryTextChange(String str) {
                return false;
            }

            public boolean onQueryTextSubmit(String str) {
                YoutubeFragment.this.searchQuery = str;
                YoutubeFragment.this.currentType = YoutubeFragment.TYPE_SEARCH;
                YoutubeFragment.this.refreshItems();
                menuInflater.clearFocus();
                return true;
            }
        });
        getPassedData();
        menuInflater.addOnAttachStateChangeListener(new C07145());
        if (getTypeBasedOnParameters().equals(TYPE_PLAYLIST)) {
            menu.findItem(R.id.menu_search).setVisible(false);
        } else {
            menu.findItem(R.id.menu_search).setActionView(menuInflater);
        }
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    public String getTypeBasedOnParameters() {
        if (getPassedData().length >= 2 && (getPassedData()[1].equals(TYPE_LIVE) || getPassedData()[1].equals(TYPE_USER) || getPassedData()[1].equals(TYPE_PLAYLIST))) {
            return getPassedData()[1];
        }
        throw new RuntimeException("Your youtube configuration is incorrect, please check your documentation");
    }

    public String getIdBasedOnParameters() {
        if (getPassedData().length >= 2) {
            return getPassedData()[0];
        }
        throw new RuntimeException("Your youtube configuration is incorrect, please check your documentation");
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        this.viewModeUtils.handleSelection(menuItem, new C10206());
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    public void onMoreRequested() {
        String str = this.upcomingPageToken;
        if (str != null && !this.isLoading) {
            loadVideosInList(str);
        }
    }
}
