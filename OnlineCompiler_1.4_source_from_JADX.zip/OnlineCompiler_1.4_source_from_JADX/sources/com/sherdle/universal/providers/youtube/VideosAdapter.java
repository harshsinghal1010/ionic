package com.sherdle.universal.providers.youtube;

import android.content.Context;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.youtube.api.object.Video;
import com.sherdle.universal.providers.youtube.ui.YoutubeFragment;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.ViewModeUtils;
import com.squareup.picasso.Picasso;
import java.util.List;

public class VideosAdapter extends InfiniteRecyclerViewAdapter {
    private static final int HIGHLIGHT_VIDEO = 2;
    private static final int VIDEO_COMPACT = 0;
    private static final int VIDEO_NORMAL = 1;
    private OnItemClickListener clickListener;
    private Context mContext;
    private List<Video> videos;
    private ViewModeUtils viewModeUtils;

    private static abstract class VideoViewHolder extends ViewHolder {
        protected TextView date;
        protected ImageView thumb;
        protected TextView title;

        VideoViewHolder(View view) {
            super(view);
        }
    }

    private static class HighlightViewHolder extends VideoViewHolder {
        HighlightViewHolder(View view) {
            super(view);
            this.date = (TextView) view.findViewById(R.id.textViewDate);
            this.title = (TextView) view.findViewById(R.id.textViewHighlight);
            this.thumb = (ImageView) view.findViewById(R.id.imageViewHighlight);
        }
    }

    class VideoCompactViewHolder extends VideoViewHolder {
        VideoCompactViewHolder(View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.userVideoTitleTextView);
            this.date = (TextView) view.findViewById(R.id.userVideoDateTextView);
            this.thumb = (ImageView) view.findViewById(R.id.userVideoThumbImageView);
        }
    }

    private static class VideoNormalViewHolder extends VideoViewHolder {
        VideoNormalViewHolder(View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.title);
            this.date = (TextView) view.findViewById(R.id.date);
            this.thumb = (ImageView) view.findViewById(R.id.thumbImage);
        }
    }

    public VideosAdapter(Context context, List<Video> list, LoadMoreListener loadMoreListener, OnItemClickListener onItemClickListener) {
        super(context, loadMoreListener);
        this.mContext = context;
        this.videos = list;
        this.clickListener = onItemClickListener;
        this.viewModeUtils = new ViewModeUtils(context, YoutubeFragment.class);
    }

    public int getCount() {
        return this.videos.size();
    }

    protected int getViewType(int i) {
        if (i != 0) {
            if (this.viewModeUtils.getViewMode() != 2) {
                return this.viewModeUtils.getViewMode() == 0 ? 0 : 1;
            }
        }
        return 2;
    }

    protected ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new VideoCompactViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_youtube_row, viewGroup, false));
        }
        if (i != 2) {
            return i == 1 ? new VideoNormalViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_row, viewGroup, false)) : null;
        } else {
            i = new HighlightViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_highlight, viewGroup, false));
            requestFullSpan(i);
            return i;
        }
    }

    protected void doBindViewHolder(final ViewHolder viewHolder, final int i) {
        Video video = (Video) this.videos.get(i);
        if (viewHolder instanceof VideoViewHolder) {
            VideoViewHolder videoViewHolder = (VideoViewHolder) viewHolder;
            videoViewHolder.thumb.setImageDrawable(null);
            Picasso.get().load(viewHolder instanceof VideoCompactViewHolder ? video.getThumbUrl() : video.getImage()).placeholder((int) R.color.gray).into(videoViewHolder.thumb);
            videoViewHolder.title.setText(video.getTitle());
            videoViewHolder.date.setText(video.getUpdated());
        }
        viewHolder.itemView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                VideosAdapter.this.clickListener.onItemClick(null, viewHolder.itemView, i, 0);
            }
        });
    }
}
