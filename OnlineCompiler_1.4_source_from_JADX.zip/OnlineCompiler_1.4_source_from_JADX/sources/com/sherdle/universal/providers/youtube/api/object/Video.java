package com.sherdle.universal.providers.youtube.api.object;

import java.io.Serializable;

public class Video implements Serializable {
    private String channel;
    private String description;
    private String id;
    private String image;
    private String thumbUrl;
    private String title;
    private String updated;

    public Video(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.title = str;
        this.id = str2;
        this.updated = str3;
        this.description = str4;
        this.thumbUrl = str5;
        this.image = str6;
        this.channel = str7;
    }

    public String getTitle() {
        return this.title;
    }

    public String getId() {
        return this.id;
    }

    public String getUpdated() {
        return this.updated;
    }

    public String getDescription() {
        return this.description;
    }

    public String getThumbUrl() {
        return this.thumbUrl;
    }

    public String getImage() {
        return this.image;
    }

    public String getChannel() {
        return this.channel;
    }
}
