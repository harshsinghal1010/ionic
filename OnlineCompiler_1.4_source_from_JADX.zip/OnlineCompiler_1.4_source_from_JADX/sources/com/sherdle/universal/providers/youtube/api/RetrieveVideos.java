package com.sherdle.universal.providers.youtube.api;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.format.DateUtils;
import com.sherdle.universal.providers.youtube.api.object.ReturnItem;
import com.sherdle.universal.util.Log;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class RetrieveVideos {
    private static String API_BASE = "https://www.googleapis.com/youtube/v3";
    private static String API_TYPE_PLAYLIST = "/playlistItems";
    private static String API_TYPE_SEARCH = "/search";
    private static int PER_PAGE = 20;
    private Context mContext;
    private String serverKey;

    public RetrieveVideos(Context context, String str) {
        this.serverKey = str;
        this.mContext = context;
    }

    public ReturnItem getLiveVideos(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(API_BASE);
        stringBuilder.append(API_TYPE_SEARCH);
        stringBuilder.append("?part=snippet&type=video&channelId=");
        stringBuilder.append(str);
        stringBuilder.append("&eventType=live&maxResults=");
        stringBuilder.append(PER_PAGE);
        stringBuilder.append("&key=");
        stringBuilder.append(this.serverKey);
        str = stringBuilder.toString();
        if (str2 != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append("&pageToken=");
            stringBuilder.append(str2);
            str = stringBuilder.toString();
        }
        return getVideos(str, this.mContext);
    }

    public ReturnItem getUserVideos(String str) {
        return getUserVideos(str, null);
    }

    public ReturnItem getUserVideos(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(API_BASE);
        stringBuilder.append(API_TYPE_SEARCH);
        stringBuilder.append("?part=snippet&order=date&channelId=");
        stringBuilder.append(str);
        stringBuilder.append("&maxResults=");
        stringBuilder.append(PER_PAGE);
        stringBuilder.append("&key=");
        stringBuilder.append(this.serverKey);
        str = stringBuilder.toString();
        if (str2 != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append("&pageToken=");
            stringBuilder.append(str2);
            str = stringBuilder.toString();
        }
        return getVideos(str, this.mContext);
    }

    public ReturnItem getPlaylistVideos(String str) {
        return getPlaylistVideos(str, null);
    }

    public ReturnItem getPlaylistVideos(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(API_BASE);
        stringBuilder.append(API_TYPE_PLAYLIST);
        stringBuilder.append("?part=snippet&playlistId=");
        stringBuilder.append(str);
        stringBuilder.append("&maxResults=");
        stringBuilder.append(PER_PAGE);
        stringBuilder.append("&key=");
        stringBuilder.append(this.serverKey);
        str = stringBuilder.toString();
        if (str2 != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append("&pageToken=");
            stringBuilder.append(str2);
            str = stringBuilder.toString();
        }
        return getVideos(str, this.mContext);
    }

    public ReturnItem getSearchVideos(String str, String str2) {
        return getSearchVideos(str, str2, null);
    }

    public com.sherdle.universal.providers.youtube.api.object.ReturnItem getSearchVideos(java.lang.String r3, java.lang.String r4, java.lang.String r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = "UTF-8";	 Catch:{ UnsupportedEncodingException -> 0x0006 }
        r3 = java.net.URLEncoder.encode(r3, r0);	 Catch:{ UnsupportedEncodingException -> 0x0006 }
    L_0x0006:
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r1 = API_BASE;
        r0.append(r1);
        r1 = API_TYPE_SEARCH;
        r0.append(r1);
        r1 = "?part=snippet&type=video&channelId=";
        r0.append(r1);
        r0.append(r4);
        r4 = "&q=";
        r0.append(r4);
        r0.append(r3);
        r3 = "&maxResults=";
        r0.append(r3);
        r3 = PER_PAGE;
        r0.append(r3);
        r3 = "&key=";
        r0.append(r3);
        r3 = r2.serverKey;
        r0.append(r3);
        r3 = r0.toString();
        if (r5 == 0) goto L_0x0053;
    L_0x003f:
        r4 = new java.lang.StringBuilder;
        r4.<init>();
        r4.append(r3);
        r3 = "&pageToken=";
        r4.append(r3);
        r4.append(r5);
        r3 = r4.toString();
    L_0x0053:
        r4 = r2.mContext;
        r3 = getVideos(r3, r4);
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.youtube.api.RetrieveVideos.getSearchVideos(java.lang.String, java.lang.String, java.lang.String):com.sherdle.universal.providers.youtube.api.object.ReturnItem");
    }

    public static com.sherdle.universal.providers.youtube.api.object.ReturnItem getVideos(java.lang.String r14, android.content.Context r15) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r14 = com.sherdle.universal.util.Helper.getJSONObjectFromUrl(r14);
        r0 = 0;
        if (r14 != 0) goto L_0x000d;
    L_0x0007:
        r14 = new com.sherdle.universal.providers.youtube.api.object.ReturnItem;
        r14.<init>(r0, r0);
        return r14;
    L_0x000d:
        r1 = "kind";	 Catch:{ JSONException -> 0x00cd }
        r1 = r14.getString(r1);	 Catch:{ JSONException -> 0x00cd }
        r2 = "youtube";	 Catch:{ JSONException -> 0x00cd }
        r1 = r1.contains(r2);	 Catch:{ JSONException -> 0x00cd }
        if (r1 == 0) goto L_0x0021;	 Catch:{ JSONException -> 0x00cd }
    L_0x001b:
        r1 = new java.util.ArrayList;	 Catch:{ JSONException -> 0x00cd }
        r1.<init>();	 Catch:{ JSONException -> 0x00cd }
        goto L_0x0022;
    L_0x0021:
        r1 = r0;
    L_0x0022:
        r2 = "nextPageToken";	 Catch:{ JSONException -> 0x00cb }
        r2 = r14.has(r2);	 Catch:{ JSONException -> 0x00cb }
        if (r2 == 0) goto L_0x0030;	 Catch:{ JSONException -> 0x00cb }
    L_0x002a:
        r2 = "nextPageToken";	 Catch:{ JSONException -> 0x00cb }
        r0 = r14.getString(r2);	 Catch:{ JSONException -> 0x00cb }
    L_0x0030:
        r2 = "items";	 Catch:{ JSONException -> 0x00cb }
        r14 = r14.getJSONArray(r2);	 Catch:{ JSONException -> 0x00cb }
        r2 = 0;	 Catch:{ JSONException -> 0x00cb }
    L_0x0037:
        r3 = r14.length();	 Catch:{ JSONException -> 0x00cb }
        if (r2 >= r3) goto L_0x00e5;
    L_0x003d:
        r3 = r14.getJSONObject(r2);	 Catch:{ JSONException -> 0x00b0 }
        r4 = r14.getJSONObject(r2);	 Catch:{ JSONException -> 0x00b0 }
        r5 = "snippet";	 Catch:{ JSONException -> 0x00b0 }
        r4 = r4.getJSONObject(r5);	 Catch:{ JSONException -> 0x00b0 }
        r5 = "title";	 Catch:{ JSONException -> 0x00b0 }
        r7 = r4.getString(r5);	 Catch:{ JSONException -> 0x00b0 }
        r5 = "publishedAt";	 Catch:{ JSONException -> 0x00b0 }
        r5 = r4.getString(r5);	 Catch:{ JSONException -> 0x00b0 }
        r9 = formatData(r5, r15);	 Catch:{ JSONException -> 0x00b0 }
        r5 = "description";	 Catch:{ JSONException -> 0x00b0 }
        r10 = r4.getString(r5);	 Catch:{ JSONException -> 0x00b0 }
        r5 = "channelTitle";	 Catch:{ JSONException -> 0x00b0 }
        r13 = r4.getString(r5);	 Catch:{ JSONException -> 0x00b0 }
        r5 = "resourceId";	 Catch:{ Exception -> 0x0075 }
        r5 = r4.getJSONObject(r5);	 Catch:{ Exception -> 0x0075 }
        r6 = "videoId";	 Catch:{ Exception -> 0x0075 }
        r3 = r5.getString(r6);	 Catch:{ Exception -> 0x0075 }
        r8 = r3;
        goto L_0x0082;
    L_0x0075:
        r5 = "id";	 Catch:{ JSONException -> 0x00b0 }
        r3 = r3.getJSONObject(r5);	 Catch:{ JSONException -> 0x00b0 }
        r5 = "videoId";	 Catch:{ JSONException -> 0x00b0 }
        r3 = r3.getString(r5);	 Catch:{ JSONException -> 0x00b0 }
        r8 = r3;	 Catch:{ JSONException -> 0x00b0 }
    L_0x0082:
        r3 = "thumbnails";	 Catch:{ JSONException -> 0x00b0 }
        r3 = r4.getJSONObject(r3);	 Catch:{ JSONException -> 0x00b0 }
        r5 = "medium";	 Catch:{ JSONException -> 0x00b0 }
        r3 = r3.getJSONObject(r5);	 Catch:{ JSONException -> 0x00b0 }
        r5 = "url";	 Catch:{ JSONException -> 0x00b0 }
        r11 = r3.getString(r5);	 Catch:{ JSONException -> 0x00b0 }
        r3 = "thumbnails";	 Catch:{ JSONException -> 0x00b0 }
        r3 = r4.getJSONObject(r3);	 Catch:{ JSONException -> 0x00b0 }
        r4 = "high";	 Catch:{ JSONException -> 0x00b0 }
        r3 = r3.getJSONObject(r4);	 Catch:{ JSONException -> 0x00b0 }
        r4 = "url";	 Catch:{ JSONException -> 0x00b0 }
        r12 = r3.getString(r4);	 Catch:{ JSONException -> 0x00b0 }
        r3 = new com.sherdle.universal.providers.youtube.api.object.Video;	 Catch:{ JSONException -> 0x00b0 }
        r6 = r3;	 Catch:{ JSONException -> 0x00b0 }
        r6.<init>(r7, r8, r9, r10, r11, r12, r13);	 Catch:{ JSONException -> 0x00b0 }
        r1.add(r3);	 Catch:{ JSONException -> 0x00b0 }
        goto L_0x00c7;
    L_0x00b0:
        r3 = move-exception;
        r4 = "INFO";	 Catch:{ JSONException -> 0x00cb }
        r5 = new java.lang.StringBuilder;	 Catch:{ JSONException -> 0x00cb }
        r5.<init>();	 Catch:{ JSONException -> 0x00cb }
        r6 = "JSONException: ";	 Catch:{ JSONException -> 0x00cb }
        r5.append(r6);	 Catch:{ JSONException -> 0x00cb }
        r5.append(r3);	 Catch:{ JSONException -> 0x00cb }
        r3 = r5.toString();	 Catch:{ JSONException -> 0x00cb }
        com.sherdle.universal.util.Log.m161v(r4, r3);	 Catch:{ JSONException -> 0x00cb }
    L_0x00c7:
        r2 = r2 + 1;
        goto L_0x0037;
    L_0x00cb:
        r14 = move-exception;
        goto L_0x00cf;
    L_0x00cd:
        r14 = move-exception;
        r1 = r0;
    L_0x00cf:
        r15 = "INFO";
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r3 = "JSONException: ";
        r2.append(r3);
        r2.append(r14);
        r14 = r2.toString();
        com.sherdle.universal.util.Log.m161v(r15, r14);
    L_0x00e5:
        r14 = "INFO";
        r15 = new java.lang.StringBuilder;
        r15.<init>();
        r2 = "Token: ";
        r15.append(r2);
        r15.append(r0);
        r15 = r15.toString();
        com.sherdle.universal.util.Log.m161v(r14, r15);
        r14 = new com.sherdle.universal.providers.youtube.api.object.ReturnItem;
        r14.<init>(r1, r0);
        return r14;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.youtube.api.RetrieveVideos.getVideos(java.lang.String, android.content.Context):com.sherdle.universal.providers.youtube.api.object.ReturnItem");
    }

    @SuppressLint({"SimpleDateFormat"})
    private static String formatData(String str, Context context) {
        String str2 = "";
        try {
            str2 = DateUtils.getRelativeDateTimeString(context, new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).parse(str).getTime(), 1000, 604800000, 524288).toString();
        } catch (String str3) {
            Log.printStackTrace(str3);
        }
        return str2;
    }
}
