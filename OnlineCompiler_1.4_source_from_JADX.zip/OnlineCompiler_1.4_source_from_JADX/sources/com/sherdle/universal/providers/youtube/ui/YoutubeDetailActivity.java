package com.sherdle.universal.providers.youtube.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewStub;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.comments.CommentsActivity;
import com.sherdle.universal.providers.fav.FavDbAdapter;
import com.sherdle.universal.providers.youtube.api.object.Video;
import com.sherdle.universal.providers.youtube.player.YouTubePlayerActivity;
import com.sherdle.universal.util.DetailActivity;
import com.sherdle.universal.util.WebHelper;
import com.squareup.picasso.Picasso;

public class YoutubeDetailActivity extends DetailActivity {
    public static final String EXTRA_VIDEO = "videoitem";
    private FavDbAdapter mDbHelper;
    private TextView mPresentation;
    private Video video;

    /* renamed from: com.sherdle.universal.providers.youtube.ui.YoutubeDetailActivity$1 */
    class C07081 implements OnClickListener {
        C07081() {
        }

        public void onClick(View view) {
            view = new Intent(YoutubeDetailActivity.this, YouTubePlayerActivity.class);
            view.putExtra(YouTubePlayerActivity.EXTRA_VIDEO_ID, YoutubeDetailActivity.this.video.getId());
            view.setFlags(1073741824);
            YoutubeDetailActivity.this.startActivity(view);
        }
    }

    /* renamed from: com.sherdle.universal.providers.youtube.ui.YoutubeDetailActivity$2 */
    class C07092 implements OnClickListener {
        C07092() {
        }

        public void onClick(View view) {
            view = YoutubeDetailActivity.this;
            view.mDbHelper = new FavDbAdapter(view);
            YoutubeDetailActivity.this.mDbHelper.open();
            if (YoutubeDetailActivity.this.mDbHelper.checkEvent(YoutubeDetailActivity.this.video.getTitle(), YoutubeDetailActivity.this.video, 4) != null) {
                YoutubeDetailActivity.this.mDbHelper.addFavorite(YoutubeDetailActivity.this.video.getTitle(), YoutubeDetailActivity.this.video, 4);
                view = YoutubeDetailActivity.this;
                Toast.makeText(view, view.getResources().getString(R.string.favorite_success), 1).show();
                return;
            }
            view = YoutubeDetailActivity.this;
            Toast.makeText(view, view.getResources().getString(R.string.favorite_duplicate), 1).show();
        }
    }

    /* renamed from: com.sherdle.universal.providers.youtube.ui.YoutubeDetailActivity$3 */
    class C07103 implements OnClickListener {
        C07103() {
        }

        public void onClick(View view) {
            view = new Intent(YoutubeDetailActivity.this, CommentsActivity.class);
            view.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.YOUTUBE);
            view.putExtra(CommentsActivity.DATA_ID, YoutubeDetailActivity.this.video.getId());
            YoutubeDetailActivity.this.startActivity(view);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_details);
        ViewStub viewStub = (ViewStub) findViewById(R.id.layout_stub);
        viewStub.setLayoutResource(R.layout.activity_youtube_detail);
        viewStub.inflate();
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.mPresentation = (TextView) findViewById(R.id.youtubetitle);
        TextView textView = (TextView) findViewById(R.id.youtubedescription);
        TextView textView2 = (TextView) findViewById(R.id.youtubesubtitle);
        this.video = (Video) getIntent().getSerializableExtra(EXTRA_VIDEO);
        textView.setTextSize(2, (float) WebHelper.getTextViewFontSize(this));
        this.mPresentation.setText(this.video.getTitle());
        textView.setText(this.video.getDescription());
        bundle = new StringBuilder();
        bundle.append(getResources().getString(R.string.video_subtitle_start));
        bundle.append(this.video.getUpdated());
        bundle.append(getResources().getString(R.string.video_subtitle_end));
        bundle.append(this.video.getChannel());
        textView2.setText(bundle.toString());
        findViewById(R.id.adView).setVisibility(8);
        this.thumb = (ImageView) findViewById(R.id.image);
        this.coolblue = (RelativeLayout) findViewById(R.id.coolblue);
        Picasso.get().load(this.video.getImage()).into(this.thumb);
        setUpHeader(this.video.getImage());
        FloatingActionButton floatingActionButton = (FloatingActionButton) findViewById(R.id.playbutton);
        floatingActionButton.bringToFront();
        floatingActionButton.setOnClickListener(new C07081());
        ((Button) findViewById(R.id.favorite)).setOnClickListener(new C07092());
        ((Button) findViewById(R.id.comments)).setOnClickListener(new C07103());
    }

    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
    }

    public boolean onOptionsItemSelected(android.view.MenuItem r8) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r7 = this;
        r0 = r8.getItemId();
        r1 = 16908332; // 0x102002c float:2.3877352E-38 double:8.353826E-317;
        r2 = 1;
        if (r0 == r1) goto L_0x00d6;
    L_0x000a:
        switch(r0) {
            case 2131296490: goto L_0x0055;
            case 2131296491: goto L_0x0012;
            default: goto L_0x000d;
        };
    L_0x000d:
        r8 = super.onOptionsItemSelected(r8);
        return r8;
    L_0x0012:
        r8 = new android.content.Intent;	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r0 = "android.intent.action.VIEW";	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r1 = new java.lang.StringBuilder;	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r1.<init>();	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r3 = "vnd.youtube:";	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r1.append(r3);	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r3 = r7.video;	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r3 = r3.getId();	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r1.append(r3);	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r1 = r1.toString();	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r1 = android.net.Uri.parse(r1);	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r8.<init>(r0, r1);	 Catch:{ ActivityNotFoundException -> 0x0038 }
        r7.startActivity(r8);	 Catch:{ ActivityNotFoundException -> 0x0038 }
        goto L_0x0054;
    L_0x0038:
        r8 = new java.lang.StringBuilder;
        r8.<init>();
        r0 = "http://www.youtube.com/watch?v=";
        r8.append(r0);
        r0 = r7.video;
        r0 = r0.getId();
        r8.append(r0);
        r8 = r8.toString();
        r0 = 0;
        r1 = 0;
        com.sherdle.universal.HolderActivity.startWebViewActivity(r7, r8, r2, r0, r1);
    L_0x0054:
        return r2;
    L_0x0055:
        r8 = r7.getResources();
        r0 = 2131623974; // 0x7f0e0026 float:1.8875115E38 double:1.0531621754E-314;
        r8 = r8.getString(r0);
        r0 = new android.content.Intent;
        r0.<init>();
        r1 = "android.intent.action.SEND";
        r0.setAction(r1);
        r1 = r7.getResources();
        r3 = 2131624196; // 0x7f0e0104 float:1.8875565E38 double:1.053162285E-314;
        r1 = r1.getString(r3);
        r3 = r7.getResources();
        r4 = 2131624198; // 0x7f0e0106 float:1.8875569E38 double:1.053162286E-314;
        r3 = r3.getString(r4);
        r4 = r7.getResources();
        r5 = 2131624197; // 0x7f0e0105 float:1.8875567E38 double:1.0531622856E-314;
        r4 = r4.getString(r5);
        r5 = "android.intent.extra.TEXT";
        r6 = new java.lang.StringBuilder;
        r6.<init>();
        r6.append(r1);
        r1 = "http://youtube.com/watch?v=";
        r6.append(r1);
        r1 = r7.video;
        r1 = r1.getId();
        r6.append(r1);
        r6.append(r3);
        r6.append(r8);
        r6.append(r4);
        r8 = r6.toString();
        r0.putExtra(r5, r8);
        r8 = "android.intent.extra.SUBJECT";
        r1 = r7.video;
        r1 = r1.getTitle();
        r0.putExtra(r8, r1);
        r8 = "text/plain";
        r0.setType(r8);
        r8 = r7.getResources();
        r1 = 2131624173; // 0x7f0e00ed float:1.8875518E38 double:1.0531622737E-314;
        r8 = r8.getString(r1);
        r8 = android.content.Intent.createChooser(r0, r8);
        r7.startActivity(r8);
        return r2;
    L_0x00d6:
        r7.finish();
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.youtube.ui.YoutubeDetailActivity.onOptionsItemSelected(android.view.MenuItem):boolean");
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.youtube_detail_menu, menu);
        return true;
    }
}
