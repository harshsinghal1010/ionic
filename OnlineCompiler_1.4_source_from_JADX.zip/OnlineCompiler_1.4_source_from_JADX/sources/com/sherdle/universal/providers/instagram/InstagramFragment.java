package com.sherdle.universal.providers.instagram;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.gms.common.data.DataBufferSafeParcelable;
import com.google.android.gms.measurement.AppMeasurement.Param;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.providers.soundcloud.api.SoundCloudClient;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONObject;

public class InstagramFragment extends Fragment implements LoadMoreListener {
    private static String API_URL = "https://graph.facebook.com/v3.1/";
    private static String API_URL_END = "/media?fields=caption,id,ig_id,comments_count,timestamp,permalink,owner{profile_picture_url},media_url,media_type,thumbnail_url,like_count,comments{text,username},username,children&access_token=";
    private static final SimpleDateFormat INSTAGRAM_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.getDefault());
    Boolean isLoading = Boolean.valueOf(false);
    private RelativeLayout ll;
    private Activity mAct;
    private String nextpageurl;
    private ArrayList<InstagramPhoto> photosList;
    private InstagramPhotosAdapter photosListAdapter = null;
    private RecyclerView photosListView = null;
    String username;

    private class DownloadFilesTask extends AsyncTask<String, Integer, ArrayList<InstagramPhoto>> {
        boolean initialload;

        DownloadFilesTask(boolean z) {
            this.initialload = z;
        }

        protected void onPreExecute() {
            if (InstagramFragment.this.isLoading.booleanValue()) {
                cancel(true);
            } else {
                InstagramFragment.this.isLoading = Boolean.valueOf(true);
            }
            if (this.initialload) {
                InstagramFragment instagramFragment = InstagramFragment.this;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(InstagramFragment.API_URL);
                stringBuilder.append(InstagramFragment.this.username);
                stringBuilder.append(InstagramFragment.API_URL_END);
                stringBuilder.append(InstagramFragment.this.getResources().getString(R.string.instagram_access_token));
                instagramFragment.nextpageurl = stringBuilder.toString();
            }
        }

        protected void onPostExecute(ArrayList<InstagramPhoto> arrayList) {
            if (arrayList == null || arrayList.size() <= 0) {
                Helper.noConnection(InstagramFragment.this.mAct);
                InstagramFragment.this.photosListAdapter.setModeAndNotify(2);
            } else {
                InstagramFragment.this.updateList(arrayList);
            }
            InstagramFragment.this.isLoading = Boolean.valueOf(false);
        }

        protected ArrayList<InstagramPhoto> doInBackground(String... strArr) {
            return InstagramFragment.this.parseJson(Helper.getJSONObjectFromUrl(InstagramFragment.this.nextpageurl));
        }
    }

    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreate(bundle);
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list, viewGroup, false);
        setHasOptionsMenu(true);
        this.username = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        this.photosListView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.photosList = new ArrayList();
        this.photosListAdapter = new InstagramPhotosAdapter(getContext(), this.photosList, this);
        this.photosListAdapter.setModeAndNotify(3);
        this.photosListView.setAdapter(this.photosListAdapter);
        this.photosListView.setLayoutManager(new LinearLayoutManager(getContext(), 1, false));
        return this.ll;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        refreshItems();
    }

    public void updateList(ArrayList<InstagramPhoto> arrayList) {
        if (arrayList.size() > 0) {
            this.photosList.addAll(arrayList);
        }
        if (this.nextpageurl == null || arrayList.size() == null) {
            this.photosListAdapter.setHasMore(false);
        }
        this.photosListAdapter.setModeAndNotify(1);
    }

    public void onMoreRequested() {
        if (!this.isLoading.booleanValue() && this.nextpageurl != null) {
            new DownloadFilesTask(false).execute(new String[0]);
        }
    }

    public ArrayList<InstagramPhoto> parseJson(JSONObject jSONObject) {
        ArrayList<InstagramPhoto> arrayList = new ArrayList();
        try {
            if (jSONObject.has("paging") && jSONObject.getJSONObject("paging").has("next")) {
                this.nextpageurl = jSONObject.getJSONObject("paging").getString("next");
            } else {
                this.nextpageurl = null;
            }
            jSONObject = jSONObject.getJSONArray(DataBufferSafeParcelable.DATA_FIELD);
            for (int i = 0; i < jSONObject.length(); i++) {
                JSONObject jSONObject2 = jSONObject.getJSONObject(i);
                InstagramPhoto instagramPhoto = new InstagramPhoto();
                instagramPhoto.id = jSONObject2.getString("ig_id");
                instagramPhoto.type = jSONObject2.getString("media_type");
                instagramPhoto.username = jSONObject2.getString("username");
                instagramPhoto.profilePhotoUrl = jSONObject2.getJSONObject("owner").getString("profile_picture_url");
                if (jSONObject2.has("caption") && !jSONObject2.isNull("caption")) {
                    instagramPhoto.caption = jSONObject2.getString("caption");
                }
                instagramPhoto.createdTime = INSTAGRAM_DATE_FORMAT.parse(jSONObject2.getString(Param.TIMESTAMP));
                instagramPhoto.likesCount = jSONObject2.getInt("like_count");
                instagramPhoto.link = jSONObject2.getString("permalink");
                if (jSONObject2.has(SoundCloudClient.COMMENTS)) {
                    instagramPhoto.commentsJson = jSONObject2.getJSONObject(SoundCloudClient.COMMENTS).toString();
                }
                if (instagramPhoto.type.equalsIgnoreCase(MimeTypes.BASE_TYPE_VIDEO)) {
                    instagramPhoto.videoUrl = jSONObject2.getString("media_url");
                    instagramPhoto.imageUrl = jSONObject2.getString("thumbnail_url");
                } else {
                    instagramPhoto.imageUrl = jSONObject2.getString("media_url");
                }
                instagramPhoto.commentsCount = jSONObject2.getInt("comments_count");
                arrayList.add(instagramPhoto);
            }
        } catch (JSONObject jSONObject3) {
            Log.printStackTrace(jSONObject3);
        }
        return arrayList;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.refresh_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    public void refreshItems() {
        this.photosList.clear();
        this.photosListAdapter.setHasMore(true);
        this.photosListAdapter.setModeAndNotify(3);
        new DownloadFilesTask(true).execute(new String[0]);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.refresh) {
            if (this.isLoading.booleanValue()) {
                Toast.makeText(this.mAct, getString(R.string.already_loading), 1).show();
            } else {
                refreshItems();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
