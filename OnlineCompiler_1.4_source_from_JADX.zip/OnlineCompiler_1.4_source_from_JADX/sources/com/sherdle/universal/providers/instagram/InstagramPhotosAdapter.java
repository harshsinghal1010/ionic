package com.sherdle.universal.providers.instagram;

import android.content.Context;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.text.Html;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.util.MimeTypes;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentActivity;
import com.sherdle.universal.attachmentviewer.ui.VideoPlayerActivity;
import com.sherdle.universal.comments.CommentsActivity;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.WebHelper;
import com.squareup.picasso.Picasso;
import java.util.List;
import java.util.Locale;

public class InstagramPhotosAdapter extends InfiniteRecyclerViewAdapter {
    private Context context;
    private List<InstagramPhoto> objects;

    private class InstagramPhotoViewHolder extends ViewHolder {
        ImageView commentsBtn;
        TextView commentsCountView;
        TextView dateView;
        TextView descriptionView;
        ImageView inlineImg;
        FloatingActionButton inlineImgBtn;
        TextView likesCountView;
        ImageView openBtn;
        ImageView profileImg;
        ImageView shareBtn;
        TextView userNameView;

        InstagramPhotoViewHolder(View view) {
            super(view);
            this.profileImg = (ImageView) view.findViewById(R.id.profile_image);
            this.userNameView = (TextView) view.findViewById(R.id.name);
            this.dateView = (TextView) view.findViewById(R.id.date);
            this.inlineImg = (ImageView) view.findViewById(R.id.photo);
            this.inlineImgBtn = (FloatingActionButton) view.findViewById(R.id.playbutton);
            this.likesCountView = (TextView) view.findViewById(R.id.like_count);
            this.descriptionView = (TextView) view.findViewById(R.id.message);
            this.descriptionView = (TextView) view.findViewById(R.id.message);
            this.shareBtn = (ImageView) view.findViewById(R.id.share);
            this.openBtn = (ImageView) view.findViewById(R.id.open);
            this.commentsBtn = (ImageView) view.findViewById(R.id.comments);
            this.commentsCountView = (TextView) view.findViewById(R.id.comments_count);
        }
    }

    protected int getViewType(int i) {
        return 0;
    }

    public InstagramPhotosAdapter(Context context, List<InstagramPhoto> list, LoadMoreListener loadMoreListener) {
        super(context, loadMoreListener);
        this.context = context;
        this.objects = list;
    }

    protected ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        return new InstagramPhotoViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_fb_insta_row, viewGroup, false));
    }

    protected void doBindViewHolder(ViewHolder viewHolder, int i) {
        if (viewHolder instanceof InstagramPhotoViewHolder) {
            final InstagramPhoto instagramPhoto = (InstagramPhoto) this.objects.get(i);
            InstagramPhotoViewHolder instagramPhotoViewHolder = (InstagramPhotoViewHolder) viewHolder;
            instagramPhotoViewHolder.profileImg.setImageDrawable(null);
            Picasso.get().load(instagramPhoto.profilePhotoUrl).into(instagramPhotoViewHolder.profileImg);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(instagramPhoto.username.substring(0, 1).toUpperCase(Locale.getDefault()));
            stringBuilder.append(instagramPhoto.username.substring(1).toLowerCase(Locale.getDefault()));
            instagramPhotoViewHolder.userNameView.setText(stringBuilder.toString());
            instagramPhotoViewHolder.dateView.setText(DateUtils.getRelativeDateTimeString(this.context, instagramPhoto.createdTime.getTime(), 1000, 604800000, 524288));
            instagramPhotoViewHolder.inlineImg.setImageDrawable(null);
            Picasso.get().load(instagramPhoto.imageUrl).placeholder((int) R.drawable.placeholder).into(instagramPhotoViewHolder.inlineImg);
            if (instagramPhoto.type.equalsIgnoreCase(MimeTypes.BASE_TYPE_VIDEO)) {
                instagramPhotoViewHolder.inlineImgBtn.setVisibility(0);
            } else {
                instagramPhotoViewHolder.inlineImgBtn.setVisibility(8);
            }
            if (instagramPhoto.type.equalsIgnoreCase("image")) {
                instagramPhotoViewHolder.inlineImg.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        AttachmentActivity.startActivity(InstagramPhotosAdapter.this.context, MediaAttachment.withImage(instagramPhoto.imageUrl));
                    }
                });
            } else if (instagramPhoto.type.equalsIgnoreCase(MimeTypes.BASE_TYPE_VIDEO)) {
                OnClickListener c05942 = new OnClickListener() {
                    public void onClick(View view) {
                        VideoPlayerActivity.startActivity(InstagramPhotosAdapter.this.context, instagramPhoto.videoUrl);
                    }
                };
                instagramPhotoViewHolder.inlineImgBtn.setOnClickListener(c05942);
                instagramPhotoViewHolder.inlineImg.setOnClickListener(c05942);
            }
            instagramPhotoViewHolder.likesCountView.setText(Helper.formatValue((double) instagramPhoto.likesCount));
            if (instagramPhoto.caption != null) {
                instagramPhotoViewHolder.descriptionView.setText(Html.fromHtml(instagramPhoto.caption));
                instagramPhotoViewHolder.descriptionView.setTextSize(2, (float) WebHelper.getTextViewFontSize(this.context));
                instagramPhotoViewHolder.descriptionView.setVisibility(0);
            } else {
                instagramPhotoViewHolder.descriptionView.setVisibility(8);
            }
            instagramPhotoViewHolder.shareBtn.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    view = new Intent();
                    view.setAction("android.intent.action.SEND");
                    view.putExtra("android.intent.extra.TEXT", instagramPhoto.link);
                    view.setType("text/plain");
                    InstagramPhotosAdapter.this.context.startActivity(Intent.createChooser(view, InstagramPhotosAdapter.this.context.getResources().getString(R.string.share_header)));
                }
            });
            instagramPhotoViewHolder.openBtn.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    HolderActivity.startWebViewActivity(InstagramPhotosAdapter.this.context, instagramPhoto.link, true, false, null);
                }
            });
            instagramPhotoViewHolder.commentsCountView.setText(Helper.formatValue((double) instagramPhoto.commentsCount));
            instagramPhotoViewHolder.commentsBtn.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    view = new Intent(InstagramPhotosAdapter.this.context, CommentsActivity.class);
                    view.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.INSTAGRAM);
                    view.putExtra(CommentsActivity.DATA_PARSEABLE, instagramPhoto.commentsJson);
                    view.putExtra(CommentsActivity.DATA_ID, instagramPhoto.id);
                    InstagramPhotosAdapter.this.context.startActivity(view);
                }
            });
        }
    }

    protected int getCount() {
        return this.objects.size();
    }
}
