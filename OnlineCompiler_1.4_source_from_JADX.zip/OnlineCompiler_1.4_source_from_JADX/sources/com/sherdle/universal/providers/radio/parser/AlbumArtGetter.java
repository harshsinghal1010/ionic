package com.sherdle.universal.providers.radio.parser;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Picasso.LoadedFrom;
import com.squareup.picasso.Target;
import java.net.URLEncoder;

public class AlbumArtGetter {

    public interface AlbumCallback {
        void finished(Bitmap bitmap);
    }

    public static void getImageForQuery(final String str, final AlbumCallback albumCallback, Context context) {
        new AsyncTask<Void, Void, String>() {

            /* renamed from: com.sherdle.universal.providers.radio.parser.AlbumArtGetter$1$1 */
            class C09831 implements Target {
                public void onPrepareLoad(Drawable drawable) {
                }

                C09831() {
                }

                public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
                    albumCallback.finished(bitmap);
                }

                public void onBitmapFailed(Exception exception, Drawable drawable) {
                    albumCallback.finished(null);
                }
            }

            protected String doInBackground(Void... voidArr) {
                if (str.equals("null+null") == null && URLEncoder.encode(str).equals("null+null") == null) {
                    voidArr = new StringBuilder();
                    voidArr.append("https://itunes.apple.com/search?term=");
                    voidArr.append(URLEncoder.encode(str));
                    voidArr.append("&media=music&limit=1");
                    voidArr = Helper.getJSONObjectFromUrl(voidArr.toString());
                    if (voidArr != null) {
                        try {
                            if (voidArr.has("results") && voidArr.getJSONArray("results").length() > 0) {
                                return voidArr.getJSONArray("results").getJSONObject(0).getString("artworkUrl100").replace("100x100bb.jpg", "500x500bb.jpg");
                            }
                        } catch (Void[] voidArr2) {
                            voidArr2.printStackTrace();
                        }
                    }
                    Log.m161v("INFO", "No items in Album Art Request");
                }
                return null;
            }

            protected void onPostExecute(String str) {
                if (str != null) {
                    Picasso.get().load(str).into(new C09831());
                } else {
                    albumCallback.finished(null);
                }
            }
        }.execute(new Void[null]);
    }
}
