package com.sherdle.universal.providers.radio.player;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat.Builder;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.media.app.NotificationCompat.MediaStyle;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.gms.common.util.CrashUtils.ErrorDialogData;
import com.sherdle.universal.C0559R;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.providers.radio.metadata.Metadata;
import com.sherdle.universal.providers.radio.ui.RadioFragment;

public class MediaNotificationManager {
    public static final String NOTIFICATION_CHANNEL_ID = "radio_channel";
    public static final int NOTIFICATION_ID = 555;
    private Metadata meta;
    private Bitmap notifyIcon;
    private String playbackStatus;
    private Resources resources;
    private RadioService service;

    public MediaNotificationManager(RadioService radioService) {
        this.service = radioService;
        this.resources = radioService.getResources();
    }

    public void startNotify(String str) {
        this.playbackStatus = str;
        this.notifyIcon = BitmapFactory.decodeResource(this.resources, C0559R.drawable.ic_launcher);
        startNotify();
    }

    public void startNotify(Bitmap bitmap, Metadata metadata) {
        this.notifyIcon = bitmap;
        this.meta = metadata;
        startNotify();
    }

    private void startNotify() {
        if (this.playbackStatus != null) {
            if (this.notifyIcon == null) {
                this.notifyIcon = BitmapFactory.decodeResource(this.resources, C0559R.drawable.ic_launcher);
            }
            NotificationManager notificationManager = (NotificationManager) this.service.getSystemService(NotificationTable.TABLE_NAME);
            if (VERSION.SDK_INT >= 26) {
                NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, this.service.getString(R.string.audio_notification), 2);
                notificationChannel.enableVibration(false);
                notificationManager.createNotificationChannel(notificationChannel);
            }
            int i = C0559R.drawable.ic_pause_white;
            Intent intent = new Intent(this.service, RadioService.class);
            intent.setAction(RadioService.ACTION_PAUSE);
            PendingIntent service = PendingIntent.getService(this.service, 1, intent, 0);
            if (this.playbackStatus.equals(PlaybackStatus.PAUSED)) {
                i = C0559R.drawable.ic_play_white;
                intent.setAction(RadioService.ACTION_PLAY);
                service = PendingIntent.getService(this.service, 2, intent, 0);
            }
            intent = new Intent(this.service, RadioService.class);
            intent.setAction(RadioService.ACTION_STOP);
            PendingIntent service2 = PendingIntent.getService(this.service, 3, intent, 0);
            Intent intent2 = new Intent(this.service, HolderActivity.class);
            Bundle bundle = new Bundle();
            bundle.putStringArray(MainActivity.FRAGMENT_DATA, new String[]{this.service.getStreamUrl()});
            bundle.putSerializable(MainActivity.FRAGMENT_CLASS, RadioFragment.class);
            intent2.putExtras(bundle);
            intent2.addFlags(ErrorDialogData.BINDER_CRASH);
            PendingIntent activity = PendingIntent.getActivity(this.service, 0, intent2, ErrorDialogData.BINDER_CRASH);
            NotificationManagerCompat.from(this.service).cancel(NOTIFICATION_ID);
            Builder builder = new Builder(this.service, NOTIFICATION_CHANNEL_ID);
            Metadata metadata = this.meta;
            CharSequence string = (metadata == null || metadata.getArtist() == null) ? this.resources.getString(R.string.notification_playing) : this.meta.getArtist();
            Metadata metadata2 = this.meta;
            CharSequence string2 = (metadata2 == null || metadata2.getSong() == null) ? this.resources.getString(R.string.app_name) : this.meta.getSong();
            builder.setContentTitle(string).setContentText(string2).setLargeIcon(this.notifyIcon).setContentIntent(activity).setVisibility(1).setSmallIcon(C0559R.drawable.ic_radio_playing).addAction(i, "pause", service).addAction(C0559R.drawable.ic_stop, "stop", service2).setPriority(1).setWhen(System.currentTimeMillis()).setStyle(new MediaStyle().setMediaSession(this.service.getMediaSession().getSessionToken()).setShowActionsInCompactView(0, 1).setShowCancelButton(true).setCancelButtonIntent(service2));
            this.service.startForeground(NOTIFICATION_ID, builder.build());
        }
    }

    public Metadata getMetaData() {
        return this.meta;
    }

    public void cancelNotify() {
        this.service.stopForeground(true);
    }
}
