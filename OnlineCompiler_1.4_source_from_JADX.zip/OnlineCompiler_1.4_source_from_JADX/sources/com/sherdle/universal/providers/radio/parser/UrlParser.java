package com.sherdle.universal.providers.radio.parser;

import android.annotation.SuppressLint;
import com.sherdle.universal.util.Log;
import java.net.URLConnection;
import java.util.LinkedList;

public class UrlParser {
    @SuppressLint({"DefaultLocale"})
    public static String getUrl(String str) {
        String toUpperCase = str.toUpperCase();
        if (toUpperCase.endsWith(".FLAC") || toUpperCase.endsWith(".MP3") || toUpperCase.endsWith(".WAV") || toUpperCase.endsWith(".M4A") || toUpperCase.endsWith(".PLS")) {
            return str;
        }
        LinkedList rawUrl;
        if (toUpperCase.endsWith(".M3U")) {
            rawUrl = new M3UParser().getRawUrl(str);
            if (rawUrl.size() > 0) {
                return (String) rawUrl.get(0);
            }
        } else if (toUpperCase.endsWith(".ASX")) {
            rawUrl = new ASXParser().getRawUrl(str);
            if (rawUrl.size() > 0) {
                return (String) rawUrl.get(0);
            }
        } else {
            URLConnection connection = getConnection(str);
            if (connection != null) {
                String headerField = connection.getHeaderField("Content-Disposition");
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Requesting: ");
                stringBuilder.append(str);
                stringBuilder.append(" Headers: ");
                stringBuilder.append(connection.getHeaderFields());
                Log.m161v("INFO", stringBuilder.toString());
                String contentType = connection.getContentType();
                if (contentType != null) {
                    contentType = contentType.toUpperCase();
                }
                if (headerField != null && headerField.toUpperCase().endsWith("M3U")) {
                    rawUrl = new M3UParser().getRawUrl(connection);
                    if (rawUrl.size() > 0) {
                        return (String) rawUrl.getFirst();
                    }
                } else if (contentType != null && contentType.contains("AUDIO/X-SCPLS")) {
                    return str;
                } else {
                    if (contentType != null && contentType.contains("VIDEO/X-MS-ASF")) {
                        rawUrl = new ASXParser().getRawUrl(str);
                        if (rawUrl.size() > 0) {
                            return (String) rawUrl.get(0);
                        }
                        rawUrl = new PLSParser().getRawUrl(str);
                        if (rawUrl.size() > 0) {
                            return (String) rawUrl.get(0);
                        }
                    } else if ((contentType == null || !contentType.contains("AUDIO/MPEG")) && contentType != null && contentType.contains("AUDIO/X-MPEGURL")) {
                        rawUrl = new M3UParser().getRawUrl(str);
                        if (rawUrl.size() > 0) {
                            return (String) rawUrl.get(0);
                        }
                    }
                }
            }
        }
        return str;
    }

    private static java.net.URLConnection getConnection(java.lang.String r1) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = new java.net.URL;	 Catch:{ MalformedURLException -> 0x000a, MalformedURLException -> 0x000a }
        r0.<init>(r1);	 Catch:{ MalformedURLException -> 0x000a, MalformedURLException -> 0x000a }
        r1 = r0.openConnection();	 Catch:{ MalformedURLException -> 0x000a, MalformedURLException -> 0x000a }
        return r1;
    L_0x000a:
        r1 = 0;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.radio.parser.UrlParser.getConnection(java.lang.String):java.net.URLConnection");
    }
}
