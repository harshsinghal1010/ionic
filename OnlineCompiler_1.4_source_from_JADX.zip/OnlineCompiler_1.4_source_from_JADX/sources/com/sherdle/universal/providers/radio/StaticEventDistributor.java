package com.sherdle.universal.providers.radio;

import android.graphics.Bitmap;
import com.sherdle.universal.providers.radio.metadata.Metadata;
import java.util.ArrayList;
import java.util.Iterator;

public class StaticEventDistributor {
    private static ArrayList<EventListener> listeners;

    public interface EventListener {
        void onAudioSessionId(Integer num);

        void onEvent(String str);

        void onMetaDataReceived(Metadata metadata, Bitmap bitmap);
    }

    public static void registerAsListener(EventListener eventListener) {
        if (listeners == null) {
            listeners = new ArrayList();
        }
        listeners.add(eventListener);
    }

    public static void unregisterAsListener(EventListener eventListener) {
        listeners.remove(eventListener);
    }

    public static void onEvent(String str) {
        ArrayList arrayList = listeners;
        if (arrayList != null) {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                ((EventListener) it.next()).onEvent(str);
            }
        }
    }

    public static void onAudioSessionId(Integer num) {
        ArrayList arrayList = listeners;
        if (arrayList != null) {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                ((EventListener) it.next()).onAudioSessionId(num);
            }
        }
    }

    public static void onMetaDataReceived(Metadata metadata, Bitmap bitmap) {
        ArrayList arrayList = listeners;
        if (arrayList != null) {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                ((EventListener) it.next()).onMetaDataReceived(metadata, bitmap);
            }
        }
    }
}
