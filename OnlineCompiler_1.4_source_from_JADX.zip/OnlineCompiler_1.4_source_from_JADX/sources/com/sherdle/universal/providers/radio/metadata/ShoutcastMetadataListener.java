package com.sherdle.universal.providers.radio.metadata;

public interface ShoutcastMetadataListener {
    void onMetadataReceived(Metadata metadata);
}
