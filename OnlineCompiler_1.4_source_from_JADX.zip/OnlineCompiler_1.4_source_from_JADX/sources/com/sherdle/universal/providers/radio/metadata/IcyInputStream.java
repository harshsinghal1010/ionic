package com.sherdle.universal.providers.radio.metadata;

import android.support.annotation.NonNull;
import android.util.Log;
import com.google.android.exoplayer2.C0361C;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.regex.Pattern;

class IcyInputStream extends FilterInputStream {
    private static final String TAG = "com.sherdle.universal.providers.radio.metadata.IcyInputStream";
    private final String characterEncoding;
    private final int interval;
    private final MetadataListener metadataListener;
    private int remaining;

    private IcyInputStream(InputStream inputStream, int i, MetadataListener metadataListener) {
        this(inputStream, i, null, metadataListener);
    }

    public IcyInputStream(InputStream inputStream, int i, String str, MetadataListener metadataListener) {
        super(inputStream);
        this.interval = i;
        if (str == null) {
            str = C0361C.UTF8_NAME;
        }
        this.characterEncoding = str;
        this.metadataListener = metadataListener;
        this.remaining = i;
    }

    public int read() throws IOException {
        int read = super.read();
        int i = this.remaining - 1;
        this.remaining = i;
        if (i == 0) {
            getMetadata();
        }
        return read;
    }

    public int read(@NonNull byte[] bArr, int i, int i2) throws IOException {
        InputStream inputStream = this.in;
        int i3 = this.remaining;
        if (i3 < i2) {
            i2 = i3;
        }
        bArr = inputStream.read(bArr, i, i2);
        i = this.remaining;
        if (i == bArr) {
            getMetadata();
        } else {
            this.remaining = i - bArr;
        }
        return bArr;
    }

    private int readFully(byte[] bArr, int i, int i2) throws IOException {
        int i3 = i;
        while (i2 > 0) {
            int read = this.in.read(bArr, i3, i2);
            if (read == -1) {
                break;
            }
            i3 += read;
            i2 -= read;
        }
        return i3 - i;
    }

    private void getMetadata() throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = r5.interval;
        r5.remaining = r0;
        r0 = r5.in;
        r0 = r0.read();
        r1 = 1;
        if (r0 >= r1) goto L_0x000e;
    L_0x000d:
        return;
    L_0x000e:
        r0 = r0 * 16;
        r1 = new byte[r0];
        r2 = 0;
        r0 = r5.readFully(r1, r2, r0);
        r3 = 0;
    L_0x0018:
        if (r3 >= r0) goto L_0x0023;
    L_0x001a:
        r4 = r1[r3];
        if (r4 != 0) goto L_0x0020;
    L_0x001e:
        r0 = r3;
        goto L_0x0023;
    L_0x0020:
        r3 = r3 + 1;
        goto L_0x0018;
    L_0x0023:
        r3 = new java.lang.String;	 Catch:{ Exception -> 0x0044 }
        r4 = r5.characterEncoding;	 Catch:{ Exception -> 0x0044 }
        r3.<init>(r1, r2, r0, r4);	 Catch:{ Exception -> 0x0044 }
        r0 = TAG;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Metadata string: ";
        r1.append(r2);
        r1.append(r3);
        r1 = r1.toString();
        android.util.Log.d(r0, r1);
        r5.parseMetadata(r3);
        return;
    L_0x0044:
        r0 = TAG;
        r1 = "Cannot convert bytes to String";
        android.util.Log.e(r0, r1);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.radio.metadata.IcyInputStream.getMetadata():void");
    }

    private void parseMetadata(String str) {
        str = Pattern.compile("StreamTitle='([^;]*)'").matcher(str.trim());
        if (str.find()) {
            str = str.group(1).split(" - ");
            switch (str.length) {
                case 1:
                    metadataReceived(null, null, str[0]);
                    return;
                case 2:
                    metadataReceived(str[0], str[1], null);
                    return;
                case 3:
                    metadataReceived(str[1], str[2], str[0]);
                    return;
                default:
                    return;
            }
        }
    }

    private void metadataReceived(String str, String str2, String str3) {
        Log.i(TAG, "Metadata received: ");
        String str4 = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Show: ");
        stringBuilder.append(str3);
        Log.i(str4, stringBuilder.toString());
        str4 = TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Artist: ");
        stringBuilder.append(str);
        Log.i(str4, stringBuilder.toString());
        str4 = TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Song: ");
        stringBuilder.append(str2);
        Log.i(str4, stringBuilder.toString());
        MetadataListener metadataListener = this.metadataListener;
        if (metadataListener != null) {
            metadataListener.onMetadataReceived(str, str2, str3);
        }
    }
}
