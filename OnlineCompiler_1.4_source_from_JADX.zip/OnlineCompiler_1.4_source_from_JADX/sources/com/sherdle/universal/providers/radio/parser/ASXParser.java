package com.sherdle.universal.providers.radio.parser;

import com.sherdle.universal.util.Log;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

public class ASXParser {
    public java.util.LinkedList<java.lang.String> getRawUrl(java.lang.String r1) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = this;
        r1 = r0.getConnection(r1);	 Catch:{ MalformedURLException -> 0x0009, MalformedURLException -> 0x0009 }
        r1 = r0.getRawUrl(r1);	 Catch:{ MalformedURLException -> 0x0009, MalformedURLException -> 0x0009 }
        return r1;
    L_0x0009:
        r1 = 0;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.radio.parser.ASXParser.getRawUrl(java.lang.String):java.util.LinkedList<java.lang.String>");
    }

    public java.util.LinkedList<java.lang.String> getRawUrl(java.net.URLConnection r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r3 = this;
        r0 = new java.util.LinkedList;
        r0.<init>();
        r1 = new java.io.BufferedReader;	 Catch:{ MalformedURLException -> 0x002c, MalformedURLException -> 0x002c }
        r2 = new java.io.InputStreamReader;	 Catch:{ MalformedURLException -> 0x002c, MalformedURLException -> 0x002c }
        r4 = r4.getInputStream();	 Catch:{ MalformedURLException -> 0x002c, MalformedURLException -> 0x002c }
        r2.<init>(r4);	 Catch:{ MalformedURLException -> 0x002c, MalformedURLException -> 0x002c }
        r1.<init>(r2);	 Catch:{ MalformedURLException -> 0x002c, MalformedURLException -> 0x002c }
    L_0x0013:
        r4 = r1.readLine();	 Catch:{ IOException -> 0x0013 }
        if (r4 != 0) goto L_0x001a;	 Catch:{ IOException -> 0x0013 }
    L_0x0019:
        goto L_0x002c;	 Catch:{ IOException -> 0x0013 }
    L_0x001a:
        r4 = r3.parseLine(r4);	 Catch:{ IOException -> 0x0013 }
        if (r4 == 0) goto L_0x0013;	 Catch:{ IOException -> 0x0013 }
    L_0x0020:
        r2 = "";	 Catch:{ IOException -> 0x0013 }
        r2 = r4.equals(r2);	 Catch:{ IOException -> 0x0013 }
        if (r2 != 0) goto L_0x0013;	 Catch:{ IOException -> 0x0013 }
    L_0x0028:
        r0.add(r4);	 Catch:{ IOException -> 0x0013 }
        goto L_0x0013;
    L_0x002c:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.radio.parser.ASXParser.getRawUrl(java.net.URLConnection):java.util.LinkedList<java.lang.String>");
    }

    private String parseLine(String str) {
        if (str == null) {
            return null;
        }
        str = str.trim();
        if (str.startsWith("<ref href=\"")) {
            str = str.replace("<ref href=\"", "").replace("/>", "").trim();
            if (str.endsWith("\"")) {
                str = str.replace("\"", "");
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("ASX: ");
                stringBuilder.append(str);
                Log.m161v("INFO", stringBuilder.toString());
                return str;
            }
        }
        return "";
    }

    private URLConnection getConnection(String str) throws IOException {
        return new URL(str).openConnection();
    }
}
