package com.sherdle.universal.providers.radio.ui;

import android.app.Activity;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.cleveroad.audiovisualization.AudioVisualization;
import com.cleveroad.audiovisualization.DbmHandler.Factory;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.util.MimeTypes;
import com.sherdle.universal.Config;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.inherit.CollapseControllingFragment;
import com.sherdle.universal.inherit.PermissionsFragment;
import com.sherdle.universal.providers.radio.StaticEventDistributor;
import com.sherdle.universal.providers.radio.StaticEventDistributor.EventListener;
import com.sherdle.universal.providers.radio.metadata.Metadata;
import com.sherdle.universal.providers.radio.parser.UrlParser;
import com.sherdle.universal.providers.radio.player.PlaybackStatus;
import com.sherdle.universal.providers.radio.player.RadioManager;
import com.sherdle.universal.util.Helper;

public class RadioFragment extends Fragment implements OnClickListener, PermissionsFragment, CollapseControllingFragment, EventListener {
    private ImageView albumArtView;
    private String[] arguments;
    private AudioVisualization audioVisualization;
    private FloatingActionButton buttonPlayPause;
    private RelativeLayout layout;
    private ProgressBar loadingIndicator;
    private Activity mAct;
    private RadioManager radioManager;
    private String urlToPlay;

    /* renamed from: com.sherdle.universal.providers.radio.ui.RadioFragment$1 */
    class C06131 implements Runnable {

        /* renamed from: com.sherdle.universal.providers.radio.ui.RadioFragment$1$1 */
        class C06121 implements Runnable {
            C06121() {
            }

            public void run() {
                RadioFragment.this.loadingIndicator.setVisibility(4);
                RadioFragment.this.updateButtons();
            }
        }

        C06131() {
        }

        public void run() {
            RadioFragment radioFragment = RadioFragment.this;
            radioFragment.urlToPlay = UrlParser.getUrl(radioFragment.arguments[0]);
            RadioFragment.this.mAct.runOnUiThread(new C06121());
        }
    }

    public boolean dynamicToolbarElevation() {
        return false;
    }

    public boolean supportsCollapse() {
        return false;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.layout = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_radio, viewGroup, false);
        initializeUIElements();
        this.arguments = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        if (Config.VISUALIZER_ENABLED == null) {
            this.albumArtView.setVisibility(0);
            this.albumArtView.setImageResource(Config.BACKGROUND_IMAGE_ID);
        }
        return this.layout;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        Helper.isOnlineShowDialog(this.mAct);
        this.radioManager = RadioManager.with();
        this.loadingIndicator.setVisibility(0);
        AsyncTask.execute(new C06131());
        if (isPlaying() != null) {
            onAudioSessionId(Integer.valueOf(RadioManager.getService().getAudioSessionId()));
        }
    }

    public void onEvent(String str) {
        Object obj;
        int hashCode = str.hashCode();
        if (hashCode != -1435314966) {
            if (hashCode == -906175178) {
                if (str.equals(PlaybackStatus.ERROR)) {
                    obj = 1;
                    switch (obj) {
                        case null:
                            this.loadingIndicator.setVisibility(0);
                            break;
                        case 1:
                            makeSnackbar(R.string.error_retry);
                            break;
                        default:
                            break;
                    }
                    if (str.equals(PlaybackStatus.LOADING) == null) {
                        this.loadingIndicator.setVisibility(4);
                    }
                    updateButtons();
                }
            }
        } else if (str.equals(PlaybackStatus.LOADING)) {
            obj = null;
            switch (obj) {
                case null:
                    this.loadingIndicator.setVisibility(0);
                    break;
                case 1:
                    makeSnackbar(R.string.error_retry);
                    break;
                default:
                    break;
            }
            if (str.equals(PlaybackStatus.LOADING) == null) {
                this.loadingIndicator.setVisibility(4);
            }
            updateButtons();
        }
        obj = -1;
        switch (obj) {
            case null:
                this.loadingIndicator.setVisibility(0);
                break;
            case 1:
                makeSnackbar(R.string.error_retry);
                break;
            default:
                break;
        }
        if (str.equals(PlaybackStatus.LOADING) == null) {
            this.loadingIndicator.setVisibility(4);
        }
        updateButtons();
    }

    public void onAudioSessionId(Integer num) {
        if (Config.VISUALIZER_ENABLED) {
            this.audioVisualization.linkTo(Factory.newVisualizerHandler(getContext(), num.intValue()));
            this.audioVisualization.onResume();
        }
    }

    public void onStart() {
        super.onStart();
        StaticEventDistributor.registerAsListener(this);
    }

    public void onStop() {
        StaticEventDistributor.unregisterAsListener(this);
        super.onStop();
    }

    public void onDestroy() {
        if (!this.radioManager.isPlaying()) {
            this.radioManager.unbind(getContext());
        }
        this.audioVisualization.release();
        super.onDestroy();
    }

    public void onPause() {
        super.onPause();
        this.audioVisualization.onPause();
    }

    public void onResume() {
        super.onResume();
        updateButtons();
        this.radioManager.bind(getContext());
        AudioVisualization audioVisualization = this.audioVisualization;
        if (audioVisualization != null) {
            audioVisualization.onResume();
        }
    }

    private void initializeUIElements() {
        this.loadingIndicator = (ProgressBar) this.layout.findViewById(R.id.progressBar);
        this.loadingIndicator.setMax(100);
        this.loadingIndicator.setVisibility(0);
        this.albumArtView = (ImageView) this.layout.findViewById(R.id.albumArt);
        this.audioVisualization = (AudioVisualization) this.layout.findViewById(R.id.visualizer_view);
        this.buttonPlayPause = (FloatingActionButton) this.layout.findViewById(R.id.btn_play_pause);
        this.buttonPlayPause.setOnClickListener(this);
        updateButtons();
    }

    public void updateButtons() {
        if (!isPlaying()) {
            if (this.loadingIndicator.getVisibility() != 0) {
                this.buttonPlayPause.setImageResource(R.drawable.exomedia_ic_play_arrow_white);
                this.layout.findViewById(R.id.already_playing_tooltip).setVisibility(8);
                updateMediaInfoFromBackground(null, null);
                return;
            }
        }
        if (RadioManager.getService() != null) {
            String str = this.urlToPlay;
            if (!(str == null || str.equals(RadioManager.getService().getStreamUrl()))) {
                this.buttonPlayPause.setImageResource(R.drawable.exomedia_ic_play_arrow_white);
                this.layout.findViewById(R.id.already_playing_tooltip).setVisibility(0);
                return;
            }
        }
        if (!(RadioManager.getService() == null || RadioManager.getService().getMetaData() == null)) {
            onMetaDataReceived(RadioManager.getService().getMetaData(), null);
        }
        this.buttonPlayPause.setImageResource(R.drawable.exomedia_ic_pause_white);
        this.layout.findViewById(R.id.already_playing_tooltip).setVisibility(8);
    }

    public void onClick(View view) {
        if (isPlaying() != null) {
            startStopPlaying();
        } else if (this.urlToPlay != null) {
            startStopPlaying();
            if (((AudioManager) this.mAct.getSystemService(MimeTypes.BASE_TYPE_AUDIO)).getStreamVolume(3) < 2) {
                makeSnackbar(R.string.volume_low);
            }
        } else {
            makeSnackbar(R.string.error_retry_later);
        }
    }

    private void startStopPlaying() {
        this.radioManager.playOrPause(this.urlToPlay);
        updateButtons();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    public void updateMediaInfoFromBackground(String str, Bitmap bitmap) {
        TextView textView = (TextView) this.layout.findViewById(R.id.now_playing_title);
        TextView textView2 = (TextView) this.layout.findViewById(R.id.now_playing);
        if (str != null) {
            textView2.setText(str);
        }
        if (str != null && textView.getVisibility() == 8) {
            textView.setVisibility(0);
            textView2.setVisibility(0);
        } else if (str == null) {
            textView.setVisibility(8);
            textView2.setVisibility(8);
        }
        if (Config.VISUALIZER_ENABLED != null) {
            return;
        }
        if (bitmap != null) {
            this.albumArtView.setImageBitmap(bitmap);
        } else {
            this.albumArtView.setImageResource(Config.BACKGROUND_IMAGE_ID);
        }
    }

    public String[] requiredPermissions() {
        if (Config.VISUALIZER_ENABLED) {
            return new String[]{"android.permission.RECORD_AUDIO", "android.permission.READ_PHONE_STATE"};
        }
        return new String[]{"android.permission.READ_PHONE_STATE"};
    }

    public void onMetaDataReceived(Metadata metadata, Bitmap bitmap) {
        if (metadata == null || metadata.getArtist() == null) {
            metadata = null;
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(metadata.getArtist());
            stringBuilder.append(" - ");
            stringBuilder.append(metadata.getSong());
            metadata = stringBuilder.toString();
        }
        updateMediaInfoFromBackground(metadata, bitmap);
    }

    private boolean isPlaying() {
        return (this.radioManager == null || RadioManager.getService() == null || !RadioManager.getService().isPlaying()) ? false : true;
    }

    private void makeSnackbar(int i) {
        i = Snackbar.make(this.buttonPlayPause, i, -1);
        i.show();
        ((TextView) i.getView().findViewById(R.id.snackbar_text)).setTextColor(getResources().getColor(R.color.white));
    }
}
