package com.sherdle.universal.providers.radio.metadata;

interface MetadataListener {
    void onMetadataReceived(String str, String str2, String str3);
}
