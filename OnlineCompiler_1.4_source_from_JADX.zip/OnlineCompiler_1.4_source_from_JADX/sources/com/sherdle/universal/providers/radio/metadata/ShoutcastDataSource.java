package com.sherdle.universal.providers.radio.metadata;

import android.net.Uri;
import com.google.android.exoplayer2.upstream.DataSourceException;
import com.google.android.exoplayer2.upstream.DataSpec;
import com.google.android.exoplayer2.upstream.HttpDataSource;
import com.google.android.exoplayer2.upstream.HttpDataSource.HttpDataSourceException;
import com.google.android.exoplayer2.upstream.HttpDataSource.InvalidContentTypeException;
import com.google.android.exoplayer2.upstream.HttpDataSource.InvalidResponseCodeException;
import com.google.android.exoplayer2.upstream.TransferListener;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.Predicate;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import okhttp3.CacheControl;
import okhttp3.Call.Factory;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.Response;

final class ShoutcastDataSource implements HttpDataSource, MetadataListener {
    private static final String AAC = "audio/aac";
    private static final String AACP = "audio/aacp";
    private static final String ICY_METADATA = "Icy-Metadata";
    private static final String ICY_METAINT = "icy-metaint";
    private static final String MP3 = "audio/mpeg";
    private static final String OGG = "application/ogg";
    private static final AtomicReference<byte[]> skipBufferReference = new AtomicReference();
    private long bytesRead;
    private long bytesSkipped;
    private long bytesToRead;
    private long bytesToSkip;
    private final CacheControl cacheControl;
    private final Factory callFactory;
    private final Predicate<String> contentTypePredicate;
    private DataSpec dataSpec;
    private IcyHeader icyHeader;
    private boolean opened;
    private final HashMap<String, String> requestProperties;
    private Response response;
    private InputStream responseByteStream;
    private final ShoutcastMetadataListener shoutcastMetadataListener;
    private final TransferListener<? super ShoutcastDataSource> transferListener;
    private final String userAgent;

    private class IcyHeader {
        public String bitrate;
        public String channels;
        public String genre;
        public String station;
        public String url;

        private IcyHeader() {
        }
    }

    private okhttp3.Request makeRequest(com.google.android.exoplayer2.upstream.DataSpec r7) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:27:0x0072 in {2, 3, 6, 13, 17, 20, 22, 26} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r6 = this;
        r0 = r7.flags;
        r1 = 1;
        r0 = r0 & r1;
        if (r0 == 0) goto L_0x0007;
    L_0x0006:
        goto L_0x0008;
    L_0x0007:
        r1 = 0;
    L_0x0008:
        r0 = r7.uri;
        r0 = r0.toString();
        r0 = okhttp3.HttpUrl.parse(r0);
        r2 = new okhttp3.Request$Builder;
        r2.<init>();
        r0 = r2.url(r0);
        r2 = r6.cacheControl;
        if (r2 == 0) goto L_0x0022;
    L_0x001f:
        r0.cacheControl(r2);
    L_0x0022:
        r2 = r6.requestProperties;
        monitor-enter(r2);
        r3 = r6.requestProperties;	 Catch:{ all -> 0x006f }
        r3 = r3.entrySet();	 Catch:{ all -> 0x006f }
        r3 = r3.iterator();	 Catch:{ all -> 0x006f }
    L_0x002f:
        r4 = r3.hasNext();	 Catch:{ all -> 0x006f }
        if (r4 == 0) goto L_0x004b;	 Catch:{ all -> 0x006f }
    L_0x0035:
        r4 = r3.next();	 Catch:{ all -> 0x006f }
        r4 = (java.util.Map.Entry) r4;	 Catch:{ all -> 0x006f }
        r5 = r4.getKey();	 Catch:{ all -> 0x006f }
        r5 = (java.lang.String) r5;	 Catch:{ all -> 0x006f }
        r4 = r4.getValue();	 Catch:{ all -> 0x006f }
        r4 = (java.lang.String) r4;	 Catch:{ all -> 0x006f }
        r0.addHeader(r5, r4);	 Catch:{ all -> 0x006f }
        goto L_0x002f;	 Catch:{ all -> 0x006f }
    L_0x004b:
        monitor-exit(r2);	 Catch:{ all -> 0x006f }
        r2 = "User-Agent";
        r3 = r6.userAgent;
        r0.addHeader(r2, r3);
        if (r1 != 0) goto L_0x005c;
    L_0x0055:
        r1 = "Accept-Encoding";
        r2 = "identity";
        r0.addHeader(r1, r2);
    L_0x005c:
        r1 = r7.postBody;
        if (r1 == 0) goto L_0x006a;
    L_0x0060:
        r1 = 0;
        r7 = r7.postBody;
        r7 = okhttp3.RequestBody.create(r1, r7);
        r0.post(r7);
    L_0x006a:
        r7 = r0.build();
        return r7;
    L_0x006f:
        r7 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x006f }
        throw r7;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.radio.metadata.ShoutcastDataSource.makeRequest(com.google.android.exoplayer2.upstream.DataSpec):okhttp3.Request");
    }

    public ShoutcastDataSource(Factory factory, String str, Predicate<String> predicate) {
        this(factory, str, predicate, null, null);
    }

    private ShoutcastDataSource(Factory factory, String str, Predicate<String> predicate, TransferListener<? super ShoutcastDataSource> transferListener, ShoutcastMetadataListener shoutcastMetadataListener) {
        this(factory, str, predicate, transferListener, shoutcastMetadataListener, null);
    }

    public ShoutcastDataSource(Factory factory, String str, Predicate<String> predicate, TransferListener<? super ShoutcastDataSource> transferListener, ShoutcastMetadataListener shoutcastMetadataListener, CacheControl cacheControl) {
        this.callFactory = (Factory) Assertions.checkNotNull(factory);
        this.userAgent = Assertions.checkNotEmpty(str);
        this.contentTypePredicate = predicate;
        this.transferListener = transferListener;
        this.shoutcastMetadataListener = shoutcastMetadataListener;
        this.cacheControl = cacheControl;
        this.requestProperties = new HashMap();
    }

    public Uri getUri() {
        Response response = this.response;
        return response == null ? null : Uri.parse(response.request().url().toString());
    }

    public Map<String, List<String>> getResponseHeaders() {
        Response response = this.response;
        return response == null ? null : response.headers().toMultimap();
    }

    public void setRequestProperty(String str, String str2) {
        Assertions.checkNotNull(str);
        Assertions.checkNotNull(str2);
        synchronized (this.requestProperties) {
            this.requestProperties.put(str, str2);
        }
    }

    public void clearRequestProperty(String str) {
        Assertions.checkNotNull(str);
        synchronized (this.requestProperties) {
            this.requestProperties.remove(str);
        }
    }

    public void clearAllRequestProperties() {
        synchronized (this.requestProperties) {
            this.requestProperties.clear();
        }
    }

    public long open(DataSpec dataSpec) throws HttpDataSourceException {
        this.dataSpec = dataSpec;
        long j = 0;
        this.bytesRead = 0;
        this.bytesSkipped = 0;
        setRequestProperty(ICY_METADATA, "1");
        Request makeRequest = makeRequest(dataSpec);
        try {
            this.response = this.callFactory.newCall(makeRequest).execute();
            this.responseByteStream = getInputStream(this.response);
            int code = this.response.code();
            if (this.response.isSuccessful()) {
                MediaType contentType = this.response.body().contentType();
                String mediaType = contentType != null ? contentType.toString() : null;
                Predicate predicate = this.contentTypePredicate;
                if (predicate != null) {
                    if (!predicate.evaluate(mediaType)) {
                        closeConnectionQuietly();
                        throw new InvalidContentTypeException(mediaType, dataSpec);
                    }
                }
                if (code == 200 && dataSpec.position != 0) {
                    j = dataSpec.position;
                }
                this.bytesToSkip = j;
                long j2 = -1;
                if (dataSpec.length != -1) {
                    this.bytesToRead = dataSpec.length;
                } else {
                    j = this.response.body().contentLength();
                    if (j != -1) {
                        j2 = j - this.bytesToSkip;
                    }
                    this.bytesToRead = j2;
                }
                this.opened = true;
                TransferListener transferListener = this.transferListener;
                if (transferListener != null) {
                    transferListener.onTransferStart(this, dataSpec);
                }
                return this.bytesToRead;
            }
            Map toMultimap = makeRequest.headers().toMultimap();
            closeConnectionQuietly();
            InvalidResponseCodeException invalidResponseCodeException = new InvalidResponseCodeException(code, toMultimap, dataSpec);
            if (code == 416) {
                invalidResponseCodeException.initCause(new DataSourceException(0));
            }
            throw invalidResponseCodeException;
        } catch (IOException e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to connect to ");
            stringBuilder.append(dataSpec.uri.toString());
            throw new HttpDataSourceException(stringBuilder.toString(), e, dataSpec, 1);
        }
    }

    public int read(byte[] bArr, int i, int i2) throws HttpDataSourceException {
        try {
            skipInternal();
            return readInternal(bArr, i, i2);
        } catch (IOException e) {
            throw new HttpDataSourceException(e, this.dataSpec, 2);
        }
    }

    public void close() throws HttpDataSourceException {
        if (this.opened) {
            this.opened = false;
            TransferListener transferListener = this.transferListener;
            if (transferListener != null) {
                transferListener.onTransferEnd(this);
            }
            closeConnectionQuietly();
        }
    }

    private InputStream getInputStream(Response response) throws IOException {
        Object obj;
        String header = response.header("Content-Type");
        setIcyHeader(response.headers());
        InputStream byteStream = response.body().byteStream();
        int hashCode = header.hashCode();
        if (hashCode != -1248335792) {
            if (hashCode != 187078282) {
                if (hashCode != 1504459558) {
                    if (hashCode == 1504831518) {
                        if (header.equals("audio/mpeg")) {
                            obj = null;
                            switch (obj) {
                                case null:
                                case 1:
                                case 2:
                                    return new IcyInputStream(byteStream, response.header(ICY_METAINT) == null ? 8192 : Integer.parseInt(response.header(ICY_METAINT)), null, this);
                                case 3:
                                    return new OggInputStream(byteStream, this);
                                default:
                                    return byteStream;
                            }
                        }
                    }
                } else if (header.equals(AACP)) {
                    obj = 2;
                    switch (obj) {
                        case null:
                        case 1:
                        case 2:
                            if (response.header(ICY_METAINT) == null) {
                            }
                            return new IcyInputStream(byteStream, response.header(ICY_METAINT) == null ? 8192 : Integer.parseInt(response.header(ICY_METAINT)), null, this);
                        case 3:
                            return new OggInputStream(byteStream, this);
                        default:
                            return byteStream;
                    }
                }
            } else if (header.equals(AAC)) {
                obj = 1;
                switch (obj) {
                    case null:
                    case 1:
                    case 2:
                        if (response.header(ICY_METAINT) == null) {
                        }
                        return new IcyInputStream(byteStream, response.header(ICY_METAINT) == null ? 8192 : Integer.parseInt(response.header(ICY_METAINT)), null, this);
                    case 3:
                        return new OggInputStream(byteStream, this);
                    default:
                        return byteStream;
                }
            }
        } else if (header.equals(OGG)) {
            obj = 3;
            switch (obj) {
                case null:
                case 1:
                case 2:
                    if (response.header(ICY_METAINT) == null) {
                    }
                    return new IcyInputStream(byteStream, response.header(ICY_METAINT) == null ? 8192 : Integer.parseInt(response.header(ICY_METAINT)), null, this);
                case 3:
                    return new OggInputStream(byteStream, this);
                default:
                    return byteStream;
            }
        }
        obj = -1;
        switch (obj) {
            case null:
            case 1:
            case 2:
                if (response.header(ICY_METAINT) == null) {
                }
                return new IcyInputStream(byteStream, response.header(ICY_METAINT) == null ? 8192 : Integer.parseInt(response.header(ICY_METAINT)), null, this);
            case 3:
                return new OggInputStream(byteStream, this);
            default:
                return byteStream;
        }
    }

    private void skipInternal() throws IOException {
        if (this.bytesSkipped != this.bytesToSkip) {
            Object obj = (byte[]) skipBufferReference.getAndSet(null);
            if (obj == null) {
                obj = new byte[4096];
            }
            while (true) {
                long j = this.bytesSkipped;
                long j2 = this.bytesToSkip;
                if (j != j2) {
                    int read = this.responseByteStream.read(obj, 0, (int) Math.min(j2 - j, (long) obj.length));
                    if (Thread.interrupted()) {
                        throw new InterruptedIOException();
                    } else if (read != -1) {
                        this.bytesSkipped += (long) read;
                        TransferListener transferListener = this.transferListener;
                        if (transferListener != null) {
                            transferListener.onBytesTransferred(this, read);
                        }
                    } else {
                        throw new EOFException();
                    }
                }
                skipBufferReference.set(obj);
                return;
            }
        }
    }

    private int readInternal(byte[] bArr, int i, int i2) throws IOException {
        if (i2 == 0) {
            return null;
        }
        long j = this.bytesToRead;
        if (j != -1) {
            j -= this.bytesRead;
            if (j == 0) {
                return -1;
            }
            i2 = (int) Math.min((long) i2, j);
        }
        bArr = this.responseByteStream.read(bArr, i, i2);
        if (bArr != -1) {
            this.bytesRead += (long) bArr;
            i = this.transferListener;
            if (i != 0) {
                i.onBytesTransferred(this, bArr);
            }
            return bArr;
        } else if (this.bytesToRead == -1) {
            return -1;
        } else {
            throw new EOFException();
        }
    }

    private void closeConnectionQuietly() {
        this.response.body().close();
        this.response = null;
        this.responseByteStream = null;
    }

    private void setIcyHeader(Headers headers) {
        if (this.icyHeader == null) {
            this.icyHeader = new IcyHeader();
        }
        this.icyHeader.station = headers.get("icy-name");
        this.icyHeader.url = headers.get("icy-url");
        this.icyHeader.genre = headers.get("icy-genre");
        this.icyHeader.channels = headers.get("icy-channels");
        this.icyHeader.bitrate = headers.get("icy-br");
    }

    public void onMetadataReceived(String str, String str2, String str3) {
        if (this.shoutcastMetadataListener != null) {
            this.shoutcastMetadataListener.onMetadataReceived(new Metadata(str, str2, str3, this.icyHeader.channels, this.icyHeader.bitrate, this.icyHeader.station, this.icyHeader.genre, this.icyHeader.url));
        }
    }
}
