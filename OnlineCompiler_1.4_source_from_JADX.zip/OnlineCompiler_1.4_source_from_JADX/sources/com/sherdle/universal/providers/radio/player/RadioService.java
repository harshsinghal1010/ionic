package com.sherdle.universal.providers.radio.player;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.WifiLock;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.MediaMetadataCompat.Builder;
import android.support.v4.media.session.MediaButtonReceiver;
import android.support.v4.media.session.MediaControllerCompat.TransportControls;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.MediaSessionCompat.Callback;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer.EventListener;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.audio.AudioRendererEventListener;
import com.google.android.exoplayer2.decoder.DecoderCounters;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection.Factory;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.exoplayer2.util.Util;
import com.sherdle.universal.providers.radio.StaticEventDistributor;
import com.sherdle.universal.providers.radio.metadata.Metadata;
import com.sherdle.universal.providers.radio.metadata.ShoutcastDataSourceFactory;
import com.sherdle.universal.providers.radio.metadata.ShoutcastMetadataListener;
import com.sherdle.universal.providers.radio.parser.AlbumArtGetter;
import com.sherdle.universal.providers.radio.parser.AlbumArtGetter.AlbumCallback;
import okhttp3.OkHttpClient;

public class RadioService extends Service implements EventListener, OnAudioFocusChangeListener, ShoutcastMetadataListener {
    public static final String ACTION_PAUSE = "com.sherdle.universal.radio.ACTION_PAUSE";
    public static final String ACTION_PLAY = "com.sherdle.universal.radio.ACTION_PLAY";
    public static final String ACTION_STOP = "com.sherdle.universal.radio.ACTION_STOP";
    private AudioManager audioManager;
    private BroadcastReceiver becomingNoisyReceiver = new C06101();
    private SimpleExoPlayer exoPlayer;
    private Handler handler;
    private final IBinder iBinder = new LocalBinder();
    private MediaSessionCompat mediaSession;
    private Callback mediasSessionCallback = new C09843();
    private MediaNotificationManager notificationManager;
    private boolean onGoingCall = false;
    private PhoneStateListener phoneStateListener = new C06112();
    private boolean serviceInUse = false;
    private String status;
    private String strAppName;
    private String strLiveBroadcast;
    private String streamUrl;
    private TelephonyManager telephonyManager;
    private TransportControls transportControls;
    private WifiLock wifiLock;

    /* renamed from: com.sherdle.universal.providers.radio.player.RadioService$1 */
    class C06101 extends BroadcastReceiver {
        C06101() {
        }

        public void onReceive(Context context, Intent intent) {
            RadioService.this.pause();
        }
    }

    /* renamed from: com.sherdle.universal.providers.radio.player.RadioService$2 */
    class C06112 extends PhoneStateListener {
        C06112() {
        }

        public void onCallStateChanged(int i, String str) {
            if (i != 2) {
                if (i != 1) {
                    if (i == 0 && RadioService.this.onGoingCall != 0) {
                        RadioService.this.onGoingCall = null;
                        RadioService.this.resume();
                    }
                    return;
                }
            }
            if (RadioService.this.isPlaying() != 0) {
                RadioService.this.onGoingCall = true;
                RadioService.this.stop();
            }
        }
    }

    public class LocalBinder extends Binder {
        public RadioService getService() {
            return RadioService.this;
        }
    }

    /* renamed from: com.sherdle.universal.providers.radio.player.RadioService$3 */
    class C09843 extends Callback {
        C09843() {
        }

        public void onPause() {
            super.onPause();
            RadioService.this.pause();
        }

        public void onStop() {
            super.onStop();
            RadioService.this.stop();
            RadioService.this.notificationManager.cancelNotify();
        }

        public void onPlay() {
            super.onPlay();
            RadioService.this.resume();
        }
    }

    /* renamed from: com.sherdle.universal.providers.radio.player.RadioService$4 */
    class C09854 implements AudioRendererEventListener {
        public void onAudioDecoderInitialized(String str, long j, long j2) {
        }

        public void onAudioDisabled(DecoderCounters decoderCounters) {
        }

        public void onAudioEnabled(DecoderCounters decoderCounters) {
        }

        public void onAudioInputFormatChanged(Format format) {
        }

        public void onAudioTrackUnderrun(int i, long j, long j2) {
        }

        C09854() {
        }

        public void onAudioSessionId(int i) {
            StaticEventDistributor.onAudioSessionId(Integer.valueOf(RadioService.this.getAudioSessionId()));
        }
    }

    public void onLoadingChanged(boolean z) {
    }

    public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {
    }

    public void onPositionDiscontinuity() {
    }

    public void onRepeatModeChanged(int i) {
    }

    public void onTimelineChanged(Timeline timeline, Object obj) {
    }

    public void onTracksChanged(TrackGroupArray trackGroupArray, TrackSelectionArray trackSelectionArray) {
    }

    @Nullable
    public IBinder onBind(Intent intent) {
        this.serviceInUse = true;
        return this.iBinder;
    }

    public void onCreate() {
        super.onCreate();
        this.strAppName = getResources().getString(R.string.app_name);
        this.strLiveBroadcast = getResources().getString(R.string.notification_playing);
        this.onGoingCall = false;
        this.audioManager = (AudioManager) getSystemService(MimeTypes.BASE_TYPE_AUDIO);
        this.notificationManager = new MediaNotificationManager(this);
        this.wifiLock = ((WifiManager) getApplicationContext().getSystemService("wifi")).createWifiLock(1, "mcScPAmpLock");
        this.mediaSession = new MediaSessionCompat(this, getClass().getSimpleName(), new ComponentName(getApplicationContext(), MediaButtonReceiver.class), null);
        this.transportControls = this.mediaSession.getController().getTransportControls();
        this.mediaSession.setActive(true);
        this.mediaSession.setFlags(3);
        this.mediaSession.setMetadata(new Builder().putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "...").putString(MediaMetadataCompat.METADATA_KEY_ALBUM, this.strAppName).putString(MediaMetadataCompat.METADATA_KEY_TITLE, this.strLiveBroadcast).build());
        this.mediaSession.setCallback(this.mediasSessionCallback);
        this.telephonyManager = (TelephonyManager) getSystemService("phone");
        this.telephonyManager.listen(this.phoneStateListener, 32);
        this.handler = new Handler();
        this.exoPlayer = ExoPlayerFactory.newSimpleInstance(getApplicationContext(), new DefaultTrackSelector(new Factory(new DefaultBandwidthMeter())));
        this.exoPlayer.addListener(this);
        this.exoPlayer.setAudioDebugListener(new C09854());
        this.exoPlayer.setPlayWhenReady(true);
        registerReceiver(this.becomingNoisyReceiver, new IntentFilter("android.media.AUDIO_BECOMING_NOISY"));
        this.status = PlaybackStatus.IDLE;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        intent = intent.getAction();
        if (TextUtils.isEmpty(intent) != 0) {
            return 2;
        }
        if (this.audioManager.requestAudioFocus(this, 3, 1) != 1) {
            stop();
            return 2;
        }
        if (intent.equalsIgnoreCase(ACTION_PLAY) != 0) {
            this.transportControls.play();
        } else if (intent.equalsIgnoreCase(ACTION_PAUSE) != 0) {
            this.transportControls.pause();
        } else if (intent.equalsIgnoreCase(ACTION_STOP) != null) {
            this.transportControls.stop();
        }
        return 2;
    }

    public boolean onUnbind(Intent intent) {
        this.serviceInUse = false;
        if (this.status.equals(PlaybackStatus.IDLE)) {
            stopSelf();
        }
        return super.onUnbind(intent);
    }

    public void onRebind(Intent intent) {
        this.serviceInUse = true;
    }

    public void onDestroy() {
        pause();
        this.exoPlayer.release();
        this.exoPlayer.removeListener(this);
        TelephonyManager telephonyManager = this.telephonyManager;
        if (telephonyManager != null) {
            telephonyManager.listen(this.phoneStateListener, 0);
        }
        this.notificationManager.cancelNotify();
        this.mediaSession.release();
        unregisterReceiver(this.becomingNoisyReceiver);
        super.onDestroy();
    }

    public void onAudioFocusChange(int i) {
        if (i != 1) {
            switch (i) {
                case -3:
                    if (isPlaying() != 0) {
                        this.exoPlayer.setVolume(0.1f);
                        return;
                    }
                    return;
                case -2:
                    if (isPlaying() != 0) {
                        pause();
                        return;
                    }
                    return;
                case -1:
                    stop();
                    return;
                default:
                    return;
            }
        }
        this.exoPlayer.setVolume(0.8f);
        resume();
    }

    public void onPlayerStateChanged(boolean z, int i) {
        switch (i) {
            case 1:
                this.status = PlaybackStatus.IDLE;
                break;
            case 2:
                this.status = PlaybackStatus.LOADING;
                break;
            case 3:
                this.status = z ? PlaybackStatus.PLAYING : PlaybackStatus.PAUSED;
                break;
            case 4:
                this.status = PlaybackStatus.STOPPED;
                break;
            default:
                this.status = PlaybackStatus.IDLE;
                break;
        }
        if (!this.status.equals(PlaybackStatus.IDLE)) {
            this.notificationManager.startNotify(this.status);
        }
        StaticEventDistributor.onEvent(this.status);
    }

    public void onPlayerError(ExoPlaybackException exoPlaybackException) {
        StaticEventDistributor.onEvent(PlaybackStatus.ERROR);
    }

    public String getStreamUrl() {
        return this.streamUrl;
    }

    public void play(String str) {
        this.streamUrl = str;
        WifiLock wifiLock = this.wifiLock;
        if (!(wifiLock == null || wifiLock.isHeld())) {
            this.wifiLock.acquire();
        }
        this.exoPlayer.prepare(new ExtractorMediaSource(Uri.parse(str), new ShoutcastDataSourceFactory(new OkHttpClient.Builder().build(), Util.getUserAgent(this, getClass().getSimpleName()), new DefaultBandwidthMeter(), this), new DefaultExtractorsFactory(), this.handler, null));
        this.exoPlayer.setPlayWhenReady(true);
    }

    public int getAudioSessionId() {
        return this.exoPlayer.getAudioSessionId();
    }

    public void resume() {
        String str = this.streamUrl;
        if (str != null) {
            play(str);
        }
    }

    public void pause() {
        this.exoPlayer.setPlayWhenReady(false);
        this.audioManager.abandonAudioFocus(this);
        wifiLockRelease();
    }

    public void stop() {
        this.exoPlayer.stop();
        this.audioManager.abandonAudioFocus(this);
        wifiLockRelease();
    }

    public void playOrPause(String str) {
        String str2 = this.streamUrl;
        if (str2 == null || !str2.equals(str)) {
            if (isPlaying()) {
                pause();
            }
            play(str);
        } else if (isPlaying() == null) {
            play(this.streamUrl);
        } else {
            pause();
        }
    }

    public String getStatus() {
        return this.status;
    }

    public void onMetadataReceived(final Metadata metadata) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(metadata.getArtist());
        stringBuilder.append(" ");
        stringBuilder.append(metadata.getSong());
        AlbumArtGetter.getImageForQuery(stringBuilder.toString(), new AlbumCallback() {
            public void finished(Bitmap bitmap) {
                RadioService.this.notificationManager.startNotify(bitmap, metadata);
                StaticEventDistributor.onMetaDataReceived(metadata, bitmap);
            }
        }, this);
    }

    public Metadata getMetaData() {
        return this.notificationManager.getMetaData();
    }

    public MediaSessionCompat getMediaSession() {
        return this.mediaSession;
    }

    public boolean isPlaying() {
        return this.status.equals(PlaybackStatus.PLAYING);
    }

    private void wifiLockRelease() {
        WifiLock wifiLock = this.wifiLock;
        if (wifiLock != null && wifiLock.isHeld()) {
            this.wifiLock.release();
        }
    }
}
