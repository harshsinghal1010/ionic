package com.sherdle.universal.providers.radio.parser;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

public class PLSParser {
    public java.util.LinkedList<java.lang.String> getRawUrl(java.lang.String r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = new java.util.LinkedList;
        r0.<init>();
        r1 = r2.getConnection(r3);	 Catch:{ MalformedURLException -> 0x000e, MalformedURLException -> 0x000e }
        r3 = r2.getRawUrl(r1);	 Catch:{ MalformedURLException -> 0x000e, MalformedURLException -> 0x000e }
        return r3;
    L_0x000e:
        r0.add(r3);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.radio.parser.PLSParser.getRawUrl(java.lang.String):java.util.LinkedList<java.lang.String>");
    }

    public java.util.LinkedList<java.lang.String> getRawUrl(java.net.URLConnection r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r4 = this;
        r0 = new java.util.LinkedList;
        r0.<init>();
        r1 = new java.io.BufferedReader;	 Catch:{ MalformedURLException -> 0x002c, MalformedURLException -> 0x002c }
        r2 = new java.io.InputStreamReader;	 Catch:{ MalformedURLException -> 0x002c, MalformedURLException -> 0x002c }
        r3 = r5.getInputStream();	 Catch:{ MalformedURLException -> 0x002c, MalformedURLException -> 0x002c }
        r2.<init>(r3);	 Catch:{ MalformedURLException -> 0x002c, MalformedURLException -> 0x002c }
        r1.<init>(r2);	 Catch:{ MalformedURLException -> 0x002c, MalformedURLException -> 0x002c }
    L_0x0013:
        r2 = r1.readLine();	 Catch:{ IOException -> 0x0013 }
        if (r2 != 0) goto L_0x001a;	 Catch:{ IOException -> 0x0013 }
    L_0x0019:
        goto L_0x002c;	 Catch:{ IOException -> 0x0013 }
    L_0x001a:
        r2 = r4.parseLine(r2);	 Catch:{ IOException -> 0x0013 }
        if (r2 == 0) goto L_0x0013;	 Catch:{ IOException -> 0x0013 }
    L_0x0020:
        r3 = "";	 Catch:{ IOException -> 0x0013 }
        r3 = r2.equals(r3);	 Catch:{ IOException -> 0x0013 }
        if (r3 != 0) goto L_0x0013;	 Catch:{ IOException -> 0x0013 }
    L_0x0028:
        r0.add(r2);	 Catch:{ IOException -> 0x0013 }
        goto L_0x0013;
    L_0x002c:
        r5 = r5.getURL();
        r5 = r5.toString();
        r0.add(r5);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.radio.parser.PLSParser.getRawUrl(java.net.URLConnection):java.util.LinkedList<java.lang.String>");
    }

    private String parseLine(String str) {
        if (str == null) {
            return null;
        }
        str = str.trim();
        return str.indexOf("http") >= 0 ? str.substring(str.indexOf("http")) : "";
    }

    private URLConnection getConnection(String str) throws IOException {
        return new URL(str).openConnection();
    }
}
