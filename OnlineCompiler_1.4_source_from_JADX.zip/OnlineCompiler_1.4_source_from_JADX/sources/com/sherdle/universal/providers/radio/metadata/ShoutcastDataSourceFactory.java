package com.sherdle.universal.providers.radio.metadata;

import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.HttpDataSource;
import com.google.android.exoplayer2.upstream.HttpDataSource.BaseFactory;
import com.google.android.exoplayer2.upstream.HttpDataSource.RequestProperties;
import com.google.android.exoplayer2.upstream.TransferListener;
import okhttp3.CacheControl;
import okhttp3.Call.Factory;

public final class ShoutcastDataSourceFactory extends BaseFactory {
    private final CacheControl cacheControl;
    private final Factory callFactory;
    private final ShoutcastMetadataListener shoutcastMetadataListener;
    private final TransferListener<? super DataSource> transferListener;
    private final String userAgent;

    public ShoutcastDataSourceFactory(Factory factory, String str, TransferListener<? super DataSource> transferListener, ShoutcastMetadataListener shoutcastMetadataListener) {
        this(factory, str, transferListener, shoutcastMetadataListener, null);
    }

    private ShoutcastDataSourceFactory(Factory factory, String str, TransferListener<? super DataSource> transferListener, ShoutcastMetadataListener shoutcastMetadataListener, CacheControl cacheControl) {
        this.callFactory = factory;
        this.userAgent = str;
        this.transferListener = transferListener;
        this.shoutcastMetadataListener = shoutcastMetadataListener;
        this.cacheControl = cacheControl;
    }

    protected HttpDataSource createDataSourceInternal(RequestProperties requestProperties) {
        return new ShoutcastDataSource(this.callFactory, this.userAgent, null, this.transferListener, this.shoutcastMetadataListener, this.cacheControl);
    }
}
