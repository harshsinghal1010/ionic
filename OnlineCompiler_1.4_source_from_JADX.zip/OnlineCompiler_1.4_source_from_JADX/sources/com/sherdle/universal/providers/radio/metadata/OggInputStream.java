package com.sherdle.universal.providers.radio.metadata;

import android.util.Log;
import com.google.android.exoplayer2.util.ParsableByteArray;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

final class OggInputStream extends PeekInputStream {
    private static final String TAG = "com.sherdle.universal.providers.radio.metadata.OggInputStream";
    private final CommentHeader commentHeader = new CommentHeader();
    private final ParsableByteArray headerArray = new ParsableByteArray(282);
    private final PacketInfoHolder holder = new PacketInfoHolder();
    private final IdHeader idHeader = new IdHeader();
    private final MetadataListener listener;
    private final ParsableByteArray packetArray = new ParsableByteArray(new byte[OggPageHeader.MAX_PAGE_PAYLOAD], 0);
    private final PageHeader pageHeader = new PageHeader();

    private class CommentHeader {
        public final HashMap<String, String> comments = new HashMap();
        public int length;
        public String vendor;

        public void reset() {
            this.vendor = "";
            this.comments.clear();
            this.length = 0;
        }
    }

    private class IdHeader {
        public int audioChannels;
        public long audioSampleRate;
        public int bitRateMaximum;
        public int bitRateMinimum;
        public int bitRateNominal;
        public int blockSize0;
        public int blockSize1;
        public long version;

        private IdHeader() {
        }

        public void reset() {
            this.audioChannels = 0;
            this.audioSampleRate = 0;
            this.bitRateMaximum = 0;
            this.bitRateNominal = 0;
            this.bitRateMinimum = 0;
            this.blockSize0 = 0;
            this.blockSize1 = 0;
        }
    }

    private class PacketInfoHolder {
        public int segmentCount;
        public int size;
    }

    private class PageHeader {
        public int bodySize;
        public long granulePosition;
        public int headerSize;
        public final int[] laces;
        public long pageChecksum;
        public int pageSegmentCount;
        public long pageSequenceNumber;
        public int revision;
        public long streamSerialNumber;
        public int type;

        private PageHeader() {
            this.laces = new int[255];
        }

        public void reset() {
            this.revision = 0;
            this.type = 0;
            this.granulePosition = 0;
            this.streamSerialNumber = 0;
            this.pageSequenceNumber = 0;
            this.pageChecksum = 0;
            this.pageSegmentCount = 0;
            this.headerSize = 0;
            this.bodySize = 0;
        }
    }

    public OggInputStream(InputStream inputStream, MetadataListener metadataListener) {
        super(inputStream);
        this.listener = metadataListener;
    }

    public int read(byte[] bArr, int i, int i2) throws IOException {
        try {
            if (peekPacket(this, this.packetArray, this.headerArray, this.pageHeader, this.holder)) {
                unpackIdHeader(this.packetArray, this.idHeader);
                unpackCommentHeader(this.packetArray, this.commentHeader, this.listener);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return super.read(bArr, i, i2);
    }

    private static boolean peekPacket(PeekInputStream peekInputStream, ParsableByteArray parsableByteArray, ParsableByteArray parsableByteArray2, PageHeader pageHeader, PacketInfoHolder packetInfoHolder) throws IOException, InterruptedException {
        parsableByteArray.reset();
        boolean z = false;
        while (true) {
            int i = -1;
            do {
                boolean z2 = true;
                if (z) {
                    return true;
                }
                if (i < 0) {
                    if (!unpackPageHeader(peekInputStream, parsableByteArray2, pageHeader)) {
                        return false;
                    }
                    if ((pageHeader.type & 1) == 1 && parsableByteArray.limit() == 0) {
                        calculatePacketSize(pageHeader, 0, packetInfoHolder);
                        i = packetInfoHolder.segmentCount + 0;
                    } else {
                        i = 0;
                    }
                }
                calculatePacketSize(pageHeader, i, packetInfoHolder);
                i += packetInfoHolder.segmentCount;
                if (packetInfoHolder.size > 0) {
                    peekInputStream.peekFully(parsableByteArray.data, parsableByteArray.limit(), packetInfoHolder.size);
                    parsableByteArray.setLimit(parsableByteArray.limit() + packetInfoHolder.size);
                    if (pageHeader.laces[i - 1] == 255) {
                        z2 = false;
                    }
                    z = z2;
                }
            } while (i != pageHeader.pageSegmentCount);
        }
    }

    private static void calculatePacketSize(PageHeader pageHeader, int i, PacketInfoHolder packetInfoHolder) {
        packetInfoHolder.segmentCount = 0;
        packetInfoHolder.size = 0;
        while (packetInfoHolder.segmentCount + i < pageHeader.pageSegmentCount) {
            int[] iArr = pageHeader.laces;
            int i2 = packetInfoHolder.segmentCount;
            packetInfoHolder.segmentCount = i2 + 1;
            int i3 = iArr[i2 + i];
            packetInfoHolder.size += i3;
            if (i3 != 255) {
                return;
            }
        }
    }

    private static boolean unpackPageHeader(PeekInputStream peekInputStream, ParsableByteArray parsableByteArray, PageHeader pageHeader) throws IOException, InterruptedException {
        parsableByteArray.reset();
        pageHeader.reset();
        int i = 0;
        if (!peekInputStream.peekFully(parsableByteArray.data, 0, 27, true) || parsableByteArray.readUnsignedByte() != 79 || parsableByteArray.readUnsignedByte() != 103 || parsableByteArray.readUnsignedByte() != 103 || parsableByteArray.readUnsignedByte() != 83) {
            return false;
        }
        pageHeader.revision = parsableByteArray.readUnsignedByte();
        if (pageHeader.revision != 0) {
            return false;
        }
        pageHeader.type = parsableByteArray.readUnsignedByte();
        pageHeader.granulePosition = parsableByteArray.readLittleEndianLong();
        pageHeader.streamSerialNumber = parsableByteArray.readLittleEndianUnsignedInt();
        pageHeader.pageSequenceNumber = parsableByteArray.readLittleEndianUnsignedInt();
        pageHeader.pageChecksum = parsableByteArray.readLittleEndianUnsignedInt();
        pageHeader.pageSegmentCount = parsableByteArray.readUnsignedByte();
        parsableByteArray.reset();
        pageHeader.headerSize = pageHeader.pageSegmentCount + 27;
        peekInputStream.peekFully(parsableByteArray.data, 0, pageHeader.pageSegmentCount);
        while (i < pageHeader.pageSegmentCount) {
            pageHeader.laces[i] = parsableByteArray.readUnsignedByte();
            pageHeader.bodySize += pageHeader.laces[i];
            i++;
        }
        return true;
    }

    private static void unpackIdHeader(ParsableByteArray parsableByteArray, IdHeader idHeader) {
        parsableByteArray.reset();
        if (parsableByteArray.readUnsignedByte() == 1 && parsableByteArray.readUnsignedByte() == 118 && parsableByteArray.readUnsignedByte() == 111 && parsableByteArray.readUnsignedByte() == 114 && parsableByteArray.readUnsignedByte() == 98 && parsableByteArray.readUnsignedByte() == 105 && parsableByteArray.readUnsignedByte() == 115) {
            idHeader.reset();
            idHeader.version = parsableByteArray.readLittleEndianUnsignedInt();
            idHeader.audioChannels = parsableByteArray.readUnsignedByte();
            idHeader.audioSampleRate = parsableByteArray.readLittleEndianUnsignedInt();
            idHeader.bitRateMaximum = parsableByteArray.readLittleEndianInt();
            idHeader.bitRateNominal = parsableByteArray.readLittleEndianInt();
            idHeader.bitRateMinimum = parsableByteArray.readLittleEndianInt();
            parsableByteArray = parsableByteArray.readUnsignedByte();
            idHeader.blockSize0 = (int) Math.pow(2.0d, (double) (parsableByteArray & 15));
            idHeader.blockSize1 = (int) Math.pow(2.0d, (double) (parsableByteArray >> 4));
        }
    }

    private static void unpackCommentHeader(ParsableByteArray parsableByteArray, CommentHeader commentHeader, MetadataListener metadataListener) {
        parsableByteArray.reset();
        if (parsableByteArray.readUnsignedByte() == 3 && parsableByteArray.readUnsignedByte() == 118 && parsableByteArray.readUnsignedByte() == 111 && parsableByteArray.readUnsignedByte() == 114 && parsableByteArray.readUnsignedByte() == 98 && parsableByteArray.readUnsignedByte() == 105 && parsableByteArray.readUnsignedByte() == 115) {
            commentHeader.reset();
            commentHeader.vendor = parsableByteArray.readString((int) parsableByteArray.readLittleEndianUnsignedInt());
            int length = commentHeader.vendor.length() + 11;
            long readLittleEndianUnsignedInt = parsableByteArray.readLittleEndianUnsignedInt();
            length += 4;
            for (int i = 0; ((long) i) < readLittleEndianUnsignedInt; i++) {
                length += 4;
                String readString = parsableByteArray.readString((int) parsableByteArray.readLittleEndianUnsignedInt());
                unPackComment(readString, commentHeader.comments);
                length += readString.length();
            }
            commentHeader.length = length;
            metadataReceived((String) commentHeader.comments.get("ARTIST"), (String) commentHeader.comments.get("TITLE"), metadataListener);
        }
    }

    private static void unPackComment(String str, HashMap<String, String> hashMap) {
        if (str.contains("=")) {
            str = str.split("=");
            if (str.length == 2) {
                hashMap.put(str[0], str[1]);
            } else if (str.length == 1) {
                hashMap.put(str[0], "");
            }
        }
    }

    private static void metadataReceived(String str, String str2, MetadataListener metadataListener) {
        Log.i(TAG, "Metadata received: ");
        String str3 = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Artist: ");
        stringBuilder.append(str);
        Log.i(str3, stringBuilder.toString());
        str3 = TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Song: ");
        stringBuilder.append(str2);
        Log.i(str3, stringBuilder.toString());
        if (metadataListener != null) {
            metadataListener.onMetadataReceived(str, str2, "");
        }
    }
}
