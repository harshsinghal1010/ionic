package com.sherdle.universal.providers.web;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build.VERSION;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.ClientCertRequest;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions.Callback;
import android.webkit.HttpAuthHandler;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.CustomViewCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebSettings.RenderPriority;
import android.webkit.WebStorage.QuotaUpdater;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.common.util.CrashUtils.ErrorDialogData;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class AdvancedWebView extends WebView {
    protected static final String[] ALTERNATIVE_BROWSERS = new String[]{"org.mozilla.firefox", "com.android.chrome", "com.opera.browser", "org.mozilla.firefox_beta", "com.chrome.beta", "com.opera.browser.beta"};
    protected static final String CHARSET_DEFAULT = "UTF-8";
    protected static final String DATABASES_SUB_FOLDER = "/databases";
    protected static final String LANGUAGE_DEFAULT_ISO3 = "eng";
    public static final String PACKAGE_NAME_DOWNLOAD_MANAGER = "com.android.providers.downloads";
    protected static final int REQUEST_CODE_FILE_PICKER = 51426;
    protected WeakReference<Activity> mActivity;
    protected WebChromeClient mCustomWebChromeClient;
    protected WebViewClient mCustomWebViewClient;
    protected ValueCallback<Uri> mFileUploadCallbackFirst;
    protected ValueCallback<Uri[]> mFileUploadCallbackSecond;
    protected WeakReference<Fragment> mFragment;
    protected boolean mGeolocationEnabled;
    protected final Map<String, String> mHttpHeaders = new HashMap();
    protected String mLanguageIso3;
    protected long mLastError;
    protected Listener mListener;
    protected final List<String> mPermittedHostnames = new LinkedList();
    protected int mRequestCodeFilePicker = REQUEST_CODE_FILE_PICKER;
    protected String mUploadableFileTypes = "*/*";

    /* renamed from: com.sherdle.universal.providers.web.AdvancedWebView$1 */
    class C06461 extends WebViewClient {
        C06461() {
        }

        public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
            if (!(AdvancedWebView.this.hasError() || AdvancedWebView.this.mListener == null)) {
                AdvancedWebView.this.mListener.onPageStarted(str, bitmap);
            }
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onPageStarted(webView, str, bitmap);
            }
        }

        public void onPageFinished(WebView webView, String str) {
            if (!(AdvancedWebView.this.hasError() || AdvancedWebView.this.mListener == null)) {
                AdvancedWebView.this.mListener.onPageFinished(str);
            }
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onPageFinished(webView, str);
            }
        }

        public void onReceivedError(WebView webView, int i, String str, String str2) {
            AdvancedWebView.this.setLastError();
            if (AdvancedWebView.this.mListener != null) {
                AdvancedWebView.this.mListener.onPageError(i, str, str2);
            }
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onReceivedError(webView, i, str, str2);
            }
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            if (!AdvancedWebView.this.isHostnameAllowed(str)) {
                if (AdvancedWebView.this.mListener != null) {
                    AdvancedWebView.this.mListener.onExternalPageRequest(str);
                }
                return true;
            } else if (AdvancedWebView.this.mCustomWebViewClient != null && AdvancedWebView.this.mCustomWebViewClient.shouldOverrideUrlLoading(webView, str)) {
                return true;
            } else {
                webView.loadUrl(str);
                return true;
            }
        }

        public void onLoadResource(WebView webView, String str) {
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onLoadResource(webView, str);
            } else {
                super.onLoadResource(webView, str);
            }
        }

        @SuppressLint({"NewApi"})
        public WebResourceResponse shouldInterceptRequest(WebView webView, String str) {
            if (VERSION.SDK_INT < 11) {
                return null;
            }
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                return AdvancedWebView.this.mCustomWebViewClient.shouldInterceptRequest(webView, str);
            }
            return super.shouldInterceptRequest(webView, str);
        }

        @SuppressLint({"NewApi"})
        public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
            if (VERSION.SDK_INT < 21) {
                return null;
            }
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                return AdvancedWebView.this.mCustomWebViewClient.shouldInterceptRequest(webView, webResourceRequest);
            }
            return super.shouldInterceptRequest(webView, webResourceRequest);
        }

        public void onFormResubmission(WebView webView, Message message, Message message2) {
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onFormResubmission(webView, message, message2);
            } else {
                super.onFormResubmission(webView, message, message2);
            }
        }

        public void doUpdateVisitedHistory(WebView webView, String str, boolean z) {
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.doUpdateVisitedHistory(webView, str, z);
            } else {
                super.doUpdateVisitedHistory(webView, str, z);
            }
        }

        public void onReceivedSslError(WebView webView, SslErrorHandler sslErrorHandler, SslError sslError) {
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onReceivedSslError(webView, sslErrorHandler, sslError);
            } else {
                super.onReceivedSslError(webView, sslErrorHandler, sslError);
            }
        }

        @SuppressLint({"NewApi"})
        public void onReceivedClientCertRequest(WebView webView, ClientCertRequest clientCertRequest) {
            if (VERSION.SDK_INT < 21) {
                return;
            }
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onReceivedClientCertRequest(webView, clientCertRequest);
            } else {
                super.onReceivedClientCertRequest(webView, clientCertRequest);
            }
        }

        public void onReceivedHttpAuthRequest(WebView webView, HttpAuthHandler httpAuthHandler, String str, String str2) {
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onReceivedHttpAuthRequest(webView, httpAuthHandler, str, str2);
            } else {
                super.onReceivedHttpAuthRequest(webView, httpAuthHandler, str, str2);
            }
        }

        public boolean shouldOverrideKeyEvent(WebView webView, KeyEvent keyEvent) {
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                return AdvancedWebView.this.mCustomWebViewClient.shouldOverrideKeyEvent(webView, keyEvent);
            }
            return super.shouldOverrideKeyEvent(webView, keyEvent);
        }

        public void onUnhandledKeyEvent(WebView webView, KeyEvent keyEvent) {
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onUnhandledKeyEvent(webView, keyEvent);
            } else {
                super.onUnhandledKeyEvent(webView, keyEvent);
            }
        }

        public void onScaleChanged(WebView webView, float f, float f2) {
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onScaleChanged(webView, f, f2);
            } else {
                super.onScaleChanged(webView, f, f2);
            }
        }

        @SuppressLint({"NewApi"})
        public void onReceivedLoginRequest(WebView webView, String str, String str2, String str3) {
            if (VERSION.SDK_INT < 12) {
                return;
            }
            if (AdvancedWebView.this.mCustomWebViewClient != null) {
                AdvancedWebView.this.mCustomWebViewClient.onReceivedLoginRequest(webView, str, str2, str3);
            } else {
                super.onReceivedLoginRequest(webView, str, str2, str3);
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.web.AdvancedWebView$2 */
    class C06472 extends WebChromeClient {
        C06472() {
        }

        public void openFileChooser(ValueCallback<Uri> valueCallback) {
            openFileChooser(valueCallback, null);
        }

        public void openFileChooser(ValueCallback<Uri> valueCallback, String str) {
            openFileChooser(valueCallback, str, null);
        }

        public void openFileChooser(ValueCallback<Uri> valueCallback, String str, String str2) {
            AdvancedWebView.this.openFileInput(valueCallback, null, false);
        }

        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> valueCallback, FileChooserParams fileChooserParams) {
            boolean z = false;
            if (VERSION.SDK_INT < 21) {
                return false;
            }
            if (fileChooserParams.getMode() == 1) {
                z = true;
            }
            AdvancedWebView.this.openFileInput(null, valueCallback, z);
            return true;
        }

        public void onProgressChanged(WebView webView, int i) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onProgressChanged(webView, i);
            } else {
                super.onProgressChanged(webView, i);
            }
        }

        public void onReceivedTitle(WebView webView, String str) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onReceivedTitle(webView, str);
            } else {
                super.onReceivedTitle(webView, str);
            }
        }

        public void onReceivedIcon(WebView webView, Bitmap bitmap) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onReceivedIcon(webView, bitmap);
            } else {
                super.onReceivedIcon(webView, bitmap);
            }
        }

        public void onReceivedTouchIconUrl(WebView webView, String str, boolean z) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onReceivedTouchIconUrl(webView, str, z);
            } else {
                super.onReceivedTouchIconUrl(webView, str, z);
            }
        }

        public void onShowCustomView(View view, CustomViewCallback customViewCallback) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onShowCustomView(view, customViewCallback);
            } else {
                super.onShowCustomView(view, customViewCallback);
            }
        }

        @SuppressLint({"NewApi"})
        public void onShowCustomView(View view, int i, CustomViewCallback customViewCallback) {
            if (VERSION.SDK_INT < 14) {
                return;
            }
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onShowCustomView(view, i, customViewCallback);
            } else {
                super.onShowCustomView(view, i, customViewCallback);
            }
        }

        public void onHideCustomView() {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onHideCustomView();
            } else {
                super.onHideCustomView();
            }
        }

        public boolean onCreateWindow(WebView webView, boolean z, boolean z2, Message message) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                return AdvancedWebView.this.mCustomWebChromeClient.onCreateWindow(webView, z, z2, message);
            }
            return super.onCreateWindow(webView, z, z2, message);
        }

        public void onRequestFocus(WebView webView) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onRequestFocus(webView);
            } else {
                super.onRequestFocus(webView);
            }
        }

        public void onCloseWindow(WebView webView) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onCloseWindow(webView);
            } else {
                super.onCloseWindow(webView);
            }
        }

        public boolean onJsAlert(WebView webView, String str, String str2, JsResult jsResult) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                return AdvancedWebView.this.mCustomWebChromeClient.onJsAlert(webView, str, str2, jsResult);
            }
            return super.onJsAlert(webView, str, str2, jsResult);
        }

        public boolean onJsConfirm(WebView webView, String str, String str2, JsResult jsResult) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                return AdvancedWebView.this.mCustomWebChromeClient.onJsConfirm(webView, str, str2, jsResult);
            }
            return super.onJsConfirm(webView, str, str2, jsResult);
        }

        public boolean onJsPrompt(WebView webView, String str, String str2, String str3, JsPromptResult jsPromptResult) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                return AdvancedWebView.this.mCustomWebChromeClient.onJsPrompt(webView, str, str2, str3, jsPromptResult);
            }
            return super.onJsPrompt(webView, str, str2, str3, jsPromptResult);
        }

        public boolean onJsBeforeUnload(WebView webView, String str, String str2, JsResult jsResult) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                return AdvancedWebView.this.mCustomWebChromeClient.onJsBeforeUnload(webView, str, str2, jsResult);
            }
            return super.onJsBeforeUnload(webView, str, str2, jsResult);
        }

        public void onGeolocationPermissionsShowPrompt(String str, Callback callback) {
            if (AdvancedWebView.this.mGeolocationEnabled) {
                callback.invoke(str, true, false);
            } else if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onGeolocationPermissionsShowPrompt(str, callback);
            } else {
                super.onGeolocationPermissionsShowPrompt(str, callback);
            }
        }

        public void onGeolocationPermissionsHidePrompt() {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onGeolocationPermissionsHidePrompt();
            } else {
                super.onGeolocationPermissionsHidePrompt();
            }
        }

        @SuppressLint({"NewApi"})
        public void onPermissionRequest(PermissionRequest permissionRequest) {
            if (VERSION.SDK_INT < 21) {
                return;
            }
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onPermissionRequest(permissionRequest);
            } else {
                super.onPermissionRequest(permissionRequest);
            }
        }

        @SuppressLint({"NewApi"})
        public void onPermissionRequestCanceled(PermissionRequest permissionRequest) {
            if (VERSION.SDK_INT < 21) {
                return;
            }
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onPermissionRequestCanceled(permissionRequest);
            } else {
                super.onPermissionRequestCanceled(permissionRequest);
            }
        }

        public boolean onJsTimeout() {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                return AdvancedWebView.this.mCustomWebChromeClient.onJsTimeout();
            }
            return super.onJsTimeout();
        }

        public void onConsoleMessage(String str, int i, String str2) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onConsoleMessage(str, i, str2);
            } else {
                super.onConsoleMessage(str, i, str2);
            }
        }

        public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                return AdvancedWebView.this.mCustomWebChromeClient.onConsoleMessage(consoleMessage);
            }
            return super.onConsoleMessage(consoleMessage);
        }

        public Bitmap getDefaultVideoPoster() {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                return AdvancedWebView.this.mCustomWebChromeClient.getDefaultVideoPoster();
            }
            return super.getDefaultVideoPoster();
        }

        public View getVideoLoadingProgressView() {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                return AdvancedWebView.this.mCustomWebChromeClient.getVideoLoadingProgressView();
            }
            return super.getVideoLoadingProgressView();
        }

        public void getVisitedHistory(ValueCallback<String[]> valueCallback) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.getVisitedHistory(valueCallback);
            } else {
                super.getVisitedHistory(valueCallback);
            }
        }

        public void onExceededDatabaseQuota(String str, String str2, long j, long j2, long j3, QuotaUpdater quotaUpdater) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onExceededDatabaseQuota(str, str2, j, j2, j3, quotaUpdater);
            } else {
                super.onExceededDatabaseQuota(str, str2, j, j2, j3, quotaUpdater);
            }
        }

        public void onReachedMaxAppCacheSize(long j, long j2, QuotaUpdater quotaUpdater) {
            if (AdvancedWebView.this.mCustomWebChromeClient != null) {
                AdvancedWebView.this.mCustomWebChromeClient.onReachedMaxAppCacheSize(j, j2, quotaUpdater);
            } else {
                super.onReachedMaxAppCacheSize(j, j2, quotaUpdater);
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.web.AdvancedWebView$3 */
    class C06483 implements DownloadListener {
        C06483() {
        }

        public void onDownloadStart(String str, String str2, String str3, String str4, long j) {
            String guessFileName = URLUtil.guessFileName(str, str3, str4);
            if (AdvancedWebView.this.mListener != null) {
                AdvancedWebView.this.mListener.onDownloadRequested(str, guessFileName, str4, j, str3, str2);
            }
        }
    }

    public static class Browsers {
        private static String mAlternativePackage;

        public static boolean hasAlternative(Context context) {
            return getAlternative(context) != null ? true : null;
        }

        public static String getAlternative(Context context) {
            String str = mAlternativePackage;
            if (str != null) {
                return str;
            }
            List asList = Arrays.asList(AdvancedWebView.ALTERNATIVE_BROWSERS);
            for (ApplicationInfo applicationInfo : context.getPackageManager().getInstalledApplications(128)) {
                if (applicationInfo.enabled) {
                    if (asList.contains(applicationInfo.packageName)) {
                        mAlternativePackage = applicationInfo.packageName;
                        return applicationInfo.packageName;
                    }
                }
            }
            return null;
        }

        public static void openUrl(Activity activity, String str) {
            openUrl(activity, str, false);
        }

        public static void openUrl(Activity activity, String str, boolean z) {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.setPackage(getAlternative(activity));
            intent.addFlags(ErrorDialogData.BINDER_CRASH);
            activity.startActivity(intent);
            if (z) {
                activity.overridePendingTransition(0, 0);
            }
        }
    }

    public interface Listener {
        void onDownloadRequested(String str, String str2, String str3, long j, String str4, String str5);

        void onExternalPageRequest(String str);

        void onPageError(int i, String str, String str2);

        void onPageFinished(String str);

        void onPageStarted(String str, Bitmap bitmap);
    }

    public AdvancedWebView(Context context) {
        super(context);
        init(context);
    }

    public AdvancedWebView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public AdvancedWebView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context);
    }

    public void setListener(Activity activity, Listener listener) {
        setListener(activity, listener, (int) REQUEST_CODE_FILE_PICKER);
    }

    public void setListener(Activity activity, Listener listener, int i) {
        if (activity != null) {
            this.mActivity = new WeakReference(activity);
        } else {
            this.mActivity = null;
        }
        setListener(listener, i);
    }

    public void setListener(Fragment fragment, Listener listener) {
        setListener(fragment, listener, (int) REQUEST_CODE_FILE_PICKER);
    }

    public void setListener(Fragment fragment, Listener listener, int i) {
        if (fragment != null) {
            this.mFragment = new WeakReference(fragment);
        } else {
            this.mFragment = null;
        }
        setListener(listener, i);
    }

    protected void setListener(Listener listener, int i) {
        this.mListener = listener;
        this.mRequestCodeFilePicker = i;
    }

    public void setWebViewClient(WebViewClient webViewClient) {
        this.mCustomWebViewClient = webViewClient;
    }

    public void setWebChromeClient(WebChromeClient webChromeClient) {
        this.mCustomWebChromeClient = webChromeClient;
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public void setGeolocationEnabled(boolean z) {
        if (z) {
            getSettings().setJavaScriptEnabled(true);
            getSettings().setGeolocationEnabled(true);
            setGeolocationDatabasePath();
        }
        this.mGeolocationEnabled = z;
    }

    @SuppressLint({"NewApi"})
    protected void setGeolocationDatabasePath() {
        Activity activity;
        WeakReference weakReference = this.mFragment;
        if (weakReference == null || weakReference.get() == null || VERSION.SDK_INT < 11 || ((Fragment) this.mFragment.get()).getActivity() == null) {
            weakReference = this.mActivity;
            if (weakReference != null && weakReference.get() != null) {
                activity = (Activity) this.mActivity.get();
            } else {
                return;
            }
        }
        activity = ((Fragment) this.mFragment.get()).getActivity();
        getSettings().setGeolocationDatabasePath(activity.getFilesDir().getPath());
    }

    public void setUploadableFileTypes(String str) {
        this.mUploadableFileTypes = str;
    }

    public void loadHtml(String str) {
        loadHtml(str, null);
    }

    public void loadHtml(String str, String str2) {
        loadHtml(str, str2, null);
    }

    public void loadHtml(String str, String str2, String str3) {
        loadHtml(str, str2, str3, "utf-8");
    }

    public void loadHtml(String str, String str2, String str3, String str4) {
        loadDataWithBaseURL(str2, str, "text/html", str4, str3);
    }

    @SuppressLint({"NewApi"})
    public void onResume() {
        if (VERSION.SDK_INT >= 11) {
            super.onResume();
        }
        resumeTimers();
    }

    @SuppressLint({"NewApi"})
    public void onPause() {
        if (VERSION.SDK_INT >= 11) {
            super.onPause();
        }
    }

    public void onDestroy() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r1 = this;
        r0 = r1.getParent();	 Catch:{ Exception -> 0x0009 }
        r0 = (android.view.ViewGroup) r0;	 Catch:{ Exception -> 0x0009 }
        r0.removeView(r1);	 Catch:{ Exception -> 0x0009 }
    L_0x0009:
        r1.removeAllViews();	 Catch:{ Exception -> 0x000c }
    L_0x000c:
        r1.destroy();
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.web.AdvancedWebView.onDestroy():void");
    }

    public void onActivityResult(int r4, int r5, android.content.Intent r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r3 = this;
        r0 = r3.mRequestCodeFilePicker;
        if (r4 != r0) goto L_0x007d;
    L_0x0004:
        r4 = -1;
        r0 = 0;
        if (r5 != r4) goto L_0x006a;
    L_0x0008:
        if (r6 == 0) goto L_0x007d;
    L_0x000a:
        r4 = r3.mFileUploadCallbackFirst;
        if (r4 == 0) goto L_0x0019;
    L_0x000e:
        r5 = r6.getData();
        r4.onReceiveValue(r5);
        r3.mFileUploadCallbackFirst = r0;
        goto L_0x007d;
    L_0x0019:
        r4 = r3.mFileUploadCallbackSecond;
        if (r4 == 0) goto L_0x007d;
    L_0x001d:
        r4 = r6.getDataString();	 Catch:{ Exception -> 0x0061 }
        r5 = 0;	 Catch:{ Exception -> 0x0061 }
        if (r4 == 0) goto L_0x0032;	 Catch:{ Exception -> 0x0061 }
    L_0x0024:
        r4 = 1;	 Catch:{ Exception -> 0x0061 }
        r4 = new android.net.Uri[r4];	 Catch:{ Exception -> 0x0061 }
        r6 = r6.getDataString();	 Catch:{ Exception -> 0x0061 }
        r6 = android.net.Uri.parse(r6);	 Catch:{ Exception -> 0x0061 }
        r4[r5] = r6;	 Catch:{ Exception -> 0x0061 }
        goto L_0x0062;	 Catch:{ Exception -> 0x0061 }
    L_0x0032:
        r4 = android.os.Build.VERSION.SDK_INT;	 Catch:{ Exception -> 0x0061 }
        r1 = 16;	 Catch:{ Exception -> 0x0061 }
        if (r4 < r1) goto L_0x005f;	 Catch:{ Exception -> 0x0061 }
    L_0x0038:
        r4 = r6.getClipData();	 Catch:{ Exception -> 0x0061 }
        if (r4 == 0) goto L_0x005f;	 Catch:{ Exception -> 0x0061 }
    L_0x003e:
        r4 = r6.getClipData();	 Catch:{ Exception -> 0x0061 }
        r4 = r4.getItemCount();	 Catch:{ Exception -> 0x0061 }
        r1 = new android.net.Uri[r4];	 Catch:{ Exception -> 0x0061 }
    L_0x0048:
        if (r5 >= r4) goto L_0x005d;
    L_0x004a:
        r2 = r6.getClipData();	 Catch:{ Exception -> 0x005b }
        r2 = r2.getItemAt(r5);	 Catch:{ Exception -> 0x005b }
        r2 = r2.getUri();	 Catch:{ Exception -> 0x005b }
        r1[r5] = r2;	 Catch:{ Exception -> 0x005b }
        r5 = r5 + 1;
        goto L_0x0048;
    L_0x005b:
        r4 = r1;
        goto L_0x0062;
    L_0x005d:
        r4 = r1;
        goto L_0x0062;
    L_0x005f:
        r4 = r0;
        goto L_0x0062;
    L_0x0061:
        r4 = r0;
    L_0x0062:
        r5 = r3.mFileUploadCallbackSecond;
        r5.onReceiveValue(r4);
        r3.mFileUploadCallbackSecond = r0;
        goto L_0x007d;
    L_0x006a:
        r4 = r3.mFileUploadCallbackFirst;
        if (r4 == 0) goto L_0x0074;
    L_0x006e:
        r4.onReceiveValue(r0);
        r3.mFileUploadCallbackFirst = r0;
        goto L_0x007d;
    L_0x0074:
        r4 = r3.mFileUploadCallbackSecond;
        if (r4 == 0) goto L_0x007d;
    L_0x0078:
        r4.onReceiveValue(r0);
        r3.mFileUploadCallbackSecond = r0;
    L_0x007d:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.web.AdvancedWebView.onActivityResult(int, int, android.content.Intent):void");
    }

    public void addHttpHeader(String str, String str2) {
        this.mHttpHeaders.put(str, str2);
    }

    public void removeHttpHeader(String str) {
        this.mHttpHeaders.remove(str);
    }

    public void addPermittedHostname(String str) {
        this.mPermittedHostnames.add(str);
    }

    public void addPermittedHostnames(Collection<? extends String> collection) {
        this.mPermittedHostnames.addAll(collection);
    }

    public List<String> getPermittedHostnames() {
        return this.mPermittedHostnames;
    }

    public void removePermittedHostname(String str) {
        this.mPermittedHostnames.remove(str);
    }

    public void clearPermittedHostnames() {
        this.mPermittedHostnames.clear();
    }

    public boolean onBackPressed() {
        if (!canGoBack()) {
            return true;
        }
        goBack();
        return false;
    }

    @SuppressLint({"NewApi"})
    protected static void setAllowAccessFromFileUrls(WebSettings webSettings, boolean z) {
        if (VERSION.SDK_INT >= 16) {
            webSettings.setAllowFileAccessFromFileURLs(z);
            webSettings.setAllowUniversalAccessFromFileURLs(z);
        }
    }

    public void setCookiesEnabled(boolean z) {
        CookieManager.getInstance().setAcceptCookie(z);
    }

    @SuppressLint({"NewApi"})
    public void setThirdPartyCookiesEnabled(boolean z) {
        if (VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, z);
        }
    }

    public void setMixedContentAllowed(boolean z) {
        setMixedContentAllowed(getSettings(), z);
    }

    @SuppressLint({"NewApi"})
    protected void setMixedContentAllowed(WebSettings webSettings, boolean z) {
        if (VERSION.SDK_INT >= 21) {
            webSettings.setMixedContentMode(z ^ 1);
        }
    }

    public void setDesktopMode(boolean z) {
        String replace;
        WebSettings settings = getSettings();
        if (z) {
            replace = settings.getUserAgentString().replace("Mobile", "eliboM").replace("Android", "diordnA");
        } else {
            replace = settings.getUserAgentString().replace("eliboM", "Mobile").replace("diordnA", "Android");
        }
        settings.setUserAgentString(replace);
        settings.setUseWideViewPort(z);
        settings.setLoadWithOverviewMode(z);
        settings.setSupportZoom(z);
        settings.setBuiltInZoomControls(z);
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    protected void init(Context context) {
        if (!isInEditMode()) {
            if (context instanceof Activity) {
                this.mActivity = new WeakReference((Activity) context);
            }
            this.mLanguageIso3 = getLanguageIso3();
            setFocusable(true);
            setFocusableInTouchMode(true);
            setSaveEnabled(true);
            context = context.getFilesDir().getPath();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(context.substring(0, context.lastIndexOf("/")));
            stringBuilder.append(DATABASES_SUB_FOLDER);
            context = stringBuilder.toString();
            WebSettings settings = getSettings();
            settings.setAllowFileAccess(false);
            setAllowAccessFromFileUrls(settings, false);
            settings.setBuiltInZoomControls(false);
            if (VERSION.SDK_INT >= 21) {
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true);
            }
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            if (VERSION.SDK_INT < 18) {
                settings.setRenderPriority(RenderPriority.HIGH);
            }
            settings.setDatabaseEnabled(true);
            if (VERSION.SDK_INT < 19) {
                settings.setDatabasePath(context);
            }
            setMixedContentAllowed(settings, true);
            setThirdPartyCookiesEnabled(true);
            super.setWebViewClient(new C06461());
            super.setWebChromeClient(new C06472());
            setDownloadListener(new C06483());
        }
    }

    public void loadUrl(String str, Map<String, String> map) {
        if (map == null) {
            map = this.mHttpHeaders;
        } else if (this.mHttpHeaders.size() > 0) {
            map.putAll(this.mHttpHeaders);
        }
        super.loadUrl(str, map);
    }

    public void loadUrl(String str) {
        if (this.mHttpHeaders.size() > 0) {
            super.loadUrl(str, this.mHttpHeaders);
        } else {
            super.loadUrl(str);
        }
    }

    public void loadUrl(String str, boolean z) {
        if (z) {
            str = makeUrlUnique(str);
        }
        loadUrl(str);
    }

    public void loadUrl(String str, boolean z, Map<String, String> map) {
        if (z) {
            str = makeUrlUnique(str);
        }
        loadUrl(str, (Map) map);
    }

    protected static String makeUrlUnique(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        if (str.contains("?")) {
            stringBuilder.append('&');
        } else {
            if (str.lastIndexOf(47) <= 7) {
                stringBuilder.append('/');
            }
            stringBuilder.append('?');
        }
        stringBuilder.append(System.currentTimeMillis());
        stringBuilder.append('=');
        stringBuilder.append(1);
        return stringBuilder.toString();
    }

    protected boolean isHostnameAllowed(String str) {
        if (this.mPermittedHostnames.size() == 0) {
            return true;
        }
        str = Uri.parse(str).getHost();
        for (String str2 : this.mPermittedHostnames) {
            if (!str.equals(str2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(".");
                stringBuilder.append(str2);
                if (str.endsWith(stringBuilder.toString())) {
                }
            }
            return true;
        }
        return null;
    }

    protected void setLastError() {
        this.mLastError = System.currentTimeMillis();
    }

    protected boolean hasError() {
        return this.mLastError + 500 >= System.currentTimeMillis();
    }

    protected static java.lang.String getLanguageIso3() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = java.util.Locale.getDefault();	 Catch:{ MissingResourceException -> 0x000f }
        r0 = r0.getISO3Language();	 Catch:{ MissingResourceException -> 0x000f }
        r1 = java.util.Locale.US;	 Catch:{ MissingResourceException -> 0x000f }
        r0 = r0.toLowerCase(r1);	 Catch:{ MissingResourceException -> 0x000f }
        return r0;
    L_0x000f:
        r0 = "eng";
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.web.AdvancedWebView.getLanguageIso3():java.lang.String");
    }

    protected java.lang.String getFileUploadPromptLabel() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "zho";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0011;	 Catch:{ Exception -> 0x0198 }
    L_0x000a:
        r0 = "6YCJ5oup5LiA5Liq5paH5Lu2";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0011:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "spa";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0022;	 Catch:{ Exception -> 0x0198 }
    L_0x001b:
        r0 = "RWxpamEgdW4gYXJjaGl2bw==";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0022:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "hin";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0033;	 Catch:{ Exception -> 0x0198 }
    L_0x002c:
        r0 = "4KSP4KSVIOCkq+CkvOCkvuCkh+CksiDgpJrgpYHgpKjgpYfgpII=";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0033:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "ben";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0044;	 Catch:{ Exception -> 0x0198 }
    L_0x003d:
        r0 = "4KaP4KaV4Kaf4Ka/IOCmq+CmvuCmh+CmsiDgpqjgpr/gprDgp43gpqzgpr7gpprgpqg=";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0044:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "ara";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0055;	 Catch:{ Exception -> 0x0198 }
    L_0x004e:
        r0 = "2KfYrtiq2YrYp9ixINmF2YTZgSDZiNin2K3Yrw==";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0055:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "por";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0066;	 Catch:{ Exception -> 0x0198 }
    L_0x005f:
        r0 = "RXNjb2xoYSB1bSBhcnF1aXZv";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0066:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "rus";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0077;	 Catch:{ Exception -> 0x0198 }
    L_0x0070:
        r0 = "0JLRi9Cx0LXRgNC40YLQtSDQvtC00LjQvSDRhNCw0LnQuw==";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0077:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "jpn";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0088;	 Catch:{ Exception -> 0x0198 }
    L_0x0081:
        r0 = "MeODleOCoeOCpOODq+OCkumBuOaKnuOBl+OBpuOBj+OBoOOBleOBhA==";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0088:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "pan";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0099;	 Catch:{ Exception -> 0x0198 }
    L_0x0092:
        r0 = "4KiH4Kmx4KiVIOCoq+CovuCoh+CosiDgqJrgqYHgqKPgqYs=";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0099:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "deu";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x00aa;	 Catch:{ Exception -> 0x0198 }
    L_0x00a3:
        r0 = "V8OkaGxlIGVpbmUgRGF0ZWk=";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x00aa:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "jav";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x00bb;	 Catch:{ Exception -> 0x0198 }
    L_0x00b4:
        r0 = "UGlsaWggc2lqaSBiZXJrYXM=";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x00bb:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "msa";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x00cc;	 Catch:{ Exception -> 0x0198 }
    L_0x00c5:
        r0 = "UGlsaWggc2F0dSBmYWls";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x00cc:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "tel";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x00dd;	 Catch:{ Exception -> 0x0198 }
    L_0x00d6:
        r0 = "4LCS4LCVIOCwq+CxhuCxluCwsuCxjeCwqOCxgSDgsI7gsILgsJrgsYHgsJXgsYvgsILgsKHgsL8=";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x00dd:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "vie";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x00ee;	 Catch:{ Exception -> 0x0198 }
    L_0x00e7:
        r0 = "Q2jhu41uIG3hu5l0IHThuq1wIHRpbg==";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x00ee:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "kor";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x00ff;	 Catch:{ Exception -> 0x0198 }
    L_0x00f8:
        r0 = "7ZWY64KY7J2YIO2MjOydvOydhCDshKDtg50=";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x00ff:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "fra";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0110;	 Catch:{ Exception -> 0x0198 }
    L_0x0109:
        r0 = "Q2hvaXNpc3NleiB1biBmaWNoaWVy";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0110:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "mar";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0121;	 Catch:{ Exception -> 0x0198 }
    L_0x011a:
        r0 = "4KSr4KS+4KSH4KSyIOCkqOCkv+CkteCkoeCkvg==";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0121:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "tam";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0132;	 Catch:{ Exception -> 0x0198 }
    L_0x012b:
        r0 = "4K6S4K6w4K+BIOCuleCvh+CuvuCuquCvjeCuquCviCDgrqTgr4fgrrDgr43grrXgr4E=";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0132:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "urd";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0143;	 Catch:{ Exception -> 0x0198 }
    L_0x013c:
        r0 = "2KfbjNqpINmB2KfYptmEINmF24zauiDYs9uSINin2YbYqtiu2KfYqCDaqdix24zaug==";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0143:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "fas";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0154;	 Catch:{ Exception -> 0x0198 }
    L_0x014d:
        r0 = "2LHYpyDYp9mG2KrYrtin2Kgg2qnZhtuM2K8g24zaqSDZgdin24zZhA==";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0154:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "tur";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0165;	 Catch:{ Exception -> 0x0198 }
    L_0x015e:
        r0 = "QmlyIGRvc3lhIHNlw6dpbg==";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0165:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "ita";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0176;	 Catch:{ Exception -> 0x0198 }
    L_0x016f:
        r0 = "U2NlZ2xpIHVuIGZpbGU=";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0176:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "tha";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0187;	 Catch:{ Exception -> 0x0198 }
    L_0x0180:
        r0 = "4LmA4Lil4Li34Lit4LiB4LmE4Lif4Lil4LmM4Lir4LiZ4Li24LmI4LiH";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;	 Catch:{ Exception -> 0x0198 }
    L_0x0187:
        r0 = r2.mLanguageIso3;	 Catch:{ Exception -> 0x0198 }
        r1 = "guj";	 Catch:{ Exception -> 0x0198 }
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x0198 }
        if (r0 == 0) goto L_0x0198;	 Catch:{ Exception -> 0x0198 }
    L_0x0191:
        r0 = "4KqP4KqVIOCqq+CqvuCqh+CqsuCqqOCrhyDgqqrgqrjgqoLgqqY=";	 Catch:{ Exception -> 0x0198 }
        r0 = decodeBase64(r0);	 Catch:{ Exception -> 0x0198 }
        return r0;
    L_0x0198:
        r0 = "Choose a file";
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.web.AdvancedWebView.getFileUploadPromptLabel():java.lang.String");
    }

    protected static String decodeBase64(String str) throws IllegalArgumentException, UnsupportedEncodingException {
        return new String(Base64.decode(str, 0), "UTF-8");
    }

    @SuppressLint({"NewApi"})
    protected void openFileInput(ValueCallback<Uri> valueCallback, ValueCallback<Uri[]> valueCallback2, boolean z) {
        ValueCallback valueCallback3 = this.mFileUploadCallbackFirst;
        if (valueCallback3 != null) {
            valueCallback3.onReceiveValue(null);
        }
        this.mFileUploadCallbackFirst = valueCallback;
        valueCallback = this.mFileUploadCallbackSecond;
        if (valueCallback != null) {
            valueCallback.onReceiveValue(null);
        }
        this.mFileUploadCallbackSecond = valueCallback2;
        valueCallback = new Intent("android.intent.action.GET_CONTENT");
        valueCallback.addCategory("android.intent.category.OPENABLE");
        if (z && VERSION.SDK_INT >= true) {
            valueCallback.putExtra("android.intent.extra.ALLOW_MULTIPLE", true);
        }
        valueCallback.setType(this.mUploadableFileTypes);
        valueCallback2 = this.mFragment;
        if (valueCallback2 == null || valueCallback2.get() == null || VERSION.SDK_INT < true) {
            valueCallback2 = this.mActivity;
            if (valueCallback2 != null && valueCallback2.get() != null) {
                ((Activity) this.mActivity.get()).startActivityForResult(Intent.createChooser(valueCallback, getFileUploadPromptLabel()), this.mRequestCodeFilePicker);
                return;
            }
            return;
        }
        ((Fragment) this.mFragment.get()).startActivityForResult(Intent.createChooser(valueCallback, getFileUploadPromptLabel()), this.mRequestCodeFilePicker);
    }

    public static boolean isFileUploadAvailable() {
        return isFileUploadAvailable(false);
    }

    public static boolean isFileUploadAvailable(boolean z) {
        boolean z2 = true;
        if (VERSION.SDK_INT != 19) {
            return true;
        }
        String str = VERSION.RELEASE == null ? "" : VERSION.RELEASE;
        if (!z) {
            if (!str.startsWith("4.4.3")) {
                if (str.startsWith("4.4.4")) {
                }
            }
            return z2;
        }
        z2 = false;
        return z2;
    }

    @android.annotation.SuppressLint({"NewApi"})
    public static boolean handleDownload(android.content.Context r4, java.lang.String r5, java.lang.String r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = android.os.Build.VERSION.SDK_INT;
        r1 = 9;
        if (r0 < r1) goto L_0x003f;
    L_0x0006:
        r0 = new android.app.DownloadManager$Request;
        r5 = android.net.Uri.parse(r5);
        r0.<init>(r5);
        r5 = android.os.Build.VERSION.SDK_INT;
        r1 = 1;
        r2 = 11;
        if (r5 < r2) goto L_0x001c;
    L_0x0016:
        r0.allowScanningByMediaScanner();
        r0.setNotificationVisibility(r1);
    L_0x001c:
        r5 = android.os.Environment.DIRECTORY_DOWNLOADS;
        r0.setDestinationInExternalPublicDir(r5, r6);
        r5 = "download";
        r5 = r4.getSystemService(r5);
        r5 = (android.app.DownloadManager) r5;
        r6 = 0;
        r5.enqueue(r0);	 Catch:{ SecurityException -> 0x002e }
        goto L_0x0038;
    L_0x002e:
        r3 = android.os.Build.VERSION.SDK_INT;	 Catch:{ IllegalArgumentException -> 0x0039 }
        if (r3 < r2) goto L_0x0035;	 Catch:{ IllegalArgumentException -> 0x0039 }
    L_0x0032:
        r0.setNotificationVisibility(r6);	 Catch:{ IllegalArgumentException -> 0x0039 }
    L_0x0035:
        r5.enqueue(r0);	 Catch:{ IllegalArgumentException -> 0x0039 }
    L_0x0038:
        return r1;
    L_0x0039:
        r5 = "com.android.providers.downloads";
        openAppSettings(r4, r5);
        return r6;
    L_0x003f:
        r4 = new java.lang.RuntimeException;
        r5 = "Method requires API level 9 or above";
        r4.<init>(r5);
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.web.AdvancedWebView.handleDownload(android.content.Context, java.lang.String, java.lang.String):boolean");
    }

    @android.annotation.SuppressLint({"NewApi"})
    private static boolean openAppSettings(android.content.Context r3, java.lang.String r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r0 = android.os.Build.VERSION.SDK_INT;
        r1 = 9;
        if (r0 < r1) goto L_0x0031;
    L_0x0006:
        r0 = new android.content.Intent;	 Catch:{ Exception -> 0x002f }
        r1 = "android.settings.APPLICATION_DETAILS_SETTINGS";	 Catch:{ Exception -> 0x002f }
        r0.<init>(r1);	 Catch:{ Exception -> 0x002f }
        r1 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x002f }
        r1.<init>();	 Catch:{ Exception -> 0x002f }
        r2 = "package:";	 Catch:{ Exception -> 0x002f }
        r1.append(r2);	 Catch:{ Exception -> 0x002f }
        r1.append(r4);	 Catch:{ Exception -> 0x002f }
        r4 = r1.toString();	 Catch:{ Exception -> 0x002f }
        r4 = android.net.Uri.parse(r4);	 Catch:{ Exception -> 0x002f }
        r0.setData(r4);	 Catch:{ Exception -> 0x002f }
        r4 = 268435456; // 0x10000000 float:2.5243549E-29 double:1.32624737E-315;	 Catch:{ Exception -> 0x002f }
        r0.setFlags(r4);	 Catch:{ Exception -> 0x002f }
        r3.startActivity(r0);	 Catch:{ Exception -> 0x002f }
        r3 = 1;
        return r3;
    L_0x002f:
        r3 = 0;
        return r3;
    L_0x0031:
        r3 = new java.lang.RuntimeException;
        r4 = "Method requires API level 9 or above";
        r3.<init>(r4);
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.web.AdvancedWebView.openAppSettings(android.content.Context, java.lang.String):boolean");
    }
}
