package com.sherdle.universal.providers.web;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.v7.app.ActionBar.LayoutParams;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.C0361C;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.inherit.BackPressFragment;
import com.sherdle.universal.inherit.CollapseControllingFragment;
import com.sherdle.universal.inherit.ConfigurationChangeFragment;
import com.sherdle.universal.inherit.PermissionsFragment;
import com.sherdle.universal.providers.fav.FavDbAdapter;
import com.sherdle.universal.providers.web.AdvancedWebView.Listener;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.ThemeUtils;
import java.io.Serializable;

public class WebviewFragment extends Fragment implements BackPressFragment, CollapseControllingFragment, Listener, ConfigurationChangeFragment, PermissionsFragment {
    public static final String HIDE_NAVIGATION = "hide_navigation";
    public static final String LOAD_DATA = "loadwithdata";
    private AdvancedWebView browser;
    private FrameLayout ll;
    private Activity mAct;
    private FavDbAdapter mDbHelper;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private ImageButton webBackButton;
    private ImageButton webForwButton;

    /* renamed from: com.sherdle.universal.providers.web.WebviewFragment$1 */
    class C06511 extends WebViewClient {
        C06511() {
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            return handleUri(str);
        }

        @TargetApi(24)
        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            return handleUri(webResourceRequest.getUrl().toString());
        }

        public void onReceivedSslError(WebView webView, final SslErrorHandler sslErrorHandler, SslError sslError) {
            webView = new Builder(WebviewFragment.this.mAct);
            webView.setMessage((int) R.string.notification_error_ssl_cert_invalid);
            webView.setPositiveButton((int) R.string.yes, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    sslErrorHandler.proceed();
                }
            });
            webView.setNegativeButton((int) R.string.cancel, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    sslErrorHandler.cancel();
                }
            });
            webView.create().show();
        }

        boolean handleUri(String str) {
            if (!(str.contains("market://") || str.contains("mailto:") || str.contains("play.google") || str.contains("tel:"))) {
                if (!str.contains("vid:")) {
                    return null;
                }
            }
            WebviewFragment.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
            return true;
        }
    }

    /* renamed from: com.sherdle.universal.providers.web.WebviewFragment$3 */
    class C06523 implements View.OnClickListener {
        C06523() {
        }

        public void onClick(View view) {
            if (WebviewFragment.this.browser.canGoBack() != null) {
                WebviewFragment.this.browser.goBack();
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.web.WebviewFragment$4 */
    class C06534 implements View.OnClickListener {
        C06534() {
        }

        public void onClick(View view) {
            if (WebviewFragment.this.browser.canGoForward() != null) {
                WebviewFragment.this.browser.goForward();
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.web.WebviewFragment$5 */
    class C06545 implements View.OnClickListener {
        C06545() {
        }

        public void onClick(View view) {
            WebviewFragment.this.browser.loadUrl("javascript:document.open();document.close();");
            WebviewFragment.this.browser.reload();
        }
    }

    /* renamed from: com.sherdle.universal.providers.web.WebviewFragment$2 */
    class C09982 implements OnRefreshListener {
        C09982() {
        }

        public void onRefresh() {
            WebviewFragment.this.browser.reload();
        }
    }

    public boolean dynamicToolbarElevation() {
        return false;
    }

    public void onExternalPageRequest(String str) {
    }

    public boolean supportsCollapse() {
        return false;
    }

    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreateView(layoutInflater, viewGroup, bundle);
        this.ll = (FrameLayout) layoutInflater.inflate(R.layout.fragment_webview, viewGroup, false);
        setHasOptionsMenu(true);
        this.browser = (AdvancedWebView) this.ll.findViewById(R.id.webView);
        this.mSwipeRefreshLayout = (SwipeRefreshLayout) this.ll.findViewById(R.id.refreshlayout);
        this.browser.setListener(getActivity(), (Listener) this);
        this.browser.setGeolocationEnabled(false);
        this.browser.setWebViewClient(new C06511());
        this.mSwipeRefreshLayout.setOnRefreshListener(new C09982());
        return this.ll;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        setRetainInstance(true);
        this.browser.setWebChromeClient(new FullscreenableChromeClient(this.mAct));
        String str = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        Bundle string = getArguments().containsKey(LOAD_DATA) != null ? getArguments().getString(LOAD_DATA) : null;
        if (string != null) {
            this.browser.loadDataWithBaseURL(str, string, "text/html", C0361C.UTF8_NAME, "");
        } else {
            this.browser.loadUrl(str);
        }
    }

    public void onPause() {
        super.onPause();
        AdvancedWebView advancedWebView = this.browser;
        if (advancedWebView != null) {
            advancedWebView.onPause();
        }
        if (isMenuVisible() || getUserVisibleHint()) {
            setMenuVisibility(false);
        }
    }

    public void setMenuVisibility(boolean z) {
        super.setMenuVisibility(z);
        if (this.mAct != null) {
            if (z) {
                if (navigationIsVisible()) {
                    z = ((AppCompatActivity) this.mAct).getSupportActionBar();
                    if (z) {
                        if (this.mAct instanceof HolderActivity) {
                            z.setDisplayOptions(30);
                        } else {
                            z.setDisplayOptions(26);
                        }
                        z.setCustomView(this.mAct.getLayoutInflater().inflate(R.layout.fragment_webview_actionbar, null), new LayoutParams(-2, -2, 8388629));
                        this.webBackButton = (ImageButton) this.mAct.findViewById(R.id.goBack);
                        this.webForwButton = (ImageButton) this.mAct.findViewById(R.id.goForward);
                        this.webBackButton.setOnClickListener(new C06523());
                        this.webForwButton.setOnClickListener(new C06534());
                    }
                }
            } else if (navigationIsVisible() && getActivity()) {
                ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayOptions(10);
            }
        }
    }

    @SuppressLint({"RestrictedApi"})
    public void onResume() {
        super.onResume();
        AdvancedWebView advancedWebView = this.browser;
        if (advancedWebView != null) {
            advancedWebView.onResume();
        } else {
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
        if (getArguments().containsKey(HIDE_NAVIGATION) && getArguments().getBoolean(HIDE_NAVIGATION)) {
            this.mSwipeRefreshLayout.setEnabled(false);
        }
        if (isMenuVisible() || getUserVisibleHint()) {
            setMenuVisibility(true);
        }
        adjustControls();
    }

    public void onDestroyView() {
        super.onDestroyView();
        this.browser.onDestroy();
    }

    public void onHiddenChanged(boolean z) {
        super.onHiddenChanged(z);
        if (!z) {
            setMenuVisibility(true);
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.favorite) {
            this.mDbHelper = new FavDbAdapter(this.mAct);
            this.mDbHelper.open();
            menuItem = this.browser.getTitle();
            Serializable url = this.browser.getUrl();
            if (this.mDbHelper.checkEvent(menuItem, url, 3)) {
                this.mDbHelper.addFavorite(menuItem, url, 3);
                Toast.makeText(this.mAct, getResources().getString(R.string.favorite_success), 1).show();
            } else {
                Toast.makeText(this.mAct, getResources().getString(R.string.favorite_duplicate), 1).show();
            }
            return true;
        } else if (itemId != R.id.share) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            shareURL();
            return true;
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        if (!(getArguments().containsKey(HIDE_NAVIGATION) && getArguments().getBoolean(HIDE_NAVIGATION))) {
            menuInflater.inflate(R.menu.webview_menu, menu);
        }
        if (!(this.browser.getUrl() == null || this.browser.getUrl().startsWith("file:///android_asset/") == null)) {
            menu.findItem(R.id.share).setVisible(false);
        }
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    private boolean hasConnectivity() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) this.mAct.getSystemService("connectivity")).getActiveNetworkInfo();
        if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
            if (activeNetworkInfo.isAvailable()) {
                return true;
            }
        }
        return false;
    }

    public void adjustControls() {
        this.webBackButton = (ImageButton) this.mAct.findViewById(R.id.goBack);
        this.webForwButton = (ImageButton) this.mAct.findViewById(R.id.goForward);
        if (!(this.webBackButton == null || this.webForwButton == null)) {
            if (this.browser != null) {
                if (ThemeUtils.lightToolbarThemeActive(this.mAct)) {
                    this.webBackButton.setColorFilter(ViewCompat.MEASURED_STATE_MASK);
                    this.webForwButton.setColorFilter(ViewCompat.MEASURED_STATE_MASK);
                }
                float f = 1.0f;
                this.webBackButton.setAlpha(this.browser.canGoBack() ? 1.0f : 0.5f);
                ImageButton imageButton = this.webForwButton;
                if (!this.browser.canGoForward()) {
                    f = 0.5f;
                }
                imageButton.setAlpha(f);
            }
        }
    }

    private void shareURL() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        String string = getString(R.string.app_name);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getResources().getString(R.string.web_share_begin));
        stringBuilder.append(string);
        stringBuilder.append(getResources().getString(R.string.web_share_end));
        stringBuilder.append(this.browser.getUrl());
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        startActivity(Intent.createChooser(intent, getResources().getString(R.string.share)));
    }

    public boolean handleBackPress() {
        return this.browser.onBackPressed() ^ 1;
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        this.browser.onActivityResult(i, i2, intent);
    }

    public boolean navigationIsVisible() {
        if (getArguments().containsKey(HIDE_NAVIGATION)) {
            if (getArguments().getBoolean(HIDE_NAVIGATION)) {
                return false;
            }
        }
        return true;
    }

    public void onPageStarted(String str, Bitmap bitmap) {
        if (navigationIsVisible() != null) {
            this.mSwipeRefreshLayout.setRefreshing(true);
        }
    }

    public void onPageFinished(String str) {
        if (this.mSwipeRefreshLayout.isRefreshing() != null) {
            this.mSwipeRefreshLayout.setRefreshing(false);
        }
        adjustControls();
        hideErrorScreen();
    }

    public void onPageError(int i, String str, String str2) {
        if (this.mSwipeRefreshLayout.isRefreshing() != 0) {
            this.mSwipeRefreshLayout.setRefreshing(null);
        }
        if (str2.startsWith("file:///android_asset/") != 0) {
            return;
        }
        if (hasConnectivity() == 0) {
            showErrorScreen();
        }
    }

    public void onDownloadRequested(String str, String str2, String str3, long j, String str4, String str5) {
        if (Helper.hasPermissionToDownload(getActivity()) != null) {
            if (AdvancedWebView.handleDownload(this.mAct, str, str2) == null) {
                Toast.makeText(this.mAct, R.string.download_failed, null).show();
            }
        }
    }

    public String[] requiredPermissions() {
        return new String[0];
    }

    public void showErrorScreen() {
        View findViewById = this.ll.findViewById(R.id.empty_view);
        findViewById.setVisibility(0);
        findViewById.findViewById(R.id.retry_button).setOnClickListener(new C06545());
    }

    public void hideErrorScreen() {
        View findViewById = this.ll.findViewById(R.id.empty_view);
        if (findViewById.getVisibility() == 0) {
            findViewById.setVisibility(8);
        }
    }
}
