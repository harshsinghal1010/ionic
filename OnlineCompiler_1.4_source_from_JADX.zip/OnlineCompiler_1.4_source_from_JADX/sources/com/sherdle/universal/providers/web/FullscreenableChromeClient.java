package com.sherdle.universal.providers.web;

import android.app.Activity;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.CustomViewCallback;
import android.webkit.WebView;
import android.webkit.WebView.WebViewTransport;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import com.sherdle.universal.util.ThemeUtils;

public class FullscreenableChromeClient extends WebChromeClient {
    private static final LayoutParams COVER_SCREEN_PARAMS = new LayoutParams(-1, -1);
    private Activity mActivity = null;
    private View mCustomView;
    private CustomViewCallback mCustomViewCallback;
    private FrameLayout mFullscreenContainer;
    private int mOriginalOrientation;

    private static class FullscreenHolder extends FrameLayout {
        public boolean onTouchEvent(MotionEvent motionEvent) {
            return true;
        }

        public FullscreenHolder(Context context) {
            super(context);
            setBackgroundColor(ContextCompat.getColor(context, 17170444));
        }
    }

    public FullscreenableChromeClient(Activity activity) {
        this.mActivity = activity;
    }

    public void onShowCustomView(View view, CustomViewCallback customViewCallback) {
        if (VERSION.SDK_INT >= 14) {
            if (this.mCustomView != null) {
                customViewCallback.onCustomViewHidden();
                return;
            }
            this.mOriginalOrientation = this.mActivity.getRequestedOrientation();
            FrameLayout frameLayout = (FrameLayout) this.mActivity.getWindow().getDecorView();
            this.mFullscreenContainer = new FullscreenHolder(this.mActivity);
            this.mFullscreenContainer.addView(view, COVER_SCREEN_PARAMS);
            frameLayout.addView(this.mFullscreenContainer, COVER_SCREEN_PARAMS);
            this.mCustomView = view;
            setFullscreen(true);
            this.mCustomViewCallback = customViewCallback;
        }
        super.onShowCustomView(view, customViewCallback);
    }

    public void onShowCustomView(View view, int i, CustomViewCallback customViewCallback) {
        onShowCustomView(view, customViewCallback);
    }

    public void onHideCustomView() {
        if (this.mCustomView != null) {
            setFullscreen(false);
            FrameLayout frameLayout = (FrameLayout) this.mActivity.getWindow().getDecorView();
            frameLayout.removeView(this.mFullscreenContainer);
            this.mFullscreenContainer = null;
            this.mCustomView = null;
            this.mCustomViewCallback.onCustomViewHidden();
            this.mActivity.setRequestedOrientation(this.mOriginalOrientation);
            if (VERSION.SDK_INT >= 23 && ThemeUtils.lightToolbarThemeActive(this.mActivity)) {
                frameLayout.setSystemUiVisibility(frameLayout.getSystemUiVisibility() | 8192);
            }
        }
    }

    public boolean onCreateWindow(WebView webView, boolean z, boolean z2, Message message) {
        ((WebViewTransport) message.obj).setWebView(new AdvancedWebView(this.mActivity));
        message.sendToTarget();
        return true;
    }

    private void setFullscreen(boolean z) {
        Window window = this.mActivity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags |= 1024;
            this.mActivity.getWindow().getDecorView().setSystemUiVisibility(3846);
        } else {
            attributes.flags &= -1025;
            z = this.mCustomView;
            if (z) {
                z.setSystemUiVisibility(0);
            }
            this.mActivity.getWindow().getDecorView().setSystemUiVisibility(256);
        }
        window.setAttributes(attributes);
    }
}
