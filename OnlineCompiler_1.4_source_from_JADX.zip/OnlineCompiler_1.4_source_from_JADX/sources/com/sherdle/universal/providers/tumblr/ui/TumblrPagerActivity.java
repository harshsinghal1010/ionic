package com.sherdle.universal.providers.tumblr.ui;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.provider.MediaStore.Images.Media;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.tumblr.TumblrItem;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import uk.co.senab.photoview.PhotoViewAttacher;

public class TumblrPagerActivity extends Activity {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final String STATE_POSITION = "STATE_POSITION";
    ViewPager imagePager;

    private class ImagePagerAdapter extends PagerAdapter {
        static final /* synthetic */ boolean $assertionsDisabled = false;
        private ArrayList<TumblrItem> images;
        private LayoutInflater inflater;

        public void restoreState(Parcelable parcelable, ClassLoader classLoader) {
        }

        public Parcelable saveState() {
            return null;
        }

        static {
            Class cls = TumblrPagerActivity.class;
        }

        ImagePagerAdapter(ArrayList<TumblrItem> arrayList) {
            this.images = arrayList;
            this.inflater = TumblrPagerActivity.this.getLayoutInflater();
        }

        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            viewGroup.removeView((View) obj);
        }

        public int getCount() {
            return this.images.size();
        }

        public Object instantiateItem(ViewGroup viewGroup, int i) {
            View inflate = this.inflater.inflate(R.layout.activity_tumblr_pager_image, viewGroup, false);
            final ImageView imageView = (ImageView) inflate.findViewById(R.id.image);
            final Button button = (Button) inflate.findViewById(R.id.btnShare);
            Button button2 = (Button) inflate.findViewById(R.id.btnSet);
            final Button button3 = (Button) inflate.findViewById(R.id.btnSave);
            final ProgressBar progressBar = (ProgressBar) inflate.findViewById(R.id.loading);
            progressBar.setVisibility(0);
            final ImageView imageView2 = imageView;
            final int i2 = i;
            Picasso.get().load(((TumblrItem) this.images.get(i)).getUrl()).into(imageView, new Callback() {

                /* renamed from: com.sherdle.universal.providers.tumblr.ui.TumblrPagerActivity$ImagePagerAdapter$1$1 */
                class C06371 implements OnClickListener {
                    C06371() {
                    }

                    public void onClick(View view) {
                        view = Environment.getExternalStorageDirectory().toString();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("tumblr_");
                        stringBuilder.append(((TumblrItem) ImagePagerAdapter.this.images.get(i2)).getId());
                        stringBuilder.append(".jpg");
                        File file = new File(view, stringBuilder.toString());
                        try {
                            view = new FileOutputStream(file);
                            ((BitmapDrawable) imageView2.getDrawable()).getBitmap().compress(CompressFormat.JPEG, 99, view);
                            view.flush();
                            view.close();
                            Media.insertImage(TumblrPagerActivity.this.getContentResolver(), file.getAbsolutePath(), file.getName(), file.getName());
                            view = TumblrPagerActivity.this.getResources().getString(R.string.saved);
                            Context baseContext = TumblrPagerActivity.this.getBaseContext();
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(view);
                            stringBuilder2.append(" ");
                            stringBuilder2.append(file.toString());
                            Toast.makeText(baseContext, stringBuilder2.toString(), 1).show();
                        } catch (View view2) {
                            Log.printStackTrace(view2);
                        } catch (View view22) {
                            Log.printStackTrace(view22);
                        }
                    }
                }

                /* renamed from: com.sherdle.universal.providers.tumblr.ui.TumblrPagerActivity$ImagePagerAdapter$1$2 */
                class C06382 implements OnClickListener {
                    C06382() {
                    }

                    public void onClick(View view) {
                        view = TumblrPagerActivity.this.getResources().getString(R.string.tumblr_share_begin);
                        String string = TumblrPagerActivity.this.getResources().getString(R.string.app_name);
                        Intent intent = new Intent();
                        intent.setType("text/plain");
                        intent.setAction("android.intent.action.SEND");
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(view);
                        stringBuilder.append(" ");
                        stringBuilder.append(string);
                        stringBuilder.append(": ");
                        stringBuilder.append(((TumblrItem) ImagePagerAdapter.this.images.get(i2)).getLink());
                        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                        TumblrPagerActivity.this.startActivity(Intent.createChooser(intent, "Share"));
                    }
                }

                public void onSuccess() {
                    progressBar.setVisibility(8);
                    PhotoViewAttacher photoViewAttacher = new PhotoViewAttacher(imageView2);
                    button3.setOnClickListener(new C06371());
                    button.setOnClickListener(new C06382());
                }

                public void onError(Exception exception) {
                    progressBar.setVisibility(8);
                }
            });
            button2.setOnClickListener(new OnClickListener() {

                /* renamed from: com.sherdle.universal.providers.tumblr.ui.TumblrPagerActivity$ImagePagerAdapter$2$1 */
                class C06391 implements DialogInterface.OnClickListener {
                    C06391() {
                    }

                    public void onClick(DialogInterface dialogInterface, int i) {
                        try {
                            WallpaperManager.getInstance(TumblrPagerActivity.this).setBitmap(((BitmapDrawable) imageView.getDrawable()).getBitmap());
                            Toast.makeText(TumblrPagerActivity.this, TumblrPagerActivity.this.getResources().getString(R.string.set_success), 0).show();
                        } catch (DialogInterface dialogInterface2) {
                            Log.printStackTrace(dialogInterface2);
                            Log.m161v("ERROR", "Wallpaper not set");
                        }
                    }
                }

                public void onClick(View view) {
                    view = new Builder(TumblrPagerActivity.this);
                    view.setMessage(TumblrPagerActivity.this.getResources().getString(R.string.set_confirm)).setCancelable(true).setPositiveButton(TumblrPagerActivity.this.getResources().getString(R.string.yes), new C06391());
                    view.create().show();
                }
            });
            viewGroup.addView(inflate, 0);
            return inflate;
        }

        public boolean isViewFromObject(View view, Object obj) {
            return view.equals(obj);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_tumblr_pager);
        Bundle extras = getIntent().getExtras();
        ArrayList parcelableArrayList = extras.getParcelableArrayList("com.nostra13.example.universalimageloader.IMAGES");
        int i = extras.getInt("com.nostra13.example.universalimageloader.IMAGE_POSITION", 0);
        if (bundle != null) {
            i = bundle.getInt(STATE_POSITION);
        }
        this.imagePager = (ViewPager) findViewById(R.id.pager);
        if (parcelableArrayList != null) {
            this.imagePager.setAdapter(new ImagePagerAdapter(parcelableArrayList));
            this.imagePager.setCurrentItem(i);
        }
        Helper.admobLoader(this, findViewById(R.id.adView));
    }

    public void onSaveInstanceState(Bundle bundle) {
        bundle.putInt(STATE_POSITION, this.imagePager.getCurrentItem());
    }
}
