package com.sherdle.universal.providers.tumblr.ui;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.inherit.PermissionsFragment;
import com.sherdle.universal.providers.tumblr.ImageAdapter;
import com.sherdle.universal.providers.tumblr.TumblrItem;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import com.sherdle.universal.util.layout.StaggeredGridSpacingItemDecoration;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TumblrFragment extends Fragment implements PermissionsFragment, LoadMoreListener {
    String baseurl;
    Integer curpage = Integer.valueOf(0);
    private ImageAdapter imageAdapter = null;
    Boolean isLoading = Boolean.valueOf(true);
    private RecyclerView listView;
    private RelativeLayout ll;
    private Activity mAct;
    String perpage = "25";
    Integer total_posts;
    ArrayList<TumblrItem> tumblrItems;

    private class InitialLoadGridView extends AsyncTask<String, Void, ArrayList<TumblrItem>> {
        private InitialLoadGridView() {
        }

        protected ArrayList<TumblrItem> doInBackground(String... strArr) {
            strArr = strArr[0];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(strArr);
            stringBuilder.append(Integer.toString(TumblrFragment.this.curpage.intValue() * Integer.parseInt(TumblrFragment.this.perpage)));
            strArr = stringBuilder.toString();
            TumblrFragment tumblrFragment = TumblrFragment.this;
            tumblrFragment.curpage = Integer.valueOf(tumblrFragment.curpage.intValue() + 1);
            strArr = Helper.getDataFromUrl(strArr);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Tumblr JSON: ");
            stringBuilder2.append(strArr);
            Log.m161v("INFO", stringBuilder2.toString());
            ArrayList<TumblrItem> arrayList = null;
            try {
                strArr = new JSONObject(strArr).getJSONObject("response");
            } catch (String[] strArr2) {
                Log.printStackTrace(strArr2);
                strArr2 = null;
            }
            try {
                TumblrFragment.this.total_posts = Integer.valueOf(strArr2.getInt("total_posts"));
                if (TumblrFragment.this.total_posts.intValue() > 0) {
                    strArr2 = strArr2.getJSONArray("posts");
                    ArrayList<TumblrItem> arrayList2 = new ArrayList();
                    int i = 0;
                    while (i < strArr2.length()) {
                        try {
                            JSONObject jSONObject = strArr2.getJSONObject(i);
                            String string = jSONObject.getString(TtmlNode.ATTR_ID);
                            String string2 = jSONObject.getString("post_url");
                            JSONArray jSONArray = jSONObject.getJSONArray("photos");
                            String string3 = jSONArray.length() > 0 ? ((JSONObject) jSONArray.get(0)).getJSONObject("original_size").getString("url") : null;
                            if (string3 != null) {
                                arrayList2.add(new TumblrItem(string, string2, string3));
                            }
                            i++;
                        } catch (JSONException e) {
                            strArr2 = e;
                            arrayList = arrayList2;
                        } catch (NullPointerException e2) {
                            strArr2 = e2;
                            arrayList = arrayList2;
                        }
                    }
                    return arrayList2;
                }
                Log.m161v("INFO", "No items found");
                return null;
            } catch (JSONException e3) {
                strArr2 = e3;
                Log.printStackTrace(strArr2);
                return arrayList;
            } catch (NullPointerException e4) {
                strArr2 = e4;
                Log.printStackTrace(strArr2);
                return arrayList;
            }
        }

        protected void onPostExecute(ArrayList<TumblrItem> arrayList) {
            if (arrayList != null) {
                TumblrFragment.this.updateList(arrayList);
            } else {
                Helper.noConnection(TumblrFragment.this.mAct);
                TumblrFragment.this.imageAdapter.setModeAndNotify(2);
            }
            TumblrFragment.this.isLoading = Boolean.valueOf(false);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list, viewGroup, false);
        return this.ll;
    }

    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        setHasOptionsMenu(true);
        bundle = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("https://api.tumblr.com/v2/blog/");
        stringBuilder.append(bundle);
        stringBuilder.append(".tumblr.com/posts?api_key=");
        stringBuilder.append(getString(R.string.tumblr_key));
        stringBuilder.append("&type=photo&limit=");
        stringBuilder.append(this.perpage);
        stringBuilder.append("&offset=");
        this.baseurl = stringBuilder.toString();
        this.listView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.tumblrItems = new ArrayList();
        this.imageAdapter = new ImageAdapter(getContext(), this.tumblrItems, this);
        this.imageAdapter.setModeAndNotify(3);
        this.listView.setAdapter(this.imageAdapter);
        this.listView.setLayoutManager(new StaggeredGridLayoutManager(3, 1));
        this.listView.setItemAnimator(new DefaultItemAnimator());
        this.listView.addItemDecoration(new StaggeredGridSpacingItemDecoration((int) getResources().getDimension(R.dimen.woocommerce_padding), true));
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        refreshItems();
    }

    public void updateList(ArrayList<TumblrItem> arrayList) {
        if (arrayList.size() > 0) {
            this.tumblrItems.addAll(arrayList);
        }
        if (this.curpage.intValue() * Integer.parseInt(this.perpage) > this.total_posts.intValue() || arrayList.size() == null) {
            this.imageAdapter.setHasMore(false);
        }
        this.imageAdapter.setModeAndNotify(1);
    }

    public String[] requiredPermissions() {
        return new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    }

    public void onMoreRequested() {
        if (!this.isLoading.booleanValue() && this.curpage.intValue() * Integer.parseInt(this.perpage) <= this.total_posts.intValue()) {
            this.isLoading = Boolean.valueOf(true);
            new InitialLoadGridView().execute(new String[]{this.baseurl});
        }
    }

    void refreshItems() {
        this.isLoading = Boolean.valueOf(true);
        this.curpage = Integer.valueOf(0);
        this.tumblrItems.clear();
        this.imageAdapter.setHasMore(true);
        this.imageAdapter.setModeAndNotify(3);
        new InitialLoadGridView().execute(new String[]{this.baseurl});
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.refresh_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.refresh) {
            if (this.isLoading.booleanValue()) {
                Toast.makeText(this.mAct, getString(R.string.already_loading), 1).show();
            } else {
                refreshItems();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
