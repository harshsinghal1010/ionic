package com.sherdle.universal.providers.tumblr;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class TumblrItem implements Parcelable {
    public static final Creator<TumblrItem> CREATOR = new C06351();
    protected String id;
    protected String link;
    protected String url;

    /* renamed from: com.sherdle.universal.providers.tumblr.TumblrItem$1 */
    static class C06351 implements Creator<TumblrItem> {
        C06351() {
        }

        public TumblrItem createFromParcel(Parcel parcel) {
            return new TumblrItem(parcel);
        }

        public TumblrItem[] newArray(int i) {
            return new TumblrItem[i];
        }
    }

    public TumblrItem(String str, String str2, String str3) {
        this.id = str;
        this.link = str2;
        this.url = str3;
    }

    public String getUrl() {
        return this.url;
    }

    public String getId() {
        return this.id;
    }

    public String getLink() {
        return this.link;
    }

    public TumblrItem(Parcel parcel) {
        this.id = parcel.readString();
        this.link = parcel.readString();
        this.url = parcel.readString();
    }

    public int describeContents() {
        return hashCode();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.id);
        parcel.writeString(this.link);
        parcel.writeString(this.url);
    }
}
