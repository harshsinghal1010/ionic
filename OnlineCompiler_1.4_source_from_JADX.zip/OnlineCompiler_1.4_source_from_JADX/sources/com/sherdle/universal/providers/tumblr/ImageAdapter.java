package com.sherdle.universal.providers.tumblr;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.tumblr.ui.TumblrPagerActivity;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class ImageAdapter extends InfiniteRecyclerViewAdapter {
    private ArrayList<TumblrItem> listData;
    private Context mContext;

    private static class ItemViewHolder extends ViewHolder {
        ImageView imageView;

        private ItemViewHolder(View view) {
            super(view);
            this.imageView = (ImageView) view.findViewById(R.id.image);
        }
    }

    public long getItemId(int i) {
        return (long) i;
    }

    protected int getViewType(int i) {
        return 0;
    }

    public ImageAdapter(Context context, ArrayList<TumblrItem> arrayList, LoadMoreListener loadMoreListener) {
        super(context, loadMoreListener);
        this.listData = arrayList;
        this.mContext = context;
    }

    protected ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        return new ItemViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_tumblr_row, viewGroup, false));
    }

    protected void doBindViewHolder(ViewHolder viewHolder, final int i) {
        if (viewHolder instanceof ItemViewHolder) {
            Picasso.get().load(((TumblrItem) this.listData.get(i)).getUrl()).placeholder((int) R.drawable.placeholder).fit().centerCrop().into(((ItemViewHolder) viewHolder).imageView);
            viewHolder.itemView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ImageAdapter.this.startImagePagerActivity(i);
                }
            });
        }
    }

    public int getCount() {
        return this.listData.size();
    }

    private void startImagePagerActivity(int i) {
        Intent intent = new Intent(this.mContext, TumblrPagerActivity.class);
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < getCount(); i2++) {
            arrayList.add(this.listData.get(i2));
        }
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("com.nostra13.example.universalimageloader.IMAGES", arrayList);
        intent.putExtras(bundle);
        intent.putExtra("com.nostra13.example.universalimageloader.IMAGE_POSITION", i);
        this.mContext.startActivity(intent);
    }
}
