package com.sherdle.universal.providers.wordpress.ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.format.DateUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewStub;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.C0361C;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentActivity;
import com.sherdle.universal.comments.CommentsActivity;
import com.sherdle.universal.providers.fav.FavDbAdapter;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.PostItem.PostType;
import com.sherdle.universal.providers.wordpress.WordpressListAdapter;
import com.sherdle.universal.providers.wordpress.api.JsonApiPostLoader;
import com.sherdle.universal.providers.wordpress.api.JsonApiPostLoader.BackgroundPostCompleterListener;
import com.sherdle.universal.providers.wordpress.api.RestApiPostLoader;
import com.sherdle.universal.providers.wordpress.api.WordpressGetTaskInfo;
import com.sherdle.universal.providers.wordpress.api.WordpressGetTaskInfo.ListListener;
import com.sherdle.universal.providers.wordpress.api.WordpressPostsLoader;
import com.sherdle.universal.providers.wordpress.api.providers.JetPackProvider;
import com.sherdle.universal.providers.wordpress.api.providers.RestApiProvider;
import com.sherdle.universal.util.DetailActivity;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.WebHelper;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.Iterator;
import org.jsoup.Jsoup;

public class WordpressDetailActivity extends DetailActivity implements BackgroundPostCompleterListener {
    public static final String EXTRA_API_BASE = "apiurl";
    public static final String EXTRA_DISQUS = "disqus";
    public static final String EXTRA_POSTITEM = "postitem";
    public static final boolean PRELOAD_POSTS = true;
    private static final boolean REMOVE_FIRST_IMG = true;
    private String apiBase;
    private String disqusParseable;
    private WebView htmlTextView;
    private FavDbAdapter mDbHelper;
    private TextView mTitle;
    private PostItem post;

    /* renamed from: com.sherdle.universal.providers.wordpress.ui.WordpressDetailActivity$1 */
    class C06961 extends WebViewClient {
        C06961() {
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            if (str == null || !(str.endsWith(".png") || str.endsWith(".jpg") || str.endsWith(".jpeg"))) {
                boolean z = false;
                if (str == null || !(str.startsWith("http://") || str.startsWith("https://"))) {
                    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
                    if (WordpressDetailActivity.this.getPackageManager().queryIntentActivities(intent, 0).size() > null) {
                        z = true;
                    }
                    if (z) {
                        WordpressDetailActivity.this.startActivity(intent);
                    }
                    return true;
                }
                HolderActivity.startWebViewActivity(WordpressDetailActivity.this, str, false, false, null);
                return true;
            }
            AttachmentActivity.startActivity(WordpressDetailActivity.this, MediaAttachment.withImage(str));
            return true;
        }
    }

    /* renamed from: com.sherdle.universal.providers.wordpress.ui.WordpressDetailActivity$2 */
    class C06972 implements OnClickListener {
        C06972() {
        }

        public void onClick(View view) {
            Context context = WordpressDetailActivity.this;
            AttachmentActivity.startActivity(context, context.post.getAttachments());
        }
    }

    /* renamed from: com.sherdle.universal.providers.wordpress.ui.WordpressDetailActivity$3 */
    class C06983 implements OnClickListener {
        C06983() {
        }

        public void onClick(View view) {
            if (WordpressDetailActivity.this.post.getAttachments() != null) {
                view = WordpressDetailActivity.this.post.getImageCandidate();
                ArrayList arrayList = new ArrayList();
                Iterator it = WordpressDetailActivity.this.post.getAttachments().iterator();
                Object obj = null;
                while (it.hasNext()) {
                    MediaAttachment mediaAttachment = (MediaAttachment) it.next();
                    if (!view.equals(mediaAttachment.getUrl())) {
                        if (!view.equals(mediaAttachment.getThumbnailUrl())) {
                            arrayList.add(mediaAttachment);
                        }
                    }
                    arrayList.add(0, mediaAttachment);
                    obj = 1;
                }
                if (obj == null) {
                    arrayList.add(0, MediaAttachment.withImage(view));
                }
                AttachmentActivity.startActivity(WordpressDetailActivity.this, arrayList);
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.wordpress.ui.WordpressDetailActivity$4 */
    class C06994 implements OnTouchListener {
        C06994() {
        }

        @SuppressLint({"ClickableViewAccessibility"})
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return (WordpressDetailActivity.this.findViewById(R.id.progressBar).getVisibility() != null || VERSION.SDK_INT > 16) ? null : true;
        }
    }

    /* renamed from: com.sherdle.universal.providers.wordpress.ui.WordpressDetailActivity$5 */
    class C07005 implements OnClickListener {
        C07005() {
        }

        public void onClick(View view) {
            view = WordpressDetailActivity.this;
            view.mDbHelper = new FavDbAdapter(view);
            WordpressDetailActivity.this.mDbHelper.open();
            if (WordpressDetailActivity.this.mDbHelper.checkEvent(WordpressDetailActivity.this.post.getTitle(), WordpressDetailActivity.this.post, 1) != null) {
                WordpressDetailActivity.this.mDbHelper.addFavorite(WordpressDetailActivity.this.post.getTitle(), WordpressDetailActivity.this.post, 1);
                view = WordpressDetailActivity.this;
                Toast.makeText(view, view.getResources().getString(R.string.favorite_success), 1).show();
                return;
            }
            view = WordpressDetailActivity.this;
            Toast.makeText(view, view.getResources().getString(R.string.favorite_duplicate), 1).show();
        }
    }

    /* renamed from: com.sherdle.universal.providers.wordpress.ui.WordpressDetailActivity$6 */
    class C10136 implements ListListener {
        C10136() {
        }

        public void completedWithPosts() {
            WordpressDetailActivity.this.findViewById(R.id.related).setVisibility(0);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_details);
        ViewStub viewStub = (ViewStub) findViewById(R.id.layout_stub);
        viewStub.setLayoutResource(R.layout.activity_wordpress_details);
        viewStub.inflate();
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.thumb = (ImageView) findViewById(R.id.image);
        this.coolblue = (RelativeLayout) findViewById(R.id.coolblue);
        this.mTitle = (TextView) findViewById(R.id.title);
        TextView textView = (TextView) findViewById(R.id.dateauthorview);
        Bundle extras = getIntent().getExtras();
        this.post = (PostItem) getIntent().getSerializableExtra("postitem");
        this.disqusParseable = getIntent().getStringExtra(EXTRA_DISQUS);
        this.apiBase = getIntent().getStringExtra(EXTRA_API_BASE);
        PostItem postItem = this.post;
        if (postItem != null && extras != null) {
            CharSequence stringBuilder;
            if (postItem.getDate() != null) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(getResources().getString(R.string.wordpress_subtitle_start));
                stringBuilder2.append(DateUtils.getRelativeDateTimeString(this, this.post.getDate().getTime(), 1000, 604800000, 524288));
                stringBuilder2.append(getResources().getString(R.string.wordpress_subtitle_end));
                stringBuilder2.append(this.post.getAuthor());
                stringBuilder = stringBuilder2.toString();
            } else {
                stringBuilder = this.post.getAuthor();
            }
            this.mTitle.setText(this.post.getTitle());
            textView.setText(stringBuilder);
            loadHeaderImage();
            configureFAB();
            setUpHeader(this.post.getImageCandidate());
            Helper.admobLoader(this, findViewById(R.id.adView));
            configureContentWebView();
            if (this.post.getPostType() == PostType.JSON && this.post.isCompleted() == null) {
                new JsonApiPostLoader(this.post, getIntent().getStringExtra(EXTRA_API_BASE), this).start();
            } else if (this.post.getPostType() == PostType.REST && this.post.isCompleted() == null) {
                new RestApiPostLoader(this.post, getIntent().getStringExtra(EXTRA_API_BASE), this).start();
                loadPostBody(this.post);
            } else {
                loadPostBody(this.post);
            }
            configureFavoritesButton();
            loadRelatedPosts();
        }
    }

    private void configureContentWebView() {
        this.htmlTextView = (WebView) findViewById(R.id.htmlTextView);
        this.htmlTextView.getSettings().setJavaScriptEnabled(true);
        this.htmlTextView.setBackgroundColor(0);
        this.htmlTextView.getSettings().setDefaultFontSize(WebHelper.getWebViewFontSize(this));
        this.htmlTextView.getSettings().setCacheMode(2);
        this.htmlTextView.setWebViewClient(new C06961());
    }

    private void configureFAB() {
        String imageCandidate = this.post.getImageCandidate();
        if (!(imageCandidate == null || imageCandidate.equals(""))) {
            boolean equals = imageCandidate.equals("null");
        }
        if (this.post.getAttachments() != null) {
            this.post.getAttachments().size();
        }
    }

    private void loadHeaderImage() {
        String imageCandidate = this.post.getImageCandidate();
        if (imageCandidate != null && !imageCandidate.equals("") && !imageCandidate.equals("null")) {
            Picasso.get().load(imageCandidate).fit().centerCrop().into(this.thumb);
            this.thumb.setOnClickListener(new C06983());
            findViewById(R.id.scroller).setOnTouchListener(new C06994());
        }
    }

    private void configureFavoritesButton() {
        ((Button) findViewById(R.id.favorite)).setOnClickListener(new C07005());
    }

    private void loadRelatedPosts() {
        if (this.post.getTag() != null && getIntent().getStringExtra(EXTRA_API_BASE) != null) {
            RecyclerView recyclerView = (RecyclerView) findViewById(R.id.related_list);
            final WordpressGetTaskInfo wordpressGetTaskInfo = new WordpressGetTaskInfo(recyclerView, this, getIntent().getStringExtra(EXTRA_API_BASE), Boolean.valueOf(true));
            wordpressGetTaskInfo.ignoreId = this.post.getId();
            wordpressGetTaskInfo.setListener(new C10136());
            wordpressGetTaskInfo.adapter = new WordpressListAdapter(this, wordpressGetTaskInfo.posts, null, new OnItemClickListener() {
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    PostItem postItem = (PostItem) wordpressGetTaskInfo.posts.get(i);
                    view = new Intent(WordpressDetailActivity.this, WordpressDetailActivity.class);
                    view.putExtra("postitem", postItem);
                    view.putExtra(WordpressDetailActivity.EXTRA_API_BASE, WordpressDetailActivity.this.getIntent().getStringExtra(WordpressDetailActivity.EXTRA_API_BASE));
                    if (WordpressDetailActivity.this.disqusParseable != null) {
                        view.putExtra(WordpressDetailActivity.EXTRA_DISQUS, WordpressDetailActivity.this.disqusParseable);
                    }
                    WordpressDetailActivity.this.startActivity(view);
                    WordpressDetailActivity.this.finish();
                }
            }, wordpressGetTaskInfo.simpleMode.booleanValue());
            recyclerView.setAdapter(wordpressGetTaskInfo.adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, 1, false));
            WordpressPostsLoader.getTagPosts(wordpressGetTaskInfo, this.post.getTag());
        }
    }

    public void onPause() {
        super.onPause();
        this.htmlTextView.onPause();
    }

    public void onResume() {
        super.onResume();
        WebView webView = this.htmlTextView;
        if (webView != null) {
            webView.onResume();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.wordpress_detail_menu, menu);
        onMenuItemsSet(menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId != 16908332) {
            switch (itemId) {
                case R.id.menu_share:
                    shareContent();
                    return true;
                case R.id.menu_view:
                    HolderActivity.startWebViewActivity(this, this.post.getUrl(), true, false, null);
                    return true;
                default:
                    return super.onOptionsItemSelected(menuItem);
            }
        }
        finish();
        return true;
    }

    private void shareContent() {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.post.getTitle());
        stringBuilder.append("\n");
        stringBuilder.append(this.post.getUrl());
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        intent.setType("text/plain");
        startActivity(Intent.createChooser(intent, getString(R.string.share_header)));
    }

    private void loadPostBody(final PostItem postItem) {
        if (postItem != null) {
            setHTML(postItem.getContent());
            if ((postItem.getCommentCount() != null && postItem.getCommentCount().longValue() != 0 && postItem.getCommentsArray() != null) || this.disqusParseable != null || ((this.post.getPostType() == PostType.JETPACK || this.post.getPostType() == PostType.REST) && postItem.getCommentCount().longValue() != 0)) {
                Button button = (Button) findViewById(R.id.comments);
                if (postItem.getCommentCount().longValue() != 0) {
                    if (postItem.getCommentCount().longValue() != 10 || this.post.getPostType() != PostType.REST) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(Helper.formatValue((double) postItem.getCommentCount().longValue()));
                        stringBuilder.append(" ");
                        stringBuilder.append(getResources().getString(R.string.comments));
                        button.setText(stringBuilder.toString());
                        button.setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                view = new Intent(WordpressDetailActivity.this, CommentsActivity.class);
                                if (WordpressDetailActivity.this.disqusParseable != null) {
                                    view.putExtra(CommentsActivity.DATA_PARSEABLE, WordpressDetailActivity.this.disqusParseable);
                                    view.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.DISQUS);
                                    view.putExtra(CommentsActivity.DATA_ID, WordpressDetailActivity.this.post.getId().toString());
                                } else if (WordpressDetailActivity.this.post.getPostType() == PostType.JETPACK) {
                                    view.putExtra(CommentsActivity.DATA_PARSEABLE, JetPackProvider.getPostCommentsUrl(WordpressDetailActivity.this.apiBase, WordpressDetailActivity.this.post.getId().toString()));
                                    view.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.WORDPRESS_JETPACK);
                                } else if (WordpressDetailActivity.this.post.getPostType() == PostType.REST) {
                                    view.putExtra(CommentsActivity.DATA_PARSEABLE, RestApiProvider.getPostCommentsUrl(WordpressDetailActivity.this.apiBase, WordpressDetailActivity.this.post.getId().toString()));
                                    view.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.WORDPRESS_REST);
                                } else if (WordpressDetailActivity.this.post.getPostType() == PostType.JSON) {
                                    view.putExtra(CommentsActivity.DATA_PARSEABLE, postItem.getCommentsArray().toString());
                                    view.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.WORDPRESS_JSON);
                                }
                                WordpressDetailActivity.this.startActivity(view);
                            }
                        });
                        return;
                    }
                }
                button.setText(getResources().getString(R.string.comments));
                button.setOnClickListener(/* anonymous class already generated */);
                return;
            }
            return;
        }
        findViewById(R.id.progressBar).setVisibility(8);
        Helper.noConnection(this);
    }

    public void setHTML(String str) {
        str = Jsoup.parse(str);
        if (!(str.select("img") == null || str.select("img").first() == null)) {
            str.select("img").first().remove();
        }
        this.htmlTextView.loadDataWithBaseURL(this.post.getUrl(), WebHelper.docToBetterHTML(str, this), "text/html", C0361C.UTF8_NAME, "");
        this.htmlTextView.setVisibility(0);
        findViewById(R.id.progressBar).setVisibility(8);
    }

    public void completed(final PostItem postItem) {
        runOnUiThread(new Runnable() {
            public void run() {
                try {
                    if (postItem.getPostType() == PostType.JSON) {
                        WordpressDetailActivity.this.loadPostBody(postItem);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
