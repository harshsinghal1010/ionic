package com.sherdle.universal.providers.wordpress.api;

import android.os.AsyncTask;
import com.sherdle.universal.providers.wordpress.PostItem;
import java.util.ArrayList;

public class WordpressPostsTask extends AsyncTask<String, Integer, ArrayList<PostItem>> {
    public static final int PER_PAGE = 15;
    public static final int PER_PAGE_RELATED = 4;
    private WordpressPostsCallback callback;
    private WordpressGetTaskInfo info;
    private String url;

    public interface WordpressPostsCallback {
        void postsFailed();

        void postsLoaded(ArrayList<PostItem> arrayList);
    }

    protected void onPreExecute() {
    }

    public WordpressPostsTask(String str, WordpressGetTaskInfo wordpressGetTaskInfo, WordpressPostsCallback wordpressPostsCallback) {
        this.url = str;
        this.info = wordpressGetTaskInfo;
        this.callback = wordpressPostsCallback;
    }

    protected ArrayList<PostItem> doInBackground(String... strArr) {
        strArr = this.info;
        strArr.curpage = Integer.valueOf(strArr.curpage.intValue() + 1);
        strArr = new StringBuilder();
        strArr.append(this.url);
        strArr.append(Integer.toString(this.info.curpage.intValue()));
        this.url = strArr.toString();
        return this.info.provider.parsePostsFromUrl(this.info, this.url);
    }

    protected void onPostExecute(ArrayList<PostItem> arrayList) {
        if (arrayList != null) {
            this.callback.postsLoaded(arrayList);
        } else {
            this.callback.postsFailed();
        }
    }
}
