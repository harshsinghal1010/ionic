package com.sherdle.universal.providers.wordpress.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.SearchView.OnQueryTextListener;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.exoplayer2.C0361C;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.PostItem.PostType;
import com.sherdle.universal.providers.wordpress.WordpressListAdapter;
import com.sherdle.universal.providers.wordpress.api.WordpressCategoriesLoader;
import com.sherdle.universal.providers.wordpress.api.WordpressGetTaskInfo;
import com.sherdle.universal.providers.wordpress.api.WordpressPostsLoader;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import com.sherdle.universal.util.ViewModeUtils;
import com.sherdle.universal.util.ViewModeUtils.ChangeListener;
import java.net.URLEncoder;

public class WordpressFragment extends Fragment implements LoadMoreListener {
    private String[] arguments;
    private RelativeLayout ll;
    private Activity mAct;
    private WordpressGetTaskInfo mInfo;
    private RecyclerView postList = null;
    private SwipeRefreshLayout swipeRefreshLayout;
    private String urlSession;
    ViewModeUtils viewModeUtils;

    /* renamed from: com.sherdle.universal.providers.wordpress.ui.WordpressFragment$1 */
    class C07041 implements OnItemClickListener {
        C07041() {
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            PostItem postItem = (PostItem) WordpressFragment.this.mInfo.posts.get(i);
            if (postItem.getPostType().equals(PostType.SLIDER) == null) {
                view = new Intent(WordpressFragment.this.mAct, WordpressDetailActivity.class);
                view.putExtra("postitem", postItem);
                view.putExtra(WordpressDetailActivity.EXTRA_API_BASE, WordpressFragment.this.arguments[0]);
                if (WordpressFragment.this.arguments.length > 2) {
                    view.putExtra(WordpressDetailActivity.EXTRA_DISQUS, WordpressFragment.this.arguments[2]);
                }
                WordpressFragment.this.startActivity(view);
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.wordpress.ui.WordpressFragment$4 */
    class C07054 implements OnAttachStateChangeListener {
        public void onViewAttachedToWindow(View view) {
        }

        C07054() {
        }

        public void onViewDetachedFromWindow(View view) {
            if (WordpressFragment.this.mInfo.isLoading == null) {
                WordpressFragment.this.getPosts();
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.wordpress.ui.WordpressFragment$2 */
    class C10142 implements OnRefreshListener {
        C10142() {
        }

        public void onRefresh() {
            if (WordpressFragment.this.mInfo.isLoading) {
                Toast.makeText(WordpressFragment.this.mAct, WordpressFragment.this.getString(R.string.already_loading), 1).show();
            } else {
                WordpressFragment.this.getPosts();
            }
            WordpressFragment.this.swipeRefreshLayout.setRefreshing(false);
        }
    }

    /* renamed from: com.sherdle.universal.providers.wordpress.ui.WordpressFragment$5 */
    class C10165 implements ChangeListener {
        C10165() {
        }

        public void modeChanged() {
            if (WordpressFragment.this.viewModeUtils.getViewMode() == 2) {
                WordpressFragment.this.mInfo.adapter.removeSlider();
            }
            WordpressFragment.this.mInfo.adapter.notifyDataSetChanged();
        }
    }

    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreate(bundle);
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list_refresh, viewGroup, false);
        setHasOptionsMenu(true);
        this.arguments = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        OnItemClickListener c07041 = new C07041();
        this.postList = (RecyclerView) this.ll.findViewById(R.id.list);
        this.swipeRefreshLayout = (SwipeRefreshLayout) this.ll.findViewById(R.id.swipeRefreshLayout);
        this.mInfo = new WordpressGetTaskInfo(this.postList, getActivity(), this.arguments[0], Boolean.valueOf(false));
        this.mInfo.adapter = new WordpressListAdapter(getContext(), this.mInfo.posts, this, c07041, this.mInfo.simpleMode.booleanValue());
        this.postList.setAdapter(this.mInfo.adapter);
        this.postList.setLayoutManager(new LinearLayoutManager(this.ll.getContext(), 1, false));
        this.swipeRefreshLayout.setOnRefreshListener(new C10142());
        return this.ll;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        getPosts();
    }

    public void getPosts() {
        String[] strArr = this.arguments;
        if (strArr.length <= 1 || strArr[1].equals("")) {
            this.urlSession = WordpressPostsLoader.getRecentPosts(this.mInfo);
            new WordpressCategoriesLoader(this.mInfo).load();
            return;
        }
        this.urlSession = WordpressPostsLoader.getCategoryPosts(this.mInfo, this.arguments[1]);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        this.viewModeUtils = new ViewModeUtils(getContext(), getClass());
        this.viewModeUtils.inflateOptionsMenu(menu, menuInflater);
        menuInflater.inflate(R.menu.menu_search, menu);
        menuInflater = new SearchView(this.mAct);
        menuInflater.setQueryHint(getResources().getString(R.string.search_hint));
        menuInflater.setOnQueryTextListener(new OnQueryTextListener() {
            public boolean onQueryTextChange(String str) {
                return false;
            }

            public boolean onQueryTextSubmit(String str) {
                try {
                    str = URLEncoder.encode(str, C0361C.UTF8_NAME);
                } catch (Exception e) {
                    Log.printStackTrace(e);
                }
                menuInflater.clearFocus();
                WordpressFragment wordpressFragment = WordpressFragment.this;
                wordpressFragment.urlSession = WordpressPostsLoader.getSearchPosts(wordpressFragment.mInfo, str);
                return true;
            }
        });
        menuInflater.addOnAttachStateChangeListener(new C07054());
        menu.findItem(R.id.menu_search).setActionView(menuInflater);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        this.viewModeUtils.handleSelection(menuItem, new C10165());
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    public void onMoreRequested() {
        if (!this.mInfo.isLoading && this.mInfo.curpage.intValue() < this.mInfo.pages.intValue()) {
            WordpressPostsLoader.loadMorePosts(this.mInfo, this.urlSession);
        }
    }
}
