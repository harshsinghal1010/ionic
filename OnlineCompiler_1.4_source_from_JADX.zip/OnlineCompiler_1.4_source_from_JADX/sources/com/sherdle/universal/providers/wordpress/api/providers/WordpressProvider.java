package com.sherdle.universal.providers.wordpress.api.providers;

import com.sherdle.universal.providers.wordpress.CategoryItem;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.api.WordpressGetTaskInfo;
import java.util.ArrayList;

public interface WordpressProvider {
    ArrayList<CategoryItem> getCategories(WordpressGetTaskInfo wordpressGetTaskInfo);

    String getCategoryPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str);

    String getRecentPosts(WordpressGetTaskInfo wordpressGetTaskInfo);

    String getSearchPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str);

    String getTagPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str);

    ArrayList<PostItem> parsePostsFromUrl(WordpressGetTaskInfo wordpressGetTaskInfo, String str);
}
