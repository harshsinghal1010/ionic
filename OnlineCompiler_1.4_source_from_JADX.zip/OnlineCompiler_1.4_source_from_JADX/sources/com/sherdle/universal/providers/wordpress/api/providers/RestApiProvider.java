package com.sherdle.universal.providers.wordpress.api.providers;

import android.text.Html;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.onesignal.shortcutbadger.impl.NewHtcHomeBadger;
import com.sherdle.universal.providers.soundcloud.helpers.SoundCloudArtworkHelper;
import com.sherdle.universal.providers.wordpress.CategoryItem;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.PostItem.PostType;
import com.sherdle.universal.providers.wordpress.api.RestApiPostLoader;
import com.sherdle.universal.providers.wordpress.api.WordpressGetTaskInfo;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RestApiProvider implements WordpressProvider {
    private static final SimpleDateFormat REST_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault());
    private static final String REST_FIELDS = "&_embed=1";

    public String getRecentPosts(WordpressGetTaskInfo wordpressGetTaskInfo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append("posts/?per_page=");
        stringBuilder.append(15);
        stringBuilder.append(REST_FIELDS);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public String getTagPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append("posts/?per_page=");
        if (wordpressGetTaskInfo.simpleMode.booleanValue() != null) {
            stringBuilder.append(4);
        } else {
            stringBuilder.append(15);
        }
        stringBuilder.append(REST_FIELDS);
        stringBuilder.append("&tags=");
        stringBuilder.append(str);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public String getCategoryPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append("posts/?per_page=");
        stringBuilder.append(15);
        stringBuilder.append(REST_FIELDS);
        stringBuilder.append("&categories=");
        stringBuilder.append(str);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public String getSearchPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append("posts/?per_page=");
        stringBuilder.append(15);
        stringBuilder.append(REST_FIELDS);
        stringBuilder.append("&search=");
        stringBuilder.append(str);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public static String getPostCommentsUrl(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("comments/?post=");
        stringBuilder.append(str2);
        stringBuilder.append(REST_FIELDS);
        stringBuilder.append("&orderby=date_gmt&order=asc");
        stringBuilder.append("&per_page=50");
        return stringBuilder.toString();
    }

    public static String getPostMediaUrl(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("media?parent=");
        stringBuilder.append(str2);
        return stringBuilder.toString();
    }

    public ArrayList<CategoryItem> getCategories(WordpressGetTaskInfo wordpressGetTaskInfo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append("categories");
        stringBuilder.append("?orderby=count&order=desc&per_page=15");
        wordpressGetTaskInfo = Helper.getJSONArrayFromUrl(stringBuilder.toString());
        ArrayList<CategoryItem> arrayList = null;
        if (wordpressGetTaskInfo != null) {
            if (wordpressGetTaskInfo.length() != 0) {
                int i = 0;
                while (i < wordpressGetTaskInfo.length()) {
                    try {
                        if (arrayList == null) {
                            arrayList = new ArrayList();
                        }
                        JSONObject jSONObject = wordpressGetTaskInfo.getJSONObject(i);
                        arrayList.add(new CategoryItem(jSONObject.getString(TtmlNode.ATTR_ID), jSONObject.getString("name"), jSONObject.getInt(NewHtcHomeBadger.COUNT)));
                        i++;
                    } catch (WordpressGetTaskInfo wordpressGetTaskInfo2) {
                        Log.printStackTrace(wordpressGetTaskInfo2);
                    }
                }
                return arrayList;
            }
        }
        return null;
    }

    public ArrayList<PostItem> parsePostsFromUrl(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        ArrayList<PostItem> arrayList = null;
        try {
            str = getJSONArrFromUrl(str, wordpressGetTaskInfo);
            if (str == null) {
                return null;
            }
            ArrayList<PostItem> arrayList2 = new ArrayList();
            for (int i = 0; i < str.length(); i++) {
                try {
                    PostItem itemFromJsonObject = itemFromJsonObject(str.getJSONObject(i));
                    new RestApiPostLoader(itemFromJsonObject, wordpressGetTaskInfo.baseurl, null).start();
                    if (!itemFromJsonObject.getId().equals(wordpressGetTaskInfo.ignoreId)) {
                        arrayList2.add(itemFromJsonObject);
                    }
                } catch (Exception e) {
                    try {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Item ");
                        stringBuilder.append(i);
                        stringBuilder.append(" of ");
                        stringBuilder.append(str.length());
                        stringBuilder.append(" has been skipped due to exception!");
                        Log.m161v("INFO", stringBuilder.toString());
                        Log.printStackTrace(e);
                    } catch (Exception e2) {
                        wordpressGetTaskInfo = e2;
                        arrayList = arrayList2;
                    }
                }
            }
            return arrayList2;
        } catch (Exception e3) {
            wordpressGetTaskInfo = e3;
            Log.printStackTrace(wordpressGetTaskInfo);
            return arrayList;
        }
    }

    public static PostItem itemFromJsonObject(JSONObject jSONObject) throws JSONException {
        PostItem postItem = new PostItem(PostType.REST);
        postItem.setId(Long.valueOf(jSONObject.getLong(TtmlNode.ATTR_ID)));
        postItem.setAuthor(jSONObject.getJSONObject("_embedded").getJSONArray("author").getJSONObject(0).getString("name"));
        try {
            postItem.setDate(REST_DATE_FORMAT.parse(jSONObject.getString("date")));
        } catch (Exception e) {
            Log.printStackTrace(e);
        }
        postItem.setTitle(Html.fromHtml(jSONObject.getJSONObject("title").getString("rendered")).toString());
        postItem.setUrl(jSONObject.getString("link"));
        postItem.setContent(jSONObject.getJSONObject(Param.CONTENT).getString("rendered"));
        if (!jSONObject.getJSONObject("_embedded").has("replies") || jSONObject.getJSONObject("_embedded").getJSONArray("replies") == null) {
            postItem.setCommentCount(Long.valueOf(0));
        } else {
            postItem.setCommentCount(Long.valueOf((long) jSONObject.getJSONObject("_embedded").getJSONArray("replies").getJSONArray(0).length()));
        }
        if (jSONObject.getJSONObject("_embedded").has("wp:featuredmedia") && jSONObject.getJSONObject("_embedded").getJSONArray("wp:featuredmedia").length() > 0 && jSONObject.getJSONObject("_embedded").getJSONArray("wp:featuredmedia").getJSONObject(0).getString("media_type").equals("image")) {
            JSONObject jSONObject2 = jSONObject.getJSONObject("_embedded").getJSONArray("wp:featuredmedia").getJSONObject(0).getJSONObject("media_details").getJSONObject("sizes");
            if (jSONObject2.has(SoundCloudArtworkHelper.LARGE)) {
                postItem.setFeaturedImageUrl(jSONObject2.getJSONObject(SoundCloudArtworkHelper.LARGE).getString("source_url"));
            } else {
                postItem.setFeaturedImageUrl(jSONObject2.getJSONObject("full").getString("source_url"));
            }
            postItem.setThumbnailUrl(jSONObject2.getJSONObject(Param.MEDIUM).getString("source_url"));
        }
        jSONObject = jSONObject.getJSONArray("tags");
        if (jSONObject != null && jSONObject.length() > 0) {
            postItem.setTag(Long.toString(jSONObject.getLong(0)));
        }
        return postItem;
    }

    private JSONArray getJSONArrFromUrl(String str, WordpressGetTaskInfo wordpressGetTaskInfo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Requesting: ");
        stringBuilder.append(str);
        Log.m161v("INFO", stringBuilder.toString());
        StringBuffer stringBuffer = new StringBuffer("");
        try {
            str = (HttpURLConnection) new URL(str).openConnection();
            str.setRequestProperty("User-Agent", "Universal/2.0 (Android)");
            str.setRequestMethod("GET");
            str.setDoInput(true);
            str.connect();
            int responseCode = str.getResponseCode();
            if (responseCode != 200 && (responseCode == 302 || responseCode == 301 || responseCode == 303)) {
                String headerField = str.getHeaderField("Location");
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(headerField).openConnection();
                httpURLConnection.setRequestProperty("Cookie", str.getHeaderField("Set-Cookie"));
                httpURLConnection.setRequestProperty("User-Agent", "Universal/2.0 (Android)");
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setDoInput(true);
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Redirect to URL: ");
                stringBuilder2.append(headerField);
                Log.m161v("INFO", stringBuilder2.toString());
                str = httpURLConnection;
            }
            if (str.getResponseCode() == 200) {
                wordpressGetTaskInfo.pages = Integer.valueOf(str.getHeaderFieldInt("X-WP-TotalPages", 1));
            }
            wordpressGetTaskInfo = new BufferedReader(new InputStreamReader(str.getInputStream()));
            while (true) {
                str = wordpressGetTaskInfo.readLine();
                if (str == null) {
                    break;
                }
                stringBuffer.append(str);
            }
        } catch (String str2) {
            Log.printStackTrace(str2);
        }
        try {
            return new JSONArray(stringBuffer.toString());
        } catch (String str22) {
            Log.m158e("INFO", "Error parsing JSON. Printing stacktrace now");
            Log.printStackTrace(str22);
            return null;
        }
    }
}
