package com.sherdle.universal.providers.wordpress.api;

import android.support.v4.app.NotificationCompat;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.sherdle.universal.providers.soundcloud.api.SoundCloudClient;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.api.providers.JsonApiProvider;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import org.json.JSONObject;

public final class JsonApiPostLoader extends Thread {
    private String apiBase;
    private PostItem item;
    private BackgroundPostCompleterListener listener;

    public interface BackgroundPostCompleterListener {
        void completed(PostItem postItem);
    }

    public JsonApiPostLoader(PostItem postItem, String str, BackgroundPostCompleterListener backgroundPostCompleterListener) {
        this.item = postItem;
        this.apiBase = str;
        this.listener = backgroundPostCompleterListener;
    }

    public void run() {
        JSONObject jSONObjectFromUrl = Helper.getJSONObjectFromUrl(JsonApiProvider.getPostUrl(this.item.getId().longValue(), this.apiBase));
        try {
            if (jSONObjectFromUrl.getString(NotificationCompat.CATEGORY_STATUS).equalsIgnoreCase("ok")) {
                jSONObjectFromUrl = jSONObjectFromUrl.getJSONObject("post");
                this.item.setContent(jSONObjectFromUrl.getString(Param.CONTENT));
                this.item.setCommentCount(Long.valueOf((long) jSONObjectFromUrl.getInt("comment_count")));
                this.item.setCommentsArray(jSONObjectFromUrl.getJSONArray(SoundCloudClient.COMMENTS));
                this.item.setPostCompleted();
                if (this.listener != null) {
                    this.listener.completed(this.item);
                }
            }
        } catch (Exception e) {
            Log.printStackTrace(e);
            BackgroundPostCompleterListener backgroundPostCompleterListener = this.listener;
            if (backgroundPostCompleterListener != null) {
                backgroundPostCompleterListener.completed(null);
            }
        }
    }
}
