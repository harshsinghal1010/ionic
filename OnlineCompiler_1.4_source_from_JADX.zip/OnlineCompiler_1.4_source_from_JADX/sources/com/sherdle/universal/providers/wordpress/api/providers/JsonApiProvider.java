package com.sherdle.universal.providers.wordpress.api.providers;

import android.text.Html;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.providers.wordpress.CategoryItem;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.PostItem.PostType;
import com.sherdle.universal.providers.wordpress.api.JsonApiPostLoader;
import com.sherdle.universal.providers.wordpress.api.WordpressGetTaskInfo;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonApiProvider implements WordpressProvider {
    private static final String API_LOC = "/?json=";
    private static final String API_LOC_FRIENDLY = "/api/";
    private static final String PARAMS = "date_format=U&exclude=comments,categories,custom_fields";
    private static final int TIME_CORRECT = 0;
    public static final boolean USE_WP_FRIENDLY = true;

    /* renamed from: com.sherdle.universal.providers.wordpress.api.providers.JsonApiProvider$1 */
    class C06951 implements Comparator<CategoryItem> {
        C06951() {
        }

        public int compare(CategoryItem categoryItem, CategoryItem categoryItem2) {
            return Integer.valueOf(categoryItem2.getPostCount()).compareTo(Integer.valueOf(categoryItem.getPostCount()));
        }
    }

    public static String getApiLoc() {
        return API_LOC_FRIENDLY;
    }

    public String getRecentPosts(WordpressGetTaskInfo wordpressGetTaskInfo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append(getApiLoc());
        stringBuilder.append("get_recent_posts");
        stringBuilder.append(getParams(PARAMS));
        stringBuilder.append("&count=");
        stringBuilder.append(15);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public String getTagPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append(getApiLoc());
        stringBuilder.append("get_tag_posts");
        stringBuilder.append(getParams(PARAMS));
        stringBuilder.append("&count=");
        if (wordpressGetTaskInfo.simpleMode.booleanValue() != null) {
            stringBuilder.append(4);
        } else {
            stringBuilder.append(15);
        }
        stringBuilder.append("&tag_slug=");
        stringBuilder.append(str);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public String getCategoryPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append(getApiLoc());
        stringBuilder.append("get_category_posts");
        stringBuilder.append(getParams(PARAMS));
        stringBuilder.append("&count=");
        stringBuilder.append(15);
        stringBuilder.append("&category_slug=");
        stringBuilder.append(str);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public String getSearchPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append(getApiLoc());
        stringBuilder.append("get_search_results");
        stringBuilder.append(getParams(PARAMS));
        stringBuilder.append("&count=");
        stringBuilder.append(15);
        stringBuilder.append("&search=");
        stringBuilder.append(str);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public ArrayList<CategoryItem> getCategories(WordpressGetTaskInfo wordpressGetTaskInfo) {
        ArrayList arrayList;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append(getApiLoc());
        stringBuilder.append("GET_CATEGORY_INDEX");
        wordpressGetTaskInfo = Helper.getJSONObjectFromUrl(stringBuilder.toString());
        if (wordpressGetTaskInfo != null) {
            if (wordpressGetTaskInfo.has("categories")) {
                try {
                    wordpressGetTaskInfo = wordpressGetTaskInfo.getJSONArray("categories");
                    arrayList = null;
                    int i = 0;
                    while (i < wordpressGetTaskInfo.length()) {
                        try {
                            if (arrayList == null) {
                                arrayList = new ArrayList();
                            }
                            JSONObject jSONObject = wordpressGetTaskInfo.getJSONObject(i);
                            arrayList.add(new CategoryItem(jSONObject.getString("slug"), jSONObject.getString("title"), jSONObject.getInt("post_count")));
                            i++;
                        } catch (JSONException e) {
                            wordpressGetTaskInfo = e;
                        }
                    }
                } catch (JSONException e2) {
                    wordpressGetTaskInfo = e2;
                    arrayList = null;
                    Log.printStackTrace(wordpressGetTaskInfo);
                    if (arrayList == null) {
                        return null;
                    }
                    Collections.sort(arrayList, new C06951());
                    return new ArrayList(arrayList.subList(0, Math.min(arrayList.size(), 15)));
                }
                if (arrayList == null) {
                    return null;
                }
                Collections.sort(arrayList, new C06951());
                return new ArrayList(arrayList.subList(0, Math.min(arrayList.size(), 15)));
            }
        }
        return null;
    }

    public ArrayList<PostItem> parsePostsFromUrl(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        str = Helper.getJSONObjectFromUrl(str);
        ArrayList<PostItem> arrayList = null;
        if (str == null) {
            return null;
        }
        try {
            wordpressGetTaskInfo.pages = Integer.valueOf(str.getInt("pages"));
            if (str.has("posts")) {
                str = str.getJSONArray("posts");
                ArrayList<PostItem> arrayList2 = new ArrayList();
                for (int i = 0; i < str.length(); i++) {
                    try {
                        PostItem itemFromJsonObject = itemFromJsonObject(str.getJSONObject(i));
                        new JsonApiPostLoader(itemFromJsonObject, wordpressGetTaskInfo.baseurl, null).start();
                        if (!itemFromJsonObject.getId().equals(wordpressGetTaskInfo.ignoreId)) {
                            arrayList2.add(itemFromJsonObject);
                        }
                    } catch (Exception e) {
                        try {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Item ");
                            stringBuilder.append(i);
                            stringBuilder.append(" of ");
                            stringBuilder.append(str.length());
                            stringBuilder.append(" has been skipped due to exception!");
                            Log.m161v("INFO", stringBuilder.toString());
                            Log.printStackTrace(e);
                        } catch (Exception e2) {
                            wordpressGetTaskInfo = e2;
                            arrayList = arrayList2;
                        }
                    }
                }
                arrayList = arrayList2;
            }
        } catch (Exception e3) {
            wordpressGetTaskInfo = e3;
            Log.printStackTrace(wordpressGetTaskInfo);
            return arrayList;
        }
        return arrayList;
    }

    public static PostItem itemFromJsonObject(JSONObject jSONObject) throws JSONException {
        JSONObject jSONObject2;
        PostItem postItem = new PostItem(PostType.JSON);
        postItem.setTitle(Html.fromHtml(jSONObject.getString("title")).toString());
        postItem.setDate(new Date((jSONObject.getLong("date") + 0) * 1000));
        postItem.setId(Long.valueOf(jSONObject.getLong(TtmlNode.ATTR_ID)));
        postItem.setUrl(jSONObject.getString("url"));
        postItem.setContent(jSONObject.getString(Param.CONTENT));
        int i = 0;
        if (jSONObject.has("author")) {
            Object obj = jSONObject.get("author");
            if (obj instanceof JSONArray) {
                JSONArray jSONArray = (JSONArray) obj;
                if (jSONArray.length() > 0) {
                    obj = jSONArray.getJSONObject(0);
                }
            }
            if (obj instanceof JSONObject) {
                jSONObject2 = (JSONObject) obj;
                if (jSONObject2.has("name")) {
                    postItem.setAuthor(jSONObject2.getString("name"));
                }
            }
        }
        if (jSONObject.has("tags") && jSONObject.getJSONArray("tags").length() > 0) {
            postItem.setTag(((JSONObject) jSONObject.getJSONArray("tags").get(0)).getString("slug"));
        }
        try {
            if (jSONObject.has("thumbnail")) {
                String string = jSONObject.getString("thumbnail");
                if (!string.equals("")) {
                    postItem.setThumbnailUrl(string);
                }
            }
            if (jSONObject.has("attachments")) {
                jSONObject = jSONObject.getJSONArray("attachments");
                while (i < jSONObject.length()) {
                    jSONObject2 = jSONObject.getJSONObject(i);
                    String str = null;
                    if (jSONObject2.has("images") && jSONObject2.optJSONObject("images") != null) {
                        if (jSONObject2.getJSONObject("images").has("post-thumbnail")) {
                            str = jSONObject2.getJSONObject("images").getJSONObject("post-thumbnail").getString("url");
                        } else if (jSONObject2.getJSONObject("images").has("thumbnail")) {
                            str = jSONObject2.getJSONObject("images").getJSONObject("thumbnail").getString("url");
                        }
                    }
                    postItem.addAttachment(new MediaAttachment(jSONObject2.getString("url"), jSONObject2.getString("mime_type"), str, jSONObject2.getString("title")));
                    i++;
                }
            }
        } catch (JSONObject jSONObject3) {
            Log.printStackTrace(jSONObject3);
        }
        return postItem;
    }

    public static String getPostUrl(long j, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append(getApiLoc());
        stringBuilder.append("get_post");
        stringBuilder.append(getParams("post_id="));
        stringBuilder.append(j);
        return stringBuilder.toString();
    }

    public static String getParams(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("?");
        stringBuilder.append(str);
        return stringBuilder.toString();
    }
}
