package com.sherdle.universal.providers.wordpress;

public class CategoryItem {
    private String id;
    private String name;
    private int postCount;

    public CategoryItem(String str, String str2, int i) {
        this.id = str;
        this.name = str2;
        this.postCount = i;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public int getPostCount() {
        return this.postCount;
    }

    public void setPostCount(int i) {
        this.postCount = i;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Id: ");
        stringBuilder.append(this.id);
        stringBuilder.append(" Name: ");
        stringBuilder.append(this.name);
        stringBuilder.append(" Postcount: ");
        stringBuilder.append(this.postCount);
        return stringBuilder.toString();
    }
}
