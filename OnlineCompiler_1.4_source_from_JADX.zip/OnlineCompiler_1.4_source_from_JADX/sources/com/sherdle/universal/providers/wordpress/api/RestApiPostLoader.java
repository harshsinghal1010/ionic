package com.sherdle.universal.providers.wordpress.api;

import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.providers.soundcloud.helpers.SoundCloudArtworkHelper;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.api.JsonApiPostLoader.BackgroundPostCompleterListener;
import com.sherdle.universal.providers.wordpress.api.providers.RestApiProvider;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

public final class RestApiPostLoader extends Thread {
    private String apiBase;
    private PostItem item;
    private BackgroundPostCompleterListener listener;

    public RestApiPostLoader(PostItem postItem, String str, BackgroundPostCompleterListener backgroundPostCompleterListener) {
        this.item = postItem;
        this.apiBase = str;
        this.listener = backgroundPostCompleterListener;
    }

    public void run() {
        String str = this.apiBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.item.getId());
        JSONArray jSONArrayFromUrl = Helper.getJSONArrayFromUrl(RestApiProvider.getPostMediaUrl(str, stringBuilder.toString()));
        if (jSONArrayFromUrl != null) {
            int i = 0;
            while (i < jSONArrayFromUrl.length()) {
                try {
                    String string;
                    String string2;
                    JSONObject jSONObject = jSONArrayFromUrl.getJSONObject(i);
                    String string3 = jSONObject.getString("mime_type");
                    if (string3.startsWith(MediaAttachment.MIME_PATTERN_IMAGE)) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("media_details").getJSONObject("sizes");
                        if (jSONObject2.has(SoundCloudArtworkHelper.LARGE)) {
                            string = jSONObject2.getJSONObject(SoundCloudArtworkHelper.LARGE).getString("source_url");
                        } else {
                            string = jSONObject.getString("source_url");
                        }
                        string2 = jSONObject2.has(Param.MEDIUM) ? jSONObject2.getJSONObject(Param.MEDIUM).getString("source_url") : null;
                    } else {
                        string = jSONObject.getString("source_url");
                        string2 = null;
                    }
                    MediaAttachment mediaAttachment = new MediaAttachment(string, jSONObject.getString("mime_type"), string2, jSONObject.getJSONObject("title").getString("rendered"));
                    if (string3.startsWith(MediaAttachment.MIME_PATTERN_AUDIO)) {
                        jSONObject = jSONObject.getJSONObject("media_details");
                        mediaAttachment.setAudioMeta(jSONObject.getString("artist"), jSONObject.getString("album"), jSONObject.getLong("length") * 1000);
                    }
                    this.item.addAttachment(mediaAttachment);
                    i++;
                } catch (Exception e) {
                    Log.printStackTrace(e);
                    BackgroundPostCompleterListener backgroundPostCompleterListener = this.listener;
                    if (backgroundPostCompleterListener != null) {
                        backgroundPostCompleterListener.completed(null);
                        return;
                    }
                    return;
                }
            }
            this.item.setPostCompleted();
            if (this.listener != null) {
                this.listener.completed(this.item);
            }
        }
    }
}
