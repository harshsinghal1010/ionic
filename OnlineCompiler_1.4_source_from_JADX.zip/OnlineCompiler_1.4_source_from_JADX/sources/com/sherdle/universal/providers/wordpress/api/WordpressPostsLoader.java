package com.sherdle.universal.providers.wordpress.api;

import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.api.WordpressPostsTask.WordpressPostsCallback;
import com.sherdle.universal.providers.wordpress.api.providers.JsonApiProvider;
import com.sherdle.universal.providers.wordpress.api.providers.RestApiProvider;
import com.sherdle.universal.util.Helper;
import java.util.ArrayList;

public class WordpressPostsLoader implements WordpressPostsCallback {
    private WordpressGetTaskInfo info;
    private boolean initialload;
    private String url;

    public static String getRecentPosts(WordpressGetTaskInfo wordpressGetTaskInfo) {
        String recentPosts = wordpressGetTaskInfo.provider.getRecentPosts(wordpressGetTaskInfo);
        new WordpressPostsLoader(recentPosts, true, wordpressGetTaskInfo).load();
        return recentPosts;
    }

    public static String getTagPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        str = wordpressGetTaskInfo.provider.getTagPosts(wordpressGetTaskInfo, str);
        new WordpressPostsLoader(str, true, wordpressGetTaskInfo).load();
        return str;
    }

    public static String getCategoryPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        str = wordpressGetTaskInfo.provider.getCategoryPosts(wordpressGetTaskInfo, str);
        new WordpressPostsLoader(str, true, wordpressGetTaskInfo).load();
        return str;
    }

    public static String getSearchPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        if (wordpressGetTaskInfo.isLoading) {
            wordpressGetTaskInfo.isLoading = false;
        }
        str = wordpressGetTaskInfo.provider.getSearchPosts(wordpressGetTaskInfo, str);
        new WordpressPostsLoader(str, true, wordpressGetTaskInfo).load();
        return str;
    }

    public static void loadMorePosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        new WordpressPostsLoader(str, false, wordpressGetTaskInfo).load();
    }

    private WordpressPostsLoader(String str, boolean z, WordpressGetTaskInfo wordpressGetTaskInfo) {
        this.url = str;
        this.initialload = z;
        this.info = wordpressGetTaskInfo;
    }

    private void load() {
        if (!this.info.isLoading) {
            WordpressGetTaskInfo wordpressGetTaskInfo = this.info;
            wordpressGetTaskInfo.isLoading = true;
            if (this.initialload) {
                wordpressGetTaskInfo.adapter.setModeAndNotify(3);
                this.info.adapter.setHasMore(true);
                this.info.posts.clear();
                this.info.curpage = Integer.valueOf(0);
            }
            new WordpressPostsTask(this.url, this.info, this).execute(new String[0]);
        }
    }

    private void complete() {
        this.info.isLoading = false;
    }

    private void updateList(ArrayList<PostItem> arrayList) {
        if (arrayList.size() > 0) {
            this.info.posts.addAll(arrayList);
        }
        if (this.info.curpage.intValue() >= this.info.pages.intValue() || this.info.simpleMode.booleanValue() != null) {
            this.info.adapter.setHasMore(false);
        }
        this.info.adapter.setModeAndNotify(1);
    }

    private void showErrorMessage() {
        String str;
        if (this.info.baseurl.contains("\"")) {
            str = "Your parameters should not contain the character \". Note that the quotes in the documentation only represent the parameters to enter in the configurator tool.";
        } else if (this.info.baseurl.endsWith("/") && (this.info.provider instanceof JsonApiProvider)) {
            r0 = new StringBuilder();
            r0.append("Your base url ");
            r0.append(this.info.baseurl);
            r0.append("should not not end with / (slash)");
            str = r0.toString();
        } else if (this.info.baseurl.endsWith("/v2/") || !(this.info.provider instanceof RestApiProvider)) {
            r0 = new StringBuilder();
            r0.append("The result of '");
            r0.append(this.url);
            r0.append("' does not appear to return valid JSON or at least not in the expected format.");
            str = r0.toString();
        } else {
            r0 = new StringBuilder();
            r0.append(this.info.baseurl.endsWith("/v2/"));
            r0.append(" is not a valid base url for the Wordpress REST API. A base url usually ends with wp-json/wp/v2/");
            str = r0.toString();
        }
        if (this.info.posts == null || this.info.posts.size() == 0) {
            this.info.adapter.setModeAndNotify(2);
        }
        Helper.noConnection(this.info.context, str);
    }

    public void postsLoaded(ArrayList<PostItem> arrayList) {
        updateList(arrayList);
        if (arrayList != null && arrayList.size() < 1 && !this.info.simpleMode.booleanValue()) {
            Toast.makeText(this.info.context, this.info.context.getResources().getString(R.string.no_results), 1).show();
            this.info.adapter.setModeAndNotify(1);
        } else if (arrayList != null && arrayList.size() > null) {
            this.info.completedWithPosts();
        }
        complete();
    }

    public void postsFailed() {
        showErrorMessage();
        complete();
    }
}
