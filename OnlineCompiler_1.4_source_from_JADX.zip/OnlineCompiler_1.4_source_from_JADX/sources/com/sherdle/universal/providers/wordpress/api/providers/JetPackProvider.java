package com.sherdle.universal.providers.wordpress.api.providers;

import android.text.Html;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.providers.wordpress.CategoryItem;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.PostItem.PostType;
import com.sherdle.universal.providers.wordpress.api.WordpressGetTaskInfo;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

public class JetPackProvider implements WordpressProvider {
    private static final String JETPACK_BASE = "https://public-api.wordpress.com/rest/v1.1/sites/";
    private static final SimpleDateFormat JETPACK_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.getDefault());
    private static final String JETPACK_FIELDS = "&fields=ID,author,title,URL,content,discussion,featured_image,post_thumbnail,tags,discussion,date,attachments";

    public String getRecentPosts(WordpressGetTaskInfo wordpressGetTaskInfo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(JETPACK_BASE);
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append("/posts/?number=");
        stringBuilder.append(15);
        stringBuilder.append(JETPACK_FIELDS);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public String getTagPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(JETPACK_BASE);
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append("/posts/?number=");
        if (wordpressGetTaskInfo.simpleMode.booleanValue() != null) {
            stringBuilder.append(4);
        } else {
            stringBuilder.append(15);
        }
        stringBuilder.append("&tag=");
        stringBuilder.append(str);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public String getCategoryPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(JETPACK_BASE);
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append("/posts/?number=");
        stringBuilder.append(15);
        stringBuilder.append("&category=");
        stringBuilder.append(str);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public String getSearchPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(JETPACK_BASE);
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append("/posts/?number=");
        stringBuilder.append(15);
        stringBuilder.append("&search=");
        stringBuilder.append(str);
        stringBuilder.append("&page=");
        return stringBuilder.toString();
    }

    public ArrayList<CategoryItem> getCategories(WordpressGetTaskInfo wordpressGetTaskInfo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(JETPACK_BASE);
        stringBuilder.append(wordpressGetTaskInfo.baseurl);
        stringBuilder.append("/categories");
        stringBuilder.append("?order_by=count&order=DESC&fields=ID,slug,name,post_count&number=15");
        wordpressGetTaskInfo = Helper.getJSONObjectFromUrl(stringBuilder.toString());
        ArrayList<CategoryItem> arrayList = null;
        if (wordpressGetTaskInfo != null) {
            if (wordpressGetTaskInfo.has("categories")) {
                try {
                    wordpressGetTaskInfo = wordpressGetTaskInfo.getJSONArray("categories");
                    for (int i = 0; i < wordpressGetTaskInfo.length(); i++) {
                        if (arrayList == null) {
                            arrayList = new ArrayList();
                        }
                        JSONObject jSONObject = wordpressGetTaskInfo.getJSONObject(i);
                        arrayList.add(new CategoryItem(jSONObject.getString("slug"), jSONObject.getString("name"), jSONObject.getInt("post_count")));
                    }
                } catch (WordpressGetTaskInfo wordpressGetTaskInfo2) {
                    Log.printStackTrace(wordpressGetTaskInfo2);
                }
                return arrayList;
            }
        }
        return null;
    }

    public ArrayList<PostItem> parsePostsFromUrl(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        str = Helper.getJSONObjectFromUrl(str);
        ArrayList<PostItem> arrayList = null;
        if (str == null) {
            return null;
        }
        try {
            wordpressGetTaskInfo.pages = Integer.valueOf((str.getInt("found") / 15) + (str.getInt("found") % 15 == 0 ? 0 : 1));
            if (str.has("posts")) {
                str = str.getJSONArray("posts");
                ArrayList<PostItem> arrayList2 = new ArrayList();
                for (int i = 0; i < str.length(); i++) {
                    try {
                        PostItem itemFromJsonObject = itemFromJsonObject(str.getJSONObject(i));
                        if (!itemFromJsonObject.getId().equals(wordpressGetTaskInfo.ignoreId)) {
                            arrayList2.add(itemFromJsonObject);
                        }
                    } catch (Exception e) {
                        try {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Item ");
                            stringBuilder.append(i);
                            stringBuilder.append(" of ");
                            stringBuilder.append(str.length());
                            stringBuilder.append(" has been skipped due to exception!");
                            Log.m161v("INFO", stringBuilder.toString());
                            Log.printStackTrace(e);
                        } catch (Exception e2) {
                            wordpressGetTaskInfo = e2;
                            arrayList = arrayList2;
                        }
                    }
                }
                arrayList = arrayList2;
            }
        } catch (Exception e3) {
            wordpressGetTaskInfo = e3;
            Log.printStackTrace(wordpressGetTaskInfo);
            return arrayList;
        }
        return arrayList;
    }

    public static String getPostCommentsUrl(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(JETPACK_BASE);
        stringBuilder.append(str);
        stringBuilder.append("/posts/");
        stringBuilder.append(str2);
        stringBuilder.append("/replies?order=ASC");
        return stringBuilder.toString();
    }

    public static PostItem itemFromJsonObject(JSONObject jSONObject) throws JSONException {
        PostItem postItem = new PostItem(PostType.JETPACK);
        postItem.setId(Long.valueOf(jSONObject.getLong("ID")));
        postItem.setAuthor(jSONObject.getJSONObject("author").getString("name"));
        try {
            postItem.setDate(JETPACK_DATE_FORMAT.parse(jSONObject.getString("date")));
        } catch (Exception e) {
            Log.printStackTrace(e);
        }
        postItem.setTitle(Html.fromHtml(jSONObject.getString("title")).toString());
        postItem.setUrl(jSONObject.getString("URL"));
        postItem.setContent(jSONObject.getString(Param.CONTENT));
        postItem.setCommentCount(Long.valueOf(jSONObject.getJSONObject("discussion").getLong("comment_count")));
        postItem.setFeaturedImageUrl(jSONObject.getString("featured_image"));
        long j = -1;
        if (!jSONObject.isNull("post_thumbnail")) {
            j = jSONObject.getJSONObject("post_thumbnail").getLong("ID");
            postItem.setThumbnailUrl(jSONObject.getJSONObject("post_thumbnail").getString("URL"));
        }
        if (jSONObject.has("attachments") && jSONObject.getJSONObject("attachments").names() != null) {
            JSONObject jSONObject2 = jSONObject.getJSONObject("attachments");
            for (int i = 0; i < jSONObject2.names().length(); i++) {
                JSONObject jSONObject3 = jSONObject2.getJSONObject(jSONObject2.names().getString(i));
                String str = null;
                String string = (jSONObject3.has("thumbnails") && jSONObject3.getJSONObject("thumbnails").has("thumbnail")) ? jSONObject3.getJSONObject("thumbnails").getString("thumbnail") : null;
                if (jSONObject3.has("title")) {
                    str = jSONObject3.getString("title");
                }
                postItem.addAttachment(new MediaAttachment(jSONObject3.getString("URL"), jSONObject3.getString("mime_type"), string, str));
                if (jSONObject3.getLong("ID") == j && jSONObject3.has("thumbnails") && jSONObject3.getJSONObject("thumbnails").has(Param.MEDIUM)) {
                    postItem.setThumbnailUrl(jSONObject3.getJSONObject("thumbnails").getString(Param.MEDIUM));
                }
            }
        }
        jSONObject = jSONObject.getJSONObject("tags");
        if (!(jSONObject == null || jSONObject.names() == null || jSONObject.names().length() <= 0)) {
            postItem.setTag(jSONObject.getJSONObject(jSONObject.names().getString(0)).getString("slug"));
        }
        postItem.setPostCompleted();
        return postItem;
    }
}
