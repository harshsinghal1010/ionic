package com.sherdle.universal.providers.wordpress;

import android.content.Context;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.providers.wordpress.PostItem.PostType;
import com.sherdle.universal.providers.wordpress.ui.WordpressFragment;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.ViewModeUtils;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class WordpressListAdapter extends InfiniteRecyclerViewAdapter {
    private static final int HEADER_IMAGE = 2;
    private static final int HEADER_TEXT = 3;
    private static final int POST = 1;
    private static final int POST_COMPACT = 0;
    private static final int SLIDER = 4;
    private ArrayList<PostItem> listData;
    private OnItemClickListener listener;
    private Context mContext;
    private int number;
    private boolean simpleMode;
    private View sliderView;
    private ViewModeUtils viewModeUtils;

    private static abstract class HeaderViewHolder extends ViewHolder {
        TextView dateView;
        TextView headlineView;
        ImageView imageView;

        HeaderViewHolder(View view) {
            super(view);
            this.dateView = (TextView) view.findViewById(R.id.textViewDate);
            this.headlineView = (TextView) view.findViewById(R.id.textViewHighlight);
            this.imageView = (ImageView) view.findViewById(R.id.imageViewHighlight);
        }
    }

    private static class ItemViewHolder extends ViewHolder {
        TextView headlineView;
        ImageView imageView;
        TextView reportedDateView;

        ItemViewHolder(View view) {
            super(view);
            this.headlineView = (TextView) view.findViewById(R.id.title);
            this.reportedDateView = (TextView) view.findViewById(R.id.date);
            this.imageView = (ImageView) view.findViewById(R.id.thumbImage);
        }
    }

    private static class SliderViewHolder extends ViewHolder {
        SliderViewHolder(View view) {
            super(view);
        }
    }

    private static class HeaderImageViewHolder extends HeaderViewHolder {
        HeaderImageViewHolder(View view) {
            super(view);
        }
    }

    private static class HeaderTextViewHolder extends HeaderViewHolder {
        HeaderTextViewHolder(View view) {
            super(view);
        }
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public WordpressListAdapter(Context context, ArrayList<PostItem> arrayList, LoadMoreListener loadMoreListener, OnItemClickListener onItemClickListener, boolean z) {
        super(context, loadMoreListener);
        this.mContext = context;
        this.listener = onItemClickListener;
        this.simpleMode = z;
        this.listData = arrayList;
        this.viewModeUtils = new ViewModeUtils(context, WordpressFragment.class);
    }

    public int getCount() {
        return this.listData.size();
    }

    protected int getViewType(int i) {
        if (this.simpleMode) {
            return 0;
        }
        PostItem postItem = (PostItem) this.listData.get(i);
        if (postItem.getPostType() == PostType.SLIDER) {
            return 4;
        }
        if (i != 0) {
            if (this.viewModeUtils.getViewMode() != 2) {
                if (this.viewModeUtils.getViewMode() == 1) {
                    return 1;
                }
                return 0;
            }
        }
        return headerType(postItem);
    }

    protected ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        switch (i) {
            case 0:
                return new ItemViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_wordpress_list_row, viewGroup, false));
            case 1:
                return new ItemViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_row, viewGroup, false));
            case 2:
                i = new HeaderImageViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_highlight, viewGroup, false));
                requestFullSpan(i);
                return i;
            case 3:
                i = new HeaderTextViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_highlight_text, viewGroup, false));
                requestFullSpan(i);
                return i;
            case 4:
                viewGroup = new SliderViewHolder(this.sliderView);
                requestFullSpan(viewGroup);
                return viewGroup;
            default:
                return null;
        }
    }

    protected void doBindViewHolder(final ViewHolder viewHolder, final int i) {
        PostItem postItem = (PostItem) this.listData.get(i);
        if (viewHolder instanceof HeaderImageViewHolder) {
            HeaderImageViewHolder headerImageViewHolder = (HeaderImageViewHolder) viewHolder;
            headerImageViewHolder.imageView.setImageBitmap(null);
            Picasso.get().load(postItem.getImageCandidate()).placeholder((int) R.drawable.placeholder).fit().centerCrop().into(headerImageViewHolder.imageView);
            headerImageViewHolder.headlineView.setText(postItem.getTitle());
            headerImageViewHolder.dateView.setText(DateUtils.getRelativeDateTimeString(this.mContext, postItem.getDate().getTime(), 1000, 604800000, 524288));
        } else if (viewHolder instanceof HeaderTextViewHolder) {
            HeaderTextViewHolder headerTextViewHolder = (HeaderTextViewHolder) viewHolder;
            headerTextViewHolder.itemView.findViewById(R.id.background).setBackgroundResource(randomGradientResource());
            headerTextViewHolder.headlineView.setText(postItem.getTitle());
            headerTextViewHolder.dateView.setText(DateUtils.getRelativeDateTimeString(this.mContext, postItem.getDate().getTime(), 1000, 604800000, 524288));
        } else if (!(viewHolder instanceof SliderViewHolder)) {
            if (viewHolder instanceof ItemViewHolder) {
                ItemViewHolder itemViewHolder = (ItemViewHolder) viewHolder;
                itemViewHolder.imageView.setImageBitmap(null);
                itemViewHolder.headlineView.setText(postItem.getTitle());
                if (postItem.getDate() != null) {
                    itemViewHolder.reportedDateView.setVisibility(0);
                    itemViewHolder.reportedDateView.setText(DateUtils.getRelativeDateTimeString(this.mContext, postItem.getDate().getTime(), 1000, 604800000, 524288));
                } else {
                    itemViewHolder.reportedDateView.setVisibility(8);
                }
                itemViewHolder.imageView.setVisibility(8);
                Object obj = 1;
                if (this.viewModeUtils.getViewMode() != 1) {
                    obj = null;
                }
                String imageCandidate = obj != null ? postItem.getImageCandidate() : postItem.getThumbnailCandidate();
                if (!(imageCandidate == null || imageCandidate.equals(""))) {
                    itemViewHolder.imageView.setVisibility(0);
                    Picasso.get().load(imageCandidate).fit().centerInside().into(itemViewHolder.imageView);
                }
            }
        }
        if (!(viewHolder instanceof SliderViewHolder)) {
            viewHolder.itemView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    WordpressListAdapter.this.listener.onItemClick(null, viewHolder.itemView, i, 0);
                }
            });
        }
    }

    private int headerType(PostItem postItem) {
        return (postItem.getImageCandidate() == null || postItem.getImageCandidate().equals("") != null) ? 3 : 2;
    }

    private int randomGradientResource() {
        this.number++;
        if (this.number == 6) {
            this.number = 1;
        }
        return Helper.getGradient(this.number);
    }

    public void setSlider(View view) {
        if (this.sliderView == null && this.viewModeUtils.getViewMode() != 2 && this.listData.size() > 0) {
            this.listData.add(1, new PostItem(PostType.SLIDER));
        }
        this.sliderView = view;
        notifyDataSetChanged();
    }

    public void removeSlider() {
        if (this.sliderView != null && this.listData.size() > 0 && ((PostItem) this.listData.get(1)).getPostType() == PostType.SLIDER) {
            this.listData.remove(1);
            this.sliderView = null;
        }
    }
}
