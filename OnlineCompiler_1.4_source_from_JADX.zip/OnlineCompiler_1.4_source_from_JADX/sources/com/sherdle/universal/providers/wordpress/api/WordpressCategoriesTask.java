package com.sherdle.universal.providers.wordpress.api;

import android.os.AsyncTask;
import com.sherdle.universal.providers.wordpress.CategoryItem;
import java.util.ArrayList;

public class WordpressCategoriesTask extends AsyncTask<String, Integer, ArrayList<CategoryItem>> {
    public static final int NUMBER_OF_CATEGORIES = 15;
    private WordpressCategoriesCallback callback;
    private WordpressGetTaskInfo info;

    public interface WordpressCategoriesCallback {
        void categoriesFailed();

        void categoriesLoaded(ArrayList<CategoryItem> arrayList);
    }

    protected void onPreExecute() {
    }

    public WordpressCategoriesTask(WordpressGetTaskInfo wordpressGetTaskInfo, WordpressCategoriesCallback wordpressCategoriesCallback) {
        this.info = wordpressGetTaskInfo;
        this.callback = wordpressCategoriesCallback;
    }

    protected ArrayList<CategoryItem> doInBackground(String... strArr) {
        return this.info.provider.getCategories(this.info);
    }

    protected void onPostExecute(ArrayList<CategoryItem> arrayList) {
        if (arrayList == null) {
            this.callback.categoriesFailed();
        } else {
            this.callback.categoriesLoaded(arrayList);
        }
    }
}
