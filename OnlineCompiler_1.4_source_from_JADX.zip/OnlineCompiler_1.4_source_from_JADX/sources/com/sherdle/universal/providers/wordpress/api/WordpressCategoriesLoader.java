package com.sherdle.universal.providers.wordpress.api;

import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.providers.wordpress.CategoryItem;
import com.sherdle.universal.providers.wordpress.api.WordpressCategoriesTask.WordpressCategoriesCallback;
import com.sherdle.universal.providers.wordpress.api.WordpressGetTaskInfo.ListListener;
import com.sherdle.universal.providers.wordpress.ui.WordpressFragment;
import com.sherdle.universal.util.Helper;
import java.util.ArrayList;

public class WordpressCategoriesLoader implements ListListener {
    private ArrayList<CategoryItem> categoryItems;
    private WordpressGetTaskInfo mInfo;

    /* renamed from: com.sherdle.universal.providers.wordpress.api.WordpressCategoriesLoader$1 */
    class C10121 implements WordpressCategoriesCallback {
        public void categoriesFailed() {
        }

        C10121() {
        }

        public void categoriesLoaded(ArrayList<CategoryItem> arrayList) {
            WordpressCategoriesLoader.this.categoryItems = arrayList;
            if (WordpressCategoriesLoader.this.mInfo.adapter == null || WordpressCategoriesLoader.this.mInfo.adapter.getCount() <= 0) {
                WordpressCategoriesLoader.this.mInfo.setListener(WordpressCategoriesLoader.this);
            } else {
                WordpressCategoriesLoader.this.createSlider(arrayList);
            }
        }
    }

    public WordpressCategoriesLoader(WordpressGetTaskInfo wordpressGetTaskInfo) {
        this.mInfo = wordpressGetTaskInfo;
    }

    public void load() {
        new WordpressCategoriesTask(this.mInfo, new C10121()).execute(new String[0]);
    }

    public void createSlider(ArrayList<CategoryItem> arrayList) {
        LayoutInflater from = LayoutInflater.from(this.mInfo.context);
        HorizontalScrollView horizontalScrollView = (HorizontalScrollView) from.inflate(R.layout.listview_slider, null);
        arrayList = arrayList.iterator();
        while (arrayList.hasNext()) {
            final CategoryItem categoryItem = (CategoryItem) arrayList.next();
            FrameLayout frameLayout = (FrameLayout) from.inflate(R.layout.listview_slider_chip, null);
            TextView textView = (TextView) frameLayout.findViewById(R.id.category_chip);
            TextView textView2 = (TextView) frameLayout.findViewById(R.id.category_chip_number);
            textView.setText(categoryItem.getName());
            textView2.setText(Helper.formatValue((double) categoryItem.getPostCount()));
            textView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    HolderActivity.startActivity(WordpressCategoriesLoader.this.mInfo.context, WordpressFragment.class, new String[]{WordpressCategoriesLoader.this.mInfo.baseurl, categoryItem.getId()});
                }
            });
            ((LinearLayout) horizontalScrollView.findViewById(R.id.slider_content)).addView(frameLayout);
        }
        this.mInfo.adapter.setSlider(horizontalScrollView);
        horizontalScrollView.setAlpha(null);
        horizontalScrollView.animate().alpha(1.0f).setDuration(500).start();
    }

    public void completedWithPosts() {
        createSlider(this.categoryItems);
    }
}
