package com.sherdle.universal.providers.wordpress.api;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import com.sherdle.universal.providers.wordpress.PostItem;
import com.sherdle.universal.providers.wordpress.WordpressListAdapter;
import com.sherdle.universal.providers.wordpress.api.providers.JetPackProvider;
import com.sherdle.universal.providers.wordpress.api.providers.JsonApiProvider;
import com.sherdle.universal.providers.wordpress.api.providers.RestApiProvider;
import com.sherdle.universal.providers.wordpress.api.providers.WordpressProvider;
import java.util.ArrayList;

public class WordpressGetTaskInfo {
    public WordpressListAdapter adapter = null;
    public String baseurl;
    public Activity context;
    public Integer curpage = Integer.valueOf(0);
    public Long ignoreId = Long.valueOf(0);
    public boolean isLoading;
    public RecyclerView listView = null;
    private ListListener listener;
    public Integer pages;
    public ArrayList<PostItem> posts;
    public WordpressProvider provider = null;
    public Boolean simpleMode;

    public interface ListListener {
        void completedWithPosts();
    }

    public WordpressGetTaskInfo(RecyclerView recyclerView, Activity activity, String str, Boolean bool) {
        this.listView = recyclerView;
        this.posts = new ArrayList();
        this.context = activity;
        this.baseurl = str;
        this.simpleMode = bool;
        if (str.startsWith("http") == null) {
            this.provider = new JetPackProvider();
        } else if (str.contains("wp-json/wp/v2/") != null) {
            this.provider = new RestApiProvider();
        } else {
            this.provider = new JsonApiProvider();
        }
    }

    public void setListener(ListListener listListener) {
        this.listener = listListener;
    }

    public void completedWithPosts() {
        ListListener listListener = this.listener;
        if (listListener != null) {
            listListener.completedWithPosts();
        }
    }
}
