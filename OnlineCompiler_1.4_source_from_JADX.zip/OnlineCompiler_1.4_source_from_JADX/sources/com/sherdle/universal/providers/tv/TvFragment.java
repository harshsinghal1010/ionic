package com.sherdle.universal.providers.tv;

import android.app.Activity;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout.LayoutParams;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.devbrackets.android.exomedia.listener.OnPreparedListener;
import com.devbrackets.android.exomedia.listener.VideoControlsVisibilityListener;
import com.devbrackets.android.exomedia.ui.widget.VideoControls;
import com.devbrackets.android.exomedia.ui.widget.VideoView;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.inherit.BackPressFragment;
import com.sherdle.universal.inherit.CollapseControllingFragment;
import com.sherdle.universal.inherit.ConfigurationChangeFragment;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import com.sherdle.universal.util.layout.CustomAppBarLayout;

public class TvFragment extends Fragment implements CollapseControllingFragment, BackPressFragment, ConfigurationChangeFragment, OnPreparedListener {
    private Activity mAct;
    private RelativeLayout rl;
    private boolean systemUIHidden = false;
    private VideoView videoView;

    /* renamed from: com.sherdle.universal.providers.tv.TvFragment$1 */
    class C06411 implements OnClickListener {
        C06411() {
        }

        public void onClick(View view) {
            if (TvFragment.this.systemUIHidden != null) {
                TvFragment.this.showSystemUI();
            } else {
                TvFragment.this.hideSystemUI();
            }
        }
    }

    private class ControlsVisibilityListener implements VideoControlsVisibilityListener {
        public void onControlsHidden() {
        }

        public void onControlsShown() {
        }

        private ControlsVisibilityListener() {
        }
    }

    public boolean dynamicToolbarElevation() {
        return false;
    }

    public boolean supportsCollapse() {
        return false;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rl = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_tv, viewGroup, false);
        this.videoView = (VideoView) this.rl.findViewById(R.id.video_view);
        return this.rl;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        setRetainInstance(true);
        Helper.isOnlineShowDialog(this.mAct);
        bundle = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        initCustomControls();
        this.videoView.setOnPreparedListener(this);
        this.videoView.setVideoURI(Uri.parse(bundle));
    }

    public void initCustomControls() {
        VideoControls videoControlsCustom = new VideoControlsCustom(this.mAct);
        videoControlsCustom.hideSeekBar();
        FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.mAct).inflate(R.layout.listview_slider_chip, null);
        frameLayout.setOnClickListener(new C06411());
        TextView textView = (TextView) frameLayout.findViewById(R.id.category_chip_number);
        ((TextView) frameLayout.findViewById(R.id.category_chip)).setText(getString(R.string.toggle_fullscreen));
        textView.setVisibility(8);
        videoControlsCustom.addExtraView(frameLayout);
        videoControlsCustom.setVisibilityListener(new ControlsVisibilityListener());
        this.videoView.setControls(videoControlsCustom);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    public void onPause() {
        super.onPause();
        this.videoView.pause();
    }

    public void onDestroy() {
        super.onDestroy();
        this.videoView.stopPlayback();
        showSystemUI();
    }

    public boolean handleBackPress() {
        if (!this.systemUIHidden) {
            return false;
        }
        showSystemUI();
        return true;
    }

    public void onPrepared() {
        this.videoView.start();
    }

    private void hideSystemUI() {
        Activity activity = this.mAct;
        if (activity instanceof MainActivity) {
            if (((MainActivity) activity).useTabletMenu()) {
                this.mAct.findViewById(R.id.nav_view).setVisibility(8);
            } else {
                ((MainActivity) this.mAct).drawer.setFitsSystemWindows(false);
                RelativeLayout relativeLayout = (RelativeLayout) this.mAct.findViewById(R.id.drawer_child);
                LayoutParams layoutParams = (LayoutParams) relativeLayout.getLayoutParams();
                layoutParams.setMargins(0, 0, 0, 0);
                relativeLayout.setLayoutParams(layoutParams);
            }
        }
        getActivity().getWindow().addFlags(1152);
        View decorView = this.mAct.getWindow().getDecorView();
        if (VERSION.SDK_INT >= 19) {
            decorView.setSystemUiVisibility(3846);
        } else if (VERSION.SDK_INT >= 16) {
            decorView.setSystemUiVisibility(1798);
        }
        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
        this.mAct.findViewById(R.id.adView).setVisibility(8);
        this.systemUIHidden = true;
    }

    private void showSystemUI() {
        try {
            if (this.mAct instanceof MainActivity) {
                if (((MainActivity) this.mAct).useTabletMenu()) {
                    this.mAct.findViewById(R.id.nav_view).setVisibility(0);
                    this.mAct.getWindow().addFlags(67108864);
                    ((CustomAppBarLayout) ((MainActivity) this.mAct).mToolbar.getParent()).setPadding(0, (int) Math.ceil((double) (getResources().getDisplayMetrics().density * 25.0f)), 0, 0);
                } else {
                    ((MainActivity) this.mAct).drawer.setFitsSystemWindows(true);
                }
            }
            getActivity().getWindow().clearFlags(1152);
            if (VERSION.SDK_INT >= 16) {
                View decorView = this.mAct.getWindow().getDecorView();
                decorView.setSystemUiVisibility(256);
                if (VERSION.SDK_INT >= 23 && ThemeUtils.lightToolbarThemeActive(this.mAct)) {
                    decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | 8192);
                }
            }
            ((AppCompatActivity) getActivity()).getSupportActionBar().show();
            Helper.admobLoader(this.mAct, this.mAct.findViewById(R.id.adView));
            this.systemUIHidden = false;
        } catch (NullPointerException e) {
            Log.m158e("INFO", e.toString());
        }
    }
}
