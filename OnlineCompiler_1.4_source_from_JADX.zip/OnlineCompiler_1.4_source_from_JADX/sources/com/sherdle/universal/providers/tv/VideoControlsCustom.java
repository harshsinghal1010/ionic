package com.sherdle.universal.providers.tv;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import com.codeintelligent.onlinecompiler.R;
import com.devbrackets.android.exomedia.ui.widget.VideoControlsMobile;

public class VideoControlsCustom extends VideoControlsMobile {
    protected int getLayoutResource() {
        return R.layout.fragment_tv_controls;
    }

    public VideoControlsCustom(Context context) {
        super(context);
    }

    public VideoControlsCustom(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public VideoControlsCustom(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    @TargetApi(21)
    public VideoControlsCustom(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }

    public void hideSeekBar() {
        this.seekBar.setVisibility(8);
        this.currentTimeTextView.setVisibility(8);
        this.endTimeTextView.setVisibility(8);
    }
}
