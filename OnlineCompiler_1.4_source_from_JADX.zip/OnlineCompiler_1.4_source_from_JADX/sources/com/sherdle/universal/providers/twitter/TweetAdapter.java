package com.sherdle.universal.providers.twitter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.attachmentviewer.model.MediaAttachment;
import com.sherdle.universal.attachmentviewer.ui.AttachmentActivity;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.WebHelper;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class TweetAdapter extends InfiniteRecyclerViewAdapter {
    private Context context;
    private ArrayList<Tweet> tweets;

    private class TweetHolder extends ViewHolder {
        TextView date;
        ImageView imagem;
        TextView message;
        TextView name;
        ImageView photo;
        TextView retweetCount;
        TextView username;

        TweetHolder(View view) {
            super(view);
            this.name = (TextView) view.findViewById(R.id.name);
            this.username = (TextView) view.findViewById(R.id.username);
            this.imagem = (ImageView) view.findViewById(R.id.profile_image);
            this.photo = (ImageView) view.findViewById(R.id.photo);
            this.message = (TextView) view.findViewById(R.id.message);
            this.retweetCount = (TextView) view.findViewById(R.id.retweet_count);
            this.date = (TextView) view.findViewById(R.id.date);
        }
    }

    protected int getViewType(int i) {
        return 0;
    }

    public TweetAdapter(Context context, ArrayList<Tweet> arrayList, LoadMoreListener loadMoreListener) {
        super(context, loadMoreListener);
        this.context = context;
        this.tweets = arrayList;
    }

    protected ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        return new TweetHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_tweets_row, viewGroup, false));
    }

    protected void doBindViewHolder(ViewHolder viewHolder, int i) {
        if (viewHolder instanceof TweetHolder) {
            TweetHolder tweetHolder = (TweetHolder) viewHolder;
            final Tweet tweet = (Tweet) this.tweets.get(i);
            tweetHolder.name.setText(tweet.getname());
            TextView textView = tweetHolder.username;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("@");
            stringBuilder.append(tweet.getusername());
            textView.setText(stringBuilder.toString());
            tweetHolder.date.setText(tweet.getData());
            tweetHolder.message.setText(Html.fromHtml(tweet.getmessage()));
            tweetHolder.message.setTextSize(2, (float) WebHelper.getTextViewFontSize(this.context));
            tweetHolder.retweetCount.setText(Helper.formatValue((double) tweet.getRetweetCount()));
            Picasso.get().load(tweet.geturlProfileImage()).into(tweetHolder.imagem);
            if (tweet.getImageUrl() != null) {
                tweetHolder.photo.setVisibility(0);
                Picasso.get().load(tweet.getImageUrl()).placeholder((int) R.drawable.placeholder).into(tweetHolder.photo);
                tweetHolder.photo.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        AttachmentActivity.startActivity(TweetAdapter.this.context, MediaAttachment.withImage(tweet.getImageUrl()));
                    }
                });
            } else {
                tweetHolder.photo.setImageDrawable(null);
                tweetHolder.photo.setVisibility(8);
            }
            tweetHolder.itemView.findViewById(R.id.share).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    view = new Intent();
                    view.setAction("android.intent.action.SEND");
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("http://twitter.com/");
                    stringBuilder.append(tweet.getusername());
                    stringBuilder.append("/status/");
                    stringBuilder.append(tweet.getTweetId());
                    view.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(tweet.getusername());
                    stringBuilder2.append(TweetAdapter.this.context.getResources().getString(R.string.tweet_share_header));
                    view.putExtra("android.intent.extra.SUBJECT", stringBuilder2.toString());
                    view.setType("text/plain");
                    TweetAdapter.this.context.startActivity(Intent.createChooser(view, TweetAdapter.this.context.getResources().getString(R.string.share_header)));
                }
            });
            tweetHolder.itemView.findViewById(R.id.open).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    view = new StringBuilder();
                    view.append("http://twitter.com/");
                    view.append(tweet.getusername());
                    view.append("/status/");
                    view.append(tweet.getTweetId());
                    HolderActivity.startWebViewActivity(TweetAdapter.this.context, view.toString(), true, false, null);
                }
            });
        }
    }

    protected int getCount() {
        return this.tweets.size();
    }
}
