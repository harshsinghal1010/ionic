package com.sherdle.universal.providers.twitter.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.providers.twitter.Tweet;
import com.sherdle.universal.providers.twitter.TweetAdapter;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.ThemeUtils;
import java.util.ArrayList;

public class TweetsFragment extends Fragment implements LoadMoreListener {
    Boolean isLoading = Boolean.valueOf(true);
    String latesttweetid;
    private RecyclerView listView;
    private RelativeLayout ll;
    private Activity mAct;
    String perpage = "25";
    String searchValue;
    private TweetAdapter tweetAdapter;
    private ArrayList<Tweet> tweets;

    private class SearchTweetsTask extends AsyncTask<String, Void, ArrayList<Tweet>> {
        private final String CONSUMER_KEY;
        private final String CONSUMER_SECRET;
        private final String URL_AUTH;
        private final String URL_BASE;
        private final String URL_PARAM;
        private final String URL_SEARCH;
        private final String URL_TIMELINE;
        private String URL_VALUE;

        private java.lang.String authenticateApp() {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:32:0x00e0 in {8, 10, 11, 13, 15, 17, 19, 23, 25, 27, 28, 30, 31} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
            /*
            r8 = this;
            r0 = 0;
            r1 = new java.net.URL;	 Catch:{ Exception -> 0x00b1, all -> 0x00ac }
            r2 = "https://api.twitter.com/oauth2/token";	 Catch:{ Exception -> 0x00b1, all -> 0x00ac }
            r1.<init>(r2);	 Catch:{ Exception -> 0x00b1, all -> 0x00ac }
            r1 = r1.openConnection();	 Catch:{ Exception -> 0x00b1, all -> 0x00ac }
            r1 = (java.net.HttpURLConnection) r1;	 Catch:{ Exception -> 0x00b1, all -> 0x00ac }
            r2 = "POST";	 Catch:{ Exception -> 0x00a9 }
            r1.setRequestMethod(r2);	 Catch:{ Exception -> 0x00a9 }
            r2 = 1;	 Catch:{ Exception -> 0x00a9 }
            r1.setDoOutput(r2);	 Catch:{ Exception -> 0x00a9 }
            r1.setDoInput(r2);	 Catch:{ Exception -> 0x00a9 }
            r2 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00a9 }
            r2.<init>();	 Catch:{ Exception -> 0x00a9 }
            r3 = r8.CONSUMER_KEY;	 Catch:{ Exception -> 0x00a9 }
            r2.append(r3);	 Catch:{ Exception -> 0x00a9 }
            r3 = ":";	 Catch:{ Exception -> 0x00a9 }
            r2.append(r3);	 Catch:{ Exception -> 0x00a9 }
            r3 = r8.CONSUMER_SECRET;	 Catch:{ Exception -> 0x00a9 }
            r2.append(r3);	 Catch:{ Exception -> 0x00a9 }
            r2 = r2.toString();	 Catch:{ Exception -> 0x00a9 }
            r3 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00a9 }
            r3.<init>();	 Catch:{ Exception -> 0x00a9 }
            r4 = "Basic ";	 Catch:{ Exception -> 0x00a9 }
            r3.append(r4);	 Catch:{ Exception -> 0x00a9 }
            r2 = r2.getBytes();	 Catch:{ Exception -> 0x00a9 }
            r4 = 2;	 Catch:{ Exception -> 0x00a9 }
            r2 = android.util.Base64.encodeToString(r2, r4);	 Catch:{ Exception -> 0x00a9 }
            r3.append(r2);	 Catch:{ Exception -> 0x00a9 }
            r2 = r3.toString();	 Catch:{ Exception -> 0x00a9 }
            r3 = "grant_type=client_credentials";	 Catch:{ Exception -> 0x00a9 }
            r4 = "Authorization";	 Catch:{ Exception -> 0x00a9 }
            r1.addRequestProperty(r4, r2);	 Catch:{ Exception -> 0x00a9 }
            r2 = "Content-Type";	 Catch:{ Exception -> 0x00a9 }
            r4 = "application/x-www-form-urlencoded;charset=UTF-8";	 Catch:{ Exception -> 0x00a9 }
            r1.setRequestProperty(r2, r4);	 Catch:{ Exception -> 0x00a9 }
            r1.connect();	 Catch:{ Exception -> 0x00a9 }
            r2 = r1.getOutputStream();	 Catch:{ Exception -> 0x00a9 }
            r3 = r3.getBytes();	 Catch:{ Exception -> 0x00a9 }
            r2.write(r3);	 Catch:{ Exception -> 0x00a9 }
            r2.flush();	 Catch:{ Exception -> 0x00a9 }
            r2.close();	 Catch:{ Exception -> 0x00a9 }
            r2 = new java.io.BufferedReader;	 Catch:{ Exception -> 0x00a9 }
            r3 = new java.io.InputStreamReader;	 Catch:{ Exception -> 0x00a9 }
            r4 = r1.getInputStream();	 Catch:{ Exception -> 0x00a9 }
            r3.<init>(r4);	 Catch:{ Exception -> 0x00a9 }
            r2.<init>(r3);	 Catch:{ Exception -> 0x00a9 }
            r3 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00a9 }
            r3.<init>();	 Catch:{ Exception -> 0x00a9 }
        L_0x0081:
            r4 = r2.readLine();	 Catch:{ Exception -> 0x00a7 }
            if (r4 == 0) goto L_0x008b;	 Catch:{ Exception -> 0x00a7 }
        L_0x0087:
            r3.append(r4);	 Catch:{ Exception -> 0x00a7 }
            goto L_0x0081;	 Catch:{ Exception -> 0x00a7 }
        L_0x008b:
            r2 = "Post response";	 Catch:{ Exception -> 0x00a7 }
            r4 = r1.getResponseCode();	 Catch:{ Exception -> 0x00a7 }
            r4 = java.lang.String.valueOf(r4);	 Catch:{ Exception -> 0x00a7 }
            com.sherdle.universal.util.Log.m157d(r2, r4);	 Catch:{ Exception -> 0x00a7 }
            r2 = "Json response - tokenk";	 Catch:{ Exception -> 0x00a7 }
            r4 = r3.toString();	 Catch:{ Exception -> 0x00a7 }
            com.sherdle.universal.util.Log.m157d(r2, r4);	 Catch:{ Exception -> 0x00a7 }
            if (r1 == 0) goto L_0x00d1;
        L_0x00a3:
            r1.disconnect();
            goto L_0x00d1;
        L_0x00a7:
            r2 = move-exception;
            goto L_0x00b4;
        L_0x00a9:
            r2 = move-exception;
            r3 = r0;
            goto L_0x00b4;
        L_0x00ac:
            r1 = move-exception;
            r7 = r1;
            r1 = r0;
            r0 = r7;
            goto L_0x00da;
        L_0x00b1:
            r2 = move-exception;
            r1 = r0;
            r3 = r1;
        L_0x00b4:
            r4 = "INFO";	 Catch:{ all -> 0x00d9 }
            r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00d9 }
            r5.<init>();	 Catch:{ all -> 0x00d9 }
            r6 = "Exception: ";	 Catch:{ all -> 0x00d9 }
            r5.append(r6);	 Catch:{ all -> 0x00d9 }
            r2 = r2.toString();	 Catch:{ all -> 0x00d9 }
            r5.append(r2);	 Catch:{ all -> 0x00d9 }
            r2 = r5.toString();	 Catch:{ all -> 0x00d9 }
            com.sherdle.universal.util.Log.m158e(r4, r2);	 Catch:{ all -> 0x00d9 }
            if (r1 == 0) goto L_0x00d1;
        L_0x00d0:
            goto L_0x00a3;
        L_0x00d1:
            if (r3 != 0) goto L_0x00d4;
        L_0x00d3:
            return r0;
        L_0x00d4:
            r0 = r3.toString();
            return r0;
        L_0x00d9:
            r0 = move-exception;
        L_0x00da:
            if (r1 == 0) goto L_0x00df;
        L_0x00dc:
            r1.disconnect();
        L_0x00df:
            throw r0;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.twitter.ui.TweetsFragment.SearchTweetsTask.authenticateApp():java.lang.String");
        }

        protected java.util.ArrayList<com.sherdle.universal.providers.twitter.Tweet> doInBackground(java.lang.String... r10) {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:67:0x0241 in {5, 7, 8, 9, 16, 17, 23, 26, 27, 40, 43, 45, 47, 49, 51, 53, 54, 56, 58, 62, 63, 65, 66} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
            /*
            r9 = this;
            r0 = 0;
            r10 = r10[r0];
            r1 = java.lang.Boolean.valueOf(r0);
            r2 = "?";
            r2 = r10.startsWith(r2);
            if (r2 == 0) goto L_0x0028;
        L_0x000f:
            r1 = r9.URL_SEARCH;
            r9.URL_VALUE = r1;
            r1 = 1;
            r2 = r10.substring(r1);	 Catch:{ UnsupportedEncodingException -> 0x001f }
            r3 = "UTF-8";	 Catch:{ UnsupportedEncodingException -> 0x001f }
            r10 = java.net.URLEncoder.encode(r2, r3);	 Catch:{ UnsupportedEncodingException -> 0x001f }
            goto L_0x0023;
        L_0x001f:
            r2 = move-exception;
            com.sherdle.universal.util.Log.printStackTrace(r2);
        L_0x0023:
            r1 = java.lang.Boolean.valueOf(r1);
            goto L_0x002c;
        L_0x0028:
            r2 = r9.URL_TIMELINE;
            r9.URL_VALUE = r2;
        L_0x002c:
            r2 = 0;
            r3 = com.sherdle.universal.providers.twitter.ui.TweetsFragment.this;	 Catch:{ Exception -> 0x0215 }
            r3 = r3.latesttweetid;	 Catch:{ Exception -> 0x0215 }
            if (r3 == 0) goto L_0x0075;	 Catch:{ Exception -> 0x0215 }
        L_0x0033:
            r3 = com.sherdle.universal.providers.twitter.ui.TweetsFragment.this;	 Catch:{ Exception -> 0x0215 }
            r3 = r3.latesttweetid;	 Catch:{ Exception -> 0x0215 }
            r4 = "";	 Catch:{ Exception -> 0x0215 }
            r3 = r3.equals(r4);	 Catch:{ Exception -> 0x0215 }
            if (r3 != 0) goto L_0x0075;	 Catch:{ Exception -> 0x0215 }
        L_0x003f:
            r3 = com.sherdle.universal.providers.twitter.ui.TweetsFragment.this;	 Catch:{ Exception -> 0x0215 }
            r3 = r3.latesttweetid;	 Catch:{ Exception -> 0x0215 }
            r3 = java.lang.Long.parseLong(r3);	 Catch:{ Exception -> 0x0215 }
            r5 = 1;	 Catch:{ Exception -> 0x0215 }
            r3 = r3 - r5;	 Catch:{ Exception -> 0x0215 }
            r3 = java.lang.Long.valueOf(r3);	 Catch:{ Exception -> 0x0215 }
            r4 = new java.net.URL;	 Catch:{ Exception -> 0x0215 }
            r5 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0215 }
            r5.<init>();	 Catch:{ Exception -> 0x0215 }
            r6 = r9.URL_VALUE;	 Catch:{ Exception -> 0x0215 }
            r5.append(r6);	 Catch:{ Exception -> 0x0215 }
            r5.append(r10);	 Catch:{ Exception -> 0x0215 }
            r10 = "&max_id=";	 Catch:{ Exception -> 0x0215 }
            r5.append(r10);	 Catch:{ Exception -> 0x0215 }
            r6 = r3.longValue();	 Catch:{ Exception -> 0x0215 }
            r10 = java.lang.Long.toString(r6);	 Catch:{ Exception -> 0x0215 }
            r5.append(r10);	 Catch:{ Exception -> 0x0215 }
            r10 = r5.toString();	 Catch:{ Exception -> 0x0215 }
            r4.<init>(r10);	 Catch:{ Exception -> 0x0215 }
            goto L_0x008b;	 Catch:{ Exception -> 0x0215 }
        L_0x0075:
            r4 = new java.net.URL;	 Catch:{ Exception -> 0x0215 }
            r3 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0215 }
            r3.<init>();	 Catch:{ Exception -> 0x0215 }
            r5 = r9.URL_VALUE;	 Catch:{ Exception -> 0x0215 }
            r3.append(r5);	 Catch:{ Exception -> 0x0215 }
            r3.append(r10);	 Catch:{ Exception -> 0x0215 }
            r10 = r3.toString();	 Catch:{ Exception -> 0x0215 }
            r4.<init>(r10);	 Catch:{ Exception -> 0x0215 }
        L_0x008b:
            r10 = "INFO";	 Catch:{ Exception -> 0x0215 }
            r3 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0215 }
            r3.<init>();	 Catch:{ Exception -> 0x0215 }
            r5 = "Requesting: ";	 Catch:{ Exception -> 0x0215 }
            r3.append(r5);	 Catch:{ Exception -> 0x0215 }
            r5 = r4.toString();	 Catch:{ Exception -> 0x0215 }
            r3.append(r5);	 Catch:{ Exception -> 0x0215 }
            r3 = r3.toString();	 Catch:{ Exception -> 0x0215 }
            com.sherdle.universal.util.Log.m161v(r10, r3);	 Catch:{ Exception -> 0x0215 }
            r10 = r4.openConnection();	 Catch:{ Exception -> 0x0215 }
            r10 = (java.net.HttpURLConnection) r10;	 Catch:{ Exception -> 0x0215 }
            r3 = "GET";	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r10.setRequestMethod(r3);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3 = r9.authenticateApp();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r4 = new org.json.JSONObject;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r4.<init>(r3);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3.<init>();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r5 = "token_type";	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r5 = r4.getString(r5);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3.append(r5);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r5 = " ";	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3.append(r5);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r5 = "access_token";	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r4 = r4.getString(r5);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3.append(r4);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3 = r3.toString();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r4 = "Authorization";	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r10.setRequestProperty(r4, r3);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3 = "Content-Type";	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r4 = "application/json";	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r10.setRequestProperty(r3, r4);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r10.connect();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3 = new java.io.BufferedReader;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r4 = new java.io.InputStreamReader;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r5 = r10.getInputStream();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r4.<init>(r5);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3.<init>(r4);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r4 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r4.<init>();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
        L_0x00fb:
            r5 = r3.readLine();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            if (r5 == 0) goto L_0x0105;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
        L_0x0101:
            r4.append(r5);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            goto L_0x00fb;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
        L_0x0105:
            r3 = "GET response";	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r5 = r10.getResponseCode();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r5 = java.lang.String.valueOf(r5);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            com.sherdle.universal.util.Log.m157d(r3, r5);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3 = "JSON response";	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r5 = r4.toString();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            com.sherdle.universal.util.Log.m157d(r3, r5);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r1 = r1.booleanValue();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            if (r1 == 0) goto L_0x0131;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
        L_0x0121:
            r1 = new org.json.JSONObject;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3 = r4.toString();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r1.<init>(r3);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3 = "statuses";	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r1 = r1.getJSONArray(r3);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            goto L_0x013a;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
        L_0x0131:
            r1 = new org.json.JSONArray;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3 = r4.toString();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r1.<init>(r3);	 Catch:{ Exception -> 0x020d, all -> 0x020b }
        L_0x013a:
            r3 = new java.util.ArrayList;	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r3.<init>();	 Catch:{ Exception -> 0x020d, all -> 0x020b }
            r2 = 0;
        L_0x0140:
            r4 = r1.length();	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            if (r2 >= r4) goto L_0x0203;	 Catch:{ Exception -> 0x0209, all -> 0x020b }
        L_0x0146:
            r4 = r1.get(r2);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r4 = (org.json.JSONObject) r4;	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r5 = new com.sherdle.universal.providers.twitter.Tweet;	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r5.<init>();	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = "user";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r4.getJSONObject(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r7 = "name";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r6.getString(r7);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r5.setname(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = "user";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r4.getJSONObject(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r7 = "screen_name";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r6.getString(r7);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r5.setusername(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = "user";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r4.getJSONObject(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r7 = "profile_image_url";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r6.getString(r7);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r7 = "_normal";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r8 = "";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r6.replace(r7, r8);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r5.seturlProfileImage(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = "full_text";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r4.getString(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r5.setmessage(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = "retweet_count";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r4.getInt(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r5.setRetweetCount(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = "created_at";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r4.getString(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r5.setData(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = "id";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = r4.getString(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r5.setTweetId(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6 = "extended_entities";	 Catch:{ JSONException -> 0x01ee }
            r6 = r4.has(r6);	 Catch:{ JSONException -> 0x01ee }
            if (r6 == 0) goto L_0x01f2;	 Catch:{ JSONException -> 0x01ee }
        L_0x01b2:
            r6 = "extended_entities";	 Catch:{ JSONException -> 0x01ee }
            r6 = r4.getJSONObject(r6);	 Catch:{ JSONException -> 0x01ee }
            r7 = "media";	 Catch:{ JSONException -> 0x01ee }
            r6 = r6.getJSONArray(r7);	 Catch:{ JSONException -> 0x01ee }
            r6 = r6.get(r0);	 Catch:{ JSONException -> 0x01ee }
            r6 = (org.json.JSONObject) r6;	 Catch:{ JSONException -> 0x01ee }
            r7 = "media_url";	 Catch:{ JSONException -> 0x01ee }
            r6 = r6.getString(r7);	 Catch:{ JSONException -> 0x01ee }
            r7 = "extended_entities";	 Catch:{ JSONException -> 0x01ee }
            r7 = r4.getJSONObject(r7);	 Catch:{ JSONException -> 0x01ee }
            r8 = "media";	 Catch:{ JSONException -> 0x01ee }
            r7 = r7.getJSONArray(r8);	 Catch:{ JSONException -> 0x01ee }
            r7 = r7.get(r0);	 Catch:{ JSONException -> 0x01ee }
            r7 = (org.json.JSONObject) r7;	 Catch:{ JSONException -> 0x01ee }
            r8 = "type";	 Catch:{ JSONException -> 0x01ee }
            r7 = r7.getString(r8);	 Catch:{ JSONException -> 0x01ee }
            r8 = "photo";	 Catch:{ JSONException -> 0x01ee }
            r7 = r7.equalsIgnoreCase(r8);	 Catch:{ JSONException -> 0x01ee }
            if (r7 == 0) goto L_0x01f2;	 Catch:{ JSONException -> 0x01ee }
        L_0x01ea:
            r5.setImageUrl(r6);	 Catch:{ JSONException -> 0x01ee }
            goto L_0x01f2;
        L_0x01ee:
            r6 = move-exception;
            com.sherdle.universal.util.Log.printStackTrace(r6);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
        L_0x01f2:
            r6 = com.sherdle.universal.providers.twitter.ui.TweetsFragment.this;	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r7 = "id";	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r4 = r4.getString(r7);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r6.latesttweetid = r4;	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r3.add(r2, r5);	 Catch:{ Exception -> 0x0209, all -> 0x020b }
            r2 = r2 + 1;
            goto L_0x0140;
        L_0x0203:
            if (r10 == 0) goto L_0x023a;
        L_0x0205:
            r10.disconnect();
            goto L_0x023a;
        L_0x0209:
            r0 = move-exception;
            goto L_0x020f;
        L_0x020b:
            r0 = move-exception;
            goto L_0x023b;
        L_0x020d:
            r0 = move-exception;
            r3 = r2;
        L_0x020f:
            r2 = r10;
            goto L_0x0218;
        L_0x0211:
            r10 = move-exception;
            r0 = r10;
            r10 = r2;
            goto L_0x023b;
        L_0x0215:
            r10 = move-exception;
            r0 = r10;
            r3 = r2;
        L_0x0218:
            com.sherdle.universal.util.Log.printStackTrace(r0);	 Catch:{ all -> 0x0211 }
            r10 = "INFO";	 Catch:{ all -> 0x0211 }
            r1 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0211 }
            r1.<init>();	 Catch:{ all -> 0x0211 }
            r4 = "Exception: GET ";	 Catch:{ all -> 0x0211 }
            r1.append(r4);	 Catch:{ all -> 0x0211 }
            r0 = r0.toString();	 Catch:{ all -> 0x0211 }
            r1.append(r0);	 Catch:{ all -> 0x0211 }
            r0 = r1.toString();	 Catch:{ all -> 0x0211 }
            com.sherdle.universal.util.Log.m158e(r10, r0);	 Catch:{ all -> 0x0211 }
            if (r2 == 0) goto L_0x023a;
        L_0x0237:
            r2.disconnect();
        L_0x023a:
            return r3;
        L_0x023b:
            if (r10 == 0) goto L_0x0240;
        L_0x023d:
            r10.disconnect();
        L_0x0240:
            throw r0;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.twitter.ui.TweetsFragment.SearchTweetsTask.doInBackground(java.lang.String[]):java.util.ArrayList<com.sherdle.universal.providers.twitter.Tweet>");
        }

        private SearchTweetsTask() {
            this.URL_BASE = "https://api.twitter.com";
            TweetsFragment stringBuilder = new StringBuilder();
            stringBuilder.append("https://api.twitter.com/1.1/statuses/user_timeline.json?count=");
            stringBuilder.append(TweetsFragment.this.perpage);
            stringBuilder.append("&tweet_mode=extended&exclude_replies=true&include_rts=1&screen_name=");
            this.URL_TIMELINE = stringBuilder.toString();
            stringBuilder = new StringBuilder();
            stringBuilder.append("https://api.twitter.com/1.1/search/tweets.json?count=");
            stringBuilder.append(TweetsFragment.this.perpage);
            stringBuilder.append("&q=");
            this.URL_SEARCH = stringBuilder.toString();
            this.URL_PARAM = "&max_id=";
            this.URL_AUTH = "https://api.twitter.com/oauth2/token";
            this.CONSUMER_KEY = TweetsFragment.this.getResources().getString(R.string.twitter_api_consumer_key);
            this.CONSUMER_SECRET = TweetsFragment.this.getResources().getString(R.string.twitter_api_consumer_secret_key);
        }

        protected void onPreExecute() {
            super.onPreExecute();
            TweetsFragment.this.isLoading = Boolean.valueOf(true);
        }

        protected void onPostExecute(ArrayList<Tweet> arrayList) {
            TweetsFragment.this.isLoading = Boolean.valueOf(false);
            if (arrayList != null) {
                TweetsFragment.this.updateList(arrayList);
                return;
            }
            Helper.noConnection(TweetsFragment.this.mAct);
            TweetsFragment.this.tweetAdapter.setModeAndNotify(2);
        }
    }

    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list, viewGroup, false);
        setHasOptionsMenu(true);
        this.searchValue = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        this.listView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.tweets = new ArrayList();
        this.tweetAdapter = new TweetAdapter(getContext(), this.tweets, this);
        this.tweetAdapter.setModeAndNotify(3);
        this.listView.setAdapter(this.tweetAdapter);
        this.listView.setLayoutManager(new LinearLayoutManager(getContext(), 1, false));
        return this.ll;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        refreshItems();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.refresh) {
            if (this.isLoading.booleanValue()) {
                Toast.makeText(this.mAct, getString(R.string.already_loading), 1).show();
            } else {
                refreshItems();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void refreshItems() {
        this.isLoading = Boolean.valueOf(true);
        this.latesttweetid = null;
        this.tweets.clear();
        this.tweetAdapter.setHasMore(true);
        this.tweetAdapter.setModeAndNotify(3);
        new SearchTweetsTask().execute(new String[]{this.searchValue});
    }

    public void updateList(ArrayList<Tweet> arrayList) {
        if (arrayList.size() > 0) {
            this.tweets.addAll(arrayList);
        }
        if (arrayList.size() == null) {
            this.tweetAdapter.setHasMore(false);
        }
        this.tweetAdapter.setModeAndNotify(1);
    }

    public void onMoreRequested() {
        if (!this.isLoading.booleanValue()) {
            new SearchTweetsTask().execute(new String[]{this.searchValue});
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.refresh_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }
}
