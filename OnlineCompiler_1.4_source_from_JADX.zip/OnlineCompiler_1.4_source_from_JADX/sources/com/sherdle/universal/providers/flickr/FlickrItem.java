package com.sherdle.universal.providers.flickr;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.sherdle.universal.providers.tumblr.TumblrItem;

public class FlickrItem extends TumblrItem implements Parcelable {
    public static final Creator<FlickrItem> CREATOR = new C05901();
    private String thumbUrl;

    /* renamed from: com.sherdle.universal.providers.flickr.FlickrItem$1 */
    static class C05901 implements Creator<FlickrItem> {
        C05901() {
        }

        public FlickrItem createFromParcel(Parcel parcel) {
            return new FlickrItem(parcel);
        }

        public FlickrItem[] newArray(int i) {
            return new FlickrItem[i];
        }
    }

    public FlickrItem(String str, String str2, String str3, String str4) {
        this.id = str;
        this.link = str2;
        this.url = str3;
        this.thumbUrl = str4;
    }

    public String getThumbUrl() {
        return this.thumbUrl;
    }

    public FlickrItem(Parcel parcel) {
        this.id = parcel.readString();
        this.link = parcel.readString();
        this.url = parcel.readString();
        this.thumbUrl = parcel.readString();
    }

    public int describeContents() {
        return hashCode();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.id);
        parcel.writeString(this.link);
        parcel.writeString(this.url);
        parcel.writeString(this.thumbUrl);
    }
}
