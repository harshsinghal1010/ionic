package com.sherdle.universal.providers.flickr.ui;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.codeintelligent.onlinecompiler.R;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.inherit.PermissionsFragment;
import com.sherdle.universal.providers.flickr.FlickrItem;
import com.sherdle.universal.providers.flickr.ImageAdapter;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.InfiniteRecyclerViewAdapter.LoadMoreListener;
import com.sherdle.universal.util.Log;
import com.sherdle.universal.util.ThemeUtils;
import com.sherdle.universal.util.layout.StaggeredGridSpacingItemDecoration;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

public class FlickrFragment extends Fragment implements PermissionsFragment, LoadMoreListener {
    String baseurl;
    Integer curpage = Integer.valueOf(0);
    private ImageAdapter imageAdapter = null;
    Boolean isLoading = Boolean.valueOf(true);
    private RecyclerView listView;
    private RelativeLayout ll;
    private Activity mAct;
    String method;
    Integer total_pages;
    ArrayList<FlickrItem> tumblrItems;

    private class InitialLoadGridView extends AsyncTask<String, Void, ArrayList<FlickrItem>> {
        private InitialLoadGridView() {
        }

        protected ArrayList<FlickrItem> doInBackground(String... strArr) {
            int i = 0;
            strArr = strArr[0];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(strArr);
            stringBuilder.append(Integer.toString(FlickrFragment.this.curpage.intValue()));
            strArr = stringBuilder.toString();
            FlickrFragment flickrFragment = FlickrFragment.this;
            flickrFragment.curpage = Integer.valueOf(flickrFragment.curpage.intValue() + 1);
            strArr = Helper.getDataFromUrl(strArr);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Tumblr JSON: ");
            stringBuilder2.append(strArr);
            Log.m161v("INFO", stringBuilder2.toString());
            if (strArr.isEmpty()) {
                return null;
            }
            JSONObject jSONObject;
            ArrayList<FlickrItem> arrayList;
            try {
                strArr = strArr.replace("jsonFlickrApi(", "");
                jSONObject = new JSONObject(strArr.substring(0, strArr.length() - 1));
            } catch (String[] strArr2) {
                Log.printStackTrace(strArr2);
                jSONObject = null;
            }
            try {
                strArr2 = FlickrFragment.this.method.equals("gallery") == null ? "photoset" : "photos";
                FlickrFragment.this.total_pages = Integer.valueOf(jSONObject.getJSONObject(strArr2).getInt("pages"));
                strArr2 = jSONObject.getJSONObject(strArr2).getJSONArray("photo");
                arrayList = new ArrayList();
                while (i < strArr2.length()) {
                    try {
                        JSONObject jSONObject2 = strArr2.getJSONObject(i);
                        String string = jSONObject2.getString(TtmlNode.ATTR_ID);
                        jSONObject2.getString("title");
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("https://www.flickr.com/photos/");
                        stringBuilder3.append(jSONObject2.getString("pathalias"));
                        stringBuilder3.append("/");
                        stringBuilder3.append(string);
                        String stringBuilder4 = stringBuilder3.toString();
                        String string2 = jSONObject2.has("url_o") ? jSONObject2.getString("url_o") : jSONObject2.has("url_b") ? jSONObject2.getString("url_b") : jSONObject2.has("url_c") ? jSONObject2.getString("url_c") : null;
                        String string3 = jSONObject2.has("url_z") ? jSONObject2.getString("url_z") : string2;
                        if (string2 != null) {
                            arrayList.add(new FlickrItem(string, stringBuilder4, string2, string3));
                        }
                        i++;
                    } catch (JSONException e) {
                        strArr2 = e;
                    } catch (NullPointerException e2) {
                        strArr2 = e2;
                    }
                }
            } catch (JSONException e3) {
                strArr2 = e3;
                arrayList = null;
                Log.printStackTrace(strArr2);
                return arrayList;
            } catch (NullPointerException e4) {
                strArr2 = e4;
                arrayList = null;
                Log.printStackTrace(strArr2);
                return arrayList;
            }
            return arrayList;
        }

        protected void onPostExecute(ArrayList<FlickrItem> arrayList) {
            if (arrayList != null) {
                FlickrFragment.this.updateList(arrayList);
            } else {
                Helper.noConnection(FlickrFragment.this.mAct);
                FlickrFragment.this.imageAdapter.setModeAndNotify(2);
            }
            FlickrFragment.this.isLoading = Boolean.valueOf(false);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list, viewGroup, false);
        return this.ll;
    }

    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        setHasOptionsMenu(true);
        bundle = getString(R.string.flickr_key);
        String str = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        this.method = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[1];
        String str2 = !this.method.equals("gallery") ? "photosets" : "galleries";
        String str3 = !this.method.equals("gallery") ? "photoset_id" : "gallery_id";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("https://api.flickr.com/services/rest/?method=flickr.");
        stringBuilder.append(str2);
        stringBuilder.append(".getPhotos&api_key=");
        stringBuilder.append(bundle);
        stringBuilder.append("&");
        stringBuilder.append(str3);
        stringBuilder.append("=");
        stringBuilder.append(str);
        stringBuilder.append("&format=json&extras=path_alias,url_o,url_c,url_b,url_z&page=");
        this.baseurl = stringBuilder.toString();
        this.listView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.tumblrItems = new ArrayList();
        this.imageAdapter = new ImageAdapter(getContext(), this.tumblrItems, this);
        this.imageAdapter.setModeAndNotify(3);
        this.listView.setAdapter(this.imageAdapter);
        this.listView.setLayoutManager(new StaggeredGridLayoutManager(3, 1));
        this.listView.setItemAnimator(new DefaultItemAnimator());
        this.listView.addItemDecoration(new StaggeredGridSpacingItemDecoration((int) getResources().getDimension(R.dimen.woocommerce_padding), true));
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        refreshItems();
    }

    public void updateList(ArrayList<FlickrItem> arrayList) {
        if (arrayList.size() > 0) {
            this.tumblrItems.addAll(arrayList);
        }
        if (this.curpage.intValue() >= this.total_pages.intValue() || arrayList.size() == null) {
            this.imageAdapter.setHasMore(false);
        }
        this.imageAdapter.setModeAndNotify(1);
    }

    public String[] requiredPermissions() {
        return new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    }

    public void onMoreRequested() {
        if (!this.isLoading.booleanValue() && this.curpage.intValue() < this.total_pages.intValue()) {
            this.isLoading = Boolean.valueOf(true);
            new InitialLoadGridView().execute(new String[]{this.baseurl});
        }
    }

    void refreshItems() {
        this.isLoading = Boolean.valueOf(true);
        this.curpage = Integer.valueOf(1);
        this.tumblrItems.clear();
        this.imageAdapter.setHasMore(true);
        this.imageAdapter.setModeAndNotify(3);
        new InitialLoadGridView().execute(new String[]{this.baseurl});
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.refresh_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.refresh) {
            if (this.isLoading.booleanValue()) {
                Toast.makeText(this.mAct, getString(R.string.already_loading), 1).show();
            } else {
                refreshItems();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
