package com.sherdle.universal.providers.maps;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.codeintelligent.onlinecompiler.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.maps.android.data.Geometry;
import com.google.maps.android.data.geojson.GeoJsonFeature;
import com.google.maps.android.data.geojson.GeoJsonGeometryCollection;
import com.google.maps.android.data.geojson.GeoJsonLayer;
import com.google.maps.android.data.geojson.GeoJsonPoint;
import com.google.maps.android.data.geojson.GeoJsonPointStyle;
import com.sherdle.universal.HolderActivity;
import com.sherdle.universal.MainActivity;
import com.sherdle.universal.billing.Constants;
import com.sherdle.universal.inherit.CollapseControllingFragment;
import com.sherdle.universal.inherit.PermissionsFragment;
import com.sherdle.universal.util.Helper;
import com.sherdle.universal.util.Log;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

public class MapsFragment extends Fragment implements PermissionsFragment, CollapseControllingFragment {
    private String[] data;
    private GoogleMap googleMap;
    private LinearLayout ll;
    private Activity mAct;
    private MapView mMapView;

    private class LoadGeoData extends AsyncTask<String, String, GeoJsonLayer> {
        private Context context;
        private ProgressDialog dialog;

        public LoadGeoData(Context context) {
            this.context = context;
        }

        protected void onPostExecute(final GeoJsonLayer geoJsonLayer) {
            super.onPostExecute(geoJsonLayer);
            if (this.dialog.isShowing()) {
                this.dialog.dismiss();
            }
            if (geoJsonLayer == null) {
                Helper.noConnection(MapsFragment.this.mAct);
            } else {
                MapsFragment.this.googleMap.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {
                    public void onInfoWindowClick(Marker marker) {
                        for (GeoJsonFeature geoJsonFeature : geoJsonLayer.getFeatures()) {
                            if (geoJsonFeature.getGeometry().getGeometryType().equals("Point") && ((GeoJsonPoint) geoJsonFeature.getGeometry()).getCoordinates().equals(marker.getPosition()) && geoJsonFeature.hasProperty("url")) {
                                HolderActivity.startWebViewActivity(MapsFragment.this.mAct, geoJsonFeature.getProperty("url"), true, false, null);
                            }
                        }
                    }
                });
            }
        }

        protected GeoJsonLayer doInBackground(String... strArr) {
            if (strArr[0].startsWith("http")) {
                strArr = Helper.getJSONObjectFromUrl(strArr[0]);
            } else {
                try {
                    strArr = new JSONObject(Helper.loadJSONFromAsset(MapsFragment.this.mAct, strArr[0]));
                } catch (String[] strArr2) {
                    Log.m158e("INFO", "Error parsing JSON. Printing stacktrace now");
                    Log.printStackTrace(strArr2);
                    strArr2 = null;
                }
            }
            if (strArr2 == null) {
                return null;
            }
            final GeoJsonLayer geoJsonLayer = new GeoJsonLayer(MapsFragment.this.googleMap, strArr2);
            MapsFragment.this.mAct.runOnUiThread(new Runnable() {
                public void run() {
                    geoJsonLayer.addLayerToMap();
                    for (GeoJsonFeature geoJsonFeature : geoJsonLayer.getFeatures()) {
                        if (geoJsonFeature.getPointStyle() != null) {
                            GeoJsonPointStyle geoJsonPointStyle = new GeoJsonPointStyle();
                            geoJsonPointStyle.setTitle(geoJsonFeature.getProperty("name"));
                            if (geoJsonFeature.hasProperty("snippet")) {
                                geoJsonPointStyle.setSnippet(geoJsonFeature.getProperty("snippet"));
                            } else if (geoJsonFeature.hasProperty(Constants.RESPONSE_DESCRIPTION)) {
                                geoJsonPointStyle.setSnippet(geoJsonFeature.getProperty(Constants.RESPONSE_DESCRIPTION));
                            } else if (geoJsonFeature.hasProperty("popupContent")) {
                                geoJsonPointStyle.setSnippet(geoJsonFeature.getProperty("popupContent"));
                            }
                            geoJsonFeature.setPointStyle(geoJsonPointStyle);
                        }
                    }
                }
            });
            MapsFragment.this.focusMapOnLayer(geoJsonLayer);
            return geoJsonLayer;
        }

        protected void onPreExecute() {
            super.onPreExecute();
            if (MapsFragment.this.data[0].startsWith("http")) {
                this.dialog = new ProgressDialog(this.context);
                this.dialog.setCancelable(true);
                this.dialog.setMessage(MapsFragment.this.getResources().getString(R.string.loading));
                this.dialog.isIndeterminate();
                this.dialog.show();
            }
        }
    }

    /* renamed from: com.sherdle.universal.providers.maps.MapsFragment$1 */
    class C09801 implements OnMapReadyCallback {
        C09801() {
        }

        public void onMapReady(GoogleMap googleMap) {
            MapsFragment.this.googleMap = googleMap;
            if (ContextCompat.checkSelfPermission(MapsFragment.this.mAct, "android.permission.ACCESS_FINE_LOCATION") == null) {
                MapsFragment.this.googleMap.setMyLocationEnabled(true);
            }
            MapsFragment mapsFragment = MapsFragment.this;
            new LoadGeoData(mapsFragment.mAct).execute(MapsFragment.this.data);
        }
    }

    public boolean dynamicToolbarElevation() {
        return false;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
    }

    public boolean supportsCollapse() {
        return false;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreateView(layoutInflater, viewGroup, bundle);
        this.ll = (LinearLayout) layoutInflater.inflate(R.layout.fragment_maps, viewGroup, false);
        setHasOptionsMenu(true);
        this.mMapView = (MapView) this.ll.findViewById(R.id.map);
        this.mMapView.onCreate(bundle);
        this.mMapView.onResume();
        return this.ll;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        Helper.isOnlineShowDialog(this.mAct);
        this.data = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        MapsInitializer.initialize(this.mAct);
        this.mMapView.getMapAsync(new C09801());
    }

    public void onResume() {
        super.onResume();
        this.mMapView.onResume();
    }

    public void onPause() {
        super.onPause();
        this.mMapView.onPause();
    }

    public void onDestroy() {
        super.onDestroy();
        this.mMapView.onDestroy();
    }

    public void onLowMemory() {
        super.onLowMemory();
        this.mMapView.onLowMemory();
    }

    private void focusMapOnLayer(GeoJsonLayer geoJsonLayer) {
        List<LatLng> arrayList = new ArrayList();
        for (GeoJsonFeature geoJsonFeature : geoJsonLayer.getFeatures()) {
            if (geoJsonFeature.hasGeometry()) {
                Geometry geometry = geoJsonFeature.getGeometry();
                if (geometry.getGeometryType().equals("GeometryCollection")) {
                    for (Geometry coordinatesFromGeometry : ((GeoJsonGeometryCollection) geometry).getGeometries()) {
                        arrayList.addAll(getCoordinatesFromGeometry(coordinatesFromGeometry));
                    }
                } else {
                    arrayList.addAll(getCoordinatesFromGeometry(geometry));
                }
            }
        }
        geoJsonLayer = LatLngBounds.builder();
        for (LatLng include : arrayList) {
            geoJsonLayer.include(include);
        }
        geoJsonLayer = geoJsonLayer.build();
        this.mAct.runOnUiThread(new Runnable() {
            public void run() {
                MapsFragment.this.googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(geoJsonLayer, 100), 500, null);
            }
        });
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.util.List<com.google.android.gms.maps.model.LatLng> getCoordinatesFromGeometry(com.google.maps.android.data.Geometry r4) {
        /*
        r3 = this;
        r0 = new java.util.ArrayList;
        r0.<init>();
        r1 = r4.getGeometryType();
        r2 = r1.hashCode();
        switch(r2) {
            case -2116761119: goto L_0x0043;
            case -1065891849: goto L_0x0039;
            case -627102946: goto L_0x002f;
            case 77292912: goto L_0x0025;
            case 1267133722: goto L_0x001b;
            case 1806700869: goto L_0x0011;
            default: goto L_0x0010;
        };
    L_0x0010:
        goto L_0x004d;
    L_0x0011:
        r2 = "LineString";
        r1 = r1.equals(r2);
        if (r1 == 0) goto L_0x004d;
    L_0x0019:
        r1 = 2;
        goto L_0x004e;
    L_0x001b:
        r2 = "Polygon";
        r1 = r1.equals(r2);
        if (r1 == 0) goto L_0x004d;
    L_0x0023:
        r1 = 4;
        goto L_0x004e;
    L_0x0025:
        r2 = "Point";
        r1 = r1.equals(r2);
        if (r1 == 0) goto L_0x004d;
    L_0x002d:
        r1 = 0;
        goto L_0x004e;
    L_0x002f:
        r2 = "MultiLineString";
        r1 = r1.equals(r2);
        if (r1 == 0) goto L_0x004d;
    L_0x0037:
        r1 = 3;
        goto L_0x004e;
    L_0x0039:
        r2 = "MultiPoint";
        r1 = r1.equals(r2);
        if (r1 == 0) goto L_0x004d;
    L_0x0041:
        r1 = 1;
        goto L_0x004e;
    L_0x0043:
        r2 = "MultiPolygon";
        r1 = r1.equals(r2);
        if (r1 == 0) goto L_0x004d;
    L_0x004b:
        r1 = 5;
        goto L_0x004e;
    L_0x004d:
        r1 = -1;
    L_0x004e:
        switch(r1) {
            case 0: goto L_0x00e1;
            case 1: goto L_0x00c3;
            case 2: goto L_0x00b9;
            case 3: goto L_0x009b;
            case 4: goto L_0x0081;
            case 5: goto L_0x0053;
            default: goto L_0x0051;
        };
    L_0x0051:
        goto L_0x00ea;
    L_0x0053:
        r4 = (com.google.maps.android.data.geojson.GeoJsonMultiPolygon) r4;
        r4 = r4.getPolygons();
        r4 = r4.iterator();
    L_0x005d:
        r1 = r4.hasNext();
        if (r1 == 0) goto L_0x00ea;
    L_0x0063:
        r1 = r4.next();
        r1 = (com.google.maps.android.data.geojson.GeoJsonPolygon) r1;
        r1 = r1.getCoordinates();
        r1 = r1.iterator();
    L_0x0071:
        r2 = r1.hasNext();
        if (r2 == 0) goto L_0x005d;
    L_0x0077:
        r2 = r1.next();
        r2 = (java.util.List) r2;
        r0.addAll(r2);
        goto L_0x0071;
    L_0x0081:
        r4 = (com.google.maps.android.data.geojson.GeoJsonPolygon) r4;
        r4 = r4.getCoordinates();
        r4 = r4.iterator();
    L_0x008b:
        r1 = r4.hasNext();
        if (r1 == 0) goto L_0x00ea;
    L_0x0091:
        r1 = r4.next();
        r1 = (java.util.List) r1;
        r0.addAll(r1);
        goto L_0x008b;
    L_0x009b:
        r4 = (com.google.maps.android.data.geojson.GeoJsonMultiLineString) r4;
        r4 = r4.getLineStrings();
        r4 = r4.iterator();
    L_0x00a5:
        r1 = r4.hasNext();
        if (r1 == 0) goto L_0x00ea;
    L_0x00ab:
        r1 = r4.next();
        r1 = (com.google.maps.android.data.geojson.GeoJsonLineString) r1;
        r1 = r1.getCoordinates();
        r0.addAll(r1);
        goto L_0x00a5;
    L_0x00b9:
        r4 = (com.google.maps.android.data.geojson.GeoJsonLineString) r4;
        r4 = r4.getCoordinates();
        r0.addAll(r4);
        goto L_0x00ea;
    L_0x00c3:
        r4 = (com.google.maps.android.data.geojson.GeoJsonMultiPoint) r4;
        r4 = r4.getPoints();
        r4 = r4.iterator();
    L_0x00cd:
        r1 = r4.hasNext();
        if (r1 == 0) goto L_0x00ea;
    L_0x00d3:
        r1 = r4.next();
        r1 = (com.google.maps.android.data.geojson.GeoJsonPoint) r1;
        r1 = r1.getCoordinates();
        r0.add(r1);
        goto L_0x00cd;
    L_0x00e1:
        r4 = (com.google.maps.android.data.geojson.GeoJsonPoint) r4;
        r4 = r4.getCoordinates();
        r0.add(r4);
    L_0x00ea:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.maps.MapsFragment.getCoordinatesFromGeometry(com.google.maps.android.data.Geometry):java.util.List<com.google.android.gms.maps.model.LatLng>");
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    public String[] requiredPermissions() {
        return new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.WRITE_EXTERNAL_STORAGE"};
    }
}
