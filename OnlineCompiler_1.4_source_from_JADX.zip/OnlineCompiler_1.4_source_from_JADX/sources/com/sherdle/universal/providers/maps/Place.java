package com.sherdle.universal.providers.maps;

import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONObject;

public class Place {
    private String icon;
    private String id;
    private Double latitude;
    private Double longitude;
    private String name;
    private String vicinity;

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getIcon() {
        return this.icon;
    }

    public void setIcon(String str) {
        this.icon = str;
    }

    public Double getLatitude() {
        return this.latitude;
    }

    public void setLatitude(Double d) {
        this.latitude = d;
    }

    public Double getLongitude() {
        return this.longitude;
    }

    public void setLongitude(Double d) {
        this.longitude = d;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getVicinity() {
        return this.vicinity;
    }

    public void setVicinity(String str) {
        this.vicinity = str;
    }

    static Place jsonToPontoReferencia(JSONObject jSONObject) {
        try {
            Place place = new Place();
            JSONObject jSONObject2 = (JSONObject) ((JSONObject) jSONObject.get("geometry")).get(Param.LOCATION);
            place.setLatitude((Double) jSONObject2.get("lat"));
            place.setLongitude((Double) jSONObject2.get("lng"));
            place.setIcon(jSONObject.getString("icon"));
            place.setName(jSONObject.getString("name"));
            place.setVicinity(jSONObject.getString("vicinity"));
            place.setId(jSONObject.getString(TtmlNode.ATTR_ID));
            return place;
        } catch (JSONObject jSONObject3) {
            Logger.getLogger(Place.class.getName()).log(Level.SEVERE, null, jSONObject3);
            return null;
        }
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Place{id=");
        stringBuilder.append(this.id);
        stringBuilder.append(", icon=");
        stringBuilder.append(this.icon);
        stringBuilder.append(", name=");
        stringBuilder.append(this.name);
        stringBuilder.append(", latitude=");
        stringBuilder.append(this.latitude);
        stringBuilder.append(", longitude=");
        stringBuilder.append(this.longitude);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
