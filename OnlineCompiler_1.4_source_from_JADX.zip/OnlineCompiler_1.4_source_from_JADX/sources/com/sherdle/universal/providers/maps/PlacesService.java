package com.sherdle.universal.providers.maps;

import com.google.android.exoplayer2.C0361C;
import com.sherdle.universal.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;

public class PlacesService {
    private String API_KEY;

    public PlacesService(String str) {
        this.API_KEY = str;
    }

    public void setApiKey(String str) {
        this.API_KEY = str;
    }

    public java.util.ArrayList<com.sherdle.universal.providers.maps.Place> findPlaces(double r3, double r5, java.lang.String r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1449263511.run(Unknown Source)
*/
        /*
        r2 = this;
        r3 = r2.makeUrl(r3, r5, r7);
        r3 = r2.getJSON(r3);	 Catch:{ JSONException -> 0x0046 }
        r4 = new org.json.JSONObject;	 Catch:{ JSONException -> 0x0046 }
        r4.<init>(r3);	 Catch:{ JSONException -> 0x0046 }
        r3 = "results";	 Catch:{ JSONException -> 0x0046 }
        r3 = r4.getJSONArray(r3);	 Catch:{ JSONException -> 0x0046 }
        r4 = new java.util.ArrayList;	 Catch:{ JSONException -> 0x0046 }
        r4.<init>();	 Catch:{ JSONException -> 0x0046 }
        r5 = 0;	 Catch:{ JSONException -> 0x0046 }
    L_0x0019:
        r6 = r3.length();	 Catch:{ JSONException -> 0x0046 }
        if (r5 >= r6) goto L_0x0045;
    L_0x001f:
        r6 = r3.get(r5);	 Catch:{ Exception -> 0x0042 }
        r6 = (org.json.JSONObject) r6;	 Catch:{ Exception -> 0x0042 }
        r6 = com.sherdle.universal.providers.maps.Place.jsonToPontoReferencia(r6);	 Catch:{ Exception -> 0x0042 }
        r7 = "Places Services ";	 Catch:{ Exception -> 0x0042 }
        r0 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0042 }
        r0.<init>();	 Catch:{ Exception -> 0x0042 }
        r1 = "";	 Catch:{ Exception -> 0x0042 }
        r0.append(r1);	 Catch:{ Exception -> 0x0042 }
        r0.append(r6);	 Catch:{ Exception -> 0x0042 }
        r0 = r0.toString();	 Catch:{ Exception -> 0x0042 }
        com.sherdle.universal.util.Log.m161v(r7, r0);	 Catch:{ Exception -> 0x0042 }
        r4.add(r6);	 Catch:{ Exception -> 0x0042 }
    L_0x0042:
        r5 = r5 + 1;
        goto L_0x0019;
    L_0x0045:
        return r4;
    L_0x0046:
        r3 = move-exception;
        r4 = com.sherdle.universal.providers.maps.PlacesService.class;
        r4 = r4.getName();
        r4 = java.util.logging.Logger.getLogger(r4);
        r5 = java.util.logging.Level.SEVERE;
        r6 = 0;
        r4.log(r5, r6, r3);
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sherdle.universal.providers.maps.PlacesService.findPlaces(double, double, java.lang.String):java.util.ArrayList<com.sherdle.universal.providers.maps.Place>");
    }

    private String makeUrl(double d, double d2, String str) {
        StringBuilder stringBuilder = new StringBuilder("https://maps.googleapis.com/maps/api/place/search/json?");
        try {
            str = URLEncoder.encode(str, C0361C.UTF8_NAME);
        } catch (String str2) {
            Log.printStackTrace(str2);
            str2 = "";
        }
        if (str2.equals("")) {
            stringBuilder.append("&location=");
            stringBuilder.append(Double.toString(d));
            stringBuilder.append(",");
            stringBuilder.append(Double.toString(d2));
            stringBuilder.append("&radius=1000");
            d = new StringBuilder();
            d.append("&sensor=false&key=");
            d.append(this.API_KEY);
            stringBuilder.append(d.toString());
        } else {
            stringBuilder.append("&location=");
            stringBuilder.append(Double.toString(d));
            stringBuilder.append(",");
            stringBuilder.append(Double.toString(d2));
            stringBuilder.append("&radius=1000");
            d = new StringBuilder();
            d.append("&keyword=");
            d.append(str2);
            stringBuilder.append(d.toString());
            d = new StringBuilder();
            d.append("&sensor=false&key=");
            d.append(this.API_KEY);
            stringBuilder.append(d.toString());
        }
        return stringBuilder.toString();
    }

    protected String getJSON(String str) {
        return getUrlContents(str);
    }

    private String getUrlContents(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new URL(str).openConnection().getInputStream()), 8);
            while (true) {
                str = bufferedReader.readLine();
                if (str == null) {
                    break;
                }
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append("\n");
                stringBuilder.append(stringBuilder2.toString());
            }
            bufferedReader.close();
        } catch (String str2) {
            Log.printStackTrace(str2);
        }
        return stringBuilder.toString();
    }
}
